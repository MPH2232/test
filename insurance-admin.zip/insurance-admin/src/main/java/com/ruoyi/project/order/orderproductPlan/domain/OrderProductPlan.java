package com.ruoyi.project.order.orderproductPlan.domain;

import com.ruoyi.framework.web.domain.BaseEntity;
import java.util.Date;

/**
 * 订单关联计划--详细产品--关联分期id--关联保全表 f_orderproduct_plan
 * 
 * @author ruoyi
 * @date 2018-08-31
 */
public class OrderProductPlan extends BaseEntity
{



	/** id */
	private Integer id;
	/** 订单关联id，子订单关联id */
	private String orderProductId;
	/** 产品关联id */
	private Integer productId;
	/** 计划的总保费 */
	private String planCharge;
	/** 这条分期显示日期月份 */
	private String planMonth;
	/** 创建者 */
	private String createBy;
	/** 创建时间 */
	private Date createTime;
	/** 更新者 */
	private String updateBy;
	/** 更新时间 */
	private Date updateTime;
	/** 产品类型0基本产品，1会员费产品 */
	private Integer productType;
	/** 计划表关联分期表id */
	private String planFenqiId;
	/** 方案层级定义（高管） */
	private String planCengji;

	/** 计划名称 */
	private String planName;
	/** 产品名称 */
	private String productName;
	/** 备注 */
	private String beizhu;


	/** 产品保额类型（0固定保额，1不确定倍数） */
	private String productBaoeType;
	/** 产品保费类型（0固定保费，1不确定保费（0.4%）） */
	private String productBaofeiType;
	/** 是否高端产品（0不使用费率，1使用费率） */
	private String productFeilv;
	/** 计划的人数 */
	private String planRenshu;
	/** 计划类型，0新保，1续保，2新保保全，3续保保全 */
	private Integer planType;
	/** 保全表关联id，和保全表自增id绑定 */
	private Integer baoquanId;
	/** 关联人员表id,联合查询 */
	private String planPeopleId;
	/** 分期数 */
	private String payMode;
	/** 产品保额 */
	private String productBaoe;
	/** 产品保费 */
	private String productBaofei;


	/** 提交产品list */
	private String chanpingList;

	private static final long serialVersionUID = 1L;


	public String getChanpingList() {
		return chanpingList;
	}

	public void setChanpingList(String chanpingList) {
		this.chanpingList = chanpingList;
	}

	/**
	 * 设置：id
	 */
	public void setId(Integer id) 
	{
		this.id = id;
	}
	
	/**
	 * 获取：id
	 */
	public Integer getId() 
	{
		return id;
	}
	
	/**
	 * 设置：订单关联id，子订单关联id
	 */
	public void setOrderProductId(String orderProductId) 
	{
		this.orderProductId = orderProductId;
	}
	
	/**
	 * 获取：订单关联id，子订单关联id
	 */
	public String getOrderProductId() 
	{
		return orderProductId;
	}
	
	/**
	 * 设置：产品关联id
	 */
	public void setProductId(Integer productId) 
	{
		this.productId = productId;
	}
	
	/**
	 * 获取：产品关联id
	 */
	public Integer getProductId() 
	{
		return productId;
	}
	
	/**
	 * 设置：产品名称
	 */
	public void setProductName(String productName) 
	{
		this.productName = productName;
	}
	
	/**
	 * 获取：产品名称
	 */
	public String getProductName() 
	{
		return productName;
	}
	
	/**
	 * 设置：计划的总保费
	 */
	public void setPlanCharge(String planCharge) 
	{
		this.planCharge = planCharge;
	}
	
	/**
	 * 获取：计划的总保费
	 */
	public String getPlanCharge() 
	{
		return planCharge;
	}
	
	/**
	 * 设置：这条分期显示日期月份
	 */
	public void setPlanMonth(String planMonth) 
	{
		this.planMonth = planMonth;
	}
	
	/**
	 * 获取：这条分期显示日期月份
	 */
	public String getPlanMonth() 
	{
		return planMonth;
	}
	
	/**
	 * 设置：创建者
	 */
	public void setCreateBy(String createBy) 
	{
		this.createBy = createBy;
	}
	
	/**
	 * 获取：创建者
	 */
	public String getCreateBy() 
	{
		return createBy;
	}
	
	/**
	 * 设置：创建时间
	 */
	public void setCreateTime(Date createTime) 
	{
		this.createTime = createTime;
	}
	
	/**
	 * 获取：创建时间
	 */
	public Date getCreateTime() 
	{
		return createTime;
	}
	
	/**
	 * 设置：更新者
	 */
	public void setUpdateBy(String updateBy) 
	{
		this.updateBy = updateBy;
	}
	
	/**
	 * 获取：更新者
	 */
	public String getUpdateBy() 
	{
		return updateBy;
	}
	
	/**
	 * 设置：更新时间
	 */
	public void setUpdateTime(Date updateTime) 
	{
		this.updateTime = updateTime;
	}
	
	/**
	 * 获取：更新时间
	 */
	public Date getUpdateTime() 
	{
		return updateTime;
	}
	
	/**
	 * 设置：产品类型0基本产品，1会员费产品
	 */
	public void setProductType(Integer productType) 
	{
		this.productType = productType;
	}
	
	/**
	 * 获取：产品类型0基本产品，1会员费产品
	 */
	public Integer getProductType() 
	{
		return productType;
	}
	
	/**
	 * 设置：计划表关联分期表id
	 */
	public void setPlanFenqiId(String planFenqiId) 
	{
		this.planFenqiId = planFenqiId;
	}
	
	/**
	 * 获取：计划表关联分期表id
	 */
	public String getPlanFenqiId() 
	{
		return planFenqiId;
	}
	
	/**
	 * 设置：计划名称
	 */
	public void setPlanName(String planName) 
	{
		this.planName = planName;
	}
	
	/**
	 * 获取：计划名称
	 */
	public String getPlanName() 
	{
		return planName;
	}
	
	/**
	 * 设置：产品保额
	 */
	public void setProductBaoe(String productBaoe) 
	{
		this.productBaoe = productBaoe;
	}
	
	/**
	 * 获取：产品保额
	 */
	public String getProductBaoe() 
	{
		return productBaoe;
	}
	
	/**
	 * 设置：产品保费
	 */
	public void setProductBaofei(String productBaofei) 
	{
		this.productBaofei = productBaofei;
	}
	
	/**
	 * 获取：产品保费
	 */
	public String getProductBaofei() 
	{
		return productBaofei;
	}
	
	/**
	 * 设置：方案层级定义（高管）
	 */
	public void setPlanCengji(String planCengji) 
	{
		this.planCengji = planCengji;
	}
	
	/**
	 * 获取：方案层级定义（高管）
	 */
	public String getPlanCengji() 
	{
		return planCengji;
	}
	
	/**
	 * 设置：产品保额类型（0固定保额，1不确定倍数）
	 */
	public void setProductBaoeType(String productBaoeType) 
	{
		this.productBaoeType = productBaoeType;
	}
	
	/**
	 * 获取：产品保额类型（0固定保额，1不确定倍数）
	 */
	public String getProductBaoeType() 
	{
		return productBaoeType;
	}
	
	/**
	 * 设置：产品保费类型（0固定保费，1不确定保费（0.4%））
	 */
	public void setProductBaofeiType(String productBaofeiType) 
	{
		this.productBaofeiType = productBaofeiType;
	}
	
	/**
	 * 获取：产品保费类型（0固定保费，1不确定保费（0.4%））
	 */
	public String getProductBaofeiType() 
	{
		return productBaofeiType;
	}
	
	/**
	 * 设置：是否高端产品（0不使用费率，1使用费率）
	 */
	public void setProductFeilv(String productFeilv) 
	{
		this.productFeilv = productFeilv;
	}
	
	/**
	 * 获取：是否高端产品（0不使用费率，1使用费率）
	 */
	public String getProductFeilv() 
	{
		return productFeilv;
	}
	
	/**
	 * 设置：计划的人数
	 */
	public void setPlanRenshu(String planRenshu) 
	{
		this.planRenshu = planRenshu;
	}
	
	/**
	 * 获取：计划的人数
	 */
	public String getPlanRenshu() 
	{
		return planRenshu;
	}
	
	/**
	 * 设置：计划类型，0新保，1续保，2新保保全，3续保保全
	 */
	public void setPlanType(Integer planType) 
	{
		this.planType = planType;
	}
	
	/**
	 * 获取：计划类型，0新保，1续保，2新保保全，3续保保全
	 */
	public Integer getPlanType() 
	{
		return planType;
	}
	
	/**
	 * 设置：保全表关联id，和保全表自增id绑定
	 */
	public void setBaoquanId(Integer baoquanId) 
	{
		this.baoquanId = baoquanId;
	}
	
	/**
	 * 获取：保全表关联id，和保全表自增id绑定
	 */
	public Integer getBaoquanId() 
	{
		return baoquanId;
	}
	
	/**
	 * 设置：关联人员表id,联合查询
	 */
	public void setPlanPeopleId(String planPeopleId) 
	{
		this.planPeopleId = planPeopleId;
	}
	
	/**
	 * 获取：关联人员表id,联合查询
	 */
	public String getPlanPeopleId() 
	{
		return planPeopleId;
	}
	
	/**
	 * 设置：分期数
	 */
	public void setPayMode(String payMode) 
	{
		this.payMode = payMode;
	}
	
	/**
	 * 获取：分期数
	 */
	public String getPayMode() 
	{
		return payMode;
	}
	
	/**
	 * 设置：备注
	 */
	public void setBeizhu(String beizhu) 
	{
		this.beizhu = beizhu;
	}
	
	/**
	 * 获取：备注
	 */
	public String getBeizhu() 
	{
		return beizhu;
	}
	
}
