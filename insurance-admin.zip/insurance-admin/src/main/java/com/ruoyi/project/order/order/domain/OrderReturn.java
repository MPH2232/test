package com.ruoyi.project.order.order.domain;


import com.ruoyi.project.order.orderBaofei.domain.OrderBaofei;

import java.util.Map;

/**
 * 保险订单表 f_order
 * 
 * @author ruoyi
 * @date 2018-08-14
 */
public class OrderReturn
{
	//暂时存产品对应总保费
	private Map<String,OrderBaofei> mapBaofei;
	//产品名称对应的个数，直接乘以产品的单价就是
	private  Map map;

	public Map<String, OrderBaofei> getMapBaofei() {
		return mapBaofei;
	}

	public void setMapBaofei(Map<String, OrderBaofei> mapBaofei) {
		this.mapBaofei = mapBaofei;
	}

	public Map getMap() {
		return map;
	}

	public void setMap(Map map) {
		this.map = map;
	}
}
