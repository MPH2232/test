package com.ruoyi.project.system.product.mapper;

import com.ruoyi.project.system.product.domain.Feilv;
import com.ruoyi.project.system.product.domain.Product;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.HashMap;
import java.util.List;


/**
 * Created by x on 2018/8/7.
 * 产品信息 数据层
 */
public interface ProductFeilvMapper {

    public List<Feilv> selectFeilvList(Feilv feilv);

    public List<Feilv> selectFeilvListById(Long productId);

    public Feilv selectFeilvById(Long feilvId);

//    public Long[] selectIdsByProductName(String productName);

    public List<Feilv> selectFeilvsByName(String productName);

    public int addFeilv(HashMap<String,Object> map);

    public int deleteFeilvByIds(Long[] ids);

    public int countFeilvById(Long feilvId);

    public int delete(HashMap map);

    public int updateFeilv(Feilv feilv);





}
