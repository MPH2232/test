package com.ruoyi.project.order.orderBaofei.domain;

import com.ruoyi.framework.web.domain.BaseEntity;
import java.util.Date;

/**
 * 订单分期--关联计划id,--关联订单id--关联保全表 f_order_baofei
 * 
 * @author ruoyi
 * @date 2018-09-21
 */
public class OrderBaofei extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** id */
	private Integer id;
	/** 订单表关联的分期id */
	private String orderFenqiId;
	/** 产品关联id */
	private Integer productId;
	/** 产品名称 */
	private String productName;
	/** 产品对应的汇总保费 */
	private String productCharge;
	/** 创建者 */
	private String createBy;
	/** 创建时间 */
	private Date createTime;
	/** 更新者 */
	private String updateBy;
	/** 更新时间 */
	private Date updateTime;
	/** 产品金额总计，相同产品 */
	private String productSum;
	/** 保单号 */
	private String orderPolicy;
	/** 产品下的人数 */
	private String productPeople;
	/** 分期表和保费关联id */
	private String planFenqiId;

	/**
	 * 设置：id
	 */
	public void setId(Integer id) 
	{
		this.id = id;
	}
	
	/**
	 * 获取：id
	 */
	public Integer getId() 
	{
		return id;
	}
	
	/**
	 * 设置：订单表关联的分期id
	 */
	public void setOrderFenqiId(String orderFenqiId) 
	{
		this.orderFenqiId = orderFenqiId;
	}
	
	/**
	 * 获取：订单表关联的分期id
	 */
	public String getOrderFenqiId() 
	{
		return orderFenqiId;
	}
	
	/**
	 * 设置：产品关联id
	 */
	public void setProductId(Integer productId) 
	{
		this.productId = productId;
	}
	
	/**
	 * 获取：产品关联id
	 */
	public Integer getProductId() 
	{
		return productId;
	}
	
	/**
	 * 设置：产品名称
	 */
	public void setProductName(String productName) 
	{
		this.productName = productName;
	}
	
	/**
	 * 获取：产品名称
	 */
	public String getProductName() 
	{
		return productName;
	}
	
	/**
	 * 设置：产品对应的汇总保费
	 */
	public void setProductCharge(String productCharge) 
	{
		this.productCharge = productCharge;
	}
	
	/**
	 * 获取：产品对应的汇总保费
	 */
	public String getProductCharge() 
	{
		return productCharge;
	}
	
	/**
	 * 设置：创建者
	 */
	public void setCreateBy(String createBy) 
	{
		this.createBy = createBy;
	}
	
	/**
	 * 获取：创建者
	 */
	public String getCreateBy() 
	{
		return createBy;
	}
	
	/**
	 * 设置：创建时间
	 */
	public void setCreateTime(Date createTime) 
	{
		this.createTime = createTime;
	}
	
	/**
	 * 获取：创建时间
	 */
	public Date getCreateTime() 
	{
		return createTime;
	}
	
	/**
	 * 设置：更新者
	 */
	public void setUpdateBy(String updateBy) 
	{
		this.updateBy = updateBy;
	}
	
	/**
	 * 获取：更新者
	 */
	public String getUpdateBy() 
	{
		return updateBy;
	}
	
	/**
	 * 设置：更新时间
	 */
	public void setUpdateTime(Date updateTime) 
	{
		this.updateTime = updateTime;
	}
	
	/**
	 * 获取：更新时间
	 */
	public Date getUpdateTime() 
	{
		return updateTime;
	}
	
	/**
	 * 设置：产品金额总计，相同产品
	 */
	public void setProductSum(String productSum) 
	{
		this.productSum = productSum;
	}
	
	/**
	 * 获取：产品金额总计，相同产品
	 */
	public String getProductSum() 
	{
		return productSum;
	}
	
	/**
	 * 设置：保单号
	 */
	public void setOrderPolicy(String orderPolicy) 
	{
		this.orderPolicy = orderPolicy;
	}
	
	/**
	 * 获取：保单号
	 */
	public String getOrderPolicy() 
	{
		return orderPolicy;
	}
	
	/**
	 * 设置：产品下的人数
	 */
	public void setProductPeople(String productPeople) 
	{
		this.productPeople = productPeople;
	}
	
	/**
	 * 获取：产品下的人数
	 */
	public String getProductPeople() 
	{
		return productPeople;
	}
	
	/**
	 * 设置：分期表和保费关联id
	 */
	public void setPlanFenqiId(String planFenqiId) 
	{
		this.planFenqiId = planFenqiId;
	}
	
	/**
	 * 获取：分期表和保费关联id
	 */
	public String getPlanFenqiId() 
	{
		return planFenqiId;
	}
	
}
