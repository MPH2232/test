package com.ruoyi.project.system.adjust.service;

import com.ruoyi.project.homepage.homepage.damain.AdjustUser;
import com.ruoyi.project.homepage.homepage.damain.OrderUser;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 渠道信息 服务层
 * 
 * @author ruoyi
 */
public interface IAdjustService
{
    public int insertAdjustByUser(AdjustUser adjustUser);
    /*管理员*/
    public List<AdjustUser> selectAdjustList(AdjustUser adjustUser);

    public AdjustUser selectAdjustById(Long id);

   public AdjustUser selectAdjustById1(Long buserId);


    /*主管*/
    public List<AdjustUser> selectAdjustListZongjian(AdjustUser adjustUser);
    /*总监*/
    public List<AdjustUser> selectAdjustMajordomoList(AdjustUser adjustUser);
    /**
     * 业务员
     */
    public List <AdjustUser> selectAdjustYwyList( AdjustUser adjustUser);


    /**
     * 更改（保存）
     * @param adjustUser
     * @return
     */
    public int updateAdjust(AdjustUser adjustUser);


    /**
     * 通过业务员id查询业务员调整信息
     * @param
     * @return
     */
    public AdjustUser selectAdjustUserByBuserId(Integer buserId);



    /**
     * 插入业务员调整信息
     * @param adjustUser
     * @return
     */
    public  int insertAdjustUser(AdjustUser adjustUser);


    /**
     *总监查询企业客户信息
     *
     */
    public List<AdjustUser> selectCustomerListMajordomo(long deptId);

    /**
     * 主管查看企业客户信息
     */
    public List<AdjustUser> selectCustomerListCharge(long deptId);

    /**
     *业务员查询企业客户信息
     *
     */
    public List<AdjustUser> selectCustomerListSalesman(long userIdd);


//1031
    public  int insertAftUser(AdjustUser adjustUser);


    public int updateAdjustStatus(AdjustUser adjustUser);
//1102
    public int updateAdjustUser(AdjustUser adjustUser);
}

