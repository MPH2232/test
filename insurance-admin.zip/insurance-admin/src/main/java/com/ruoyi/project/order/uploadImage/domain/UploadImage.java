package com.ruoyi.project.order.uploadImage.domain;

import com.ruoyi.framework.web.domain.BaseEntity;
import java.util.Date;

/**
 * 影像件管理表 f_upload_image
 * 
 * @author ruoyi
 * @date 2018-08-22
 */
public class UploadImage extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** id */
	private Integer id;
	/** 影像件名称 */
	private String name;
	/** 和订单表，新保，续保，保全。关联id */
	private String orderId;
	/** 0新保，1续保，2新保保全，3续保保全 */
	private String orderType;
	/** 图片上传的路径 /resoruese/upload/ */
	private String uploadPath;
	/** 影像件状态（0正常 1停用） */
	private String status;
	/** 创建者 */
	private String createBy;
	/** 创建时间 */
	private Date createTime;
	/** 更新者 */
	private String updateBy;
	/** 更新时间 */
	private Date updateTime;
	/** linux的上传下载路径 */
	private String linuxPath;
	/** 续保订单 */
	private String renewId;
	/** 订单类型 */
	private int customerSo;
	/** 订单表接受主键id*/
	private int orderIdZhu;

	public String getLinuxPath() {
		return linuxPath;
	}

	public void setLinuxPath(String linuxPath) {
		this.linuxPath = linuxPath;
	}

	public int getOrderIdZhu() {
		return orderIdZhu;
	}

	public void setOrderIdZhu(int orderIdZhu) {
		this.orderIdZhu = orderIdZhu;
	}

	/**
	 * 设置：id
	 */
	public void setId(Integer id) 
	{
		this.id = id;
	}
	
	/**
	 * 获取：id
	 */
	public Integer getId() 
	{
		return id;
	}
	
	/**
	 * 设置：影像件名称
	 */
	public void setName(String name) 
	{
		this.name = name;
	}
	
	/**
	 * 获取：影像件名称
	 */
	public String getName() 
	{
		return name;
	}
	
	/**
	 * 设置：和订单表，新保，续保，保全。关联id
	 */
	public void setOrderId(String orderId) 
	{
		this.orderId = orderId;
	}
	
	/**
	 * 获取：和订单表，新保，续保，保全。关联id
	 */
	public String getOrderId() 
	{
		return orderId;
	}
	
	/**
	 * 设置：0新保，1续保，2新保保全，3续保保全
	 */
	public void setOrderType(String orderType) 
	{
		this.orderType = orderType;
	}
	
	/**
	 * 获取：0新保，1续保，2新保保全，3续保保全
	 */
	public String getOrderType() 
	{
		return orderType;
	}
	
	/**
	 * 设置：图片上传的路径 /resoruese/upload/
	 */
	public void setUploadPath(String uploadPath) 
	{
		this.uploadPath = uploadPath;
	}
	
	/**
	 * 获取：图片上传的路径 /resoruese/upload/
	 */
	public String getUploadPath() 
	{
		return uploadPath;
	}
	
	/**
	 * 设置：影像件状态（0正常 1停用）
	 */
	public void setStatus(String status) 
	{
		this.status = status;
	}
	
	/**
	 * 获取：影像件状态（0正常 1停用）
	 */
	public String getStatus() 
	{
		return status;
	}
	
	/**
	 * 设置：创建者
	 */
	public void setCreateBy(String createBy) 
	{
		this.createBy = createBy;
	}
	
	/**
	 * 获取：创建者
	 */
	public String getCreateBy() 
	{
		return createBy;
	}
	
	/**
	 * 设置：创建时间
	 */
	public void setCreateTime(Date createTime) 
	{
		this.createTime = createTime;
	}
	
	/**
	 * 获取：创建时间
	 */
	public Date getCreateTime() 
	{
		return createTime;
	}
	
	/**
	 * 设置：更新者
	 */
	public void setUpdateBy(String updateBy) 
	{
		this.updateBy = updateBy;
	}
	
	/**
	 * 获取：更新者
	 */
	public String getUpdateBy() 
	{
		return updateBy;
	}
	
	/**
	 * 设置：更新时间
	 */
	public void setUpdateTime(Date updateTime) 
	{
		this.updateTime = updateTime;
	}
	
	/**
	 * 获取：更新时间
	 */
	public Date getUpdateTime() 
	{
		return updateTime;
	}

	public String getRenewId() {
		return renewId;
	}

	public void setRenewId(String renewId) {
		this.renewId = renewId;
	}

	public int getCustomerSo() {
		return customerSo;
	}

	public void setCustomerSo(int customerSo) {
		this.customerSo = customerSo;
	}
}
