package com.ruoyi.project.system.product.domain;

import com.ruoyi.framework.aspectj.lang.annotation.Excel;

import java.util.Date;

/**
 * 普通费率模板实体
 * Created by x on 2018/8/21.
 */
public class Feilv {
    @Excel(name = "产品名称")
    private String productName;

    @Excel(name = "产品id")
    private Long productId;

    @Excel(name = "年龄")
    private Integer age;

    @Excel(name = "性别")
    private String sex;

    @Excel(name = "保费")
    private String baofei;

    @Excel(name = "备注")
    private String beizhu;

    @Excel(name = "备注2")
    private String beizhu2;

    @Excel(name = "启动时间-Date类型")
    private Date startTime;

    @Excel(name = "结束时间-Date类型")
    private Date endTime;

    @Excel(name = "状态")
    private String status;

    @Excel(name = "创建者")
    private String createBy;

    @Excel(name = "创建时间")
    private Date createTime;

    @Excel(name = "更新者")
    private String updateBy;

    @Excel(name = "更新时间")
    private Date updateTime;

//    @Excel(name = "普通产品费率id")
    private Long feilvId;

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getBaofei() {
        return baofei;
    }

    public void setBaofei(String baofei) {
        this.baofei = baofei;
    }

    public String getBeizhu() {
        return beizhu;
    }

    public void setBeizhu(String beizhu) {
        this.beizhu = beizhu;
    }

    public String getBeizhu2() {
        return beizhu2;
    }

    public void setBeizhu2(String beizhu2) {
        this.beizhu2 = beizhu2;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Long getFeilvId() {
        return feilvId;
    }

    public void setFeilvId(Long feilvId) {
        this.feilvId = feilvId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Feilv feilv = (Feilv) o;

        if (!productName.equals(feilv.productName)) return false;
        if (!productId.equals(feilv.productId)) return false;
        if (!age.equals(feilv.age)) return false;
        if (!sex.equals(feilv.sex)) return false;
        if (!baofei.equals(feilv.baofei)) return false;
        if (!beizhu.equals(feilv.beizhu)) return false;
        if (!beizhu2.equals(feilv.beizhu2)) return false;
        if (!startTime.equals(feilv.startTime)) return false;
        if (!endTime.equals(feilv.endTime)) return false;
        if (!status.equals(feilv.status)) return false;
        if (!createBy.equals(feilv.createBy)) return false;
        if (!createTime.equals(feilv.createTime)) return false;
        if (!updateBy.equals(feilv.updateBy)) return false;
        if (!updateTime.equals(feilv.updateTime)) return false;
        return feilvId.equals(feilv.feilvId);
    }

    @Override
    public int hashCode() {
        int result = productName.hashCode();
        result = 31 * result + productId.hashCode();
        result = 31 * result + age.hashCode();
        result = 31 * result + sex.hashCode();
        result = 31 * result + baofei.hashCode();
        result = 31 * result + beizhu.hashCode();
        result = 31 * result + beizhu2.hashCode();
        result = 31 * result + startTime.hashCode();
        result = 31 * result + endTime.hashCode();
        result = 31 * result + status.hashCode();
        result = 31 * result + createBy.hashCode();
        result = 31 * result + createTime.hashCode();
        result = 31 * result + updateBy.hashCode();
        result = 31 * result + updateTime.hashCode();
        result = 31 * result + feilvId.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "Feilv{" +
                "productName='" + productName + '\'' +
                ", productId=" + productId +
                ", age=" + age +
                ", sex='" + sex + '\'' +
                ", baofei='" + baofei + '\'' +
                ", beizhu='" + beizhu + '\'' +
                ", beizhu2='" + beizhu2 + '\'' +
                ", startTime=" + startTime +
                ", endTime=" + endTime +
                ", status='" + status + '\'' +
                ", createBy='" + createBy + '\'' +
                ", createTime=" + createTime +
                ", updateBy='" + updateBy + '\'' +
                ", updateTime=" + updateTime +
                ", feilvId=" + feilvId +
                '}';
    }


}

