package com.ruoyi.project.system.channel.service;

import com.ruoyi.project.system.channel.domain.Channel;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 渠道信息 服务层
 * 
 * @author ruoyi
 */
public interface IChannelService
{ /**
 * 查询渠道数据集合
 *
 * @param  channel 渠道信息
 * @return 渠道数据集合
 */
public List<Channel> selectChannelList(Channel channel);

    /**
     * 查询所有渠道
     *
     * @return 渠道列表
     */
    public List<Channel> selectChannelAll();


    /**
     * 通过渠道ID查询渠道信息
     *
     * @param ChannelId 渠道ID
     * @return 角色对象信息
     */
    public Channel selectChannelById(Long ChannelId);

    /**
     * 通过渠道ID删除渠道
     *
     * @param channelId 渠道ID
     * @return 结果
     */
    public int deleteChannelById(Long channelId);

    /**
     * 批量删除渠道信息
     * 
     * @param ids 需要删除的数据ID
     */
    public int deleteChannelByIds(String ids) throws Exception;

    /**
     * 修改渠道信息
     *
     * @param channel 渠道信息
     * @return 结果
     */
    public int updateChannel(Channel channel);

    /**
     * 新增渠道信息
     *
     * @param channel 渠道信息Channel
     * @return 结果
     */
    public int insertChannel(Channel channel);

//    /**
//     * 上传excel文件到临时目录后并开始解析
//     * @param  channel
//     * @param mfile
//     * @return
//     */
//    public String batchImport(Channel channel, MultipartFile mfile);
//
//
    /**
     * 校验字典类型称是否唯一
     *
     * @param channel 字典类型
     * @return 结果
     */
    public String checkChannelNameUnique(Channel channel);

    /**
     * 改变渠道状态
     * @param channel
     * @return
     */
    public int updateStatus(Channel channel);

    /**
     * 根据Id查询渠道日期
     * @param channelId
     * @return
     */
    public Channel selectProtocolDateById(Long channelId);

    /**
     *总监查询渠道信息
     *
     */
    public List<Channel> selectCustomerListMajordomo(long deptId);

    /**
     * 主管查看渠道信息
     */
    public List<Channel> selectCustomerListCharge(long deptId);

    /**
     *业务员查询渠道信息
     *
     */
    public List<Channel> selectCustomerListSalesman(long userIdd);


    public String batchImport(Channel channel,  MultipartFile mfile);

}

