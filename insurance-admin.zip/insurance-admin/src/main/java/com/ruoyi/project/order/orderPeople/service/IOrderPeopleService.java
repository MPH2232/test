package com.ruoyi.project.order.orderPeople.service;

import com.ruoyi.project.order.orderPeople.domain.OrderPeople;
import com.ruoyi.project.order.orderPeople.domain.OrderPeopleCount;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;

/**
 * 人员清单，关联订单， 服务层
 * 
 * @author ruoyi
 * @date 2018-08-23
 */
public interface IOrderPeopleService 
{
	/**
     * 查询人员清单，关联订单，信息
     * 
     * @param id 人员清单，关联订单，ID
     * @return 人员清单，关联订单，信息
     */
	public OrderPeople selectOrderPeopleById(Integer id);

	/**
	 * 根据计划名称统计条数
	 *
	 * @param planName 计划名称
	 */
	public  List<OrderPeopleCount> selectOrderPeopleByPlans(String planName,String orderType);
	
	/**
     * 查询人员清单，关联订单，列表
     * 
     * @param orderPeople 人员清单，关联订单，信息
     * @return 人员清单，关联订单，集合
     */
	public List<OrderPeople> selectOrderPeopleList(OrderPeople orderPeople);
	
	/**
     * 新增人员清单，关联订单，
     * 
     * @param orderPeople 人员清单，关联订单，信息
     * @return 结果
     */
	public int insertOrderPeople(OrderPeople orderPeople);
	
	/**
     * 修改人员清单，关联订单，
     * 
     * @param orderPeople 人员清单，关联订单，信息
     * @return 结果
     */
	public int updateOrderPeople(OrderPeople orderPeople);
		
	/**
     * 删除人员清单，关联订单，信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteOrderPeopleByIds(String ids);
	/**
	 * 删除通过订单id
	 *
	 * @param orderid 需要删除的数据ID
	 * @return 结果
	 */
	public int deleteOrderPeopleByOrderId(String orderid);

	/**
	 * 上传excel文件到临时目录后并开始解析
	 * @param orderPeople
	 * @param mfile
	 * @return
	 */
	public String batchImport(OrderPeople orderPeople, MultipartFile mfile);

	public int addOrderPeople(HashMap<String,Object> map);

	public int insertOrderPeopleList(List<OrderPeople> orderPeopleList);

	public int deleteOrderPeopleByPolicyNum(String policyNum);
}
