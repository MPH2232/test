package com.ruoyi.project.system.product.service;


import com.ruoyi.project.system.product.domain.Feilv;
import org.apache.poi.ss.usermodel.Workbook;

import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by x on 2018/8/7.
 * 产品信息 服务层
 */
public interface IProductFeilvService {

    public List<Feilv> selectFeilvList(Feilv feilv);


//    public Long[] selectIdsByProductName(String productName);


    public Feilv selectFeilvById(Long feilvId);


    public List<Feilv> selectFeilvsByName(String productName);


    public int addFeilv(HashMap<String,Object> map);


    public int deleteFeilvByIds(String ids) throws Exception;


    public int countFeilvById(Long feilvId);


    public int delete(String productName, Date startTime, Date endTime);


    public List<Feilv> selectFeilvListById(Long productId);


    public int updateFeilv(Feilv feilv);



















}
