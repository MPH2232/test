package com.ruoyi.project.system.product.service;

import com.ruoyi.project.system.product.domain.CommisionBili;
import com.ruoyi.project.system.product.mapper.ProductCommisionMapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;


/**
 * Created by x on 2018/8/7.
 */
@Service
public class ProductCommisionServiceImpl implements IProductCommisionService {
    @Autowired
    private ProductCommisionMapper productCommisionMapper;

    @Override
    public int insertCommisionBiliList(List<CommisionBili> commisionBili) {
        return productCommisionMapper.insertCommisionBiliList(commisionBili);
    }

    @Override
    public List<CommisionBili> selectCommisionBiliInfo(Long productId){
        return productCommisionMapper.selectCommisionBiliInfo(productId);
    };

    @Override
    public int updateCommisionBili(@Param("list") List<CommisionBili> commisionBili){
        return productCommisionMapper.updateCommisionBili(commisionBili);
    };


}






