package com.ruoyi.project.homepage.homepage.mapper;

import com.ruoyi.project.homepage.homepage.damain.NewsAgency;
import com.ruoyi.project.system.customer.domain.Customer;

import java.util.List;

/**
 * Created by x on 2018/9/17.
 */
public interface NewsAgencyMapper {
    /**
     * 查询所有待办消息
     */

    public List<NewsAgency> selectNewsAgencyList(NewsAgency newsAgency);

    /**
     * 通过待办消息ID查询客户信息
     *
     * @param id 客户id
     * @return 客户信息
     */
    public NewsAgency selectNewsAgencyById(Long id);

    public NewsAgency selectNewsAgencyById1(Long porposerId);

    /**
     *查询所有待办消息
     * @return
     */
    public List<NewsAgency> selectNewsAgencyAll();

    /**
     * 改变代办状态
     * @param newsAgency
     * @return
     */
    public int changeNewsAgencyStatus(NewsAgency newsAgency);


}
