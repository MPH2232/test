package com.ruoyi.project.order.orderproductPlan.mapper;

import com.ruoyi.project.order.orderPeople.domain.ProductCount;
import com.ruoyi.project.order.orderproductPlan.domain.OrderProductPlan;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;

/**
 * 订单关联计划--详细产品--关联分期id--关联保全 数据层
 * 
 * @author ruoyi
 * @date 2018-08-31
 */
public interface OrderproductPlanMapper 
{
	/**
     * 查询订单关联计划--详细产品--关联分期id--关联保全信息
     * 
     * @param id 订单关联计划--详细产品--关联分期id--关联保全ID
     * @return 订单关联计划--详细产品--关联分期id--关联保全信息
     */
	public OrderProductPlan selectOrderproductPlanById(Integer id);

	public int selectcheckPlanByName(@Param("name") String name,@Param("orderid") String orderid);

	public int selectcheckCengjiByName(@Param("name") String name,@Param("orderid") String orderid);
	/**
     * 查询订单关联计划--详细产品--关联分期id--关联保全列表
     * 
     * @param orderproductPlan 订单关联计划--详细产品--关联分期id--关联保全信息
     * @return 订单关联计划--详细产品--关联分期id--关联保全集合
     */
	public List<OrderProductPlan> selectOrderproductPlanList(OrderProductPlan orderproductPlan);
	public List<ProductCount> selectproductList(OrderProductPlan orderproductPlan);
	public List<OrderProductPlan> selectProductGaoduan(@Param("productName") String productName,@Param("orderid") String orderid);

	/**
     * 新增订单关联计划--详细产品--关联分期id--关联保全
     * 
     * @param orderproductPlan 订单关联计划--详细产品--关联分期id--关联保全信息
     * @return 结果
     */
	public int insertOrderproductPlan(OrderProductPlan orderproductPlan);

	/**
	 * 新增订单关联计划--详细产品--关联分期id--关联保全
	 *
	 * @param orderproductPlan 订单关联计划--详细产品--关联分期id--关联保全信息
	 * @return 结果
	 */
	public int insertOrderproductPlanList(@Param("list") List<OrderProductPlan> orderproductPlan);
	
	/**
     * 修改订单关联计划--详细产品--关联分期id--关联保全
     * 
     * @param orderproductPlan 订单关联计划--详细产品--关联分期id--关联保全信息
     * @return 结果
     */
	public int updateOrderproductPlan(OrderProductPlan orderproductPlan);
	
	/**
     * 删除订单关联计划--详细产品--关联分期id--关联保全
     * 
     * @param id 订单关联计划--详细产品--关联分期id--关联保全ID
     * @return 结果
     */
	public int deleteOrderproductPlanById(Integer id);
	
	/**
     * 批量删除订单关联计划--详细产品--关联分期id--关联保全
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteOrderproductPlanByIds(String[] ids);

	public int addOrderproductPlan(HashMap<String,Object> map);

	public int deleteOrderProductPlanByOrderProductId(String orderProductId);

    public List<OrderProductPlan> selectOrderProductPlanAll();
}