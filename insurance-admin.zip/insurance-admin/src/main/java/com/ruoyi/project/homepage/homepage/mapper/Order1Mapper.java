package com.ruoyi.project.homepage.homepage.mapper;

import com.ruoyi.project.homepage.homepage.damain.Order1;
import com.ruoyi.project.system.customer.domain.CustomerContacts;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 保险订单 数据层
 * 
 * @author ruoyi
 * @date 2018-08-13
 */
public interface Order1Mapper {

	public List<Order1> selectOrder1List(Order1 order1);

	public List<Order1> selectOrder2List(Order1 order2);


	/**
	 * 管理员
	 */
	public List<Order1>selectOrderListInfoAdmin(int status);


	/**
	 * 主管
	 */
	public List<Order1> selectOrderListInfozhu(@Param("deptId")long deptId, @Param("statu")long statu);

	/**
	 * 总监
	 */
	public List<Order1> selectOrderListInfoMajordomo(@Param("deptId")long deptId,@Param("stat")long stat);

	/**
	 * 业务员
	 */
	public List<Order1> selectOrderListInfoye(@Param("userIdd")long userIdd, @Param("statuss")long statuss);

	
}