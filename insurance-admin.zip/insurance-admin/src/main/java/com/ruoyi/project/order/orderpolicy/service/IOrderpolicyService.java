package com.ruoyi.project.order.orderpolicy.service;

import com.ruoyi.project.order.orderpolicy.domain.Orderpolicy;
import java.util.List;

/**
 * 订单关联保全管理 服务层
 * 
 * @author ruoyi
 * @date 2018-08-13
 */
public interface IOrderpolicyService 
{
	/**
     * 查询订单关联保全管理信息
     * 
     * @param id 订单关联保全管理ID
     * @return 订单关联保全管理信息
     */
	public Orderpolicy selectOrderpolicyById(Integer id);
	
	/**
     * 查询订单关联保全管理列表
     * 
     * @param orderpolicy 订单关联保全管理信息
     * @return 订单关联保全管理集合
     */
	public List<Orderpolicy> selectOrderpolicyList(Orderpolicy orderpolicy);
	
	/**
     * 新增订单关联保全管理
     * 
     * @param orderpolicy 订单关联保全管理信息
     * @return 结果
     */
	public int insertOrderpolicy(Orderpolicy orderpolicy);
	
	/**
     * 修改订单关联保全管理
     * 
     * @param orderpolicy 订单关联保全管理信息
     * @return 结果
     */
	public int updateOrderpolicy(Orderpolicy orderpolicy);
		
	/**
     * 删除订单关联保全管理信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteOrderpolicyByIds(String ids);
	
}
