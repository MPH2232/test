package com.ruoyi.project.system.customer.controller;

import com.alibaba.fastjson.JSONObject;
import com.ruoyi.common.utils.BankUtil;
import com.ruoyi.common.utils.NewFileUploadUtils;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.domain.Pcustomer;
import com.ruoyi.project.system.customer.service.lCustomerPersonService;
import com.ruoyi.project.system.customer.service.lCustomerService;
import com.ruoyi.project.system.user.domain.User;
import com.ruoyi.project.system.user.service.IUserService;
import com.xiaoleilu.hutool.http.HttpUtil;
import com.xiaoleilu.hutool.util.ReUtil;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.*;

/**
 * 个人客户信息操作处理
 * @author ruoyi
 */
@Controller
//个人客户
@RequestMapping("/system/customerPerson")
public class CustomerPersonController extends BaseController {

    private static final Logger log = LoggerFactory.getLogger(CustomerPersonController.class);

    private String prefix = "system/customerPerson";
    @Autowired
    private lCustomerService customerService;

    @Autowired
    private lCustomerPersonService customerPersonService;

    @Autowired
    private IUserService userService;

    @RequiresPermissions("system:customerPerson:view")
    @GetMapping()
    public String operlog(ModelMap mmap) {
        mmap.put("userId",getUserId());
        return prefix+ "/customerPerson";

    }

    @RequiresPermissions("system:customerPerson:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Customer customer) {
        User user = getUser();
        String name=userService.selectUserRoleGroup(user.getUserId());
        startPage();
        List<Customer> list=new ArrayList<Customer>();
        if(name.contains("管理员")){
            //管理员
            list = customerPersonService.selectPersonCustomerList(customer);
        }else if(name.equals("主管")){
            //主管
            list = customerPersonService.selectselectPersonCustomerListCharge(user.getDeptId(),customer);
        }else if(name.equals("总监")){
            //总监
            list = customerPersonService.selectPersonCustomerListMajordomo(user.getDeptId(),customer);
        }else {
            //业务员
            list = customerPersonService.selectselectPersonCustomerListSalesman(user.getUserId(),customer);
        }
        return getDataTable(list);
    }

    /**
     * 导出Excel表
     * @param pcustomer
     * @return
     * @throws Exception
     */
    @Log(title = "客户管理", action = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Pcustomer pcustomer) throws Exception {
        try {
            List<Pcustomer> list = customerPersonService.selectPersonCustomerList1(pcustomer);
            ExcelUtil<Pcustomer> util = new ExcelUtil<Pcustomer>(Pcustomer.class);
            return util.exportExcel(list, "Pcustomer");
        } catch (Exception e) {
            return error("导出Excel失败，请联系网站管理员！");
        }
    }


//    @GetMapping("/add")
//    public String add() {
//        return prefix + "/add";
//    }

    /**
     * 新增个人客户
     */
    @GetMapping("/add/{userId}")
    public String add(@PathVariable("userId") String userId, ModelMap mmap) {
        mmap.put("userId",userId);
        return prefix + "/add";
    }

    /**
     * 新增保存个人客户
     */
    @RequiresPermissions("system:customerPerson:add")
    @Log(title = "客户管理", action = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Customer customer) {
        return toAjax(customerPersonService.insertPersonCustomer(customer));
    }
    /**
     * 修改个人客户
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap) {
        mmap.put("customer", customerService.selectCustomerById(id));
        return prefix + "/edit";
    }
    /**
     * 修改保存个人客户
     */
    @RequiresPermissions("system:customerPerson:edit")
    @Log(title = "客户管理", action = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Customer customer) {
        return toAjax(customerPersonService.updatePersonCustomer(customer));
    }

    /**
     * 查看个人客户
     */
    @GetMapping("/cmd/{id}")
    public String look(@PathVariable("id") Long id, ModelMap mmap) {
        mmap.put("customer", customerService.selectCustomerById(id));
        return prefix + "/cmd";
    }

    /**
     * 批量删除个人客户
     * @param ids
     * @return
     */
    @RequiresPermissions("system:customerPerson:remove")
    @Log(title = "客户管理", action = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        try {
            return toAjax(customerService.deleteCustomerByIds(ids));
        } catch (Exception e) {
            return error(e.getMessage());
        }
    }

    /**
     *上传excel表
     */
    @RequiresPermissions("system:customerPerson:upload")
    @GetMapping("/upload")
    public String upload(Customer customer,ModelMap mmap) {
        Customer customerPerson =customerService.selectCustomerById(customer.getId());
        mmap.put("customerPerson",customerPerson);
        return prefix + "/upload";
    }

    /**
     * 导入个人客户信息
     */
    @RequiresPermissions("system:customerPerson:upload")
    @PostMapping("/importPeople")
    @ResponseBody
        public AjaxResult excelSave(Pcustomer pcustomer, @RequestParam("uploadFile") MultipartFile file)
    {

        Map map = new HashMap();
        int su = 0;
        String xu = "";
        String mess="";
        try {
            List<Map<String, Object>> list = ExcelUtil.importExcelsPro(file, pcustomer);
            for (int i = 0; i < list.size(); i++) {
                Map<String, Object> map1 = list.get(i);
                Iterator<Map.Entry<String, Object>> iterator = map1.entrySet().iterator();
                while (iterator.hasNext()) {
                    Map.Entry<String, Object> entry = iterator.next();
                    System.out.println("key: " + entry.getKey() + " value: " + entry.getValue());
                    if(entry.getValue().toString().contains("格式错误")){
                        log.info("===导入异常原因===", entry.getValue().toString());
                        mess+=entry.getValue().toString();
                    }
                }
            }
            if(mess.contains("格式错误")){
                return toAjaxMesMeg(su, mess);
            }
            for (int q = 0; q < list.size(); q++) {
                Map<String, Object> map1 = list.get(q);
                log.info("====获取excel值==" + list);
                su = list.size();
                //执行insert语句
                customerPersonService.addPersonCustomer((HashMap<String, Object>) map1);
                mess="导入成功";
            }
        } catch (Exception e) {
            log.error("导入异常", e);
            //获取文件名
            String fileName=file.getOriginalFilename();
            //验证文件名是否合格
            if(!NewFileUploadUtils.validateExcel(fileName)){
                mess="文件必须是excel格式！";
                return toAjaxMes(su,mess);
            }
            mess="上传失败,请稍后重试!";
            return toAjaxMes(su, mess);
        }
        return toAjaxMes(su, mess);
    }

    /**
     * 校验证件号码
     */
    @PostMapping("/checkCardNumUnique")
    @ResponseBody
    public String checkCardNumUnique(Customer cardNum)
    {
        String uniqueFlag = "0";
        if (cardNum != null)
        {
            uniqueFlag = customerPersonService.checkCardNumUnique(cardNum);
        }
        return uniqueFlag;
    }


    /**
     * 根据银行卡号查开户行
     */
    @PostMapping("/findPaytaxesBank")
    @ResponseBody
    public String findPaytaxesBank(Customer customer){
        String title=BankUtil.getNameOfBank(customer.getPaytaxesNumber());
        if(title==""){
            try{
                //获取到银行卡号
                String bankNo=customer.getPaytaxesNumber();
                //银行代码请求接口 url
                String url = "https://ccdcapi.alipay.com/validateAndCacheCardInfo.json?_input_charset=utf-8&cardNo="+bankNo+"&cardBinCheck=true";
                //发送请求，得到 josn 类型的字符串
                String result = HttpUtil.get(url);
                // 转为 Json 对象
                com.xiaoleilu.hutool.json.JSONObject json = new com.xiaoleilu.hutool.json.JSONObject(result);
                //获取到 bank 代码
                String bank = String.valueOf(json.get("bank"));
                //爬取支付宝银行合作商页面
                String listContent = HttpUtil.get("http://ab.alipay.com/i/yinhang.htm","gb2312");
                //过滤得到需要的银行名称
                List<String> titles = ReUtil.findAll("<span title=\"(.*?)\" class=\"icon "+bank+"\">(.*?)</span>", listContent, 2);
                for (String title1 : titles) {
                    //打印银行名称
                    System.out.print(title1);
                    title=title1;
                }
            }catch(Exception e){
                return title;
            }
        }
        return title;
    }

    @PostMapping("/findPremiumBank")
    @ResponseBody
        public String findPremiumBank(Customer customer){
        String title=BankUtil.getNameOfBank(customer.getPremiumNumber());
        if(title==""){
            try{
                //获取到银行卡号
                String bankNo=customer.getPremiumNumber();
                //银行代码请求接口 url
                String url = "https://ccdcapi.alipay.com/validateAndCacheCardInfo.json?_input_charset=utf-8&cardNo="+bankNo+"&cardBinCheck=true";
                //发送请求，得到 josn 类型的字符串
                String result = HttpUtil.get(url);
                // 转为 Json 对象
                com.xiaoleilu.hutool.json.JSONObject json = new com.xiaoleilu.hutool.json.JSONObject(result);
                //获取到 bank 代码
                String bank = String.valueOf(json.get("bank"));
                //爬取支付宝银行合作商页面
                String listContent = HttpUtil.get("http://ab.alipay.com/i/yinhang.htm","gb2312");
                //过滤得到需要的银行名称
                List<String> titles = ReUtil.findAll("<span title=\"(.*?)\" class=\"icon "+bank+"\">(.*?)</span>", listContent, 2);
                for (String title1 : titles) {
                    //打印银行名称
                    System.out.print(title1);
                    title=title1;
                }
            }catch(Exception e){
                return title;
            }
        }
        return title;
    }

}