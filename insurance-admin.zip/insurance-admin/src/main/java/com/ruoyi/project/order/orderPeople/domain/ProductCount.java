package com.ruoyi.project.order.orderPeople.domain;

/**
 * 产品统计实体
 * 
 * @author ruoyi
 * @date 2018-08-23
 */
public class ProductCount
{
	/** 产品名称 */
	private String productName;
	/** 相同产品总额 */
	private String counts;


	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCounts() {
		return counts;
	}

	public void setCounts(String counts) {
		this.counts = counts;
	}
}
