package com.ruoyi.project.homepage.homepage.controller;

import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.project.homepage.homepage.damain.NewsAgency;
import com.ruoyi.project.homepage.homepage.service.INewsAgencyService;
import com.ruoyi.project.order.order.domain.Order;
import com.ruoyi.project.order.order.service.IOrderService;
import com.ruoyi.project.system.customer.service.lCustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

/*
 * Created by x on 2018/9/19.
 */
@Controller
@RequestMapping("/newsagency")
public class NewsAgencyController extends BaseController{

    @Autowired
    private INewsAgencyService newsAgencyService;
    @Autowired
    private IOrderService orderService;

    private String prefix = "newsagency";

    /**
     * 查看个人客户
     */
    @GetMapping("/cmd/{id}")
    public String look(@PathVariable("id") Long id, ModelMap mmap) {
        mmap.put("NewsAgency", newsAgencyService.selectNewsAgencyById(id));
        return prefix + "/cmd";
    }
    /**
     * 审核页面
     * @param
     * @param mmap
     * @return
     */
    @GetMapping("/detail/{proposerId}")
    public String detail(@PathVariable("proposerId") Long proposerId, ModelMap mmap, NewsAgency newsAgency,Order order)
    {
      mmap.put("newsAgency", newsAgencyService.selectNewsAgencyById(proposerId));
       // mmap.put("newsAgency",newsAgencyService.selectNewsAgencyById1(proposerId));
    //    mmap.put("newsAgencyList",newsAgencyService.selectNewsAgencyAll());
        return prefix + "/adjustUser";
    }


}
