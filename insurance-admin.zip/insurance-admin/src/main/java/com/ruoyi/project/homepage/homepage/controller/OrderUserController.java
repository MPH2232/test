package com.ruoyi.project.homepage.homepage.controller;

import com.ruoyi.common.utils.NewFileUploadUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.framework.web.page.TableDataInfo;

import com.ruoyi.project.homepage.homepage.damain.AdjustUser;
import com.ruoyi.project.homepage.homepage.damain.NewsAgency;
import com.ruoyi.project.homepage.homepage.damain.OrderUser;
import com.ruoyi.project.homepage.homepage.service.INewsAgencyService;
import com.ruoyi.project.homepage.homepage.service.IOrderUserService;

import com.ruoyi.project.order.order.domain.Order;
import com.ruoyi.project.order.order.service.IOrderService;
import com.ruoyi.project.system.adjust.service.IAdjustService;
import com.ruoyi.project.system.dept.domain.Dept;
import com.ruoyi.project.system.user.domain.User;
import com.ruoyi.project.system.user.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by x on 2018/9/19.
 */
@Controller
@RequestMapping("/newsagency")
public class OrderUserController extends BaseController {

    private String prefix = "newsagency";

    @Autowired
    private IOrderUserService orderUserService;
    @Autowired
    private IOrderService orderService;
    @Autowired
    private INewsAgencyService newsAgencyService;
    @Autowired
    private IAdjustService adjustService;
    @Autowired
    private IUserService userService;

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
    }

    @GetMapping()
    public String orderUser() {
        return prefix + "/adjustUser";
    }


    /**
     * 显示订单
     *
     * @param
     * @return
     */
    @PostMapping("/list1")
    @ResponseBody
    public TableDataInfo list(OrderUser orderUser) {
        startPage();
        List<OrderUser> lists = new ArrayList<OrderUser>();
        List<OrderUser> list = orderUserService.selectOrderUserList(orderUser);
        for(OrderUser orderUser1 :list){
            OrderUser order2 = orderUserService.selectOrderUserById(orderUser1.getId());
            //调整过的不显示,没有实现效果
                if(order2.getSalesmanName()==null || order2.getSalesmanName().equals("")){
                    lists = orderUserService.selectOrderUserList(orderUser);
                }
        }
        //判断订单，订单全部调整过的更改状态
        if(lists.size()==0 ) {
                NewsAgency newsAgency1 = newsAgencyService.selectNewsAgencyById1(Long.valueOf(orderUser.getUserId()));
                newsAgency1.setStatus("1");
                newsAgencyService.changeNewsAgencyStatus(newsAgency1);
                AdjustUser adjustUser = adjustService.selectAdjustById1(Long.valueOf(orderUser.getUserId()));
                adjustUser.setAdjustStatus("已调整");
                adjustService.updateAdjustStatus(adjustUser);
        }
        if(list.size()==0){
            AdjustUser adjustUser = adjustService.selectAdjustById1(Long.valueOf(orderUser.getUserId()));
            adjustUser.setAdjustStatus("已调整");
            adjustService.updateAdjustStatus(adjustUser);
        }
        return getDataTable(lists);
    }

    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(OrderUser orderUser) throws Exception {
        try {
            List<OrderUser> list = orderUserService.selectOrderUserList(orderUser);
            ExcelUtil<OrderUser> util = new ExcelUtil<OrderUser>(OrderUser.class);
            return util.exportExcel(list, "orderUser");
        } catch (Exception e) {
            return error("导出Excel失败，请联系网站管理员！");
        }
    }

    /**
     * 调整更改页面
     *
     * @param proposerId
     * @param mmap
     * @return
     */
    @GetMapping("/add/{userId}/{ids}")
    public String add(@PathVariable("userId") String proposerId,@PathVariable("ids") String ids, ModelMap mmap, User user) {
        User user1 = getUser();
        mmap.put("newsAgency", newsAgencyService.selectNewsAgencyById1(Long.valueOf(proposerId)));
        Boolean deptUp=false;
        NewsAgency newsAgency =  newsAgencyService.selectNewsAgencyById1(Long.valueOf(proposerId));
        String name = newsAgency.getRoleName();
        if(name.contains("总监")){
            user.setDeptId(newsAgency.getDeptId());
            user.setParentId(newsAgency.getDeptId());
            mmap.put("userList",userService.selectUserList1(user));
        }else if(name.contains("主管")){
//            List<Dept> listDp = userService.selectDeptList(newsAgency.getDeptId());
//            String ance =listDp.get(0).getAncestors();
//            String[] anceList=ance.split(",");
//            for(int i=0;i<anceList.length;i++){
//                if(user.getDeptId()==null){
//                    deptUp=true;
//                }
//                if( String.valueOf(user.getDeptId()).equals(anceList[i])){
//                    deptUp=true;
//                }
//            }
//            if(deptUp){
                //根据登录用户的deptId
                user.setDeptId(newsAgency.getDeptId());
                mmap.put("userList", userService.selectUserListZongjian(user));
                // list = userService.selectUserListZongjian(user);
//            }else{
//                //根据点击传入的deptId
//                mmap.put("userList", userService.selectUserListZongjian(user));
//            }
        }else if(name.contains("业务员")) {
            //根据自己部门id查询所在部门的在职人员
            user.setDeptId(newsAgency.getDeptId());
            user.setParentId(newsAgency.getDeptId());
            mmap.put("userList",userService.selectUserList1(user));
        }
        mmap.put("ids", ids);
        mmap.put("adminId", user1.getUserId());
        mmap.put("adminName", user1.getUserName());

        return prefix + "/add";
    }
    /**
     * 保存调整更改
     *
     * @param adjustUser
     * @return
     */
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(String ids,AdjustUser adjustUser) {

        String[] orderIds = ids.split(",");
        for (String orderId : orderIds) {
           // toAjax(adjustService.updateAdjust(adjustUser));
            Order order1 = orderService.selectOrderById(Integer.valueOf(orderId));
            order1.setSalesmanName(adjustUser.getAftUser());
            order1.setSalesmanTrim(adjustUser.getRemark());
            //根据userName插入userId
            String strUser="";
            List<User> userList = userService.selectUserStatusAll();
            for(User users : userList){
                strUser +=users.getUserName()+',';
            }
            String arrUser [] = strUser.split(",");
            if(strUser.contains(adjustUser.getAftUser())) {
                for (int index = 0; index < arrUser.length; index++) {
                    if (arrUser[index].equals(adjustUser.getAftUser())) {
                        order1.setSalesmanId(Math.toIntExact(userList.get(index).getUserId()));
                    }
                }
            }
            orderService.updateSalesmanName(order1);
        }
        //当调整的订单业务员一样时，以张三，李四保存
        long id = Long.parseLong(orderIds[0]);
        Order order = orderService.selectOrderById(Math.toIntExact(id));
        AdjustUser adjustUser1 = adjustService.selectAdjustUserByBuserId(Math.toIntExact(adjustUser.getBuserId()));
        if(Long.valueOf(order.getUserId()).equals(adjustUser.getBuserId())){
            //去除重复的接收人姓名
            if(adjustUser.getAftUser().contains(adjustUser1.getAftUser())){
                adjustUser1.setAftUser(adjustUser.getAftUser());
                adjustUser1.setRemark(adjustUser.getRemark());
            }else {
                adjustUser1.setAftUser(adjustUser.getAftUser() + "," + adjustUser1.getAftUser());
                adjustUser1.setRemark(adjustUser.getRemark() + ";" + adjustUser1.getRemark());
            }
        }
            return toAjax(adjustService.updateAdjust(adjustUser));
        }


    /**
     * 不调整
     *
     * @param id
     * @param mmap
     * @return
     */
    @GetMapping("/edit/{id}")
    public String add(@PathVariable("id") Long id, ModelMap mmap) {
        mmap.put("newsAgency", newsAgencyService.selectNewsAgencyById1(id));
        return prefix + "/edit";
    }


    /**
     * 保存不调整原因
     *
     * @param adjustUser
     * @return
     */
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(AdjustUser adjustUser,NewsAgency newsAgency) {
        adjustUser.setAdjustStatus("已调整");
       // adjustService.updateAdjustStatus(adjustUser);
        List<NewsAgency> lists = newsAgencyService.selectNewsAgencyList(newsAgency);
        for(NewsAgency newsAgency1:lists){
            AdjustUser adjustUser1=adjustService.selectAdjustUserByBuserId(newsAgency1.getProposerId());
            if(adjustUser1!=null){
                if (adjustUser.getRemark()!=null && adjustUser.getBefUser().equals(adjustUser1.getBefUser())){
                    newsAgency1.setStatus("1");

                }else{
                    newsAgency1.setStatus("0");
                }
                newsAgencyService.changeNewsAgencyStatus(newsAgency1);
            }
        }
        return toAjax(adjustService.updateAdjust(adjustUser));
    }


    @GetMapping("/upload/{proposerId}")
    public String upload(NewsAgency newsAgency, ModelMap mmap) {
        NewsAgency newsAgency1 = newsAgencyService.selectNewsAgencyById1(Long.valueOf(newsAgency.getProposerId()));
        mmap.put("newsAgency", newsAgency1);
        return prefix + "/upload";
    }


    /**
     * 导入excel文件
     * */
    @PostMapping("/uploadSave")
    @ResponseBody
    @Transactional
    public AjaxResult excelSave(Order order, @RequestParam("uploadFile") MultipartFile file, HttpServletRequest request,AdjustUser adjustUser,NewsAgency newsAgency)
    {
        String message="";
        //判断文件是否为空
        if(file==null){
            message="文件不能为空！";
            return toAjaxMes(0,message);
        }
        //获取文件名
        String fileName=file.getOriginalFilename();
        //验证文件名是否合格
        if(!NewFileUploadUtils.validateExcel(fileName)){
            message="文件必须是excel格式！";
            return toAjaxMes(0,message);
        }
        //进一步判断文件内容是否为空（即判断其大小是否为0或其名称是否为null）
        long size=file.getSize();
        if(StringUtils.isEmpty(fileName) || size==0){
            message="文件不能为空！";
            return toAjaxMes(0,message);
        }
        //批量导入
        message = orderUserService.batchImport(order,file,adjustUser,newsAgency);
        if(message.contains("行")){
            return error(message);
        }else{
            return success(message);
        }
      //  return toAjaxMes(1,message);
    }


}