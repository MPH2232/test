package com.ruoyi.project.system.customer.service;


import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.domain.Pcustomer;

import java.util.HashMap;
import java.util.List;

/**
 * Created by x on 2018/8/8.
 */

public interface lCustomerPersonService {

    /**
     * 查询个人客户信息集合
     *
     * @param customer 个人客户信息
     * @return 个人客户信息集合
     */
    public List<Customer> selectPersonCustomerList(Customer customer);

    /**
     * 查询个人客户信息集合
     *
     * @param customer1 个人客户信息
     * @return 个人客户信息集合
     */
    public List<Pcustomer> selectPersonCustomerList1(Pcustomer customer1);

    /**
     * 新增保存个人客户信息
     *
     * @param customer 个人客户信息
     * @return 结果
     */
    public int insertPersonCustomer(Customer customer);

    /**
     * 修改保存个人客户信息
     *
     * @param customer 岗位信息
     * @return 结果
     */
    public int updatePersonCustomer(Customer customer);

    /**
     * 通过id查询个人客户信息
     * @param id
     * @return
     */
    public Customer selectPersonCustomerById(Long id);
    /**
     * 校验证件号码是否唯一
     *
     * @param cardNum 证件号码
     * @return 结果
     */
    public String checkCardNumUnique(Customer cardNum);

    public int addPersonCustomer(HashMap<String,Object> map);


    /**
     *总监查询个人客户信息
     *
     */
    public List<Customer> selectPersonCustomerListMajordomo(long deptId,Customer customer);

    /**
     * 主管查看个人客户信息
     */
    public List<Customer> selectselectPersonCustomerListCharge(long deptId,Customer customer);

    /**
     *业务员查询个人客户信息
     *
     */
    public List<Customer> selectselectPersonCustomerListSalesman(long userIdd,Customer customer);


}
