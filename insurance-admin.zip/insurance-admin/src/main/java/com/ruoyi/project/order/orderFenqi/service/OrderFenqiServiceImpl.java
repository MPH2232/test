package com.ruoyi.project.order.orderFenqi.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.order.orderFenqi.mapper.OrderFenqiMapper;
import com.ruoyi.project.order.orderFenqi.domain.OrderFenqi;
import com.ruoyi.project.order.orderFenqi.service.IOrderFenqiService;
import com.ruoyi.common.support.Convert;

/**
 * 订单分期--关联计划id,--关联订单id--关联保全 服务层实现
 * 
 * @author ruoyi
 * @date 2018-09-17
 */
@Service
public class OrderFenqiServiceImpl implements IOrderFenqiService 
{
	@Autowired
	private OrderFenqiMapper orderFenqiMapper;

	/**
     * 查询订单分期--关联计划id,--关联订单id--关联保全信息
     * 
     * @param id 订单分期--关联计划id,--关联订单id--关联保全ID
     * @return 订单分期--关联计划id,--关联订单id--关联保全信息
     */
    @Override
	public OrderFenqi selectOrderFenqiById(Integer id)
	{
	    return orderFenqiMapper.selectOrderFenqiById(id);
	}
	
	/**
     * 查询订单分期--关联计划id,--关联订单id--关联保全列表
     * 
     * @param orderFenqi 订单分期--关联计划id,--关联订单id--关联保全信息
     * @return 订单分期--关联计划id,--关联订单id--关联保全集合
     */
	@Override
	public List<OrderFenqi> selectOrderFenqiList(OrderFenqi orderFenqi)
	{
	    return orderFenqiMapper.selectOrderFenqiList(orderFenqi);
	}
	@Override
	public int selectOrderFenqiId(String orderFenqiId){
		return orderFenqiMapper.selectOrderFenqiId(orderFenqiId);
	}
    /**
     * 新增订单分期--关联计划id,--关联订单id--关联保全
     * 
     * @param orderFenqi 订单分期--关联计划id,--关联订单id--关联保全信息
     * @return 结果
     */
	@Override
	public int insertOrderFenqi(OrderFenqi orderFenqi)
	{
	    return orderFenqiMapper.insertOrderFenqi(orderFenqi);
	}
	@Override
	public int insertOrderFenqiList(List<OrderFenqi> orderFenqi)
	{
		return orderFenqiMapper.insertOrderFenqiList(orderFenqi);
	}

	/**
     * 修改订单分期--关联计划id,--关联订单id--关联保全
     * 
     * @param orderFenqi 订单分期--关联计划id,--关联订单id--关联保全信息
     * @return 结果
     */
	@Override
	public int updateOrderFenqi(OrderFenqi orderFenqi)
	{
	    return orderFenqiMapper.updateOrderFenqi(orderFenqi);
	}

	/**
     * 删除订单分期--关联计划id,--关联订单id--关联保全对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteOrderFenqiByIds(String ids)
	{
		return orderFenqiMapper.deleteOrderFenqiByIds(Convert.toStrArray(ids));
	}

//	@Override
//	public OrderFenqi selectOrderFenqiByOrderId(String orderFenqiId) {
//		return orderFenqiMapper.selectOrderFenqiByOrderId(orderFenqiId);
//	}

	@Override
	public List<OrderFenqi> selectFenqiList(String orderFenqi) {
		return orderFenqiMapper.selectFenqiList(orderFenqi);
	}

	@Override
	public OrderFenqi selectFenqiPayTime(String payTime) {
		return orderFenqiMapper.selectFenqiPayTime(payTime);
	}


}
