package com.ruoyi.project.system.customer.domain;

/**
 * Created by x on 2018/8/23.
 */
public class CustomerAttention {
    private static final long serialVersionUID = 1L;
    /*客户ID*/
    private int id;
    /*用户状态*/
    private String status;
    /*创建者*/
    private String createBy;
    /*创建时间*/
    private String createTime;
    /*更新者*/
    private String updateBy;
    /*更新时间*/
    private String updateTime;
    /*客户类型*/
    private String customerType;
    /*邮寄地址*/
    private String customerMail;
    /*收件人*/
    private String customerColl;
    /*收件人联系方式*/
    private String customerCollPhone;
    /*关联客户表id*/
    private int customerId;

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getCustomerMail() {
        return customerMail;
    }

    public void setCustomerMail(String customerMail) {
        this.customerMail = customerMail;
    }

    public String getCustomerColl() {
        return customerColl;
    }

    public void setCustomerColl(String customerColl) {
        this.customerColl = customerColl;
    }

    public String getCustomerCollPhone() {
        return customerCollPhone;
    }

    public void setCustomerCollPhone(String customerCollPhone) {
        this.customerCollPhone = customerCollPhone;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    @Override
    public String toString() {
        return "CustomerAttention{" +
                "id=" + id +
                ", status='" + status + '\'' +
                ", createBy='" + createBy + '\'' +
                ", createTime='" + createTime + '\'' +
                ", updateBy='" + updateBy + '\'' +
                ", updateTime='" + updateTime + '\'' +
                ", customerType='" + customerType + '\'' +
                ", customerMail='" + customerMail + '\'' +
                ", customerColl='" + customerColl + '\'' +
                ", customerCollPhone='" + customerCollPhone + '\'' +
                ", customerId=" + customerId +

                '}';
    }

}
