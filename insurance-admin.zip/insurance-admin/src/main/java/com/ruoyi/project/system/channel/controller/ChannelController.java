package com.ruoyi.project.system.channel.controller;
import com.ruoyi.common.utils.*;

import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.project.system.channel.domain.Channel;
import com.ruoyi.project.system.channel.domain.ChannelXieyi;
import com.ruoyi.project.system.channel.service.IChannelService;
import com.ruoyi.project.system.user.domain.User;
import com.ruoyi.project.system.user.service.IUserService;
import org.apache.shiro.authz.annotation.RequiresPermissions;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.math.BigDecimal;

import java.text.SimpleDateFormat;
import java.util.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import static java.math.BigDecimal.ROUND_UNNECESSARY;

/**
 * 渠道信息操作处理
 *
 * @author ruoyi
 */
@Controller
@RequestMapping("/system/channel")
public class ChannelController extends BaseController {
    private String prefix = "system/channel";
    @Autowired
    private IChannelService channelService;
    @Autowired
    private IUserService userService;


    private static final Logger log = LoggerFactory.getLogger(ChannelController.class);

    List<ChannelXieyi> lists = new ArrayList<ChannelXieyi>();

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
    }

    @RequiresPermissions("system:channel:view")
    @GetMapping()
    public String operlog(ModelMap mmap) {
        mmap.put("userId",getUserId());
        return prefix + "/channel";
    }


    /**
     * 根据渠道日期改变渠道状态
     * @param channel
     * @return
     */
    @RequiresPermissions("system:channel:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Channel channel) {
        User user = getUser();
        String name=userService.selectUserRoleGroup(user.getUserId());
        startPage();
        List<Channel> list=new ArrayList<Channel>();
        if(name.contains("管理员")){
            //管理员
            list = channelService.selectChannelList(channel);
        }else if(name.equals("主管")){
            //主管
            list = channelService.selectCustomerListCharge(user.getDeptId());
        }else if(name.equals("总监")){
            //总监
            list = channelService.selectCustomerListMajordomo(user.getDeptId());
        }else {
            //业务员
            list = channelService.selectCustomerListSalesman(user.getUserId());
        }

//        Date date = new Date();
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//    for(Channel channel1:list) {
//       Channel channel2 = channelService.selectProtocolDateById(channel1.getChannelId());
//        if (channel2 != null) {
//            if (((channel2.getProtocolDate())).before(date)) {
//             System.out.print("停用");
//             channel1.setStatus("1");
//         } else {
//              System.out.print("正常");
//              channel1.setStatus("0");
//          }
//         channelService.updateStatus(channel1);
//      }
//    }
        return getDataTable(list);
    }

    //
    @RequiresPermissions("system:channel:list")
    @PostMapping("/lists")
    @ResponseBody
    public TableDataInfo list(ChannelXieyi channelXieyi, Channel channel, ModelMap mmap) {
        startPage();
        return getDataTable(lists);

//    }
//       List<ChannelXieyi> lists;
//       lists.get(0).setChannelXieyiname("文件的name");
//        return getDataTable(files);
//        return "system"
    }

    @GetMapping("/yulan/{channelId}")
    public String detail(@PathVariable("channelId") Long channelId, ModelMap mmap) {
        mmap.put("channel", channelId);
        return "system/channel/down";
//    return getDataTable(lists);
    }

    /**
     * 在线预览
     * @param channel
     * @return
     */
    @PostMapping("/listFile")
    @ResponseBody
    public TableDataInfo listFile(ChannelXieyi channel) {
        lists = new ArrayList<ChannelXieyi>();
        startPage();
        String path="profile/qd"+String.valueOf(channel.getChannelId());
        //文件路径
        List<File> files = NewFileUploadUtils.getFiles("D:/profile" + "/qd" + String.valueOf(channel.getChannelId()));
        //遍历文件
        for (File f : files) {
            System.out.println(f.getName());
            String fName = f.getName().trim();
            ChannelXieyi channelXieyi = new ChannelXieyi();
            String fileName = fName.substring(fName.lastIndexOf("\\") + 1);
            String[] arr = fileName.split("\\.");
            String name = arr[0];
            if (channel.getChannelXieyiname() == null) {
                String type = arr[1];
                channelXieyi.setChannelId(channel.getChannelId());
                channelXieyi.setChannelXieyiname(name);
                channelXieyi.setChannellujing(path);
                channelXieyi.setChannelXieyitype(type);
            } else {
                if (channel.getChannelXieyiname().equals("")) {
                    String type = arr[1];
                    channelXieyi.setChannelId(channel.getChannelId());
                    channelXieyi.setChannellujing(path);
                    channelXieyi.setChannelXieyiname(name);
                    channelXieyi.setChannelXieyitype(type);
                } else {
                    if (name.contains(channel.getChannelXieyiname())) {
                        String type = arr[1];
                        channelXieyi.setChannelId(channel.getChannelId());
                        channelXieyi.setChannellujing(path);
                        channelXieyi.setChannelXieyiname(name);
                        channelXieyi.setChannelXieyitype(type);
                    }
                }
            }
            lists.add(channelXieyi);
        }
        return getDataTable(lists);
    }


    @Log(title = "渠道管理", action = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Channel channel) throws Exception {
        try {
            List<Channel> list = channelService.selectChannelList(channel);
            ExcelUtil<Channel> util = new ExcelUtil<Channel>(Channel.class);
            return util.exportExcel(list, "channel");
        } catch (Exception e) {
            return error("导出Excel失败，请联系网站管理员！");
        }
    }


    @RequiresPermissions("system:channel:remove")
    @Log(title = "渠道管理", action = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        try {
            String[] str = ids.split(",");
            for (String strs : str) {
                String path = channelService.selectChannelById(Long.valueOf(strs)).getProtocol();
                //删除文件夹
                if (path != null) {
                    DeleteFile.delAllFile(path);
                    DeleteFile.delFolder(path);
                }
            }
            return toAjax(channelService.deleteChannelByIds(ids));
        } catch (Exception e) {
            return error(e.getMessage());
        }
    }

    /**
     * 新增渠道
     */
    @GetMapping("/add/{userId}")
    public String add(ModelMap mmap) {
        //直接获取的登陆人的id，姓名
//        mmap.put("userId",getUserId());
//        mmap.put("userName", getUser().getUserName());
        return prefix + "/add";
    }

    /**
     * 新增保存渠道
     */
    @RequiresPermissions("system:channel:add")
    @Log(title = "渠道管理", action = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Channel channel) {
        return toAjax(channelService.insertChannel(channel));
    }

    /**
     * 修改渠道
     */
    @GetMapping("/edit/{channelId}")
    public String edit(@PathVariable("channelId") Long channelId, ModelMap mmap,Channel channel) {
        mmap.put("channel", channelService.selectChannelById(channelId));
        return prefix + "/edit";
    }

    /**
     * 修改保存渠道
     *
     * @param channel
     * @return
     */
    @RequiresPermissions("system:channel:edit")
    @Log(title = "渠道管理", action = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Channel channel) {
        BigDecimal b = new BigDecimal(String.valueOf(channel.getFenBiLi()));
        BigDecimal c = new BigDecimal(String.valueOf(100));
        channel.setFenBiLi(Double.toString(b.divide(c, 6, ROUND_UNNECESSARY).doubleValue()));
        return toAjax(channelService.updateChannel(channel));
    }

    /**
     * 查看渠道
     */
    @GetMapping("/query/{channelId}")
    public String query(@PathVariable("channelId") Long channelId, ModelMap mmap) {
        mmap.put("channel", channelService.selectChannelById(channelId));
        return prefix + "/query";
}

    @RequiresPermissions("system:channel:upload")
    @GetMapping("/upload/{channelId}")
    public String upload(Channel channel, ModelMap mmap) {
        channel = channelService.selectChannelById(channel.getChannelId());
        mmap.put("channel", channel);
        return prefix + "/upload";
    }

    /**
     * 上传影像件
     */
    @PostMapping("/uploadSave")
    @ResponseBody
    public AjaxResult uploadSave(Channel channel, @RequestParam("uploadFile") MultipartFile[] file) {
        Map map = new HashMap();
        int su = 0;
        String xu = "";
        try {
//            if (channel.getChannelName() != 0) {
//                channel.setChannelId(uploadImage.getRenewId());
//                xu = "续保";
//            }

            if (file.length > 0) {
                //多文件上传
                map = NewFileUploadUtils.uploadNewMany(file, "qd" + String.valueOf(channel.getChannelId()));
                log.info("====上传影像件状态===" + xu + "==" + map.get("mes") + "订单号：" + channel.getChannelId());

                if (map.get("mes").toString().contains("成功")) {
                    if ("0" == map.get("separator")) {
                        //已经存在的数据
                        su = channelService.updateChannel(channel);
                    } else {
                        String osName = System.getProperties().getProperty("os.name");
                        if (osName.equals("Linux")) {
                            channel.setLinuxPath(map.get("path").toString());
                        } else {
                            channel.setProtocol(map.get("path").toString());
                        }
                        // uploadImage.setOrderType(uploadImage.getCustomerSo() + "");
                        channel.setProtocol(map.get("path").toString());
                        su = channelService.updateChannel(channel);
                    }
                }
            } else {
                map.put("mes", "请选择上传文件!");
            }
        } catch (Exception e) {
            log.error("上传影像异常", e);
            return error("上传影像件失败,请稍后重试!");
        }
        return toAjaxMes(su, map.get("mes").toString());
    }


    //待生成的zip包名
    // String zipName = String.valueOf(new Date().getTime());
    @RequiresPermissions("system:channel:download")
    @GetMapping("/download/{channelId}")
    @ResponseBody
    public String download(HttpServletResponse response, Channel channel) {

        try {
            //待生成的zip包名
            String zipName = "qd" + String.valueOf(channel.getChannelId());
            //数据库中文件的保存路径
            String sourceFilePath = "";
            if(sourceFilePath!=null){
                //待生成的zip保存路径
                String osName = System.getProperties().getProperty("os.name");
                System.out.println("----系统是---"+osName);
                String filePath = "";
                String zipFilePath ="";
//                String zipFilePath = "D:\\yasuobao";
                String path="";
                if (osName.equals("Linux")) {
                    filePath = "/var/opt/yasuobao/";
                    zipFilePath="/var/opt/yasuobao";
                    sourceFilePath=channelService.selectChannelById(channel.getChannelId()).getLinuxPath();
                } else {
                    filePath = "D:/yasuobao\\";
                    zipFilePath = "D:/yasuobao";
                  sourceFilePath=channelService.selectChannelById(channel.getChannelId()).getProtocol();
                }
                path=filePath+zipName+".zip";
                //压缩
                FileToZip.fileToZip(sourceFilePath , zipFilePath , zipName);
                //压缩包的绝对路径+完整压缩包名字
//                String path="D:\\yasuobao\\"+zipName+".zip";
                // path是指欲下载的文件的路径。
                File file = new File(path);
                // 取得文件名。
                String filename = file.getName();
                // 取得文件的后缀名。
                String ext = filename.substring(filename.lastIndexOf(".") + 1).toUpperCase();
                // 以流的形式下载文件。
                InputStream fis = new BufferedInputStream(new FileInputStream(path));
                byte[] buffer = new byte[fis.available()];
                fis.read(buffer);
                fis.close();
                // 清空response
                response.reset();
                // 设置response的Header
                response.addHeader("Content-Disposition", "attachment;filename=" + new String(filename.getBytes("utf-8"),"iso-8859-1"));
                response.addHeader("Content-Length", "" + file.length());
                OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
                response.setContentType("application/octet-stream");
                toClient.write(buffer);
                toClient.flush();
                toClient.close();


//            if (sourceFilePath != null) {
//                //待生成的zip保存路径
//                String zipFilePath = "D:\\yasuobao";
//                //压缩
//                FileToZip.fileToZip(sourceFilePath, zipFilePath, zipName);
//                //压缩包的绝对路径+完整压缩包名字
//                String path = "D:\\yasuobao\\" + zipName + ".zip";
//                // path是指欲下载的文件的路径。
//                File file = new File(path);
//                // 取得文件名。
//                String filename = file.getName();
//                // 取得文件的后缀名。
//                String ext = filename.substring(filename.lastIndexOf(".") + 1).toUpperCase();
//                // 以流的形式下载文件。
//                InputStream fis = new BufferedInputStream(new FileInputStream(path));
//                byte[] buffer = new byte[fis.available()];
//                fis.read(buffer);
//                fis.close();
//                // 清空response
//                response.reset();
//                // 设置response的Header
//                response.addHeader("Content-Disposition", "attachment;filename=" + new String(filename.getBytes()));
//                response.addHeader("Content-Length", "" + file.length());
//                OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
//                response.setContentType("application/octet-stream");
//                toClient.write(buffer);
//                toClient.flush();
//                toClient.close();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return "对不起！该条协议您还没有上传影像不能进行下载！";
//        return response;
    }


    /**
     * 校验字典类型
     */
    @PostMapping("/checkChannelNameUnique")
    @ResponseBody
    public String checkChannelNameUnique(Channel channel) {
        String uniqueFlag = "0";
        if (channel != null) {
            uniqueFlag = channelService.checkChannelNameUnique(channel);
        }
        return uniqueFlag;
    }
    /**
     *上传excel表
     */
    @RequiresPermissions("order:order:batchAdd")
    @GetMapping("/uploadBath")
    public String uploadBath(Channel channel,ModelMap mmap) {

        return prefix + "/uploadBath";
    }

    /**
     * 导入人员清单数据
     */
    @RequiresPermissions("system:channel:batchAdd")
    @PostMapping("/excelSave")
    @ResponseBody
    public AjaxResult excelSave(Channel channel,@RequestParam("uploadFile") MultipartFile file)
    {
        String message="";
        //判断文件是否为空
        if(file==null){
            message="文件不能为空！";
            return toAjaxMes(0,message);
        }

        //获取文件名
        String fileName=file.getOriginalFilename();

        //验证文件名是否合格
        if(!NewFileUploadUtils.validateExcel(fileName)){
            message="文件必须是excel格式！";
            return toAjaxMes(0,message);
        }

        //进一步判断文件内容是否为空（即判断其大小是否为0或其名称是否为null）
        long size=file.getSize();
        if(StringUtils.isEmpty(fileName) || size==0){
            message="文件不能为空！";
            return toAjaxMes(0,message);
        }

        //批量导入
        message = channelService.batchImport(channel,file);

        if(message.contains("行")){
            return error(message);
        }else{
            return success(message);
        }
      // return toAjaxMes(1,message);
    }

}