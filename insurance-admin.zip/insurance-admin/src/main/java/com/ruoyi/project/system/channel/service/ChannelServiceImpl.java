package com.ruoyi.project.system.channel.service;

import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.support.Convert;
import com.ruoyi.common.utils.NewFileUploadUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.security.ShiroUtils;
import com.ruoyi.project.system.channel.domain.Channel;
import com.ruoyi.project.system.channel.mapper.ChannelMapper;
import com.ruoyi.project.system.user.domain.User;
import com.ruoyi.project.system.user.mapper.UserMapper;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.*;

import static java.math.BigDecimal.ROUND_UNNECESSARY;

/**
 *Channel渠道信息 服务层处理
 * 
 * @author ruoyi
 */
@Service
public class ChannelServiceImpl implements  IChannelService
{
    @Autowired
    private ChannelMapper channelMapper;
    @Autowired
    private UserMapper userMapper;


    /**
     * 查询渠道信息集合
     *
     * @param channel 渠道信息
     * @return 渠道信息集合
     */
    @Override
    public List<Channel> selectChannelList(Channel channel)
    {
        return channelMapper.selectChannelList(channel);
    }

    /**
     * 查询所有渠道
     *
     * @return 渠道列表
     */
    @Override
    public List<Channel> selectChannelAll()
    {
        return channelMapper.selectChannelAll();
    }
    /**
     * 通过渠道ID查询渠道信息
     *
     * @param channelId 渠道ID
     * @return 角色对象信息
     */
    @Override
    public Channel selectChannelById(Long channelId)
    {
        Channel channel = channelMapper.selectChannelById(channelId);
        BigDecimal b = new BigDecimal(String.valueOf(channel.getFenBiLi()));
        BigDecimal c = new BigDecimal(String.valueOf(100));
        channel.setFenBiLi(Double.toString(b.multiply(c).doubleValue()));
        return channel;
    }

    /**
     * 通过渠道ID删除渠道
     *
     * @param channelId 渠道ID
     * @return 结果
     */
    @Override
    public int deleteChannelById(Long channelId){return channelMapper.deleteChannelById(channelId);}

    /**
     * 批量删除渠道信息
     *
     * @param ids 需要删除的数据ID
     * @throws Exception
     */
    @Override
    public int deleteChannelByIds(String ids) throws Exception {
        Long[] channelIds = Convert.toLongArray(ids);
        for (Long channelId : channelIds)
        {
            Channel channel = selectChannelById(channelId);

//            if (countUserChannelById(channelId) > 0)
//            {
//                throw new Exception(String.format("%1$s已分配,不能删除",channel.getChannelName()));
//            }
        }
        return channelMapper.deleteChannelByIds(channelIds);
    }

    /**
     * 修改保存渠道信息
     *
     * @param channel 渠道信息
     * @return 结果
     */
    @Override
    public int updateChannel(Channel channel) {
//        BigDecimal b = new BigDecimal(String.valueOf(channel.getFenBiLi()));
//        BigDecimal c = new BigDecimal(String.valueOf(100));
//        channel.setFenBiLi(Double.toString( b.divide(c,6,ROUND_UNNECESSARY).doubleValue()));
//        channel.setFenBiLi(Double.toString( b.divide(c,6, RoundingMode.HALF_UP).doubleValue()));
//        Double fenbili = Double.parseDouble(channel.getFenBiLi())/100;
//        channel.setFenBiLi(fenbili.toString());
        channel.setCreateBy(ShiroUtils.getLoginName());
        return channelMapper.updateChannel(channel);
    }

    /**
     * 新增保存渠道信息
     *
     * @param channel 渠道信息
     * @return 结果
     */
    @Override
    public int insertChannel(Channel channel) {
        BigDecimal b = new BigDecimal(String.valueOf(channel.getFenBiLi()));
        BigDecimal c = new BigDecimal(String.valueOf(100));
        channel.setFenBiLi(Double.toString( b.divide(c,6,ROUND_UNNECESSARY).doubleValue()));
        channel.setCreateBy(ShiroUtils.getLoginName());
        return channelMapper.insertChannel(channel);
    }



    /**
     * 校验字典类型称是否唯一
     *
     * @param cha 字典类型
     * @return 结果
     */
    @Override
    public String checkChannelNameUnique(Channel cha)
    {
        Long channelId = StringUtils.isNull(cha.getChannelId()) ? -1L : cha.getChannelId();
        Channel  channel= channelMapper.checkChannelNameUnique(cha.getChannelName());
        if (StringUtils.isNotNull(channel) && !channel.getChannelId() .equals(channelId) )
        {
            return UserConstants.DICT_TYPE_NOT_UNIQUE;
        }
        return UserConstants.DICT_TYPE_UNIQUE;
    }

    //改变渠道状态
    @Override
    public int updateStatus(Channel channel) {
        channel.setCreateBy(ShiroUtils.getLoginName());
        return channelMapper.updateStatus(channel);
    }

  //查询渠道日期
    @Override
    public Channel selectProtocolDateById(Long channelId) {
        return channelMapper.selectProtocolDateById(channelId);
    }

    /**
     *总监
     */
    @Override
    public List<Channel> selectCustomerListMajordomo(long deptId) {
        return channelMapper.selectCustomerListMajordomo(deptId);
    }
    /**
     *主管
     */
    @Override
    public List<Channel> selectCustomerListCharge(long deptId) {
        return channelMapper.selectCustomerListCharge(deptId);
    }
    /**
     *业务员
     */
    @Override
    public List<Channel> selectCustomerListSalesman(long userIdd) {
        return channelMapper.selectCustomerListSalesman(userIdd);
    }

//批量新增
    @Override
    public String batchImport(Channel channel, MultipartFile mfile) {
        String fileName = mfile.getOriginalFilename();
        //初始化输入流
        String msg="";
        InputStream is = null;
        try{
            is = mfile.getInputStream();
            Workbook book = null;
            if(NewFileUploadUtils.isExcel2003(mfile.getOriginalFilename())){
                book = new HSSFWorkbook(is);
            }else{
                book = new XSSFWorkbook(is);
            }
            //根据excel里面的内容读取知识库信息
//            ExcelOrderAgainUtil excelOrderAgainUtil = new ExcelOrderAgainUtil();
//            msg = excelOrderAgainUtil.readExcel(book,channel);
            return readExcelValue(book,channel);
        }catch(Exception e){
            e.printStackTrace();
        } finally{
            if(is !=null)
            {
                try{
                    is.close();
                }catch(IOException e){
                    is = null;
                    e.printStackTrace();
                }
            }
        }
        return msg;
    }


    /**
     * 解析Excel里面的数据
     *
     * @param wb
     * @param
     * @return
     */
    private String readExcelValue(Workbook wb, Channel channels) {

        //错误信息接收器
        String errorMsg = "";
        //得到第一个shell
        Sheet sheet = wb.getSheetAt(0);
//		Sheet sheet = wb.getSheetAt(0);
        //得到Excel的行数
        int totalRows = sheet.getPhysicalNumberOfRows();
        //总列数
        int totalCells = 0;
        //得到Excel的列数(前提是有行数)，从第3行算起
        if (totalRows >= 1 && sheet.getRow(1) != null) {
            totalCells = sheet.getRow(1).getLastCellNum();
        }
        List<Channel> userKnowledgeBaseList = new ArrayList<Channel>();
        Channel channel;
        String channelName = "";
        String br = "<br/>";

        //业务员
        String strUser = "";
        List<User> userList = userMapper.selectUserStatusAll();
        for(User users : userList){
            strUser +=users.getUserName()+',';
        }
        String arrUser [] = strUser.split(",");
        //循环Excel行数,从第2行开始。标题不入库
        for (int r = 1; r < totalRows; r++) {
            String rowMessage = "";
            Row row = sheet.getRow(r);
            if (row == null) {
                errorMsg += br + "第" + (r + 1) + "行数据有问题，请仔细检查！";
                continue;
            }
            channel = new Channel();
            channelName = channels.getChannelName();
          //  order.setOrderId(orders.getOrderId());
            //  orderUser.setOrderType(orderPeoples.getOrderType());
            //循环Excel的列
            for (int c = 0; c < totalCells; c++) {
                Cell cell = row.getCell(c);
                if (null != cell) {
                    row.getCell(c).setCellType(Cell.CELL_TYPE_STRING);
                    if (c == 0) {
                        //订单号
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "渠道名称不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "渠道名称的字数不能超过1000；";
                        }
                       channel.setChannelName(cell.getStringCellValue());
                    } else if (c == 1) {
                        //调整前业务员
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "业务员不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "业务员的字数不能超过1000；";
                        }else if (!strUser.contains(cell.getStringCellValue())){
                            rowMessage += "业务员还没有添加；";
                        }
                        //设置业务员id
                        if(strUser.contains(cell.getStringCellValue())) {
                            for (int index = 0; index < arrUser.length; index++) {
                                if (arrUser[index].equals(cell.getStringCellValue())) {
                                    channel.setUserId(userList.get(index).getUserId());
                                }
                            }
                        }
                       channel.setUserName(cell.getStringCellValue());
                    } else if (c ==2) {
                        //客户名称
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "渠道分成比例不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "渠道分成比例的字数不能超过1000；";
                        }
                       channel.setFenBiLi(cell.getStringCellValue());
                    } else if (c == 3) {
                        //失效日期
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "渠道失效日期不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "渠道失效日期的字数不能超过1000；";
                        }
                        channel.setProtocolDate(cell.getStringCellValue());
                    }else if (c == 4) {
                        //缴费方式
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "状态不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "状态的字数不能超过1000；";
                        }
                        channel.setStatus(cell.getStringCellValue());
                    }
                } else {
                    rowMessage += "第" + (c + 1) + "列数据有问题，请仔细检查；";
                }
            }
            //拼接每行的错误提示
            if (!StringUtils.isEmpty(rowMessage)) {
                errorMsg += br + "第" + (r + 1) + "行，" + rowMessage;
            } else {
                userKnowledgeBaseList.add(channel);
            }
        }

        if (StringUtils.isEmpty(errorMsg)) {
            // this.deleteOrderPeopleByOrderId(orderid);
            for (Channel userKnowledgeBase : userKnowledgeBaseList) {
                this.insertChannel(userKnowledgeBase);
            }
            errorMsg = "导入成功，共" + userKnowledgeBaseList.size() + "条数据！";
        }
        return errorMsg;
    }
}
