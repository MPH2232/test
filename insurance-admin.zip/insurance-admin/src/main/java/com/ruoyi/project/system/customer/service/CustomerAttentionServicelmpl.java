package com.ruoyi.project.system.customer.service;

import com.ruoyi.common.support.Convert;
import com.ruoyi.common.utils.security.ShiroUtils;
import com.ruoyi.project.system.customer.domain.CustomerAttention;
import com.ruoyi.project.system.customer.domain.CustomerContacts;
import com.ruoyi.project.system.customer.mapper.CustomerAttentionMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by x on 2018/8/8.
 */
@Service
public class CustomerAttentionServicelmpl implements lCustomerAttentionService {

    @Autowired
    private CustomerAttentionMapper customerAttentionMapper;


    @Override
    public List<CustomerAttention> selectCustomerAttentionList(CustomerAttention customerAttention) {
        return customerAttentionMapper.selectCustomerAttentionList(customerAttention);
    }

    /*查询所有收件人信息*/
    @Override
    public List<CustomerAttention> selectCustomerAttentionAll() {
        return customerAttentionMapper.selectCustomerAttentionAll();
    }

    @Override
    public CustomerAttention selectCustomerAttentionById(Long id) {
        return customerAttentionMapper.selectCustomerAttentionById(id);
    }

    /*根据客户表Id查询收件人信息*/
    @Override
    public List<CustomerAttention> selectCustomerAttentionByCustomerId(int customerId) {
        return customerAttentionMapper.selectCustomerAttentionByCustomerId(customerId);
    }

    /**
     * 新增收件人信息
     * @param customerAttention 收件人信息
     * @return
     */
    @Override
    public int insertCustomerAttention(CustomerAttention customerAttention) {
        customerAttention.setCreateBy(ShiroUtils.getLoginName());
        return customerAttentionMapper.insertCustomerAttention(customerAttention);
    }
    /**
     *修改保存收件人信息
     */
    @Override
    public int updateCustomerAttention(CustomerAttention customerAttention) {
        customerAttention.setUpdateBy(ShiroUtils.getLoginName());
        return customerAttentionMapper.updateCustomerAttention(customerAttention);
    }
    /**
     * 批量删除收件人信息
     */
    @Override
    public int deleteCustomerAttentionByIds(String ids) throws Exception {
        Long[] customerAttentionIds = Convert.toLongArray(ids);
        for (Long id : customerAttentionIds)
        {
            CustomerAttention customerAttention = selectCustomerAttentionById(id);
        }
        return customerAttentionMapper.deleteCustomerAttentionByIds(customerAttentionIds);
    }
    }


