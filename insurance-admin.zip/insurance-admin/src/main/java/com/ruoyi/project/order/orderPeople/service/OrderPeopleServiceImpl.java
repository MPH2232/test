package com.ruoyi.project.order.orderPeople.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.ruoyi.common.utils.NewFileUploadUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.poi.*;
import com.ruoyi.project.order.orderPeople.domain.OrderPeopleCount;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.order.orderPeople.mapper.OrderPeopleMapper;
import com.ruoyi.project.order.orderPeople.domain.OrderPeople;
import com.ruoyi.common.support.Convert;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

/**
 * 人员清单，关联订单， 服务层实现
 * 
 * @author ruoyi
 * @date 2018-08-23
 */
@Service
public class OrderPeopleServiceImpl implements IOrderPeopleService 
{
	@Autowired
	private OrderPeopleMapper orderPeopleMapper;

	/**
     * 查询人员清单，关联订单，信息
     * 
     * @param id 人员清单，关联订单，ID
     * @return 人员清单，关联订单，信息
     */
    @Override
	public OrderPeople selectOrderPeopleById(Integer id)
	{
	    return orderPeopleMapper.selectOrderPeopleById(id);
	}

	@Override
	public  List<OrderPeopleCount>  selectOrderPeopleByPlans(String orderId, String orderType)
	{
		return orderPeopleMapper.selectOrderPeopleByPlans(orderId,orderType);
	}

	/**
     * 查询人员清单，关联订单，列表
     * 
     * @param orderPeople 人员清单，关联订单，信息
     * @return 人员清单，关联订单，集合
     */
	@Override
	public List<OrderPeople> selectOrderPeopleList(OrderPeople orderPeople)
	{
	    return orderPeopleMapper.selectOrderPeopleList(orderPeople);
	}
	
    /**
     * 新增人员清单，关联订单，
     * 
     * @param orderPeople 人员清单，关联订单，信息
     * @return 结果
     */
	@Override
	public int insertOrderPeople(OrderPeople orderPeople)
	{
	    return orderPeopleMapper.insertOrderPeople(orderPeople);
	}
	
	/**
     * 修改人员清单，关联订单，
     * 
     * @param orderPeople 人员清单，关联订单，信息
     * @return 结果
     */
	@Override
	public int updateOrderPeople(OrderPeople orderPeople)
	{
	    return orderPeopleMapper.updateOrderPeople(orderPeople);
	}

	/**
     * 删除人员清单，关联订单，对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteOrderPeopleByIds(String ids)
	{
		return orderPeopleMapper.deleteOrderPeopleByIds(Convert.toStrArray(ids));
	}

	/**
	 * 删除人员清单，关联订单，对象
	 *
	 * @param orderid 需要删除的数据ID
	 * @return 结果
	 */
	@Override
	public int deleteOrderPeopleByOrderId(String orderid)
	{
		return orderPeopleMapper.deleteOrderPeopleByOrderId(orderid);
	}

	/**
	 * 上传excel文件到临时目录后并开始解析
	 * @param orderPeople
	 * @param mfile
	 * @return
	 */
	@Transactional
	public String batchImport(OrderPeople orderPeople, MultipartFile mfile){
		//获取Excel的名字
		String fileName = mfile.getOriginalFilename();
//		File uploadDir = new  File("E:\\fileupload");
//		//创建一个目录 （它的路径名由当前 File 对象指定，包括任一必须的父路径。）
//		if (!uploadDir.exists()) uploadDir.mkdirs();
//		//新建一个文件
//		File tempFile = new File("E:\\fileupload\\" + new Date().getTime() + ".xlsx");
		//初始化输入流
		InputStream is = null;
		String msg="";
		try{
			//将上传的文件写入新建的文件中
//			mfile.transferTo(tempFile);
			//装载流
			is = mfile.getInputStream();
//			POIFSFileSystem fs = new POIFSFileSystem(mfile.getInputStream());
//			HSSFWorkbook wb= new HSSFWorkbook(fs);
			Workbook book = null;
			if(NewFileUploadUtils.isExcel2003(mfile.getOriginalFilename())){
					book = new HSSFWorkbook(is);
			}else{
				book = new XSSFWorkbook(is);
			}
			//获取第一个sheet页
//			HSSFSheet sheet = hw.getSheetAt(0);
			//根据新建的文件实例化输入流
//			is = mfile.getInputStream();
			//根据版本选择创建Workbook的方式
//			Workbook wb = WorkbookFactory.create(is);
//			Sheet sheet = wb.getSheet("人员清单");
//			if (!sheetName.trim().equals(""))
//			{
//				sheet = workbook.getSheet(sheetName); // 如果指定sheet名,则取指定sheet中的内容.
//			}
//			if (sheet == null)
//			{
//				sheet = workbook.getSheetAt(0); // 如果传入的sheet名不存在则默认指向第1个sheet.
//			}
			//根据excel里面的内容读取知识库信息
//			return readExcelValue(book,orderPeople);
			if(fileName.contains("中意")){
				ZhongYiPeopleUtil zhongYiPeopleUtil = new ZhongYiPeopleUtil();
				msg = zhongYiPeopleUtil.readExcel(book,orderPeople);
			}else if(fileName.contains("平安健康")) {
				PingAnJianKangPeopleUtil pingAnJianKangPeopleUtil = new PingAnJianKangPeopleUtil();
				msg = pingAnJianKangPeopleUtil.readExcel(book, orderPeople);
			}else if(fileName.contains("复兴联合") || fileName.contains("永安")){
				FuXinLianHePeopleUtil fuXinLianHePeopleUtil = new FuXinLianHePeopleUtil();
				msg = fuXinLianHePeopleUtil.readExcel(book, orderPeople);
			}else if(fileName.contains("大地")){
				DaDiPeopleUtil daDiPeopleUtil = new DaDiPeopleUtil();
				msg = daDiPeopleUtil.readExcel(book, orderPeople);
			}else if(fileName.contains("太保安联")){
				TaiBaoAnLianPeopleUtil taiBaoAnLianPeopleUtil = new TaiBaoAnLianPeopleUtil();
				msg = taiBaoAnLianPeopleUtil.readExcel(book,orderPeople);
			}else if(fileName.contains("平安养老医疗")){
				PingAnYangLaoYiLiaoPeopleUtil pingAnYangLaoYiLiaoPeopleUtil = new PingAnYangLaoYiLiaoPeopleUtil();
				msg = pingAnYangLaoYiLiaoPeopleUtil.readExcel(book,orderPeople);
			}else if(fileName.contains("平安养老意外")){
				PingAnYangLaoYiWaiPeopleUtil pingAnYangLaoYiWaiPeopleUtil = new PingAnYangLaoYiWaiPeopleUtil();
				msg = pingAnYangLaoYiWaiPeopleUtil.readExcel(book,orderPeople);
			}else if(fileName.contains("利宝")){
				LiBaoPeopleUtil liBaoPeopleUtil = new LiBaoPeopleUtil();
				msg = liBaoPeopleUtil.readExcel(book,orderPeople);
			}else if(fileName.contains("苏黎世")){
				SuLiShiPeopleUtil suLiShiPeopleUtil = new SuLiShiPeopleUtil();
				msg = suLiShiPeopleUtil.readExcel(book,orderPeople);
			}else if(fileName.contains("招商信诺")){
				ZhaoShangXinNuoPeopleUtil zhaoShangXinNuoPeopleUtil = new ZhaoShangXinNuoPeopleUtil();
				msg = zhaoShangXinNuoPeopleUtil.readExcel(book,orderPeople);
			}
		}catch(Exception e){
			e.printStackTrace();
		} finally{
			if(is !=null)
			{
				try{
					is.close();
				}catch(IOException e){
					is = null;
					e.printStackTrace();
				}
			}
		}
//		return "导入出错！请检查数据格式！";
		return msg;
	}


//	/**
//	 * 解析Excel里面的数据
//	 * @param wb
//	 * @return
//	 */
//	private String readExcelValue(Workbook wb,OrderPeople orderPeoples) {
//
//		//错误信息接收器
//		String errorMsg = "";
//		//得到第一个shell
//		Sheet sheet = wb.getSheetAt(0);
////		Sheet sheet = wb.getSheetAt(0);
//		//得到Excel的行数
//		int totalRows = sheet.getPhysicalNumberOfRows();
//		//总列数
//		int totalCells = 0;
//		//得到Excel的列数(前提是有行数)，从第3行算起
//		if (totalRows >= 3 && sheet.getRow(1) != null) {
//			totalCells = sheet.getRow(1).getLastCellNum();
//		}
//		List<OrderPeople> userKnowledgeBaseList = new ArrayList<OrderPeople>();
//		OrderPeople orderPeople;
//String orderid="";
//		String br = "<br/>";
//
//		//循环Excel行数,从第3行开始。标题不入库
//		for (int r = 2; r < totalRows; r++) {
//			String rowMessage = "";
//			Row row = sheet.getRow(r);
//			if (row == null) {
//				errorMsg += br + "第" + (r + 1) + "行数据有问题，请仔细检查！";
//				continue;
//			}
//			orderPeople = new OrderPeople();
//			orderid=orderPeoples.getOrderId();
//			orderPeople.setOrderId(orderPeoples.getOrderId());
//			orderPeople.setOrderType(orderPeoples.getOrderType());
//			//循环Excel的列
//			for (int c = 0; c < totalCells; c++) {
//				Cell cell = row.getCell(c);
//				if (null != cell) {
//					row.getCell(c).setCellType(Cell.CELL_TYPE_STRING);
//					if (c == 0) {
//						//序号
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
//							rowMessage += "序号不能为空；";
//						} else if (cell.getStringCellValue().length() > 6) {
//							rowMessage += "序号的字数不能超过6；";
//						}
////						tempUserKB.setQuestion(question);
//					} else if (c == 1) {
//						//层级名称
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
//							rowMessage += "层级名称不能为空；";
//						} else if (cell.getStringCellValue().length() > 1000) {
//							rowMessage += "层级名称的字数不能超过1000；";
//						}
//						orderPeople.setCategory(cell.getStringCellValue());
//					}else if (c == 2) {
//						//被保险人属性
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
//							rowMessage += "被保险人属性不能为空；";
//						} else if (cell.getStringCellValue().length() > 1000) {
//							rowMessage += "被保险人属性的字数不能超过1000；";
//						}
//						orderPeople.setInsuredType(cell.getStringCellValue());
//					}else if (c == 3) {
//						//姓名
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
//							rowMessage += "姓名不能为空；";
//						} else if (cell.getStringCellValue().length() > 1000) {
//							rowMessage += "姓名的字数不能超过1000；";
//						}
//						orderPeople.setPeopleName(cell.getStringCellValue());
//					}else if (c == 4) {
//						//证件类型
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
//							rowMessage += "证件类型不能为空；";
//						} else if (cell.getStringCellValue().length() > 1000) {
//							rowMessage += "证件类型的字数不能超过1000；";
//						}
//						orderPeople.setIdcardType(cell.getStringCellValue());
//					}else if (c == 5) {
//						//证件号
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
//							rowMessage += "证件号不能为空；";
//						} else if (cell.getStringCellValue().length() > 1000) {
//							rowMessage += "证件号的字数不能超过1000；";
//						}
//						orderPeople.setIdcard(cell.getStringCellValue());
//					}else if (c == 6) {
//						//出生年月日
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
//							rowMessage += "出生年月日不能为空；";
//						} else if (cell.getStringCellValue().length() > 1000) {
//							rowMessage += "出生年月日的字数不能超过1000；";
//						}
//						orderPeople.setBirth(cell.getStringCellValue());
//					}else if (c == 7) {
//						//性别
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
//							rowMessage += "性别不能为空；";
//						} else if (cell.getStringCellValue().length() > 1000) {
//							rowMessage += "性别的字数不能超过1000；";
//						}
//						orderPeople.setSex(cell.getStringCellValue());
//					}else if (c == 8) {
//						//手机号
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
////							rowMessage += "手机号不能为空；";
//						} else if (cell.getStringCellValue().length() > 1000) {
//							rowMessage += "手机号的字数不能超过1000；";
//						}
//						orderPeople.setPhone(cell.getStringCellValue());
//					}else if (c == 9) {
//						//E-mail
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
////							rowMessage += "E-mail不能为空；";
//						} else if (cell.getStringCellValue().length() > 1000) {
//							rowMessage += "E-mail的字数不能超过1000；";
//						}
//						orderPeople.setEmail(cell.getStringCellValue());
//					}else if (c == 10) {
//						//账户名称
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
//							rowMessage += "账户名称不能为空；";
//						} else if (cell.getStringCellValue().length() > 1000) {
//							rowMessage += "账户名称的字数不能超过1000；";
//						}
//						orderPeople.setAccountName(cell.getStringCellValue());
//					}else if (c == 11) {
//						//银行全称
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
//							rowMessage += "银行全称不能为空；";
//						} else if (cell.getStringCellValue().length() > 1000) {
//							rowMessage += "银行全称的字数不能超过1000；";
//						}
//						orderPeople.setBankName(cell.getStringCellValue());
//					}else if (c == 12) {
//						//分行名称
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
//							rowMessage += "分行名称不能为空；";
//						} else if (cell.getStringCellValue().length() > 1000) {
//							rowMessage += "分行名称的字数不能超过1000；";
//						}
//						orderPeople.setBankbrName(cell.getStringCellValue());
//					}else if (c == 13) {
//						//支行名称
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
////							rowMessage += "支行名称不能为空；";
//						} else if (cell.getStringCellValue().length() > 1000) {
//							rowMessage += "支行名称的字数不能超过1000；";
//						}
//						orderPeople.setBanksubName(cell.getStringCellValue());
//					}else if (c == 14) {
//						//银行账号
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
//							rowMessage += "银行账号不能为空；";
//						} else if (cell.getStringCellValue().length() > 1000) {
//							rowMessage += "银行账号的字数不能超过1000；";
//						}
//						orderPeople.setBankNo(cell.getStringCellValue());
//					}else if (c == 15) {
//						//一级机构（公司名称）
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
//							rowMessage += "公司名称不能为空；";
//						} else if (cell.getStringCellValue().length() > 50) {
//							rowMessage += "公司名称的字数不能超过50；";
//						}
//						orderPeople.setCompany(cell.getStringCellValue());
//					}else if (c == 16) {
//						//雇员编号
//						if (StringUtils.isEmpty(cell.getStringCellValue())) {
////							rowMessage += "雇员编号不能为空；";
//						} else if (cell.getStringCellValue().length() > 20) {
//							rowMessage += "雇员编号的字数不能超过20；";
//						}
//						orderPeople.setEmpNo(cell.getStringCellValue());
//					}
//				} else {
//					rowMessage += "第" + (c + 1) + "列数据有问题，请仔细检查；";
//				}
//			}
//			//拼接每行的错误提示
//			if (!StringUtils.isEmpty(rowMessage)) {
//				errorMsg += br + "第" + (r + 1) + "行，" + rowMessage;
//			} else {
//				userKnowledgeBaseList.add(orderPeople);
//			}
//		}
//
////		//删除上传的临时文件
////		if (tempFile.exists()) {
////			tempFile.delete();
////		}
//
//		//全部验证通过才导入到数据库
//		if (StringUtils.isEmpty(errorMsg)) {
//			this.deleteOrderPeopleByOrderId(orderid);
//			for (OrderPeople userKnowledgeBase : userKnowledgeBaseList) {
//				this.insertOrderPeople(userKnowledgeBase);
//			}
//			errorMsg = "导入成功，共" + userKnowledgeBaseList.size() + "条数据！";
//		}
//		return errorMsg;
//	}

	@Override
	public int addOrderPeople(HashMap<String, Object> map) {
		return orderPeopleMapper.addOrderPeople(map);
	}

	@Override
	public int insertOrderPeopleList(List<OrderPeople> orderPeopleList) {
		return orderPeopleMapper.insertOrderPeopleList(orderPeopleList);
	}

	@Override
	public int deleteOrderPeopleByPolicyNum(String policyNum) {
		return orderPeopleMapper.deleteOrderPeopleByPolicyNum(policyNum);
	}
}
