package com.ruoyi.project.system.supplier.mapper;
import com.ruoyi.project.system.supplier1.domain.Supplier;

import java.util.List;

/**
 * 供应商信息 数据层
 * 
 * @author ruoyi
 */
public interface SupplierMapper
{

    /**
     * 查询供应商数据集合
     * 
     * @param supplier 供应商信息
     * @return 供应商数据集合
     */
    public List<Supplier> selectSupplierList(Supplier supplier);

    /**
     * 查询所有供应商
     * 
     * @return 供应商列表
     */
    public List<Supplier> selectSupplierAll();

    /**
     * 查询所有供应商
     * 下拉框使用值
     * @return 供应商列表
     */
    public List<Supplier> selectSupplierAllOption();

    /**
     * 根据用户ID查询供应商
     * 
     * @param userId 用户ID
     * @return 供应商列表
     */
   // public List<Supplier1> selectSuppliersByUserId(Long userId);

    /**
     * 通过供应商ID查询供应商信息
     * 
     * @param supplierId 供应商ID
     * @return 角色对象信息
     */
    public Supplier selectSupplierById(Long supplierId);

    /**
     * 批量删除供应商信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteSupplierByIds(Long[] ids);

    /**
     * 修改供应商信息
     * 
     * @param supplier 供应商信息
     * @return 结果
     */
    public int updateSupplier(Supplier supplier);

    /**
     * 新增供应商信息
     * 
     * @param supplier 供应商信息
     * @return 结果
     */
    public int insertSupplier(Supplier supplier);




}
