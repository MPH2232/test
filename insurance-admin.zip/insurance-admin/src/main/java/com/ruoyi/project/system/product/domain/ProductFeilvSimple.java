package com.ruoyi.project.system.product.domain;

import com.ruoyi.framework.web.domain.BaseEntity;
import java.util.Date;

/**
 * 产品-简单费率（定制产品）表 f_product_feilv_simple
 * 
 * @author ruoyi
 * @date 2018-10-19
 */
public class ProductFeilvSimple extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 定制产品费率自增id */
	private Integer id;
	/** 产品名称 */
	private String productName;
	/** 产品表关联id */
	private Long productId;
	/** 年龄 */
	private String age;
	/** 性别 */
	private String sex;
	/** 计划 */
	private String plan;
	/** 保费 */
	private String planValue;
	/** 费率生效日期 */
	private Date startTime;
	/** 费率失效日期 */
	private Date endTime;
	/** 定制方案名称 */
	private String proName;
	/** 创建者 */
	private String createBy;
	/** 创建时间 */
	private Date createTime;
	/** 更新者 */
	private String updateBy;
	/** 更新时间 */
	private Date updateTime;

	/**
	 * 设置：定制产品费率自增id
	 */
	public void setId(Integer id) 
	{
		this.id = id;
	}
	
	/**
	 * 获取：定制产品费率自增id
	 */
	public Integer getId() 
	{
		return id;
	}
	
	/**
	 * 设置：产品名称
	 */
	public void setProductName(String productName) 
	{
		this.productName = productName;
	}
	
	/**
	 * 获取：产品名称
	 */
	public String getProductName() 
	{
		return productName;
	}
	
	/**
	 * 设置：产品表关联id
	 */
	public void setProductId(Long productId)
	{
		this.productId = productId;
	}
	
	/**
	 * 获取：产品表关联id
	 */
	public Long getProductId()
	{
		return productId;
	}
	
	/**
	 * 设置：年龄
	 */
	public void setAge(String age) 
	{
		this.age = age;
	}
	
	/**
	 * 获取：年龄
	 */
	public String getAge() 
	{
		return age;
	}
	
	/**
	 * 设置：性别
	 */
	public void setSex(String sex) 
	{
		this.sex = sex;
	}
	
	/**
	 * 获取：性别
	 */
	public String getSex() 
	{
		return sex;
	}
	
	/**
	 * 设置：计划
	 */
	public void setPlan(String plan) 
	{
		this.plan = plan;
	}
	
	/**
	 * 获取：计划
	 */
	public String getPlan() 
	{
		return plan;
	}
	
	/**
	 * 设置：保费
	 */
	public void setPlanValue(String planValue) 
	{
		this.planValue = planValue;
	}
	
	/**
	 * 获取：保费
	 */
	public String getPlanValue() 
	{
		return planValue;
	}
	
	/**
	 * 设置：费率生效日期
	 */
	public void setStartTime(Date startTime) 
	{
		this.startTime = startTime;
	}
	
	/**
	 * 获取：费率生效日期
	 */
	public Date getStartTime() 
	{
		return startTime;
	}
	
	/**
	 * 设置：费率失效日期
	 */
	public void setEndTime(Date endTime) 
	{
		this.endTime = endTime;
	}
	
	/**
	 * 获取：费率失效日期
	 */
	public Date getEndTime() 
	{
		return endTime;
	}
	
	/**
	 * 设置：定制方案名称
	 */
	public void setProName(String proName) 
	{
		this.proName = proName;
	}
	
	/**
	 * 获取：定制方案名称
	 */
	public String getProName() 
	{
		return proName;
	}
	
	/**
	 * 设置：创建者
	 */
	public void setCreateBy(String createBy) 
	{
		this.createBy = createBy;
	}
	
	/**
	 * 获取：创建者
	 */
	public String getCreateBy() 
	{
		return createBy;
	}
	
	/**
	 * 设置：创建时间
	 */
	public void setCreateTime(Date createTime) 
	{
		this.createTime = createTime;
	}
	
	/**
	 * 获取：创建时间
	 */
	public Date getCreateTime() 
	{
		return createTime;
	}
	
	/**
	 * 设置：更新者
	 */
	public void setUpdateBy(String updateBy) 
	{
		this.updateBy = updateBy;
	}
	
	/**
	 * 获取：更新者
	 */
	public String getUpdateBy() 
	{
		return updateBy;
	}
	
	/**
	 * 设置：更新时间
	 */
	public void setUpdateTime(Date updateTime) 
	{
		this.updateTime = updateTime;
	}
	
	/**
	 * 获取：更新时间
	 */
	public Date getUpdateTime() 
	{
		return updateTime;
	}
	
}
