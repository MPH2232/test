package com.ruoyi.project.system.product.domain;

import com.ruoyi.framework.aspectj.lang.annotation.Excel;

import java.util.Date;

/**
 * 高端费率模板实体
 * Created by x on 2018/8/21.
 */
public class FeilvComplex implements Cloneable{

    @Override
    public FeilvComplex clone() throws CloneNotSupportedException {
        return (FeilvComplex) super.clone();
    }

    private Long id;

    @Excel(name = "责任名称")
    private String dutyName;

    @Excel(name = "责任详情")
    private String dutyDetail;

    @Excel(name = "责任基数")
    private String dutyRatio;

    @Excel(name = "附加产品名称")
    private String fujiaProtocolName;

    @Excel(name = "年龄")
    private String age;

    @Excel(name = "计划")
    private String plan;

    @Excel(name = "计划金额")
    private String planValue;



    @Excel(name = "责任代码")
    private String dutyCode;

    @Excel(name = "产品名称")
    private String productName;

    @Excel(name = "产品id")
    private Long productId;



    @Excel(name = "关联责任")
    private String dutyRelated;

    @Excel(name = "责任范围")
    private String dutyScope;

    @Excel(name = "保障区域")
    private String regionName;

    @Excel(name = "区域Id")
    private String regionId;

    @Excel(name = "启动时间-Date类型")
    private Date startTime;

    @Excel(name = "结束时间-Date类型")
    private Date endTime;

    @Excel(name = "状态")
    private String status;

    @Excel(name = "创建者")
    private String createBy;

    @Excel(name = "创建时间")
    private Date createTime;

    @Excel(name = "更新者")
    private String updateBy;

    @Excel(name = "更新时间")
    private Date updateTime;

    @Excel(name = "高端产品费率id")
    private Long feilvId;

    /*计划数据集合*/
    private String chanpingList;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getFujiaProtocolName() {
        return fujiaProtocolName;
    }

    public void setFujiaProtocolName(String fujiaProtocolName) {
        this.fujiaProtocolName = fujiaProtocolName;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getPlan() {
        return plan;
    }

    public void setPlan(String plan) {
        this.plan = plan;
    }

    public String getPlanValue() {
        return planValue;
    }

    public void setPlanValue(String planValue) {
        this.planValue = planValue;
    }

    public String getDutyName() {
        return dutyName;
    }

    public void setDutyName(String dutyName) {
        this.dutyName = dutyName;
    }

    public String getDutyCode() {
        return dutyCode;
    }

    public void setDutyCode(String dutyCode) {
        this.dutyCode = dutyCode;
    }

    public String getDutyRatio() {
        return dutyRatio;
    }

    public void setDutyRatio(String dutyRatio) {
        this.dutyRatio = dutyRatio;
    }

    public String getDutyDetail() {
        return dutyDetail;
    }

    public void setDutyDetail(String dutyDetail) {
        this.dutyDetail = dutyDetail;
    }

    public String getDutyRelated() {
        return dutyRelated;
    }

    public void setDutyRelated(String dutyRelated) {
        this.dutyRelated = dutyRelated;
    }

    public String getDutyScope() {
        return dutyScope;
    }

    public void setDutyScope(String dutyScope) {
        this.dutyScope = dutyScope;
    }

    public Date getStartTime() {
        return startTime;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public String getRegionId() {
        return regionId;
    }

    public void setRegionId(String regionId) {
        this.regionId = regionId;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Long getFeilvId() {
        return feilvId;
    }

    public void setFeilvId(Long feilvId) {
        this.feilvId = feilvId;
    }

    public String getChanpingList() {
        return chanpingList;
    }

    public void setChanpingList(String chanpingList) {
        this.chanpingList = chanpingList;
    }





}

