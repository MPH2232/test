package com.ruoyi.project.order.uploadImage.mapper;

import com.ruoyi.project.order.uploadImage.domain.UploadImage;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 影像件管理 数据层
 * 
 * @author ruoyi
 * @date 2018-08-22
 */
public interface UploadImageMapper 
{
	/**
     * 查询影像件管理信息
     * 
     * @param id 影像件管理ID
     * @return 影像件管理信息
     */
	public UploadImage selectUploadImageById(Integer id);
	/**
	 * 查询影像件管理信息
	 *
	 * @param id 影像件管理orderid
	 * @return 影像件管理信息
	 */
	public UploadImage selectUploadImageOrderId(@Param("id")String id, @Param("shouye")String shouye);


	/**
     * 查询影像件管理列表
     * 
     * @param uploadImage 影像件管理信息
     * @return 影像件管理集合
     */
	public List<UploadImage> selectUploadImageList(UploadImage uploadImage);
	
	/**
     * 新增影像件管理
     * 
     * @param uploadImage 影像件管理信息
     * @return 结果
     */
	public int insertUploadImage(UploadImage uploadImage);
	
	/**
     * 修改影像件管理
     * 
     * @param uploadImage 影像件管理信息
     * @return 结果
     */
	public int updateUploadImage(UploadImage uploadImage);

	/**
	 * 修改影像件管理，只更新时间
	 *
	 * @param uploadImage 影像件管理信息
	 * @return 结果
	 */
	public int updateUploadImageTime(UploadImage uploadImage);

	/**
     * 删除影像件管理
     * 
     * @param id 影像件管理ID
     * @return 结果
     */
	public int deleteUploadImageById(Integer id);
	
	/**
     * 批量删除影像件管理
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteUploadImageByIds(String[] ids);
	
}