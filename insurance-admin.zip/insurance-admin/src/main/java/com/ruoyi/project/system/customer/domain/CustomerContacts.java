package com.ruoyi.project.system.customer.domain;

/**
 * Created by x on 2018/8/20.
 */
public class CustomerContacts {
    private static final long serialVersionUID = 1L;
    //供应商id
    private int id;
    //联系人姓名
    private String contactsName;
    //联系人部门
    private String contactsDept;
    //联系人职位
    private String contactsPosition;
    //联系人电话
    private String contactsPhone;
    //联系人微信
    private String contactsWeixin;
    //联系人邮箱
    private String contactsEmail;
    //用户状态
    private String status;
    //创建者
    private String createBy;
    //创建时间
    private String createTime;
    //更新者
    private String updateBy;
    //更新时间
    private String updateTime;
    //客户表id
    private int customerId;
    //职责
    private  String contactsPositionDepict;
    //公司电话
    private  String contactNumber;


    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getContactsName() {
        return contactsName;
    }

    public void setContactsName(String contactsName) {
        this.contactsName = contactsName;
    }

    public String getContactsDept() {
        return contactsDept;
    }

    public void setContactsDept(String contactsDept) {
        this.contactsDept = contactsDept;
    }

    public String getContactsPosition() {
        return contactsPosition;
    }

    public void setContactsPosition(String contactsPosition) {
        this.contactsPosition = contactsPosition;
    }

    public String getContactsPhone() {
        return contactsPhone;
    }

    public void setContactsPhone(String contactsPhone) {
        this.contactsPhone = contactsPhone;
    }

    public String getContactsWeixin() {
        return contactsWeixin;
    }

    public void setContactsWeixin(String contactsWeixin) {
        this.contactsWeixin = contactsWeixin;
    }

    public String getContactsEmail() {
        return contactsEmail;
    }

    public void setContactsEmail(String contactsEmail) {
        this.contactsEmail = contactsEmail;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getContactsPositionDepict() {
        return contactsPositionDepict;
    }

    public void setContactsPositionDepict(String contactsPositionDepict) {
        this.contactsPositionDepict = contactsPositionDepict;
    }





    @Override
    public String toString() {
        return "CustomerContacts{" +
                "id=" + id +
                ", contactsName='" + contactsName + '\'' +
                ", contactsDept='" + contactsDept + '\'' +
                ", contactsPosition='" + contactsPosition + '\'' +
                ", contactsPhone='" + contactsPhone + '\'' +
                ", contactsWeixin='" + contactsWeixin + '\'' +
                ", contactsEmail='" + contactsEmail + '\'' +
                ", status='" + status + '\'' +
                ", createBy='" + createBy + '\'' +
                ", createTime='" + createTime + '\'' +
                ", updateBy='" + updateBy + '\'' +
                ", updateTime='" + updateTime + '\'' +
                ", customerId=" + customerId +
                ", contactsPositionDepict='" + contactsPositionDepict + '\'' +
//                ", remarks='" + remarks + '\'' +
                '}';
    }
}
