package com.ruoyi.project.order.order.controller;

import java.io.*;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import com.ruoyi.common.utils.*;
import javax.servlet.http.HttpServletRequest;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.FileToZip;
import com.ruoyi.common.utils.FileUploadUtils;
import com.ruoyi.common.utils.NewFileUploadUtils;
import com.ruoyi.common.utils.poi.ExcelOrderUtil;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.project.homepage.homepage.damain.Order1;
import com.ruoyi.project.homepage.homepage.service.IOrder1Service;
import com.ruoyi.project.order.order.domain.OrderReturn;
import com.ruoyi.project.order.orderBaofei.domain.OrderBaofei;
import com.ruoyi.project.order.orderBaofei.service.IOrderBaofeiService;
import com.ruoyi.project.order.orderFenqi.domain.OrderFenqi;
import com.ruoyi.project.order.orderFenqi.service.IOrderFenqiService;
import com.ruoyi.project.order.orderPeople.domain.OrderPeople;
import com.ruoyi.project.order.orderPeople.domain.OrderPeopleCount;
import com.ruoyi.project.order.orderPeople.domain.ProductCount;
import com.ruoyi.project.order.orderPeople.service.IOrderPeopleService;
import com.ruoyi.project.order.orderproductPlan.domain.OrderProductPlan;
import com.ruoyi.project.order.orderproductPlan.service.IOrderproductPlanService;
import com.ruoyi.project.order.uploadImage.domain.UploadImage;
import com.ruoyi.project.order.uploadImage.service.IUploadImageService;
import com.ruoyi.project.system.channel.domain.Channel;
import com.ruoyi.project.system.customer.domain.Pcustomer;
import com.ruoyi.project.system.dept.domain.Dept;
import com.ruoyi.project.system.dept.service.IDeptService;
import com.ruoyi.project.system.product.domain.ProductFeilvSimple;
import com.ruoyi.project.system.product.service.IProductFeilvSimpleService;
import com.ruoyi.project.system.product.service.IProductService;
import com.ruoyi.project.system.user.domain.User;
import com.ruoyi.project.system.user.service.IUserService;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.project.order.order.domain.Order;
import com.ruoyi.project.order.order.service.IOrderService;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.framework.web.domain.AjaxResult;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;

/**
 * 保险订单 信息操作处理
 *
 * @author ruoyi
 * @date 2018-08-13
 */
@Controller
@RequestMapping("/order/order")
public class OrderController extends BaseController {
    private static final Logger log = LoggerFactory.getLogger(OrderController.class);
    private String prefix = "order/order";

    @Autowired
    private IOrderService orderService;

    @Autowired
    private IOrderPeopleService orderPeopleService;

    //上传影像件
    @Autowired
    private IUploadImageService uploadImageService;

    @Autowired
    private IOrderproductPlanService orderPlanService;

    @Autowired
    private IProductService productService;

    @Autowired
    private IOrderFenqiService fenqiService;

    @Autowired
    private IOrderBaofeiService baofeiService;
    @Autowired
    private IProductFeilvSimpleService productFeilvSimpleService;
    /**/
    @Autowired
    private IUserService userService;
    @Autowired
    private IDeptService deptService;

    @RequiresPermissions("order:order:view")
    @GetMapping()
    public String order(ModelMap mmap) {
        return prefix + "/order";
    }

    /**
     * 查询保险订单列表
     */
    @RequiresPermissions("order:order:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Order order) {
        User user =getUser();
        String name=userService.selectUserPostGroup(user.getUserId());
//        List<User> users=userService.selectUserListPublic(user);
        startPage();
        List<Order> list=new ArrayList<Order>();
        if(name.contains("管理员")){
            //管理员
            list = orderService.selectOrderList(order);
//            list = orderService.selectOrderGlyList(order.getStatus());
        }else if(name.contains("主管")){
            //主管
            order.setDeptId(user.getDeptId());
            list = orderService.selectOrderListZhu(order);
        }else if(name.contains("总监")){
            //总监
            order.setDeptId(user.getDeptId());
            list = orderService.selectOrderListZongjian(order);
        }else {
            //业务员
            order.setUserId(Integer.parseInt(user.getUserId()+""));
            list = orderService.selectOrderList(order);
        }

        return getDataTable(list);
    }

    /**
     * 查询保险订单列表1111
     */
    @RequiresPermissions("order:order:list")
    @PostMapping("/listIndex")
    @ResponseBody
    public TableDataInfo listIndex(Order order) {
        User user = getUser();
        String name=userService.selectUserRoleGroup(user.getUserId());
        startPage();
        List<Order> list=new ArrayList<Order>();
        if(name.contains("管理员")){
            //管理员
            list = orderService.selectOrderGlyList(order.getStatus());
        }else if(name.equals("主管")){
            //主管
            list = orderService.selectOrderZhuguanList(user.getDeptId(),order.getStatus());
        }else if(name.equals("总监")){
            //总监
            list = orderService.selectOrderMajordomoList(user.getDeptId(),order.getStatus());
        }else {
            //业务员
            list = orderService.selectOrderYwyList(user.getUserId(),order.getStatus());
        }
        return getDataTable(list);
    }


    @RequiresPermissions("order:order:upload")
    @GetMapping("/upload/{id}/{customerSo}")
    public String upload(Order order, ModelMap mmap) {
        Order orders = orderService.selectOrderById(order.getId());
        String orderupid="";
        if (orders.getCustomerSo() != 0) {
            orderupid=orders.getRenewId();
//            xu = "续保";
        }else{
            orderupid=orders.getOrderId();
        }
        UploadImage uploadImage= uploadImageService.selectUploadImageOrderId(orderupid,"ying");
        if(uploadImage!=null){
            mmap.put("uploadName",  uploadImage.getName());
        }else{
            mmap.put("uploadName",  "");
        }
        mmap.put("order", orders);
        return prefix + "/upload";
    }

    /**
     * 上传影像件
     */
    @PostMapping("/uploadSave")
    @ResponseBody
    public AjaxResult uploadSave(UploadImage uploadImage, @RequestParam("uploadFile") MultipartFile[] file) {
        Map map = new HashMap();
        int su = 0;
        String xu = "";
        try {
            if (uploadImage.getCustomerSo() != 0) {
                uploadImage.setOrderId(uploadImage.getRenewId());
                xu = "续保";
            }
            if (file.length > 0) {
                //多文件上传
                map = NewFileUploadUtils.uploadNewMany(file, uploadImage.getOrderId());
                log.info("====上传影像件状态===" + xu + "==" + map.get("mes") + "订单号：" + uploadImage.getOrderId());
                if (map.get("mes").toString().contains("成功")) {
                    if ("0" == map.get("separator")) {
                        //已经存在的数据
                        su = uploadImageService.updateUploadImageTime(uploadImage);
                    } else {
                        uploadImage.setOrderType(uploadImage.getCustomerSo() + "");
                        String osName = System.getProperties().getProperty("os.name");
                        if (osName.equals("Linux")) {
                            uploadImage.setLinuxPath(map.get("path").toString());
                        } else {
                            uploadImage.setUploadPath(map.get("path").toString());
                        }

                        su = uploadImageService.insertUploadImage(uploadImage);
//                        orderService.updateOrderStatus(uploadImage.getOrderIdZhu(),1);//修改流程状态为状态（0待提交订单   1（待上传投保资料）  2待认收保费  3待寄送保险卡  4待寄送保单/发票） 5完成的订单'
                    }
                }
            } else {
                map.put("mes", "请选择上传文件!");
            }
        } catch (Exception e) {
            log.error("上传影像异常", e);
            map.put("mes", "上传影像件失败,请稍后重试!");
            return toAjaxMes(su, map.get("mes").toString());
        }
        return toAjaxMes(su, map.get("mes").toString());
    }

    /**
     * 打开人员清单导入页面
     */
    @RequiresPermissions("order:order:people")
    @GetMapping("/people/{id}/{type}")
    public String detail(@PathVariable("id") int id,@PathVariable("type") Long type, ModelMap mmap)
    {
        Order order = orderService.selectOrderById(id);
        mmap.put("order", order);
        if(1==type){
            mmap.put("orderId", order.getRenewId());//0新保，1续保
        }else{
            mmap.put("orderId", order.getOrderId());//0新保，1续保
        }
        mmap.put("customerSo", type);//0新保，1续保
        return   "order/orderPeople/orderPeopleExcel";
    }

    /**
     * 导入人员清单excel
     * */
    @PostMapping("/importPeople")
    @ResponseBody
    public AjaxResult importPeople(UploadImage uploadImage, @RequestParam("uploadFile") MultipartFile file) {
        Map map = new HashMap();
        int su = 0;
        String xu = "";
        OrderPeople people=new OrderPeople();
        try {
            List<Map<String, Object>>  list= ExcelUtil.importExcels(file,people);
            log.info("====获取excel值==" +list);
            su=list.size();
            //执行insert语句
            map.put("mes", "导入成功");
        } catch (Exception e) {
            log.error("导入异常", e);
            map.put("mes", "上传影像件失败,请稍后重试!");
            return toAjaxMes(su, map.get("mes").toString());
        }
        return toAjaxMes(su, map.get("mes").toString());
    }

    /**
     * 查询计划和产品列表
     */
    @RequiresPermissions("order:order:listPlan")
    @PostMapping("/listPlan")
    @ResponseBody
    public TableDataInfo listPlan(OrderProductPlan orderproductPlan) {
        startPage();
        List<OrderProductPlan> list = orderPlanService.selectOrderproductPlanList(orderproductPlan);
        return getDataTable(list);
    }

    /**
     *添加保单计划页面
     * */
    @GetMapping("/orderPlan/{id}")
    public String detailPlan(@PathVariable("id") int id, ModelMap mmap)
    {
        Order order = orderService.selectOrderById(id);
        if(1==order.getCustomerSo()){
            mmap.put("orderId", order.getRenewId());//0新保，1续保
        }else{
            mmap.put("orderId", order.getOrderId());//0新保，1续保
        }
        mmap.put("order", order);
        return   "order/order/orderPlan";
    }

    /**
     *查看保单计划页面
     * */
    @GetMapping("/orderPlanDis/{id}")
    public String detailPlanDis(@PathVariable("id") int id, ModelMap mmap)
    {
        Order order = orderService.selectOrderById(id);
        if(1==order.getCustomerSo()){
            mmap.put("orderId", order.getRenewId());//0新保，1续保
        }else{
            mmap.put("orderId", order.getOrderId());//0新保，1续保
        }
        mmap.put("order", order);
        return   "order/order/orderPlanDis";
    }

    /**
     * 新增计划,传入打开的新增页面实体数据
     */
    @GetMapping("/addPlan/{id}")
    public String addPlan(@PathVariable("id") int id, ModelMap mmap) {
        Order order = orderService.selectOrderById(id);
        if(1==order.getCustomerSo()){
            mmap.put("orderId", order.getRenewId());//0新保，1续保
        }else{
            mmap.put("orderId", order.getOrderId());//0新保，1续保
        }
        mmap.put("order", order);
        return prefix + "/addPlan";
    }



    /**
     * 新增计划保存,多产品     * */
    @RequiresPermissions("order:order:addPlan")
    @Log(title = "保险订单", action = BusinessType.INSERT)
    @PostMapping("/addPlan")
    @ResponseBody
    public AjaxResult addPlan(OrderProductPlan orderproductPlan) {
        //转换前台接收值为date
//        if (!order.getStartTimeStr().equals("")) {
//            order.setStartTime(DateUtils.dateTime("yyyy-MM-dd", order.getStartTimeStr()));
//        }
//        if (!order.getEndTimeStr().equals("")) {
//            order.setEndTime(DateUtils.dateTime("yyyy-MM-dd", order.getEndTimeStr()));
//        }
//        if (!order.getXubaoTimeStr().equals("")) {
//            order.setXubaoTime(DateUtils.dateTime("yyyy-MM-dd", order.getXubaoTimeStr()));
//        }
        JSONArray jsonchanping = JSONArray.fromObject(orderproductPlan.getChanpingList());
        List<OrderProductPlan> orderproductPlans=new ArrayList<OrderProductPlan>();
        OrderProductPlan pro=new OrderProductPlan();
        int j=1;
        for(int i=0;i<jsonchanping.size()-1;i++){
            pro=orderproductPlan;
            JSONObject jo = JSONObject.fromObject(jsonchanping.get(i));
            //[{"name":"sup","value":"0"},{"name":"protocolTime","value":"20180810"},{"name":"type1","value":"1"},{"name":"protocolTime1","value":"20180810"}]
            String name = jo.getString("name");
            String value = jo.getString("value");
            if(name.contains("productName")){
                pro.setProductName(value);
            }else if(name.contains("productBaoeType")){
                pro.setProductBaoeType(value);
            }else if(name.contains("productBaoe")){
                pro.setProductBaoe(value);
            }else if(name.contains("productBaofeiType")){
                pro.setProductBaofeiType(value);
            }else if(name.contains("productBaofei")){
                pro.setProductBaofei(value);
            }else if(name.contains("beizhu")){
                pro.setBeizhu(value);
            }
           //生成人员清单需要的关联id
//            pro.setPlanPeopleId( DateUtils.dateTimeHh());
            if(j%6==0){
                orderproductPlans.add(pro);
                pro=new OrderProductPlan();
            }
            j++;
        }
        pro=null;
        return toAjaxMes(orderPlanService.insertOrderproductPlanList(orderproductPlans),"成功");
    }

    /**
     * 新增保险订单
     */
    @GetMapping("/add")
    public String add(ModelMap mmap) {
        return prefix + "/add";
    }

    /**
     * 新增保存保险订单
     */
    @RequiresPermissions("order:order:add")
    @Log(title = "保险订单", action = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Order order) {
//        //转换前台接收值为date
//        if (!order.getStartTimeStr().equals("")) {
//            order.setStartTime(DateUtils.dateTime("yyyy-MM-dd", order.getStartTimeStr()));
//        }
//        if (!order.getEndTimeStr().equals("")) {
//            order.setEndTime(DateUtils.dateTime("yyyy-MM-dd", order.getEndTimeStr()));
//        }
//        if (!order.getXubaoTimeStr().equals("")) {
//            order.setXubaoTime(DateUtils.dateTime("yyyy-MM-dd", order.getXubaoTimeStr()));
//        }

      User user= userService.selectDeptNameUserId(Long.parseLong(order.getUserId()+""));
        order.setTeamId(Integer.parseInt(user.getDeptId()+""));
        order.setTeamName(order.getDeptName());
        return toAjax(orderService.insertOrder(order));
    }

    /**
     * 查看保险订单 order:order:query
     */
    @GetMapping("/query/{id}")
    public String query(@PathVariable("id") Integer id, ModelMap mmap) {
        Order order = orderService.selectOrderById(id);
        String customerStr="";
        if(order.getCustomerSo()==0){
            customerStr="新保";
        }else if(order.getCustomerSo()==1){
            customerStr="续保";
        }else if(order.getCustomerSo()==2){
            customerStr="渠道";
        }else if(order.getCustomerSo()==3){
            customerStr="自行拓展";
        }else if(order.getCustomerSo()==4){
            customerStr="客户介绍";
        }else if(order.getCustomerSo()==5){
            customerStr="现有客户再开发";
        }
        String status="";
        if(order.getCustomerSo()==0){
            status="待提交订单";
        }else if(order.getCustomerSo()==1){
            status="待认收保费";
        }else if(order.getCustomerSo()==2){
            status="待寄送保险卡";
        }else if(order.getCustomerSo()==3){
            status="待寄送保单";
        }else if(order.getCustomerSo()==4){
            status="完成订单";
        }
        mmap.put("order", order);
       Dept dept= deptService.selectDeptById(Long.parseLong(order.getTeamId()+""));
        mmap.put("deptName", dept.getDeptName());
        mmap.put("parentName", dept.getParentName());
        mmap.put("customerStr", customerStr);
        mmap.put("status", status);
        return prefix + "/query";
    }

    /**
     * 保费确认提交订单页面的保费计算数据
     * id是订单关联计划id，年月日时分秒
     */
    @GetMapping("/orderSubmit/{id}")
    @Transactional(rollbackFor = Exception.class)
    public String orderSubmit(@PathVariable("id") String id, ModelMap mmap) {
        Order order = orderService.selectOrderById(Integer.parseInt(id));
        //查询出计划，
        OrderProductPlan orderproductPlan=new OrderProductPlan();
        //非0不是续保
        orderproductPlan.setPlanType(order.getCustomerSo());//0新保，1续保，2新保保全，3续保保全
        orderproductPlan.setOrderProductId(order.getOrderId());//关联订单表的id
        //按照产品分组，每个产品总共出现多少条
        List<ProductCount> productList = orderPlanService.selectproductList(orderproductPlan);
//查询计划的所有数据，定制产品，可能倍数不一样，保费就不一样，工资必须有
        List<OrderProductPlan> planList = orderPlanService.selectOrderproductPlanList(orderproductPlan);
        //统计计划下人数多少。订单号和新保，续保
        List<OrderPeopleCount>  orderPeopleCount = orderPeopleService.selectOrderPeopleByPlans(order.getOrderId(),order.getCustomerSo().toString());
//查找人员清单所有人员，必须有工资，如果是定制方案。
//        OrderPeople orderPeople=new OrderPeople();
//        orderPeople.setOrderId(order.getOrderId());
//        orderPeople.setOrderType(order.getCustomerSo().toString());
////        orderPeople.setPlanPeopleName();
//       List<OrderPeople>  orderPeopleList = orderPeopleService.selectOrderPeopleList(orderPeople);
        //这个订单的计划
        //存储产品信息，额度
        List<ProductCount> productCount=new ArrayList<ProductCount>();
        //计划的个数
        String jihuaCount="";
        String chanpcount="";
        //插入数据到保费表，以后直接查询，不走计算
        List<OrderBaofei> orderBaofeiList=new ArrayList<>();
        //合计总保费
        BigDecimal baofeiHeji = new BigDecimal(0);

        ////-------如果是高端产品，走另外一个计算方法，，标准和定制，标准的直接叠加，如果是定制的需要根据定制的简单费率计算下每个人的保费，然后再叠加
        List<OrderProductPlan> gaoduanList = orderPlanService.selectProductGaoduan("高端",order.getOrderId());
        if( gaoduanList.size()>0){
            //高端产品---------------
            BigDecimal zongGaoBaofei = new BigDecimal(0);
            BigDecimal zongYiBaofei = new BigDecimal(0);
            OrderPeople orderPeople=new OrderPeople();
//标准产品，人员清单已经算好保费，直接相加
            orderPeople.setOrderId(order.getOrderId());
            orderPeople.setOrderType(order.getCustomerSo().toString());
            //保单识别码
            orderPeople.setPolicyNum(order.getPolicyNum());
//                            orderPeople.setPlanPeopleName(planList.get(0).getPlanName());
            //该计划下有多少人
            List<OrderPeople>  orderPeopleList = orderPeopleService.selectOrderPeopleList(orderPeople);
            OrderBaofei orderBaofeigao=new OrderBaofei();
            if(gaoduanList.get(0).getProductName().contains("标准")){

                OrderBaofei orderBaofeiYi=new OrderBaofei();
                for(int e=0;e<orderPeopleList.size();e++){
                    //医疗险
                    if(  orderPeopleList.get(e).getBaofei()!=null){
                        zongGaoBaofei=zongGaoBaofei.add(new BigDecimal(orderPeopleList.get(e).getBaofei()));

                    }
                    //意外险
                    if(orderPeopleList.get(e).getYiwaiBaofei()!=null){
                        zongYiBaofei=zongYiBaofei.add(new BigDecimal(orderPeopleList.get(e).getYiwaiBaofei()));
                    }
                }

                orderBaofeigao.setProductName(gaoduanList.get(0).getProductName());
                orderBaofeigao.setProductCharge(zongGaoBaofei.toString());
                //附加险--意外险名称
                List<OrderProductPlan> yiwaiList = orderPlanService.selectProductGaoduan("意外",order.getOrderId());
                if(yiwaiList.size()>0){
                    orderBaofeiYi.setProductName(yiwaiList.get(0).getProductName());
                    orderBaofeiYi.setProductCharge(zongYiBaofei.toString());
                    orderBaofeiList.add(orderBaofeiYi);
                }
                orderBaofeiList.add(orderBaofeigao);
                //高端产品合计总保费
                baofeiHeji=baofeiHeji.add(zongYiBaofei).add(zongGaoBaofei);

            }else{ //定制-------------
                //定制产品需要算费率，
                //？？？？
                //如果有别的险种产品的时候，还需要加下别的产品保费，最后再计算相加。
                ProductFeilvSimple productFeilvSimple=new ProductFeilvSimple();
                productFeilvSimple.setProductId(Long.parseLong(gaoduanList.get(0).getProductName()));
                List<ProductFeilvSimple> listSimple = productFeilvSimpleService.selectProductFeilvSimpleList(productFeilvSimple);

                ////循环人数
                for(int f=0;f<orderPeopleList.size();f++){
                    int agePeo= DateUtils.getAge(orderPeopleList.get(f).getBirth());

                    //循环费率
                    for(int s=0;s<listSimple.size();s++){

                        //如果计划名称一样，执行计算
                        if(  orderPeopleList.get(f).getPlanName().contains(listSimple.get(s).getPlan())){
                            if(  orderPeopleList.get(f).getSex().equals(listSimple.get(s).getSex())){

                                String[] age=listSimple.get(s).getAge().split("-");
                                if(Integer.parseInt(age[0])<=agePeo && Integer.parseInt(age[1])>=agePeo){
                                    //保费是
                                    zongGaoBaofei=zongGaoBaofei.add(new BigDecimal(listSimple.get(s).getPlanValue()));
                                }


                            }
                        }
                    }
                }
                orderBaofeigao.setProductName(gaoduanList.get(0).getProductName());
                orderBaofeigao.setProductCharge(zongGaoBaofei.toString());
                orderBaofeiList.add(orderBaofeigao);
                //高端产品合计总保费
                baofeiHeji=baofeiHeji.add(zongGaoBaofei);

            }
        }else{
//普通产品---------------

            //调用订单保费计算方法，获取每个产品对应保费和总保费
            OrderReturn orderReturn=feilvJiSuan(order,planList,orderPeopleCount);

            for (Map.Entry<String,OrderBaofei> entry : orderReturn.getMapBaofei().entrySet()) {
                OrderBaofei orderBaofeis=new OrderBaofei();
                if(orderReturn.getMap().containsKey(entry.getKey())){
                    orderBaofeis=entry.getValue();
                    orderBaofeis.setProductCharge(orderReturn.getMap().get(entry.getKey()).toString());
                    baofeiHeji=baofeiHeji.add(new BigDecimal(orderReturn.getMap().get(entry.getKey()).toString()));
                }
                orderBaofeiList.add(orderBaofeis);
            }
        }

        //查询出人员清单
//        OrderPeople orderPeople=new OrderPeople();
//        orderPeople.setOrderId(id);
//        List<OrderPeople> orderPeopleList=orderPeopleService.selectOrderPeopleList(orderPeople);
        mmap.put("order", order);
        mmap.put("orderBaofeiList", orderBaofeiList);
//        mmap.put("baofeiHeji", baofeiHeji);
        //查询分期的数据是否存在
        List<OrderBaofei> orderBaofeiLists=new ArrayList<OrderBaofei>();
        OrderBaofei orderBaofeis =new OrderBaofei();
        orderBaofeis.setOrderFenqiId(order.getOrderId());
        orderBaofeiLists=baofeiService.selectOrderBaofeiList(orderBaofeis);
        if(orderBaofeiLists.size()<1){
            baofeiService.insertOrderBaofeiList(orderBaofeiList);
        }


        //查询分期的数据是否存在
        List<OrderFenqi> orderFenqiList=new ArrayList<OrderFenqi>();
        OrderFenqi orderFenqis =new OrderFenqi();
        orderFenqis.setOrderFenqiId(order.getOrderId());
        orderFenqiList=fenqiService.selectOrderFenqiList(orderFenqis);
        if(orderFenqiList.size()<1){
            BigDecimal paymode= new BigDecimal(order.getPayMode());
            //高端产品和普通产品的合计总保费
            BigDecimal charge= baofeiHeji.divide(paymode,2,BigDecimal.ROUND_HALF_UP);
            for(int r=0;r<Integer.parseInt(order.getPayMode());r++){
                OrderFenqi orderFenqi =new OrderFenqi();
                orderFenqi.setOrderFenqiId(order.getOrderId());//订单表关联分期表id
                orderFenqi.setFenqiCharge(String.valueOf(charge));
                //循环插入月份，+1
                orderFenqi.setFenqiMonth(DateUtils.dateMonth(r));
                orderFenqi.setProductSum(String.valueOf(baofeiHeji));
                //第几个分期
                orderFenqi.setPlanCount(String.valueOf(r+1));
                orderFenqi.setFenqiType(String.valueOf(order.getCustomerSo()));
                //未认收
                orderFenqi.setFenqiStatus(0);
                orderFenqiList.add(orderFenqi);
            }
            fenqiService.insertOrderFenqiList(orderFenqiList);
        }
//        baofeiHeji.divide(new BigDecimal(order.getPayMode().toString()));
        mmap.put("baofeiHeji", baofeiHeji);
        mmap.put("orderFenqiList", orderFenqiList);
        return prefix + "/orderSubmit";
    }

    //把计算内容传入这个方法，
    public OrderReturn feilvJiSuan(Order order , List<OrderProductPlan> planList, List<OrderPeopleCount>  orderPeopleCount ) {
//产品名称对应的个数，直接乘以产品的单价就是
        Map map = new HashMap<>();
        //暂时存产品对应总保费
        Map<String,OrderBaofei> mapBaofei = new HashMap<>();


        //多少条数据
        for(int a=0;a<planList.size();a++) {
            OrderBaofei  orderBaofei =new OrderBaofei();
            //修改为续保订单号，以后

            //这个产品是固定保额
            if(planList.get(a).getProductBaofeiType().equals("0")){
                //固定保费.是固定的保额。
                for (int j = 0; j < orderPeopleCount.size(); j++) {
                    if(orderPeopleCount.get(j).getPlanPeopleName()!=null){

                        if(planList.get(a).getPlanName().equals(orderPeopleCount.get(j).getPlanPeopleName())){
                            //产品找保费单价金额
                            String bZbaofei=  productFei(planList.get(a).getProductName(),order.getOrderId(),planList.get(a).getPlanName());
                            BigDecimal bZbaofeiBig = new BigDecimal(bZbaofei);
                            //以后根据产品的id对比，
                            if(map.containsKey(planList.get(a).getProductName())){
//取出计划下人数多少，乘以多少
                                int counts=Integer.parseInt(orderPeopleCount.get(j).getCounts());
//从已经添加map的产品，取出个数是多少
                                BigDecimal coBaofei = new BigDecimal(map.get(planList.get(a).getProductName()).toString());
//最后，相加就是叠加个数
//                   int conBaofei= counts+co;

//                    BigDecimal conBaofeiBig = new BigDecimal(conBaofei);
                                BigDecimal productBaofei=  bZbaofeiBig.multiply(BigDecimal.valueOf(counts));
                                coBaofei=coBaofei.add(productBaofei);
//計算保費
                                map.put(planList.get(a).getProductName(),coBaofei);
                            }else{
                                //单独产品加，
                                BigDecimal conBaofeiBigc = new BigDecimal(orderPeopleCount.get(j).getCounts());
                                BigDecimal productBaofeic=  bZbaofeiBig.multiply(conBaofeiBigc);
                                map.put(planList.get(a).getProductName(),productBaofeic);
                            }
                            //个数，人数
//                    orderPlanList.get(i).getProductName() orderPeopleCount.get(j).getCount();
                        }
                    }
                }

            }else{
                OrderPeople orderPeople=new OrderPeople();
                orderPeople.setOrderId(order.getOrderId());
                orderPeople.setOrderType(order.getCustomerSo().toString());
                orderPeople.setPlanPeopleName(planList.get(a).getPlanName());
                //该计划下有多少人
                List<OrderPeople>  orderPeopleList = orderPeopleService.selectOrderPeopleList(orderPeople);
//    planList.get(a).getProductBaoe();
                //不固定保费
                BigDecimal baofeiBig = new BigDecimal(0);
//不是固定的保额，，是倍数，百分比保费
                for (int c = 0; c < orderPeopleList.size(); c++) {
                    //人员工资*倍数*保费比例。该人这个产品的保费
//        orderPeopleList.get(c).getSalary(); planList.get(a).getProductBaoe();
                    BigDecimal salary = new BigDecimal(orderPeopleList.get(c).getSalary());
                    BigDecimal baoe= new BigDecimal( planList.get(a).getProductBaoe());
                    BigDecimal baofei = new BigDecimal( planList.get(a).getProductBaofei());
                    BigDecimal productBaofei=  salary.multiply(baoe).multiply(baofei);

                    if(map.containsKey(planList.get(a).getProductName())){
                        BigDecimal lishiBaofei=new BigDecimal( map.get(planList.get(a).getProductName()).toString());
                        baofeiBig=  lishiBaofei.multiply(productBaofei);
//計算保費
                    }else{
//如果只有一个人，直接插入该产品一个人的费用
//            BigDecimal lishiBaofei=new BigDecimal( map.get(planList.get(a).getProductName()).toString());
                        baofeiBig=  baofeiBig.multiply(productBaofei);
                    }
                }
                map.put(planList.get(a).getProductName(),baofeiBig);
            }
//产品汇总保费
//            orderBaofei.setProductCharge();
//            mapBaofei.get("")
            if(!mapBaofei.containsKey(planList.get(a).getProductName()))
//            if( planList.get(a).getProductName().equals(mapBaofei.get(planList.get(a).getProductName()+"list").getProductName()))
            {
                orderBaofei.setOrderFenqiId(order.getOrderId());
                orderBaofei.setProductName(planList.get(a).getProductName());
                orderBaofei.setProductId(planList.get(a).getProductId());
                mapBaofei.put(planList.get(a).getProductName(),orderBaofei);
            }
//            orderBaofeiList.add(orderBaofei);
        }
        OrderReturn orderReturn=new OrderReturn();
        orderReturn.setMapBaofei(mapBaofei);
        orderReturn.setMap(map);
        return orderReturn;
    }

    /**
     * 获取该产品下的保费金额
     */
    public String productFei(String productname,String orderid,String planName) {
        OrderProductPlan orderproductPlan=new OrderProductPlan();
        //非0不是续保
//        orderproductPlan.setPlanType(order.getCustomerSo());//0新保，1续保，2新保保全，3续保保全
        orderproductPlan.setOrderProductId(orderid);//关联订单表的id
        orderproductPlan.setProductName(productname);
        orderproductPlan.setPlanName(planName);
        List<OrderProductPlan> baofeiplanList = orderPlanService.selectOrderproductPlanList(orderproductPlan);

        return baofeiplanList.get(0).getProductBaofei();
    }

    /**
     * 保费页面打开数据处理
     */
    @GetMapping("/orderBaofei/{id}")
    public String orderBaofei(@PathVariable("id") String id, ModelMap mmap) {
        Order order = orderService.selectOrderById(Integer.parseInt(id));
        //查询出计划，
        OrderProductPlan orderproductPlan=new OrderProductPlan();
        orderproductPlan.setOrderProductId(id);
        List<OrderProductPlan> orderPlanList = orderPlanService.selectOrderproductPlanList(orderproductPlan);
        //查询出人员清单
        OrderPeople orderPeople=new OrderPeople();
        orderPeople.setOrderId(id);
        List<OrderPeople> orderPeopleList=orderPeopleService.selectOrderPeopleList(orderPeople);

        mmap.put("order", order);
        return prefix + "/orderSubmit";
    }
    /**
     * 新增保存保险订单
     */
    @Log(title = "保险提交保费订单", action = BusinessType.INSERT)
    @PostMapping("/saveSubmit")
    @ResponseBody
    @Transactional
    public AjaxResult saveSubmit(Order order,String fenqiList) {
        //修改订单的状态为保费认收。
        //修改订单的保单号
        //修改订单的分期数的金额（等于人员清单计算的金额）
        Order orderUp=new Order();
        int row=0;
        int j=1;
//        orderUp.setOrderId(order.getOrderId());
        orderUp.setStatus(1);//   0待提交订单  1待认收保费  2待寄送保险卡  3待寄送保单/发票） 4完成的订单
//        if(order.getOrderType()!=0){
//            orderUp.setRenewId(order.getRenewId());//续保订单号
//        }
//        orderUp.setPolicyId(order.getPolicyId());//保单号
        orderUp.setId(order.getId());
//        orderService.updateOrder(orderUp);
        JSONArray jsonchanping = JSONArray.fromObject(fenqiList);
        List<OrderFenqi> orderproductPlans=new ArrayList<OrderFenqi>();
//        OrderFenqi pro=new OrderFenqi();
        String orderId=order.getOrderId();
        if(order.getOrderType()!=0){
            orderId=order.getRenewId();//续保订单号
        }
        OrderFenqi orderFenqi=new OrderFenqi();
        orderFenqi.setOrderFenqiId(orderId);
        List<OrderFenqi> orderFenqis=fenqiService.selectOrderFenqiList(orderFenqi);
        int f=0;
        OrderFenqi pro=new OrderFenqi();
        for(int i=0;i<jsonchanping.size()-1;i++){
            JSONObject jo = JSONObject.fromObject(jsonchanping.get(i));
            //[{"name":"sup","value":"0"},{"name":"protocolTime","value":"20180810"},{"name":"type1","value":"1"},{"name":"protocolTime1","value":"20180810"}]
            String name = jo.getString("name");
            String value = jo.getString("value");
            if(name.contains("fenqiCharge")){
                pro.setFenqiCharge(value);
            }else if(name.contains("planCount")){
                pro.setPlanCount(value);
            }else if(name.contains("fenqiMonth")){
                pro.setFenqiMonth(value);
            }
            pro.setFenqiType(String.valueOf(order.getOrderType()));
            pro.setOrderFenqiId(orderId);

            if(j%3==0){
                if(!orderFenqis.get(f).getFenqiCharge().equals(pro.getFenqiCharge()))
                {
                    fenqiService.updateOrderFenqi(pro);
                }
                f++;
                pro=new OrderFenqi();
            }
            j++;
            //如果查询到保费和输入保费不一致，需要修改为输入的保费

        }
        row= orderService.updateOrder(orderUp);
        return toAjax(row);
    }

    /**
     *打开保费认收页面
     */
    @GetMapping("/orderMoney/{id}")
    public String orderMoney(@PathVariable("id") Integer id, ModelMap mmap) {
        Order order = orderService.selectOrderById(id);
        mmap.put("order", order);

        List<OrderBaofei> orderBaofeiLists=new ArrayList<OrderBaofei>();
        OrderBaofei orderBaofeis =new OrderBaofei();
        orderBaofeis.setOrderFenqiId(order.getOrderId());
        orderBaofeiLists=baofeiService.selectOrderBaofeiList(orderBaofeis);


        //查询分期的数据是否存在
        List<OrderFenqi> orderFenqiList=new ArrayList<OrderFenqi>();
        OrderFenqi orderFenqis =new OrderFenqi();
        orderFenqis.setOrderFenqiId(order.getOrderId());
        orderFenqiList=fenqiService.selectOrderFenqiList(orderFenqis);
        if(orderFenqiList.size()>0) {
            mmap.put("baofeiHeji", orderFenqiList.get(0).getProductSum());
        }else{
            mmap.put("baofeiHeji", "0");
        }
        UploadImage uploadImage=new UploadImage();
        //考虑续保订单号
        uploadImage.setOrderId(order.getOrderId());
        uploadImage.setName("shouye");
        Map map = new HashMap();
        int su = 0;
        String xu = "";
        List<UploadImage> images = uploadImageService.selectUploadImageList(uploadImage);
        if(images.size()>0){
            mmap.put("images", "1");
        }else{
            mmap.put("images", "0");
        }
        mmap.put("orderBaofeiList", orderBaofeiLists);
        mmap.put("orderFenqiList", orderFenqiList);


        if(order.getPayTo().equals("2")){
//付款到方胜
            return prefix + "/orderMoneyFang";
        }else{
            return prefix + "/orderMoney";
        }
    }

    /**
     * 新增保存保险订单
     */
    @Log(title = "保费认收", action = BusinessType.INSERT)
    @PostMapping("/saveMoney")
    @ResponseBody
    @Transactional
    public AjaxResult saveMoney(Order order,String fenqiList, String selectIndex,@RequestParam("fileIndex") MultipartFile[] file) throws IOException {
        //修改订单的状态为保费认收。
        //修改订单的保单号
        //修改订单的分期数的金额（等于人员清单计算的金额）
        Order orderUp=new Order();
        int row=0;
        int j=1;
        int jj=0;
//        orderUp.setOrderId(order.getOrderId());
        orderUp.setStatus(1);//   0待提交订单  1待认收保费  2待寄送保险卡  3待寄送保单/发票） 4完成的订单
//        if(order.getOrderType()!=0){
//            orderUp.setRenewId(order.getRenewId());//续保订单号
//        }
        orderUp.setPolicyId(order.getPolicyId());//保单号
        orderUp.setId(order.getId());
//        orderService.updateOrder(orderUp);
        JSONArray jsonchanping = JSONArray.fromObject(fenqiList);
        List<OrderFenqi> orderproductPlans=new ArrayList<OrderFenqi>();
//        OrderFenqi pro=new OrderFenqi();
        String orderId=order.getOrderId();
        if(order.getOrderType()!=0){
            orderId=order.getRenewId();//续保订单号
        }
        OrderFenqi orderFenqi=new OrderFenqi();
        orderFenqi.setOrderFenqiId(orderId);
        List<OrderFenqi> orderFenqis=fenqiService.selectOrderFenqiList(orderFenqi);
        int f=0;
        OrderFenqi pro=new OrderFenqi();
        for(int i=0;i<jsonchanping.size()-1;i++){
            JSONObject jo = JSONObject.fromObject(jsonchanping.get(i));
            //[{"name":"sup","value":"0"},{"name":"protocolTime","value":"20180810"},{"name":"type1","value":"1"},{"name":"protocolTime1","value":"20180810"}]
            String name = jo.getString("name");
            String value = jo.getString("value");
            if(name.contains("fenqiCharge")){
//                pro.setFenqiCharge(value);
            }else if(name.contains("planCount")){
                pro.setPlanCount(value);
            }else if(name.contains("fenqiMonth")){
//                pro.setFenqiMonth(value);
            }else if(name.contains("payTime")){
                if(value!=null && value!="") {
                    pro.setPayTime( value);
                }
            }else if(name.contains("weixuan")){
                jj=1;
                pro.setFenqiStatus(1);
            }
            else if(name.contains("yixuan")){
                f++;
            }
            pro.setFenqiType(String.valueOf(order.getOrderType()));
            pro.setOrderFenqiId(orderId);
            //如果有weixuan执行插入操作
            if(jj==1){

                if(j%6==0) {
                    //未认收
                    if (orderFenqis.get(f).getFenqiStatus() == 0) {
//有插入時間
                        if (!pro.getPayTime().equals("")) {
                            fenqiService.updateOrderFenqi(pro);
                        }
                    }
                    f++;
                    pro = new OrderFenqi();
                }
            }

            j++;
            //如果查询到保费和输入保费不一致，需要修改为输入的保费

        }
        row= orderService.updateOrder(orderUp);
        //已经上传过保单首页，不用再次上传
        if(selectIndex.equals("0")){
            UploadImage uploadImage=new UploadImage();
            uploadImage.setOrderId(orderId);
            uploadImage.setName("shouye");
            Map map = new HashMap();
            int su = 0;
            String xu = "";
            if (file.length > 0) {
                //多文件上传
                map = NewFileUploadUtils.IndexUpload(file, uploadImage.getOrderId());
                log.info("====上传影像件状态===" + xu + "==" + map.get("mes") + "订单号：" + uploadImage.getOrderId());
                if (map.get("mes").toString().contains("成功")) {
//            if ("0" == map.get("separator")) {
//                //已经存在的数据
////                    su = uploadImageService.updateUploadImageTime(uploadImage);
//            } else {
                    uploadImage.setOrderType(uploadImage.getCustomerSo() + "");
                    String osName = System.getProperties().getProperty("os.name");
                    if (osName.equals("Linux")) {
                        uploadImage.setLinuxPath(map.get("path").toString());
                    } else {
                        uploadImage.setUploadPath(map.get("path").toString());
                    }

                    su = uploadImageService.insertUploadImage(uploadImage);
//                        orderService.updateOrderStatus(uploadImage.getOrderIdZhu(),1);//修改流程状态为状态（0待提交订单   1（待上传投保资料）  2待认收保费  3待寄送保险卡  4待寄送保单/发票） 5完成的订单'
                }
            } else {
                map.put("mes", "请选择上传文件!");
            }
        }
        return toAjax(row);
    }

    /**
     * 修改保险订单
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        Order order = orderService.selectOrderById(id);
        mmap.put("order", order);
        return prefix + "/edit";
    }

    /**
     * 修改保存保险订单
     */
    @RequiresPermissions("order:order:edit")
    @Log(title = "保险订单", action = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Order order) {
        return toAjax(orderService.updateOrder(order));
    }

    /**
     * 删除保险订单
     */
    @RequiresPermissions("order:order:remove")
    @Log(title = "保险订单", action = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(orderService.deleteOrderByIds(ids));
    }



    @PostMapping("/download")
    @ResponseBody
    public String download(HttpServletResponse response, int id) {

        //待生成的zip包名
//        String zipName = String.valueOf(new Date().getTime());
        try {
            Order order=   orderService.selectOrderById(id);
            String xu="";
            String orderids="";
            if (order.getCustomerSo() != 0) {
                orderids=order.getRenewId();
                xu = "续保";
            }else{
                orderids=order.getOrderId();
            }
            UploadImage uploadImage= uploadImageService.selectUploadImageOrderId(orderids,"ying");
            String  zipName=uploadImage.getOrderId();
            //数据库中文件的保存路径
            String sourceFilePath="";
            if(sourceFilePath!=null){
                //待生成的zip保存路径
                String osName = System.getProperties().getProperty("os.name");
                System.out.println("----系统是---"+osName);
                String filePath = "";
                String zipFilePath ="";
//                String zipFilePath = "D:\\yasuobao";
                String path="";
                if (osName.equals("Linux")) {
                    filePath = "/var/opt/yasuobao/";
                    zipFilePath="/var/opt/yasuobao";
                    sourceFilePath=uploadImage.getLinuxPath();
                } else {
                    filePath = "D:/yasuobao\\";
                    zipFilePath = "D:/yasuobao";
                    sourceFilePath=uploadImage.getUploadPath();
                }
                path=filePath+zipName+".zip";
//                String zipFilePath = "D:\\yasuobao";
                //压缩
                FileToZip.fileToZip(sourceFilePath , zipFilePath , zipName);
                //压缩包的绝对路径+完整压缩包名字
//                String path="D:\\yasuobao\\"+zipName+".zip";
                // path是指欲下载的文件的路径。
                File file = new File(path);
                // 取得文件名。
                String filename = file.getName();
                // 取得文件的后缀名。
                String ext = filename.substring(filename.lastIndexOf(".") + 1).toUpperCase();
                // 以流的形式下载文件。
                InputStream fis = new BufferedInputStream(new FileInputStream(path));
                byte[] buffer = new byte[fis.available()];
                fis.read(buffer);
                fis.close();
                // 清空response
                response.reset();
                // 设置response的Header
                response.addHeader("Content-Disposition", "attachment;filename=" + new String(filename.getBytes("utf-8"),"iso-8859-1"));
                response.addHeader("Content-Length", "" + file.length());
                OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
                response.setContentType("application/octet-stream");
                toClient.write(buffer);
                toClient.flush();
                toClient.close();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return "对不起！该条协议您还没有上传影像不能进行下载！";
//        return response;
    }

    /**
     * 校验计划是否存在
     */
    @PostMapping("/checkPlan")
    @ResponseBody
    public String checkPlan(String name,String orderid)
    {
        String uniqueFlag = "0";
        if (name != null)
        {
            uniqueFlag = orderPlanService.selectcheckPlanByName(name,orderid);
        }
        return uniqueFlag;
    }

    /**
     * 校验计划是否存在
     */
    @PostMapping("/checkCengji")
    @ResponseBody
    public String checkCengji(String name,String orderid)
    {
        String uniqueFlag = "0";
        if (name != null)
        {
            uniqueFlag = orderPlanService.selectcheckCengjiByName(name,orderid);
        }
        return uniqueFlag;
    }

    @Log(title = "订单", action = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Order order) throws Exception
    {
        try
        {
            List<Order> list = orderService.selectOrderList(order);
            ExcelUtil<Order> util = new ExcelUtil<Order>(Order.class);
            return util.exportExcel(list, "order");
        }
        catch (Exception e)
        {
            return error("导出Excel失败，请联系网站管理员！");
        }
    }

    /**
     *上传excel表
     */
    @RequiresPermissions("order:order:batchAdd")
    @GetMapping("/uploadBath/{orderId}")
    public String uploadBath(Order order,ModelMap mmap) {
        Order orders = orderService.selectOrderById(order.getId());
        mmap.put("order", orders);
        return prefix + "/uploadBath";
    }

    //    /**
//     * 导入信息
//     */
//    @RequiresPermissions("order:order:batchAdd")
//    @PostMapping("/importOrder")
//    @ResponseBody
//    @Transactional
//    public AjaxResult excelSave(Order order, OrderProductPlan orderProductPlan, OrderPeople orderPeople, @RequestParam("uploadFile") MultipartFile file)
//    {
//        int su = 0;
//        String mess="";
//        String orderId="";
//        try {
//            //订单和计划的的导入处理
//            List<Map<String, Object>> listOrder = ExcelOrderUtil.importExcelsOrder(file, order,0,orderId);
//            List<Map<String, Object>> listPlan = ExcelOrderUtil.importExcelsOrder(file, orderProductPlan,0,orderId);
//            for (int i = 0; i < listOrder.size(); i++) {
//                Map<String, Object> map1 = listOrder.get(i);
//                Iterator<Map.Entry<String, Object>> iterator = map1.entrySet().iterator();
//                while (iterator.hasNext()) {
//                    Map.Entry<String, Object> entry = iterator.next();
//                    System.out.println("key: " + entry.getKey() + " value: " + entry.getValue());
//                    if (entry.getValue().toString().equals("企业客户")) {
//                        entry.setValue(0);
//                    }
//                    if (entry.getValue().toString().equals("个人客户")) {
//                        entry.setValue(1);
//                    }
//                    if (entry.getValue().toString().equals("新保")) {
//                        entry.setValue(0);
//                    }
//                    if (entry.getValue().toString().equals("续保")) {
//                        entry.setValue(1);
//                    }
//                    if (entry.getValue().toString().equals("渠道")) {
//                        entry.setValue(2);
//                    }
//                    if (entry.getValue().toString().equals("自行拓展")) {
//                        entry.setValue(3);
//                    }
//                    if (entry.getValue().toString().equals("客户介绍")) {
//                        entry.setValue(4);
//                    }
//                    if (entry.getValue().toString().equals("现有客户再开发")) {
//                        entry.setValue(5);
//                    }
//                    if (entry.getValue().toString().equals("保险公司")) {
//                        entry.setValue(0);
//                    }
//                    if (entry.getValue().toString().equals("FESCO")) {
//                        entry.setValue(1);
//                    }
//                    if (entry.getValue().toString().equals("方胜")) {
//                        entry.setValue(2);
//                    }
//                    if (entry.getValue().toString().equals("趸交")) {
//                        entry.setValue(1);
//                    }
//                    if (entry.getValue().toString().equals("月交")) {
//                        entry.setValue(12);
//                    }
//                    if (entry.getValue().toString().equals("季交")) {
//                        entry.setValue(4);
//                    }
//                    if (entry.getValue().toString().equals("四个月交")) {
//                        entry.setValue(3);
//                    }
//                    if (entry.getValue().toString().equals("半年交")) {
//                        entry.setValue(2);
//                    }
//                    if(entry.getValue().toString().contains("格式错误")){
//                        log.info("===导入异常原因===", entry.getValue().toString());
//                        mess+=entry.getValue().toString();
//                    }
//                }
//            }
//
//
//            if(mess.contains("格式错误")){
//                return toAjaxMesMeg(0, mess);
//            }
//
//            for (int q = 0; q < listOrder.size(); q++) {
//                Map<String, Object> map1 = listOrder.get(q);
//                log.info("====获取excel值==" + listOrder);
//                su = listOrder.size();
//                if (null != String.valueOf(map1.get("policyNum")) && !"".equals(String.valueOf(map1.get("policyNum")))) {
//                    //微秒
//                    orderId=DateUtils.dateTimeSSS();
//                    map1.put("orderId",orderId);
//                    map1.put("status",0);
//                    //执行insert语句
//                    orderService.addOrder((HashMap<String, Object>) map1);
//                }
//                Map<String, Object> map2 = listPlan.get(q);
//                map2.put("orderProductId",orderId);
//                //执行insert语句
//                orderPlanService.addOrderproductPlan((HashMap<String, Object>) map2);
////                mess = "导入成功";
//            }
//
//
//
//            //人员清单的导入处理
//            List<Map<String, Object>> listPeople = ExcelOrderUtil.importExcelsOrder(file, orderPeople,1,orderId);
//            for (int i = 0; i < listPeople.size(); i++) {
//                Map<String, Object> map3 = listPeople.get(i);
//                Iterator<Map.Entry<String, Object>> iterator = map3.entrySet().iterator();
//                while (iterator.hasNext()) {
//                    Map.Entry<String, Object> entry = iterator.next();
//                    System.out.println("key: " + entry.getKey() + " value: " + entry.getValue());
//                    if(entry.getValue().toString().contains("格式错误")){
//                        log.info("===导入异常原因===", entry.getValue().toString());
//                        mess+=entry.getValue().toString();
//                    }
//                }
//            }
//            if(mess.contains("格式错误")){
//                return toAjaxMesMeg(0, mess);
//            }
//            for (int q = 0; q < listPeople.size(); q++) {
//                Map<String, Object> map3 = listPeople.get(q);
//                log.info("====获取excel值==" + listPeople);
//                su = listPeople.size();
//                //执行insert语句
//                orderPeopleService.addOrderPeople((HashMap<String, Object>) map3);
//                mess="导入成功";
//            }
//
//        } catch (Exception e) {
//            log.error("导入异常", e);
//            mess="上传失败,请稍后重试!";
//            return toAjaxMes(su, mess);
//        }
//        return toAjaxMes(su, mess);
//    }

    /**
     * 导入信息
     */
    @RequiresPermissions("order:order:batchAdd")
    @PostMapping("/importOrder")
    @ResponseBody
    @Transactional
    public AjaxResult excelSave(Order order, OrderProductPlan orderProductPlan, OrderPeople orderPeople, @RequestParam("uploadFile") MultipartFile file, HttpServletRequest request)
    {
        String message="";
        //判断文件是否为空
        if(file==null){
            message="文件不能为空！";
            return toAjaxMes(0,message);
        }
        //获取文件名
        String fileName=file.getOriginalFilename();
        //验证文件名是否合格
        if(!NewFileUploadUtils.validateExcel(fileName)){
            message="文件必须是excel格式！";
            return toAjaxMes(0,message);
        }
        //进一步判断文件内容是否为空（即判断其大小是否为0或其名称是否为null）
        long size=file.getSize();
        if(StringUtils.isEmpty(fileName) || size==0){
            message="文件不能为空！";
            return toAjaxMes(0,message);
        }
//        try {
//            String start = request.getParameter("startTime");
//            String end = request.getParameter("endTime");
//            Date startTime = new SimpleDateFormat("yyyy-MM-dd").parse(start);
//            Date endTime = new SimpleDateFormat("yyyy-MM-dd").parse(end);
//            feilvComplex.setStartTime(startTime);
//            feilvComplex.setEndTime(endTime);
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }
        //批量导入
        message = orderService.batchImport(order,orderProductPlan,orderPeople,file);

        if(message.contains("行")){
            return error(message);
        }else{
            return success(message);
        }
    }

    /**
     * 续保保险订单
     */
    @GetMapping("/renewal/{id}")
    public String renewal(@PathVariable("id") Integer id, ModelMap mmap) {
        Order order = orderService.selectOrderById(id);
        mmap.put("order", order);
        return prefix + "/renewal";
    }

    /**
     * 新增保存保险订单
     */
    @RequiresPermissions("order:order:add")
    @Log(title = "保险订单", action = BusinessType.INSERT)
    @PostMapping("/renewal")
    @ResponseBody
    public AjaxResult renewalSave(Order order) {
//        //转换前台接收值为date
//        if (!order.getStartTimeStr().equals("")) {
//            order.setStartTime(DateUtils.dateTime("yyyy-MM-dd", order.getStartTimeStr()));
//        }
//        if (!order.getEndTimeStr().equals("")) {
//            order.setEndTime(DateUtils.dateTime("yyyy-MM-dd", order.getEndTimeStr()));
//        }
//        if (!order.getXubaoTimeStr().equals("")) {
//            order.setXubaoTime(DateUtils.dateTime("yyyy-MM-dd", order.getXubaoTimeStr()));
//        }
//        User user= userService.selectDeptNameUserId(Long.parseLong(order.getUserId()+""));
//        order.setTeamId(Integer.parseInt(user.getDeptId()+""));
//        order.setTeamName(order.getDeptName());
        Order order1 = orderService.selectOrderById(order.getId());
        order.setInsureId(order1.getInsureId());
        order.setTeamName(order1.getTeamName());
        order.setTeamId(order1.getTeamId());
        order.setUserId(order1.getUserId());
        order.setCustomerId(order1.getCustomerId());
        order.setChannelId(order1.getChannelId());
        order.setChannelName(order1.getChannelName());
        return toAjax(orderService.renewalOrder(order));
    }
    /**
     * 进入到添加计划页面
     */
    @GetMapping("/orderNextPlan/{renewId}")
    public String orderNextPlan(@PathVariable("renewId") String renewId, ModelMap mmap) {
//            Order order = orderService.selectOrderByRenewId(renewId);
        Order order = orderService.selectOrderById(189);
            if(1==order.getCustomerSo()){
                mmap.put("orderId", order.getRenewId());//0新保，1续保
            }else{
                mmap.put("orderId", order.getOrderId());//0新保，1续保
            }
            mmap.put("order", order);
            return prefix + "/addPlan";
    }

    //下载保单的首页
    @PostMapping("/downloadShouye")
    @ResponseBody
    public String downloadShouye(HttpServletResponse response, String id) {

        //待生成的zip包名
//        String zipName = String.valueOf(new Date().getTime());
        try {
            Order order=   orderService.selectOrderById(Integer.parseInt(id));
            String xu="";
            String orderids="";
            if (order.getCustomerSo() != 0) {
                orderids=order.getRenewId();
                xu = "续保";
            }else{
                orderids=order.getOrderId();
            }
            UploadImage  uploadImage = uploadImageService.selectUploadImageOrderId(orderids,"shouye");
            String  zipName=uploadImage.getOrderId()+"shouye";
            //数据库中文件的保存路径
            String sourceFilePath="";
            if(sourceFilePath!=null){
                //待生成的zip保存路径
                String osName = System.getProperties().getProperty("os.name");
                System.out.println("----系统是---"+osName);
                String filePath = "";
                String zipFilePath ="";
//                String zipFilePath = "D:\\yasuobao";
                String path="";
                if (osName.equals("Linux")) {
                    filePath = "/var/opt/yasuobao/";
                    zipFilePath="/var/opt/yasuobao";
                    sourceFilePath=uploadImage.getLinuxPath();
                } else {
                    filePath = "D:/yasuobao\\";
                    zipFilePath = "D:/yasuobao";
                    sourceFilePath=uploadImage.getUploadPath();
                }
                path=filePath+zipName+".zip";
//                String zipFilePath = "D:\\yasuobao";
                //压缩
                FileToZip.fileToZip(sourceFilePath , zipFilePath , zipName);
                //压缩包的绝对路径+完整压缩包名字
//                String path="D:\\yasuobao\\"+zipName+".zip";
                // path是指欲下载的文件的路径。
                File file = new File(path);
                // 取得文件名。
                String filename = file.getName();
                // 取得文件的后缀名。
                String ext = filename.substring(filename.lastIndexOf(".") + 1).toUpperCase();
                // 以流的形式下载文件。
                InputStream fis = new BufferedInputStream(new FileInputStream(path));
                byte[] buffer = new byte[fis.available()];
                fis.read(buffer);
                fis.close();
                // 清空response
                response.reset();
                // 设置response的Header
                response.addHeader("Content-Disposition", "attachment;filename=" + new String(filename.getBytes("utf-8"),"iso-8859-1"));
                response.addHeader("Content-Length", "" + file.length());
                OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
                response.setContentType("application/octet-stream");
                toClient.write(buffer);
                toClient.flush();
                toClient.close();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return "对不起！该条协议您还没有上传影像不能进行下载！";
//        return response;
    }

    /**
     *上传续保excel表
     */
    @RequiresPermissions("order:order:renewalAdd")
    @GetMapping("/uploadRenewal/{orderId}")
    public String uploadBath1(Order order,ModelMap mmap) {
        Order orders = orderService.selectOrderById(order.getId());
        mmap.put("order", orders);
        return prefix + "/uploadRenewal";
    }
    /**
     * 导入信息
     */
    @RequiresPermissions("order:order:renewalAdd")
    @PostMapping("/importOrder1")
    @ResponseBody
    @Transactional
    public AjaxResult excelSave1(Order order,@RequestParam("uploadFile") MultipartFile file, HttpServletRequest request) {
        String message="";
        //判断文件是否为空
        if(file==null){
            message="文件不能为空！";
            return toAjaxMes(0,message);
        }
        //获取文件名
        String fileName=file.getOriginalFilename();
        //验证文件名是否合格
        if(!NewFileUploadUtils.validateExcel(fileName)){
            message="文件必须是excel格式！";
            return toAjaxMes(0,message);
        }
        //进一步判断文件内容是否为空（即判断其大小是否为0或其名称是否为null）
        long size=file.getSize();
        if(StringUtils.isEmpty(fileName) || size==0){
            message="文件不能为空！";
            return toAjaxMes(0,message);
        }
//        try {
//            String start = request.getParameter("startTime");
//            String end = request.getParameter("endTime");
//            Date startTime = new SimpleDateFormat("yyyy-MM-dd").parse(start);
//            Date endTime = new SimpleDateFormat("yyyy-MM-dd").parse(end);
//            feilvComplex.setStartTime(startTime);
//            feilvComplex.setEndTime(endTime);
//        } catch (ParseException e) {
//            e.printStackTrace();
//        }
        //批量导入
        message = orderService.batchImport1(order,file);

        if(message.contains("行")){
            return error(message);
        }else{
            return success(message);
        }
    }



}
