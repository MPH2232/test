package com.ruoyi.project.order.orderproductPlan.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.project.order.orderproductPlan.domain.OrderProductPlan;
import com.ruoyi.project.order.orderproductPlan.service.IOrderproductPlanService;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.framework.web.domain.AjaxResult;

/**
 * 订单关联计划--详细产品--关联分期id--关联保全 信息操作处理
 * 
 * @author ruoyi
 * @date 2018-08-31
 */
@Controller
@RequestMapping("/order/orderproductPlan")
public class OrderproductPlanController extends BaseController
{
    private String prefix = "order/orderproductPlan";
	
	@Autowired
	private IOrderproductPlanService orderproductPlanService;
	
	@RequiresPermissions("order:orderproductPlan:view")
	@GetMapping()
	public String orderproductPlan()
	{
	    return prefix + "/orderproductPlan";
	}
	
	/**
	 * 查询订单关联计划--详细产品--关联分期id--关联保全列表
	 */
	@RequiresPermissions("order:orderproductPlan:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(OrderProductPlan orderproductPlan)
	{
		startPage();
        List<OrderProductPlan> list = orderproductPlanService.selectOrderproductPlanList(orderproductPlan);
		return getDataTable(list);
	}
	
	/**
	 * 新增订单关联计划--详细产品--关联分期id--关联保全
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存订单关联计划--详细产品--关联分期id--关联保全
	 */
	@RequiresPermissions("order:orderproductPlan:add")
	@Log(title = "订单关联计划--详细产品--关联分期id--关联保全", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(OrderProductPlan orderproductPlan)
	{		
		return toAjax(orderproductPlanService.insertOrderproductPlan(orderproductPlan));
	}

	/**
	 * 修改订单关联计划--详细产品--关联分期id--关联保全
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		OrderProductPlan orderproductPlan = orderproductPlanService.selectOrderproductPlanById(id);
		mmap.put("orderproductPlan", orderproductPlan);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存订单关联计划--详细产品--关联分期id--关联保全
	 */
	@RequiresPermissions("order:orderproductPlan:edit")
	@Log(title = "订单关联计划--详细产品--关联分期id--关联保全", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(OrderProductPlan orderproductPlan)
	{		
		return toAjax(orderproductPlanService.updateOrderproductPlan(orderproductPlan));
	}
	
	/**
	 * 删除订单关联计划--详细产品--关联分期id--关联保全
	 */
	@RequiresPermissions("order:orderproductPlan:remove")
	@Log(title = "订单关联计划--详细产品--关联分期id--关联保全", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(orderproductPlanService.deleteOrderproductPlanByIds(ids));
	}
	
}
