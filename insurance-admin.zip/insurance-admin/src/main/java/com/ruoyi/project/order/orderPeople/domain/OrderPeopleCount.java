package com.ruoyi.project.order.orderPeople.domain;

import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

import java.util.Date;

/**
 * 人员清单，关联订单，表 f_order_people
 * 
 * @author ruoyi
 * @date 2018-08-23
 */
public class OrderPeopleCount
{
	/** 计划表的计划名称 */
	private String planPeopleName;
	/** 计划下多少人 */
	private String counts;



	public String getPlanPeopleName() {
		return planPeopleName;
	}

	public void setPlanPeopleName(String planPeopleName) {
		this.planPeopleName = planPeopleName;
	}

	public String getCounts() {
		return counts;
	}

	public void setCounts(String counts) {
		this.counts = counts;
	}
}
