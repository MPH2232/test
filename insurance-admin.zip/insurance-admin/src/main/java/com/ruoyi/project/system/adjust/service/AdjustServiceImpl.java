package com.ruoyi.project.system.adjust.service;



import com.ruoyi.project.homepage.homepage.damain.AdjustUser;
import com.ruoyi.project.system.adjust.mapper.AdjustMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;


/**
 *AdjustUser业务员调整 服务层处理
 * 
 * @author ruoyi
 */
@Service
public class AdjustServiceImpl implements  IAdjustService {
    @Autowired
    private AdjustMapper adjustMapper;

    @Override
    public int insertAdjustByUser(AdjustUser adjustUser) {
        return adjustMapper.insertAdjustByUser(adjustUser);
    }

    /**
     * admin管理员
     *
     * @param adjustUser
     * @return
     */
    @Override
    public List<AdjustUser> selectAdjustList(AdjustUser adjustUser) {
        return adjustMapper.selectAdjustList(adjustUser);
    }

    @Override
    public AdjustUser selectAdjustById(Long id) {
        return adjustMapper.selectAdjustById(id);
    }



    @Override
    public AdjustUser selectAdjustById1(Long buserId) {
        return adjustMapper.selectAdjustById1(buserId);
    }

    @Override
    public List<AdjustUser> selectAdjustListZongjian(AdjustUser adjustUser) {
        return adjustMapper.selectAdjustListZongjian(adjustUser);
    }

    @Override
    public List<AdjustUser> selectAdjustMajordomoList(AdjustUser adjustUser) {
        return adjustMapper.selectAdjustMajordomoList(adjustUser);
    }

    @Override
    public List<AdjustUser> selectAdjustYwyList(AdjustUser adjustUser) {
        return adjustMapper.selectAdjustYwyList(adjustUser);
    }


    /**
     * 更改（保存）
     *
     * @param adjustUser
     * @return
     */
    @Override
    public int updateAdjust(AdjustUser adjustUser) {
        return adjustMapper.updateAdjust(adjustUser);
    }

    @Override
    public AdjustUser selectAdjustUserByBuserId(Integer buserId) {
        return adjustMapper.selectAdjustUserByBuserId(buserId);
    }

    @Override
    public int insertAdjustUser(AdjustUser adjustUser) {
        return adjustMapper.insertAdjustUser(adjustUser);
    }

    /**
     * 改变调整状态
     * @param adjustUser
     * @return
     */
    @Override
    public int updateAdjustStatus(AdjustUser adjustUser) {
        return adjustMapper.updateAdjustStatus(adjustUser);
    }
//1102
    @Override
    public int updateAdjustUser(AdjustUser adjustUser) {
        return adjustMapper.updateAdjustUser(adjustUser);
    }


    @Override
    public List<AdjustUser> selectCustomerListMajordomo(long deptId) {
        return adjustMapper.selectCustomerListMajordomo(deptId);
    }

    @Override
    public List<AdjustUser> selectCustomerListCharge(long deptId) {
        return  adjustMapper.selectCustomerListCharge(deptId);
    }

    @Override
    public List<AdjustUser> selectCustomerListSalesman(long userIdd) {
        return adjustMapper.selectCustomerListSalesman(userIdd);
    }

    @Override
    public int insertAftUser(AdjustUser adjustUser) {
        return adjustMapper.insertAftUser(adjustUser);
    }


}



