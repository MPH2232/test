package com.ruoyi.project.system.product.service;


import com.ruoyi.project.system.product.domain.FeilvComplex;
import com.ruoyi.project.system.product.domain.ProductFeilvSimple;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;
import java.util.List;

/**
 * 产品-简单费率（定制产品） 服务层
 * 
 * @author ruoyi
 * @date 2018-10-19
 */
public interface IProductFeilvSimpleService 
{
	/**
     * 查询产品-简单费率（定制产品）信息
     * 
     * @param id 产品-简单费率（定制产品）ID
     * @return 产品-简单费率（定制产品）信息
     */
	public ProductFeilvSimple selectProductFeilvSimpleById(Integer id);
	
	/**
     * 查询产品-简单费率（定制产品）列表
     * 
     * @param productFeilvSimple 产品-简单费率（定制产品）信息
     * @return 产品-简单费率（定制产品）集合
     */
	public List<ProductFeilvSimple> selectProductFeilvSimpleList(ProductFeilvSimple productFeilvSimple);
	
	/**
     * 新增产品-简单费率（定制产品）
     * 
     * @param productFeilvSimple 产品-简单费率（定制产品）信息
     * @return 结果
     */
	public int insertProductFeilvSimple(ProductFeilvSimple productFeilvSimple);
	
	/**
     * 修改产品-简单费率（定制产品）
     * 
     * @param productFeilvSimple 产品-简单费率（定制产品）信息
     * @return 结果
     */
	public int updateProductFeilvSimple(ProductFeilvSimple productFeilvSimple);
		
	/**
     * 删除产品-简单费率（定制产品）信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteProductFeilvSimpleByIds(String ids);

	public String batchImport(ProductFeilvSimple productFeilvSimple, MultipartFile mfile);

	public int insertProductFeilvSimpleList(List<ProductFeilvSimple> productFeilvSimpleList);

	public int deleteProductFeilvSimpleByProductIdAndEndTime(@Param("productId") Long productId, @Param("endTime")Date endTime);
	
}
