package com.ruoyi.project.system.customer.controller;

import com.ruoyi.common.utils.BankUtil;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.domain.CustomerAttention;
import com.ruoyi.project.system.customer.domain.CustomerContacts;
import com.ruoyi.project.system.customer.service.lCustomerContactsService;
import com.ruoyi.project.system.customer.service.lCustomerService;
import com.ruoyi.project.system.user.domain.User;
import com.ruoyi.project.system.user.service.IUserService;
import com.xiaoleilu.hutool.http.HttpUtil;
import com.xiaoleilu.hutool.util.ReUtil;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.omg.Messaging.SYNC_WITH_TRANSPORT;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * 客户信息操作处理
 * @author ruoyi
 */
@Controller
//企业客户
@RequestMapping("/system/customer")
public class CustomerController extends BaseController {
    private String prefix = "system/customer/homepage";

    @Autowired
    private lCustomerService customerService;

    /**/
    @Autowired
    private IUserService userService;

    /**
     * 联系人信息
     */
    @Autowired
    private lCustomerContactsService customerContactsService;

    @RequiresPermissions("system:customer:view")
    @GetMapping()
    public String operlog(ModelMap mmap) {
        mmap.put("userId",getUserId());
        return prefix + "/customer";
    }

    @RequiresPermissions("system:customer:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Customer customer) {
        User user = getUser();
        String name=userService.selectUserRoleGroup(user.getUserId());
        startPage();
        List<Customer> list=new ArrayList<Customer>();
        if(name.contains("管理员")){
            //管理员
            list = customerService.selectCustomerList(customer);
        }else if(name.equals("主管")){
            //主管
            list = customerService.selectCustomerListCharge(user.getDeptId(),customer);
        }else if(name.equals("总监")){
            //总监
            list = customerService.selectCustomerListMajordomo(user.getDeptId(),customer);
        }else {
            //业务员
            list = customerService.selectCustomerListSalesman(user.getUserId(),customer);
        }
        return getDataTable(list);
    }


//更多客户
    @PostMapping("/list1")
    @ResponseBody
    public TableDataInfo list1(Customer customer) {
        User user = getUser();
        String name=userService.selectUserRoleGroup(user.getUserId());
        startPage();
        List<Customer> list=new ArrayList<Customer>();
        if(name.contains("管理员")){
            //管理员
            list = customerService.selectCustomerList(customer);
        }else if(name.equals("主管")){
            //主管
            list = customerService.selectCustomerListCharge(user.getDeptId(),customer);
        }else if(name.equals("总监")){
            //总监
            list = customerService.selectCustomerListMajordomo(user.getDeptId(),customer);
        }else {
            //业务员
            list = customerService.selectCustomerListSalesman(user.getUserId(),customer);
        }
        return getDataTable(list);
    }

    @Log(title = "客户管理", action = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Customer customer) throws Exception {
        try {
            List<Customer> list = customerService.selectCustomerList(customer);
            ExcelUtil<Customer> util = new ExcelUtil<Customer>(Customer.class);
            return util.exportExcel(list, "post");
        } catch (Exception e) {
            return error("导出Excel失败，请联系网站管理员！");
        }
    }
    /**
     * 新增企业客户
     */
    @GetMapping("/add/{userId}")
    public String add(@PathVariable("userId") String userId, ModelMap mmap) {
        mmap.put("userId",userId);
        mmap.put("userName",getUser().getUserName());
        return prefix + "/add";
    }

    /**
     * 新增保存企业客户
     */
    @RequiresPermissions("system:customer:add")
    @Log(title = "客户管理", action = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Customer customer) {
        return toAjax(customerService.insertCustomer(customer));
    }


    /**
     * 修改客户
     */
    @GetMapping("/edit/{id}")

    public String edit(@PathVariable("id") Long id, ModelMap mmap) {
        mmap.put("customer", customerService.selectCustomerById(id));
        return prefix + "/edit";
    }

    /**
     * 修改保存客户
     */
    @RequiresPermissions("system:customer:edit")
    @Log(title = "客户管理", action = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Customer customer) {
        return toAjax(customerService.updateCustomer(customer));
    }

    /**
     * 查看企业客户信息
     */
    @GetMapping("/cmd/{id}")
    public String check(@PathVariable("id") Long id, ModelMap mmap) {
        Customer customer= customerService.selectCustomerById(id);
        List<CustomerContacts> contacts =customerService.selectCustomerContactsListInfo(customer.getId());
        List<CustomerAttention> attention = customerService.selectCustomerAttentionListInfo(customer.getId());
        mmap.put("customer", customer);
        mmap.put("contacts",contacts);
        mmap.put("attention",attention);
        return prefix + "/cmd";
    }

    /**
     * 查询联系人详细
     */
    @RequiresPermissions("system:customer:list1")
    @GetMapping("/detail/{id}")
    public String detail(@PathVariable("id") Long id, ModelMap mmap)

    {
        mmap.put("customer", customerService.selectCustomerById(id));
        mmap.put("customerList", customerService.selectCustomerAll());
        return "system/customer/contacts/contacts";
    }

    /**
     * 查询收件人详细
     */
    @RequiresPermissions("system:customer:list2")
    @GetMapping("/attention/{id}")
    public String attention(@PathVariable("id") Long id, ModelMap mmap)
    {
        System.out.println(id);
        mmap.put("customer", customerService.selectCustomerById(id));
        mmap.put("customerList", customerService.selectCustomerAll());
        return "system/customer/attention/attention";
    }

    /**
     * 批量删除企业客户
     * @param ids
     * @return
     */
    @RequiresPermissions("system:customer:remove")
    @Log(title = "客户管理", action = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        try {
            return toAjax(customerService.deleteCustomerByIds(ids));
        } catch (Exception e) {
            return error(e.getMessage());
        }
    }

    /**
     * 根据银行卡号查开户行
     */
    @PostMapping("/findPaytaxesBank")
    @ResponseBody
    public String findPaytaxesBank(Customer customer){
        String title= BankUtil.getNameOfBank(customer.getPaytaxesNumber());
        if(title==""){
            try{
                //获取到银行卡号
                String bankNo=customer.getPaytaxesNumber();
                //银行代码请求接口 url
                String url = "https://ccdcapi.alipay.com/validateAndCacheCardInfo.json?_input_charset=utf-8&cardNo="+bankNo+"&cardBinCheck=true";
                //发送请求，得到 josn 类型的字符串
                String result = HttpUtil.get(url);
                // 转为 Json 对象
                com.xiaoleilu.hutool.json.JSONObject json = new com.xiaoleilu.hutool.json.JSONObject(result);
                //获取到 bank 代码
                String bank = String.valueOf(json.get("bank"));
                //爬取支付宝银行合作商页面
                String listContent = HttpUtil.get("http://ab.alipay.com/i/yinhang.htm","gb2312");
                //过滤得到需要的银行名称
                List<String> titles = ReUtil.findAll("<span title=\"(.*?)\" class=\"icon "+bank+"\">(.*?)</span>", listContent, 2);
                for (String title1 : titles) {
                    //打印银行名称
                    System.out.print(title1);
                    title=title1;
                }
            }catch(Exception e){
                return title;
            }
        }
        return title;
    }
    @PostMapping("/findPremiumBank")
    @ResponseBody
    public String findPremiumBank(Customer customer){
        String title=BankUtil.getNameOfBank(customer.getPremiumNumber());
        if(title==""){
            try{
                //获取到银行卡号
                String bankNo=customer.getPremiumNumber();
                //银行代码请求接口 url
                String url = "https://ccdcapi.alipay.com/validateAndCacheCardInfo.json?_input_charset=utf-8&cardNo="+bankNo+"&cardBinCheck=true";
                //发送请求，得到 josn 类型的字符串
                String result = HttpUtil.get(url);
                // 转为 Json 对象
                com.xiaoleilu.hutool.json.JSONObject json = new com.xiaoleilu.hutool.json.JSONObject(result);
                //获取到 bank 代码
                String bank = String.valueOf(json.get("bank"));
                //爬取支付宝银行合作商页面
                String listContent = HttpUtil.get("http://ab.alipay.com/i/yinhang.htm","gb2312");
                //过滤得到需要的银行名称
                List<String> titles = ReUtil.findAll("<span title=\"(.*?)\" class=\"icon "+bank+"\">(.*?)</span>", listContent, 2);
                for (String title1 : titles) {
                    //打印银行名称
                    System.out.print(title1);
                    title=title1;
                }
            }catch(Exception e){
                return title;
            }
        }
        return title;
    }




}