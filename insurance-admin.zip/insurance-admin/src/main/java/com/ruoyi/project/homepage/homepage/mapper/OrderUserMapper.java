package com.ruoyi.project.homepage.homepage.mapper;


import com.ruoyi.project.homepage.homepage.damain.OrderUser;
import com.ruoyi.project.order.order.domain.Order;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * Created by x on 2018/9/17.
 */
public interface OrderUserMapper {
    /**
     * 查询所有订单消息
     */

    public List<OrderUser> selectOrderUserList(OrderUser orderUser);
    public List<OrderUser> selectOrderList1(OrderUser orderUser);


    /**
     * 通过id查询订单
     * @param id
     * @returni
     */
    public OrderUser selectOrderUserById(Integer id);



    //1024
   public int updateSalesmanName(Order order);


}
