package com.ruoyi.project.system.customer.controller;

import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.project.system.customer.domain.CustomerContacts;
import com.ruoyi.project.system.customer.service.lCustomerContactsService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 客户信息操作处理
 * @author ruoyi
 */
@Controller
//企业客户
@RequestMapping("/system/customer/contacts")
public class CustomerContactsController extends BaseController {
    private String prefix = "system/customer/contacts";
    @Autowired
    private lCustomerContactsService customerContactsService;
    @RequiresPermissions("system:customer:view")
    @GetMapping()
    public String operlog1() {
        return prefix + "/contacts";
    }

    @RequiresPermissions("system:customer:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(CustomerContacts customercontacts) {
        startPage();
        List<CustomerContacts> list = customerContactsService.selectCustomerContactsByCustomerId(customercontacts.getCustomerId());
        return getDataTable(list);
    }

//    @Log(title = "客户管理", action = BusinessType.EXPORT)
//    @PostMapping("/export")
//    @ResponseBody
//    public AjaxResult export(Customer customer) throws Exception {
//        try {
//            List<Customer> list = customerService.selectCustomerList(customer);
//            ExcelUtil<Customer> util = new ExcelUtil<Customer>(Customer.class);
//            return util.exportExcel(list, "post");
//        } catch (Exception e) {
//            return error("导出Excel失败，请联系网站管理员！");
//        }
//    }

//    @GetMapping("/add")
//    public String add() {
//        return prefix + "/add";
//    }

    /**
     * 新增联系人
     */
    @GetMapping("/add/{id}")
    public String add(@PathVariable("id") long id, ModelMap mmap)
    {
        mmap.put("customer",id);
        return prefix + "/add";
    }

    /**
     * 新增保存联系人
     */
    @RequiresPermissions("system:customer:add")
    @Log(title = "客户管理", action = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(CustomerContacts customercontacts) {
        return toAjax(customerContactsService.insertCustomerContacts(customercontacts));
    }

    /**
     * 修改联系人信息
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") long id, ModelMap mmap)
    {
        mmap.put("customercontacts", customerContactsService.selectCustomerContactsById(id));
        return prefix + "/edit";
    }

    /**
     * 修改保存联系人信息
     */
    @Log(title = "联系人信息", action = BusinessType.UPDATE)
    @RequiresPermissions("system:customer:edit")
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(CustomerContacts customerContacts)
    {
        return toAjax(customerContactsService.updateCustomerContacts(customerContacts));
    }

    /**
     * 批量删除联系人信息
     * @param ids
     * @return
     */
    @RequiresPermissions("system:customer:remove")
    @Log(title = "客户管理", action = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        try {
            return toAjax(customerContactsService.deleteCustomerContactsByIds(ids));
        } catch (Exception e) {
            return error(e.getMessage());
        }
    }

}