package com.ruoyi.project.order.orderFenqi.mapper;

import com.ruoyi.project.order.orderFenqi.domain.OrderFenqi;
import java.util.List;	

/**
 * 订单分期--关联计划id,--关联订单id--关联保全 数据层
 * 
 * @author ruoyi
 * @date 2018-09-17
 */
public interface OrderFenqiMapper 
{
	/**
     * 查询订单分期--关联计划id,--关联订单id--关联保全信息
     * 
     * @param id 订单分期--关联计划id,--关联订单id--关联保全ID
     * @return 订单分期--关联计划id,--关联订单id--关联保全信息
     */
	public OrderFenqi selectOrderFenqiById(Integer id);
	
	/**
     * 查询订单分期--关联计划id,--关联订单id--关联保全列表
     * 
     * @param orderFenqi 订单分期--关联计划id,--关联订单id--关联保全信息
     * @return 订单分期--关联计划id,--关联订单id--关联保全集合
     */
	public List<OrderFenqi> selectOrderFenqiList(OrderFenqi orderFenqi);
	public int selectOrderFenqiId(String orderFenqiId);
	/**
     * 新增订单分期--关联计划id,--关联订单id--关联保全
     * 
     * @param orderFenqi 订单分期--关联计划id,--关联订单id--关联保全信息
     * @return 结果
     */
	public int insertOrderFenqi(OrderFenqi orderFenqi);

	public int insertOrderFenqiList(List<OrderFenqi> orderFenqi);

	/**
     * 修改订单分期--关联计划id,--关联订单id--关联保全
     * 
     * @param orderFenqi 订单分期--关联计划id,--关联订单id--关联保全信息
     * @return 结果
     */
	public int updateOrderFenqi(OrderFenqi orderFenqi);
	
	/**
     * 删除订单分期--关联计划id,--关联订单id--关联保全
     * 
     * @param id 订单分期--关联计划id,--关联订单id--关联保全ID
     * @return 结果
     */
	public int deleteOrderFenqiById(Integer id);
	
	/**
     * 批量删除订单分期--关联计划id,--关联订单id--关联保全
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteOrderFenqiByIds(String[] ids);
//	public OrderFenqi selectOrderFenqiByOrderId(String orderFenqiId);
	public List<OrderFenqi> selectFenqiList(String orderFenqi);
	public OrderFenqi selectFenqiPayTime(String payTime);
}