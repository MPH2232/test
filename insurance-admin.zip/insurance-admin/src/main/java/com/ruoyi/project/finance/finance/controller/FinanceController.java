package com.ruoyi.project.finance.finance.controller;

import com.ruoyi.common.utils.NewFileUploadUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.project.finance.finance.service.IFinanceService;
import com.ruoyi.project.finance.finance.domain.Finance;
import com.ruoyi.project.order.orderPeople.domain.OrderPeople;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.notice.domain.Notice;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * 公告 信息操作处理
 * 
 * @author ruoyi
 */
@Controller
@RequestMapping("/finance/finance")
public class FinanceController extends BaseController
{
    private String prefix = "finance/finance";
    @Autowired
    private IFinanceService financeService;

    @RequiresPermissions("finance:finance:view")
    @GetMapping()
    public String finance()
    {
        return prefix + "/finance";
    }

    /**
     * 查询认收清单信息
     */
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Finance finance) {
        startPage();
        List<Finance> list = financeService.selectFinaceList(finance);
        return getDataTable(list);
    }

    /**
     * 新增公告
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存公告
     */
    @RequiresPermissions("finance:finance:add")
    @Log(title = "通知公告", action = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Finance finance)
    {
        System.out.println(finance.getFinanceStatus());
        return toAjax(financeService.insertFinance(finance));
    }

    /**
     * 修改认款清单
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long finanaceId, ModelMap mmap)
    {

        mmap.put("finance", financeService.selectFinanceById(finanaceId));
        return prefix + "/edit";
    }

    /**
     * 修改保存认款清单
     */
    @RequiresPermissions("finance:finance:edit")
    @Log(title = "认款清单", action = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Finance finance)
    {
        return toAjax(financeService.updateFinance(finance));
    }


    /**
     * 批量删除
     * @param ids
     * @return
     */
    @RequiresPermissions("finance:finance:remove")
    @Log(title = "客户管理", action = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        try {
            return toAjax(financeService.deleteFinanceByIds(ids));
        } catch (Exception e) {
            return error(e.getMessage());
        }
    }

    /**
     *上传excel表
     */
//    @RequiresPermissions("finance:finance:upload")
    @GetMapping("/upload")
    public String upload(Customer customer, ModelMap mmap) {
//        Customer customerPerson =customerService.selectCustomerById(customer.getId());
//        mmap.put("customerPerson",customerPerson);
        return prefix + "/upload";
    }

    /**
     * 导入待认款清单数据
     */
    @RequiresPermissions("finance:finance:upload")
    @PostMapping("/excelSave")
    @ResponseBody
    public AjaxResult excelSave(Finance finance, @RequestParam("uploadFile") MultipartFile file)
    {
        String message="";
        //判断文件是否为空
        if(file==null){
            message="文件不能为空！";
            return toAjaxMes(0,message);
        }

        //获取文件名
        String fileName=file.getOriginalFilename();

        //验证文件名是否合格
        if(!NewFileUploadUtils.validateExcel(fileName)){
            message="文件必须是excel格式！";
            return toAjaxMes(0,message);
        }

        //进一步判断文件内容是否为空（即判断其大小是否为0或其名称是否为null）
        long size=file.getSize();
        if(StringUtils.isEmpty(fileName) || size==0){
            message="文件不能为空！";
            return toAjaxMes(0,message);
        }
        //批量导入
        message = financeService.batchImport(finance,file);

        if(message.contains("行")){
            return error(message);
        }else{
            return success(message);
        }
//        return toAjaxMes(1,message);
    }










}
