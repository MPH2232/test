package com.ruoyi.project.system.product.controller;

import com.ruoyi.common.utils.NewFileUploadUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.poi.ExcelProductUtil;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.framework.web.page.TableDataInfo;

import com.ruoyi.project.order.order.domain.Order;
import com.ruoyi.project.order.uploadImage.domain.UploadImage;
import com.ruoyi.project.system.product.domain.Feilv;
import com.ruoyi.project.system.product.domain.FeilvComplex;
import com.ruoyi.project.system.product.domain.Product;
import com.ruoyi.project.system.product.domain.ProductFeilvSimple;
import com.ruoyi.project.system.product.service.IProductFeilvComplexService;
import com.ruoyi.project.system.product.service.IProductFeilvService;
import com.ruoyi.project.system.product.service.IProductFeilvSimpleService;
import com.ruoyi.project.system.product.service.IProductService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 费率信息
 * 
 * @author ruoyi
 */
@Controller
@RequestMapping("/system/product/data")
public class ProductFeilvController extends BaseController {
    private static final Logger log = LoggerFactory.getLogger(ProductFeilvController.class);
    private String prefix = "system/product/data";
    int su = 0;
    String mess="";

    @Autowired
    private IProductFeilvService productFeilvService;
    @Autowired
    private IProductService productService;
    @Autowired
    private IProductFeilvComplexService productFeilvComplexService;
    @Autowired
    private IProductFeilvSimpleService productFeilvSimpleService;


    @PostMapping("/list")
    @RequiresPermissions("system:product:list")
    @ResponseBody
    public TableDataInfo list(FeilvComplex feilvComplex)
    {
        startPage();
//        List<FeilvComplex> list = productFeilvComplexService.selectFeilvComplexList(feilvComplex.getProductId());
        List<FeilvComplex> list = productFeilvComplexService.selectFeilvComplexList1(feilvComplex);
        return getDataTable(list);
    }

    @PostMapping("/list2")
    @RequiresPermissions("system:product:list")
    @ResponseBody
    public TableDataInfo list2(ProductFeilvSimple productFeilvSimple)
    {
        startPage();
        List<ProductFeilvSimple> list = productFeilvSimpleService.selectProductFeilvSimpleList(productFeilvSimple);
        return getDataTable(list);
    }



    /*导出excel文件*/
    @Log(title = "费率数据", action = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Feilv feilv) throws Exception
    {
        try
        {
            List<Feilv> list = productFeilvService.selectFeilvList(feilv);
            ExcelUtil<Feilv> util = new ExcelUtil<Feilv>(Feilv.class);
            return util.exportExcel(list, "feilv");
        }
        catch (Exception e)
        {
            return error("导出Excel失败，请联系网站管理员！");
        }
    }



    /*删除功能*/
    @Log(title = "费率数据", action = BusinessType.DELETE)
    @RequiresPermissions("system:product:remove")
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) throws Exception {
        return toAjax(productFeilvService.deleteFeilvByIds(ids));
    }

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
    }

    /*显示复杂上传页面*/
    @RequiresPermissions("system:product:upload")
    @GetMapping("/upload/{productId}")
    public String upload(Feilv feilv, ModelMap mmap) {
        Product product=productService.selectProductById(feilv.getProductId());
        mmap.put("product", product);
        return prefix + "/upload";
    }

    /*显示简单上传页面*/
    @RequiresPermissions("system:product:upload")
    @GetMapping("/upload2/{productId}")
    public String upload2(Feilv feilv, ModelMap mmap) {
        Product product=productService.selectProductById(feilv.getProductId());
        mmap.put("product", product);
        return prefix + "/upload2";
    }


    /**
     * 导入复杂费率excel文件
     * */
    @PostMapping("/uploadSave")
    @ResponseBody
    @Transactional
    public AjaxResult excelSave(FeilvComplex feilvComplex, @RequestParam("uploadFile") MultipartFile file, HttpServletRequest request)
    {
        String message="";
        //判断文件是否为空
        if(file==null){
            message="文件不能为空！";
            return toAjaxMes(0,message);
        }
        //获取文件名
        String fileName=file.getOriginalFilename();
        //验证文件名是否合格
        if(!NewFileUploadUtils.validateExcel(fileName)){
            message="文件必须是excel格式！";
            return toAjaxMes(0,message);
        }
        //进一步判断文件内容是否为空（即判断其大小是否为0或其名称是否为null）
        long size=file.getSize();
        if(StringUtils.isEmpty(fileName) || size==0){
            message="文件不能为空！";
            return toAjaxMes(0,message);
        }
        try {
            String start = request.getParameter("startTime");
            String end = request.getParameter("endTime");
            Date startTime = new SimpleDateFormat("yyyy-MM-dd").parse(start);
            Date endTime = new SimpleDateFormat("yyyy-MM-dd").parse(end);
            feilvComplex.setStartTime(startTime);
            feilvComplex.setEndTime(endTime);
            String id = request.getParameter("ids");
            feilvComplex.setProductId(Long.valueOf(id));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        //批量导入
        message = productFeilvComplexService.batchImport(feilvComplex,file);

        if(message.contains("行")){
            return error(message);
        }else{
            return success(message);
        }
    }

    /**
     * 导入简单费率excel文件
     * */
    @PostMapping("/uploadSave2")
    @ResponseBody
    @Transactional
    public AjaxResult excelSave2(ProductFeilvSimple productFeilvSimple, @RequestParam("uploadFile") MultipartFile file, HttpServletRequest request)
    {
        String message="";
        //判断文件是否为空
        if(file==null){
            message="文件不能为空！";
            return toAjaxMes(0,message);
        }
        //获取文件名
        String fileName=file.getOriginalFilename();
        //验证文件名是否合格
        if(!NewFileUploadUtils.validateExcel(fileName)){
            message="文件必须是excel格式！";
            return toAjaxMes(0,message);
        }
        //进一步判断文件内容是否为空（即判断其大小是否为0或其名称是否为null）
        long size=file.getSize();
        if(StringUtils.isEmpty(fileName) || size==0){
            message="文件不能为空！";
            return toAjaxMes(0,message);
        }
        try {
//            String proName = request.getParameter("proName");
            String start = request.getParameter("startTime");
            String end = request.getParameter("endTime");
            Date startTime = new SimpleDateFormat("yyyy-MM-dd").parse(start);
            Date endTime = new SimpleDateFormat("yyyy-MM-dd").parse(end);
            productFeilvSimple.setStartTime(startTime);
            productFeilvSimple.setEndTime(endTime);
//            productFeilvSimple.setProName(proName);
            String id = request.getParameter("ids");
            productFeilvSimple.setProductId(Long.valueOf(id));

        } catch (ParseException e) {
            e.printStackTrace();
        }
        //批量导入
        message = productFeilvSimpleService.batchImport(productFeilvSimple,file);

        if(message.contains("行")){
            return error(message);
        }else{
            return success(message);
        }

    }
//    public AjaxResult importPeople(Feilv feilv,FeilvComplex feilvComplex,@RequestParam("uploadFile") MultipartFile file) {//页面导入的数据实体
//        System.out.println(feilv.toString());
//        System.out.println(feilvComplex.toString());
//
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        Feilv feilv1=null;
//        List<Feilv> list1= productFeilvService.selectFeilvListById(feilv.getProductId());  //数据库查出来的实体(普通1)
//        List<FeilvComplex> list2=productFeilvComplexService.selectFeilvComplexList(feilvComplex.getProductId()); //数据库查出来的实体(高级1)
//        System.out.println(list2.toArray());
//        if(list1!=null){
//            for(int k=0;k<list1.size();k++){
//                feilv1= list1.get(0);
//            }
//        }
//        try {
////                List<Map<String, Object>> list = ExcelUtil.importExcelsPro(file, feilv);
////                for (int i = 0; i < list.size(); i++) {
////                    Map<String, Object> map1 = list.get(i);
////                    Iterator<Map.Entry<String, Object>> iterator = map1.entrySet().iterator();
////                    while (iterator.hasNext()) {
////                        Map.Entry<String, Object> entry = iterator.next();
////                        System.out.println("key: " + entry.getKey() + " value: " + entry.getValue());
////                        if(entry.getValue().toString().contains("格式错误")){
////                            log.info("===导入异常原因===", entry.getValue().toString());
////                            mess+=entry.getValue().toString();
////                        }
////                    }
//////                    if(map1.get("mes").toString().contains("格式错误")){
//////                        log.info("===导入异常原因===", map1.get("mes").toString());
//////                        mess+=map1.get("mes").toString();
//////                    }
////                }
////            if(mess.contains("格式错误")){
////                return toAjaxMesMeg(su, mess);
////            }
////             else if(feilv1==null){
////                confirm(list,feilv);
////            }else if("0".equals(feilv1.getStatus()) && feilv.getEndTime().getTime()<=feilv1.getStartTime().getTime()){
////                mess="导入时间区间不合理，重新选择时间段";
////                return toAjaxMesMeg(su, mess);
////            }else if("0".equals(feilv1.getStatus()) && feilv.getStartTime().equals(feilv1.getStartTime())  && feilv.getEndTime().equals(feilv1.getEndTime())){
////                productFeilvService.delete(feilv1.getProductName(),feilv1.getStartTime(),feilv1.getEndTime());
////                confirm(list,feilv);
////            }else if("0".equals(feilv1.getStatus()) && feilv.getStartTime().getTime()>=feilv1.getEndTime().getTime()){
////                //把数据库里的0改成1的方法
////                feilv1.setStatus("1");
////                productFeilvService.updateFeilv(feilv1);
////                confirm(list,feilv);
////            }
////            else {
////                mess="请核对导入内容";
////                return toAjaxMesMeg(su, mess);
////            }
//
//             List<Map<String, Object>> list = ExcelProductUtil.importExcelsPro(file, feilvComplex);
//                for (int i = 0; i < list.size(); i++) {
//                    Map<String, Object> map1 = list.get(i);
//                    Iterator<Map.Entry<String, Object>> iterator = map1.entrySet().iterator();
//                    while (iterator.hasNext()) {
//                        Map.Entry<String, Object> entry = iterator.next();
//                        System.out.println("key: " + entry.getKey() + " value: " + entry.getValue());
//                        if(entry.getValue().toString().contains("格式错误")){
//                            log.info("===导入异常原因===", entry.getValue().toString());
//                            mess+=entry.getValue().toString();
//                        }
//                    }
//                }
//        } catch (Exception e) {
//            log.error("导入异常", e);
//            mess="上传失败,请稍后重试!";
//            return toAjaxMes(su, mess);
//        }
//        return toAjaxMes(su, mess);
//    }

//    /*遍历list并在list集合中添加的3个字段*/
//    public  void confirm(List<Map<String, Object>> list,Feilv feilv){
//        for (int q = 0; q < list.size(); q++) {
//            Map<String, Object> map1 = list.get(q);
//            map1.put("status","0");
//            map1.put("startTime",feilv.getStartTime());
//            map1.put("endTime",feilv.getEndTime());
//            log.info("====获取excel值==" + list);
//            su = list.size();
//            //执行insert语句
//            productFeilvService.addFeilv((HashMap<String,Object>) map1);
//            mess="导入成功";
//        }
//    }


}
