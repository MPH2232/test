package com.ruoyi.project.homepage.homepage.service;

import com.ruoyi.project.homepage.homepage.damain.NewsAgency;
import com.ruoyi.project.homepage.homepage.mapper.NewsAgencyMapper;
import com.ruoyi.project.order.order.mapper.OrderMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by x on 2018/9/17.
 */
@Service
public class NewsAgencyServicelmpl implements INewsAgencyService{

    /**
     * 查询所有待办消息
     * @return
     */
    @Autowired
    private NewsAgencyMapper newsAgencyMapper;

    /**
     * 代办消息数据集合
     * @param newsAgency
     * @return
     */
    @Override
    public List<NewsAgency> selectNewsAgencyList(NewsAgency newsAgency) {
        return newsAgencyMapper.selectNewsAgencyList(newsAgency);
    }

    /**
     * 通过id查询
     * @param id
     * @return
     */
    @Override
    public NewsAgency selectNewsAgencyById(Long id) {
        return newsAgencyMapper.selectNewsAgencyById(id);
    }

    @Override
    public NewsAgency selectNewsAgencyById1(Long porposerId) {
        return newsAgencyMapper.selectNewsAgencyById1(porposerId);
    }


    /**
     * 查询所有代办消息
     * @return
     */
    @Override
    public List<NewsAgency> selectNewsAgencyAll() {
        return newsAgencyMapper.selectNewsAgencyAll();
    }

    /**
     * 改变代办状态
     * @param newsAgency
     * @return
     */
    @Override
    public int changeNewsAgencyStatus(NewsAgency newsAgency) {
        return newsAgencyMapper.changeNewsAgencyStatus(newsAgency);
    }





}
