package com.ruoyi.project.homepage.homepage.damain;

import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

import java.util.Date;

/**
 * 保险订单表 f_order
 * 
 * @author ruoyi
 * @date 2018-08-14
 */
public class Order1 extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** id */
	@Excel(name = "id")
	private Integer id;
	/** 订单编号 */
	@Excel(name = "订单编号")
	private String orderId;
	/** 续保子订单编号 */
	@Excel(name = "续保子订单编号")
	private String renewId;
	/** 保单编号 */
	@Excel(name = "保单编号")
	private String policyId;
	/** 订单关联计划表详细表（包含多个产品） */
	@Excel(name = "订单关联计划表详细表")
	private String orderProductId;
	/** 保险公司关联id */
	@Excel(name = "保险公司关联id")
	private Integer insureId;
	/** 保险公司 */
	@Excel(name = "保险公司")
	private String insureCompany;
	/** 状态（0正常 1作废） */
	@Excel(name = "状态")
	private Integer status;
	/** 投保公司 */
	@Excel(name = "投保公司")
	private String toinsureCompany;
	/** 投保公司关联id */
	@Excel(name = "投保公司关联id")
	private Integer toinsureId;
	/** 备注 */
	@Excel(name = "备注")
	private String remark;
	/** 所属团队 */
	@Excel(name = "所属团队")
	private String teamName;
	/** 所属团队关联id */
	@Excel(name = "所属团队关联id")
	private Integer teamId;
	/** 业务员 */
	@Excel(name = "业务员")
	private String userName;
	/** 业务员id */
	@Excel(name = "业务员id")
	private Integer userId;
	/** 客户名称 */
	@Excel(name = "客户名称")
	private String customerName;
	/** 客户id */
	@Excel(name = "客户id")
	private Integer customerId;
	/** 客户类型 */
	@Excel(name = "客户类型")
	private Integer customerType;
	/** 渠道名称 */
	@Excel(name = "渠道名称")
	private String channelName;
	/** 渠道id */
	@Excel(name = "渠道id")
	private Integer channelId;
	/** 客户来源，0新保，1续保，2渠道，3自行拓展，4客户介绍，5现有客户在开发 */
	@Excel(name = "客户来源")
	private Integer customerSo;
	/** 保单识别码 */
	@Excel(name = "保单识别码")
	private String policyNum;
	/** 续保提醒日期 */
//	@Excel(name = "续保提醒日期")
//	private Date xubaoTime;
//	/** 生效日期 */
//	@Excel(name = "生效日期")
//	private Date startTime;
	/** 失效日期 */
	@Excel(name = "失效日期")
	private Date endTime;
	/** 缴费方式（0一次交，1月缴，2季交，3半年交，4） */
	@Excel(name = "缴费方式")
	private String payMode;
	/** 付费至（0保险公司。1fesco,2方胜） */
	@Excel(name = "付费至")
	private String payTo;
	/** 保单人数 */
	@Excel(name = "保单人数")
	private Integer peopleNum;
	/** 业务员调整描述 */
	@Excel(name = "业务员调整描述")
	private String salesmanTrim;
	/** 保全表关联id（包括计划表id） */
	@Excel(name = "保全表关联id")
	private String policyUpdateId;
	/** 分期表关联id */
	@Excel(name = "分期表关联id")
	private String orderFenqiId;
	/** 所属部门 */
	@Excel(name = "所属部门")
	private String deptName;

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	/**
	 * 设置：id
	 */
	public void setId(Integer id) 
	{
		this.id = id;
	}
	
	/**
	 * 获取：id
	 */
	public Integer getId() 
	{
		return id;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	/**
	 * 设置：保单编号
	 */
	public void setPolicyId(String policyId) 
	{
		this.policyId = policyId;
	}
	
	/**
	 * 获取：保单编号
	 */
	public String getPolicyId() 
	{
		return policyId;
	}
	
	/**
	 * 设置：订单关联计划表详细表（包含多个产品）
	 */
	public void setOrderProductId(String orderProductId) 
	{
		this.orderProductId = orderProductId;
	}
	
	/**
	 * 获取：订单关联计划表详细表（包含多个产品）
	 */
	public String getOrderProductId() 
	{
		return orderProductId;
	}
	
	/**
	 * 设置：保险公司关联id
	 */
	public void setInsureId(Integer insureId) 
	{
		this.insureId = insureId;
	}
	
	/**
	 * 获取：保险公司关联id
	 */
	public Integer getInsureId() 
	{
		return insureId;
	}
	
	/**
	 * 设置：保险公司
	 */
	public void setInsureCompany(String insureCompany) 
	{
		this.insureCompany = insureCompany;
	}
	
	/**
	 * 获取：保险公司
	 */
	public String getInsureCompany() 
	{
		return insureCompany;
	}
	
	/**
	 * 设置：状态（0正常 1作废）
	 */
	public void setStatus(Integer status) 
	{
		this.status = status;
	}
	
	/**
	 * 获取：状态（0正常 1作废）
	 */
	public Integer getStatus() 
	{
		return status;
	}
	
	/**
	 * 设置：投保公司
	 */
	public void setToinsureCompany(String toinsureCompany) 
	{
		this.toinsureCompany = toinsureCompany;
	}
	
	/**
	 * 获取：投保公司
	 */
	public String getToinsureCompany() 
	{
		return toinsureCompany;
	}
	
	/**
	 * 设置：投保公司关联id
	 */
	public void setToinsureId(Integer toinsureId) 
	{
		this.toinsureId = toinsureId;
	}
	
	/**
	 * 获取：投保公司关联id
	 */
	public Integer getToinsureId() 
	{
		return toinsureId;
	}
	/**
	 * 设置：备注
	 */
	public void setRemark(String remark) 
	{
		this.remark = remark;
	}
	
	/**
	 * 获取：备注
	 */
	public String getRemark() 
	{
		return remark;
	}
	
	/**
	 * 设置：所属团队
	 */
	public void setTeamName(String teamName) 
	{
		this.teamName = teamName;
	}
	
	/**
	 * 获取：所属团队
	 */
	public String getTeamName() 
	{
		return teamName;
	}
	
	/**
	 * 设置：所属团队关联id
	 */
	public void setTeamId(Integer teamId) 
	{
		this.teamId = teamId;
	}
	
	/**
	 * 获取：所属团队关联id
	 */
	public Integer getTeamId() 
	{
		return teamId;
	}
	
	/**
	 * 设置：业务员
	 */
	public void setUserName(String userName) 
	{
		this.userName = userName;
	}
	
	/**
	 * 获取：业务员
	 */
	public String getUserName() 
	{
		return userName;
	}
	
	/**
	 * 设置：业务员id
	 */
	public void setUserId(Integer userId) 
	{
		this.userId = userId;
	}
	
	/**
	 * 获取：业务员id
	 */
	public Integer getUserId() 
	{
		return userId;
	}
	
	/**
	 * 设置：客户名称
	 */
	public void setCustomerName(String customerName) 
	{
		this.customerName = customerName;
	}
	
	/**
	 * 获取：客户名称
	 */
	public String getCustomerName() 
	{
		return customerName;
	}
	
	/**
	 * 设置：客户id
	 */
	public void setCustomerId(Integer customerId) 
	{
		this.customerId = customerId;
	}
	
	/**
	 * 获取：客户id
	 */
	public Integer getCustomerId() 
	{
		return customerId;
	}
	
	/**
	 * 设置：客户类型
	 */
	public void setCustomerType(Integer customerType) 
	{
		this.customerType = customerType;
	}
	
	/**
	 * 获取：客户类型
	 */
	public Integer getCustomerType() 
	{
		return customerType;
	}
	
	/**
	 * 设置：渠道名称
	 */
	public void setChannelName(String channelName) 
	{
		this.channelName = channelName;
	}
	
	/**
	 * 获取：渠道名称
	 */
	public String getChannelName() 
	{
		return channelName;
	}
	
	/**
	 * 设置：渠道id
	 */
	public void setChannelId(Integer channelId) 
	{
		this.channelId = channelId;
	}
	
	/**
	 * 获取：渠道id
	 */
	public Integer getChannelId() 
	{
		return channelId;
	}
	
	/**
	 * 设置：客户来源，0新保，1续保，2渠道，3自行拓展，4客户介绍，5现有客户在开发
	 */
	public void setCustomerSo(Integer customerSo) 
	{
		this.customerSo = customerSo;
	}
	
	/**
	 * 获取：客户来源，0新保，1续保，2渠道，3自行拓展，4客户介绍，5现有客户在开发
	 */
	public Integer getCustomerSo() 
	{
		return customerSo;
	}
	
	/**
	 * 设置：保单识别码
	 */
	public void setPolicyNum(String policyNum) 
	{
		this.policyNum = policyNum;
	}
	
	/**
	 * 获取：保单识别码
	 */
	public String getPolicyNum() 
	{
		return policyNum;
	}
	
	/**
	 * 设置：续保提醒日期
	 */
//	public void setXubaoTime(Date xubaoTime)
//	{
//		this.xubaoTime = xubaoTime;
//	}
//
//	/**
//	 * 获取：续保提醒日期
//	 */
//	public Date getXubaoTime()
//	{
//		return xubaoTime;
//	}
//
//	/**
//	 * 设置：生效日期
//	 */
//	public void setStartTime(Date startTime)
//	{
//		this.startTime = startTime;
//	}
//
//	/**
//	 * 获取：生效日期
//	 */
//	public Date getStartTime()
//	{
//		return startTime;
//	}
	
	/**
	 * 设置：失效日期
	 */
	public void setEndTime(Date endTime) 
	{
		this.endTime = endTime;
	}
	
	/**
	 * 获取：失效日期
	 */
	public Date getEndTime() 
	{
		return endTime;
	}
	
	/**
	 * 设置：缴费方式（0一次交，1月缴，2季交，3半年交，4）
	 */
	public void setPayMode(String payMode) 
	{
		this.payMode = payMode;
	}
	
	/**
	 * 获取：缴费方式（0一次交，1月缴，2季交，3半年交，4）
	 */
	public String getPayMode() 
	{
		return payMode;
	}
	
	/**
	 * 设置：付费至（0保险公司。1fesco,2方胜）
	 */
	public void setPayTo(String payTo) 
	{
		this.payTo = payTo;
	}
	
	/**
	 * 获取：付费至（0保险公司。1fesco,2方胜）
	 */
	public String getPayTo() 
	{
		return payTo;
	}
	
	/**
	 * 设置：保单人数
	 */
	public void setPeopleNum(Integer peopleNum) 
	{
		this.peopleNum = peopleNum;
	}
	
	/**
	 * 获取：保单人数
	 */
	public Integer getPeopleNum() 
	{
		return peopleNum;
	}
	
	/**
	 * 设置：业务员调整描述
	 */
	public void setSalesmanTrim(String salesmanTrim) 
	{
		this.salesmanTrim = salesmanTrim;
	}
	
	/**
	 * 获取：业务员调整描述
	 */
	public String getSalesmanTrim() 
	{
		return salesmanTrim;
	}
	
	/**
	 * 设置：保全表关联id（包括计划表id）
	 */
	public void setPolicyUpdateId(String policyUpdateId) 
	{
		this.policyUpdateId = policyUpdateId;
	}
	
	/**
	 * 获取：保全表关联id（包括计划表id）
	 */
	public String getPolicyUpdateId() 
	{
		return policyUpdateId;
	}
	
	/**
	 * 设置：分期表关联id
	 */
	public void setOrderFenqiId(String orderFenqiId) 
	{
		this.orderFenqiId = orderFenqiId;
	}
	
	/**
	 * 获取：分期表关联id
	 */
	public String getOrderFenqiId() 
	{
		return orderFenqiId;
	}

	public String getRenewId() {
		return renewId;
	}

	public void setRenewId(String renewId) {
		this.renewId = renewId;
	}
}
