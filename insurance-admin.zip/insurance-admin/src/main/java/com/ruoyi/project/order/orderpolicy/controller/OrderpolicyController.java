package com.ruoyi.project.order.orderpolicy.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.project.order.orderpolicy.domain.Orderpolicy;
import com.ruoyi.project.order.orderpolicy.service.IOrderpolicyService;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.framework.web.domain.AjaxResult;

/**
 * 订单关联保全管理 信息操作处理
 * 
 * @author ruoyi
 * @date 2018-08-13
 */
@Controller
@RequestMapping("/module/orderpolicy")
public class OrderpolicyController extends BaseController
{
    private String prefix = "module/orderpolicy";
	
	@Autowired
	private IOrderpolicyService orderpolicyService;
	
	@RequiresPermissions("module:orderpolicy:view")
	@GetMapping()
	public String orderpolicy()
	{
	    return prefix + "/orderpolicy";
	}
	
	/**
	 * 查询订单关联保全管理列表
	 */
	@RequiresPermissions("module:orderpolicy:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(Orderpolicy orderpolicy)
	{
		startPage();
        List<Orderpolicy> list = orderpolicyService.selectOrderpolicyList(orderpolicy);
		return getDataTable(list);
	}
	
	/**
	 * 新增订单关联保全管理
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存订单关联保全管理
	 */
	@RequiresPermissions("module:orderpolicy:add")
	@Log(title = "订单关联保全管理", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(Orderpolicy orderpolicy)
	{		
		return toAjax(orderpolicyService.insertOrderpolicy(orderpolicy));
	}

	/**
	 * 修改订单关联保全管理
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		Orderpolicy orderpolicy = orderpolicyService.selectOrderpolicyById(id);
		mmap.put("orderpolicy", orderpolicy);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存订单关联保全管理
	 */
	@RequiresPermissions("module:orderpolicy:edit")
	@Log(title = "订单关联保全管理", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(Orderpolicy orderpolicy)
	{		
		return toAjax(orderpolicyService.updateOrderpolicy(orderpolicy));
	}
	
	/**
	 * 删除订单关联保全管理
	 */
	@RequiresPermissions("module:orderpolicy:remove")
	@Log(title = "订单关联保全管理", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(orderpolicyService.deleteOrderpolicyByIds(ids));
	}
	
}
