package com.ruoyi.project.order.orderFenqi.domain;

import com.ruoyi.framework.web.domain.BaseEntity;
import java.util.Date;

/**
 * 订单分期--关联计划id,--关联订单id--关联保全表 f_order_fenqi
 * 
 * @author ruoyi
 * @date 2018-09-17
 */
public class OrderFenqi extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** id */
	private Integer id;
	/** 订单表关联的分期id */
	private String orderFenqiId;
	/** 每个分期显示保费 */
	private String fenqiCharge;
	/** 这条分期显示日期月份 */
	private String fenqiMonth;
	/** 创建者 */
	private String createBy;
	/** 创建时间 */
	private Date createTime;
	/** 更新者 */
	private String updateBy;
	/** 更新时间 */
	private Date updateTime;
	/** 分期认收状态（0未认收，1已认收） */
	private Integer fenqiStatus;
	/** 订单计划表关联分期id */
	private String planFenqiId;
	/** 是否是保全的分期，0否，1是 */
	private Integer baoquanPlan;
	/** 保全表关联id,,,和保全表自增id绑定 */
	private Integer baoquanId;
	/** 分期类型，0新保，1续保，2新保保全，3续保保全 */
	private String fenqiType;
	/** 产品金额总计，相同产品 */
	private String productSum;
	/** 分期数 */
	private String planCount;
	/** 付款日期 */
	private String payTime;
	/** 付款金额 */
	private String payCharge;

	public String getPayCharge() {
		return payCharge;
	}

	public void setPayCharge(String payCharge) {
		this.payCharge = payCharge;
	}

	public String getPayTime() {
		return payTime;
	}

	public void setPayTime(String payTime) {
		this.payTime = payTime;
	}

	/**
	 * 设置：id
	 */
	public void setId(Integer id) 
	{
		this.id = id;
	}
	
	/**
	 * 获取：id
	 */
	public Integer getId() 
	{
		return id;
	}
	
	/**
	 * 设置：订单表关联的分期id
	 */
	public void setOrderFenqiId(String orderFenqiId) 
	{
		this.orderFenqiId = orderFenqiId;
	}
	
	/**
	 * 获取：订单表关联的分期id
	 */
	public String getOrderFenqiId() 
	{
		return orderFenqiId;
	}
	
	/**
	 * 设置：每个分期显示保费
	 */
	public void setFenqiCharge(String fenqiCharge) 
	{
		this.fenqiCharge = fenqiCharge;
	}
	
	/**
	 * 获取：每个分期显示保费
	 */
	public String getFenqiCharge() 
	{
		return fenqiCharge;
	}
	
	/**
	 * 设置：这条分期显示日期月份
	 */
	public void setFenqiMonth(String fenqiMonth) 
	{
		this.fenqiMonth = fenqiMonth;
	}
	
	/**
	 * 获取：这条分期显示日期月份
	 */
	public String getFenqiMonth() 
	{
		return fenqiMonth;
	}
	
	/**
	 * 设置：创建者
	 */
	public void setCreateBy(String createBy) 
	{
		this.createBy = createBy;
	}
	
	/**
	 * 获取：创建者
	 */
	public String getCreateBy() 
	{
		return createBy;
	}
	
	/**
	 * 设置：创建时间
	 */
	public void setCreateTime(Date createTime) 
	{
		this.createTime = createTime;
	}
	
	/**
	 * 获取：创建时间
	 */
	public Date getCreateTime() 
	{
		return createTime;
	}
	
	/**
	 * 设置：更新者
	 */
	public void setUpdateBy(String updateBy) 
	{
		this.updateBy = updateBy;
	}
	
	/**
	 * 获取：更新者
	 */
	public String getUpdateBy() 
	{
		return updateBy;
	}
	
	/**
	 * 设置：更新时间
	 */
	public void setUpdateTime(Date updateTime) 
	{
		this.updateTime = updateTime;
	}
	
	/**
	 * 获取：更新时间
	 */
	public Date getUpdateTime() 
	{
		return updateTime;
	}
	
	/**
	 * 设置：分期认收状态（0未认收，1已认收）
	 */
	public void setFenqiStatus(Integer fenqiStatus) 
	{
		this.fenqiStatus = fenqiStatus;
	}
	
	/**
	 * 获取：分期认收状态（0未认收，1已认收）
	 */
	public Integer getFenqiStatus() 
	{
		return fenqiStatus;
	}
	
	/**
	 * 设置：订单计划表关联分期id
	 */
	public void setPlanFenqiId(String planFenqiId) 
	{
		this.planFenqiId = planFenqiId;
	}
	
	/**
	 * 获取：订单计划表关联分期id
	 */
	public String getPlanFenqiId() 
	{
		return planFenqiId;
	}
	

	/**
	 * 设置：是否是保全的分期，0否，1是
	 */
	public void setBaoquanPlan(Integer baoquanPlan) 
	{
		this.baoquanPlan = baoquanPlan;
	}
	
	/**
	 * 获取：是否是保全的分期，0否，1是
	 */
	public Integer getBaoquanPlan() 
	{
		return baoquanPlan;
	}
	
	/**
	 * 设置：保全表关联id,,,和保全表自增id绑定
	 */
	public void setBaoquanId(Integer baoquanId) 
	{
		this.baoquanId = baoquanId;
	}
	
	/**
	 * 获取：保全表关联id,,,和保全表自增id绑定
	 */
	public Integer getBaoquanId() 
	{
		return baoquanId;
	}
	
	/**
	 * 设置：分期类型，0新保，1续保，2新保保全，3续保保全
	 */
	public void setFenqiType(String fenqiType) 
	{
		this.fenqiType = fenqiType;
	}
	
	/**
	 * 获取：分期类型，0新保，1续保，2新保保全，3续保保全
	 */
	public String getFenqiType() 
	{
		return fenqiType;
	}
	
	/**
	 * 设置：产品金额总计，相同产品
	 */
	public void setProductSum(String productSum) 
	{
		this.productSum = productSum;
	}
	
	/**
	 * 获取：产品金额总计，相同产品
	 */
	public String getProductSum() 
	{
		return productSum;
	}
	

	/**
	 * 设置：分期数
	 */
	public void setPlanCount(String planCount) 
	{
		this.planCount = planCount;
	}
	
	/**
	 * 获取：分期数
	 */
	public String getPlanCount() 
	{
		return planCount;
	}
	
}
