package com.ruoyi.project.homepage.homepage.service;

import com.ruoyi.project.homepage.homepage.damain.Order1;
import com.ruoyi.project.order.order.domain.Order;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.domain.CustomerContacts;
import org.aspectj.weaver.ast.Or;

import java.util.HashMap;
import java.util.List;

/**
 * 保险订单 服务层
 * 
 * @author ruoyi
 * @date 2018-08-13
 */
public interface IOrder1Service {

    public List<Order1> selectOrder1List(Order1 order1);

    public List<Order1> selectOrder2List(Order1 order2);

    /*管理员*/
    public List<Order1> selectOrderGlyList(int status);

    /*主管*/
    public List<Order1> selectOrderZhuguanList(long deptId,long statu);
    /*总监*/
    public List<Order1> selectOrderMajordomoList(long deptId,long stat);
    /**
     * 业务员
     */
    public List <Order1> selectOrderYwyList( long userIdd,long statuss);


	
}
