package com.ruoyi.project.order.orderPeople.domain;

import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;
import java.util.Date;

/**
 * 人员清单，关联订单，表 f_order_people
 * 
 * @author ruoyi
 * @date 2018-08-23
 */
public class OrderPeople extends BaseEntity
{
	/** 序号 */
	@Excel(name = "序号")
	private String peopleNo;
	/** 雇员编号 */
	@Excel(name = "雇员编号")
	private String empNo;
	/** 分支机构 */
	@Excel(name = "分支机构")
	private String branch;
	/**
	 * 编码
	 */
	@Excel(name = "编码")
	private String code;
	/**
	 * 主被保险人姓名
	 */
	@Excel(name = "主被保险人姓名")
	private String peopleNameZhu;
	/** 被保险姓名 */
	@Excel(name = "被保险姓名")
	private String peopleName;
	/** 身份证号和护照 */
	@Excel(name = "身份证号和护照")
	private String idcard;
	/** 出生年月日 */
	@Excel(name = "出生年月日")
	private String birth;
	/**
	 * 与主被保险人关系
	 */
	@Excel(name = "与主被保险人关系")
	private String relationship;
	/** 性别 */
	@Excel(name = "性别")
	private String sex;
	/**
	 * 计划名称
	 */
	@Excel(name = "计划名称")
	private String planName;
	/**
	 * 医疗保费
	 */
	@Excel(name = "总保费")
	private String baofei;
	/**
	 * 意外保费
	 */
	@Excel(name = "意外保费")
	private String yiwaiBaofei;
	/**
	 * 意外保费
	 */
	@Excel(name = "医疗保费")
	private String yiliaoBaofei;
	/**
	 * 意外保费
	 */
	@Excel(name = "重疾保费")
	private String zhongjiBaofei;
	/**
	 * 意外保费
	 */
	@Excel(name = "疾病身故保费")
	private String shengguBaofei;
	/**
	 * 生效日期
	 */
	@Excel(name = "生效日期")
	private String startTime;
	/**
	 * 终止时间
	 */
	@Excel(name = "终止时间")
	private String endTime;
	/** 移动电话 */
	@Excel(name = "移动电话")
	private String phone;
	/** 邮箱地址 */
	@Excel(name = "邮箱地址")
	private String email;
	/** 银行开户名 */
	@Excel(name = "银行开户名")
	private String accountName;
	/** 开户行 */
	@Excel(name = "开户行")
	private String bankName;
	/** 银行账号 */
	@Excel(name = "银行账号")
	private String bankNo;
	/**
	 * 开户省
	 */
	@Excel(name = "开户省")
	private String openProvince;
	/**
	 * 开户市
	 */
	@Excel(name = "开户市")
	private String openCity;
	/**
	 *工作所在地
	 */
	@Excel(name = "工作所在地")
	private String workPlace;
	/**
	 *社保所在地
	 */
	@Excel(name = "社保所在地")
	private String shebaoPlace;
	/**
	 *保单识别码
	 */
	@Excel(name = "保单识别码")
	private String policyNum;


	/** 人员清单id */
	@Excel(name = "人员清单id")
	private Integer id;
	/** 所属层级名称 */
	@Excel(name = "所属层级名称")
	private String category;
	/** 证件类型,0身份证，1护照，2军官证 */
	@Excel(name = "证件类型")
	private String idcardType;
	/** 分行名称 */
	@Excel(name = "分行名称")
	private String bankbrName;
	/** 支行名称 */
	@Excel(name = "支行名称")
	private String banksubName;
	/** 所在公司 */
	@Excel(name = "所在公司")
	private String company;
	/** 用户状态（0正常 1停用） */
	@Excel(name = "用户状态")
	private String status;
	/** 创建者 */
	@Excel(name = "创建者")
	private String createBy;
	/** 创建时间 */
	@Excel(name = "创建时间")
	private Date createTime;
	/** 更新者 */
	@Excel(name = "更新者")
	private String updateBy;
	/** 更新时间 */
	@Excel(name = "更新时间")
	private Date updateTime;
	/** 清单人员来源，0新保，1续保，2新保保全，3续保保全 */
	@Excel(name = "清单人员来源")
	private String orderType;
	/** 被保险人属性,0主被保险人，1配偶，2子女，3父母 */
	@Excel(name = "被保险人属性")
	private String insuredType;
	/** 计划表，关联人员id，联合查询 */
	@Excel(name = "关联人员id")
	private String planPeopleId;
	/** 计划表的计划名称 */
	@Excel(name = "计划表的计划名称")
	private String planPeopleName;
	/** 订单表关联id,共用的 */
	@Excel(name = "订单表关联id")
	private String orderId;
	@Excel(name = "工资")
	private String salary;
	@Excel(name = "工种描述")
	private String jobDescription;
	@Excel(name = "变更类型")
	private String changeType;
	@Excel(name = "医疗方案类型")
	private String medicalType;
	@Excel(name = "意外保额")
	private String yiwaiBaoe;
	@Excel(name = "重疾保额")
	private String zhongjiBaoe;
	@Excel(name = "疾病身故保额")
	private String shengguBaoe;
	@Excel(name = "企业代码")
	private String enterpriseCode;

	@Excel(name = "居住所在地")
	private String livePlace;
	@Excel(name = "投保原因")
	private String insuranceReason;
	@Excel(name = "对应员工姓名")
	private String duiyingemployeeName;
	@Excel(name = "开票单位名称")
	private String kaipiaoName;
	@Excel(name = "所属部门名")
	private String deptName;
	@Excel(name = "制卡人姓名")
	private String zhikaName;
	@Excel(name = "职业类别")
	private String workType;
	@Excel(name = "职业代码")
	private String workCode;
	@Excel(name = "结婚登记日")
	private String marryDate;
	@Excel(name = "年薪")
	private String yearSaraly;
	@Excel(name = "是否含美国区域计划")
	private String isUsplan;
	@Excel(name = "拼音(英文）名")
	private String pingMing;
	@Excel(name = "拼音（英文）中间名")
	private String pingMidming;
	@Excel(name = "拼音（英文）姓")
	private String pingXing;
	@Excel(name = "婚姻状态")
	private String marryStatue;
	@Excel(name = "高端险种被保险人性质")
	private String insuredNature;

	@Excel(name = "职业")
	private String post;
	@Excel(name = "是否参加社保")
	private String isShebao;
	@Excel(name = "变更生效日")
	private String changeDate;
	@Excel(name = "应退保费")
	private String refundBaofei;
	@Excel(name = "年龄")
	private String age;

	@Excel(name = "国籍")
	private String nationality;
	@Excel(name = "保障代码")
	private String coverageCode;
	@Excel(name = "齿科")
	private String dental;
	@Excel(name = "健康检查")
	private String wellness;
	@Excel(name = "'眼科福利'")
	private String vision;
	@Excel(name = "战争恐怖主义")
	private String war;
	@Excel(name = "生育福利")
	private String maternity;
	@Excel(name = "上一年保费")
	private String beforeBaofei;
	@Excel(name = "福利是否拆分")
	private String benefits;
	@Excel(name = "付费方式")
	private String payWay;
	@Excel(name = "工作邮箱地址")
	private String workEmail;
	@Excel(name = "私人邮箱地址")
	private String personalEmail;
	@Excel(name = "办公电话")
	private String officePhone;

	@Excel(name = "主被保险人证件类型")
	private String zhuCardtype;
	@Excel(name = "主被保险人证件号")
	private String zhuIdcard;
	@Excel(name = "个人账户金额")
	private String personMoney;
	@Excel(name = "特约凭证")
	private String teVorcher;
	@Excel(name = "医保类型")
	private String yibaoType;
	@Excel(name = "二级机构")
	private String branchTwo;
	@Excel(name = "三级机构")
	private String branchThree;
	@Excel(name = "四级机构")
	private String branchFour;

	@Excel(name = "子女1姓名")
	private String child1Name;
	@Excel(name = "子女2姓名")
	private String child2Name;
	@Excel(name = "配偶姓名")
	private String coupleName;
	@Excel(name = "子女1出生日期")
	private String child1Birth;
	@Excel(name = "子女2出生日期")
	private String child2Birth;
	@Excel(name = "配偶出生日期")
	private String coupleBirth;
	@Excel(name = "子女1证件号")
	private String child1Idcard;
	@Excel(name = "子女2证件号")
	private String child2Idcard;
	@Excel(name = "配偶证件号")
	private String coupleIdcard;
	@Excel(name = "子女1性别")
	private String child1Sex;
	@Excel(name = "子女2性别")
	private String child2Sex;
	@Excel(name = "配偶性别")
	private String coupleSex;
	@Excel(name = "子女1健康状态")
	private String child1Status;
	@Excel(name = "子女2健康状态")
	private String child2Status;
	@Excel(name = "配偶健康状态")
	private String coupleStatus;
	@Excel(name = "子女1加入层级")
	private String child1Category;
	@Excel(name = "子女2加入层级")
	private String child2Category;
	@Excel(name = "配偶加入层级")
	private String coupleCategory;
	@Excel(name = "备注")
	private String remark;

	@Excel(name = "收到三方服务同意书")
	private String threeReceived;
	@Excel(name = "家庭号码")
	private String familyNo;
	@Excel(name = "证件到期日")
	private String cardEndtime;
	@Excel(name = "分组（如适用）")
	private String fenGroup;
	@Excel(name = "保险卡邮寄地址")
	private String mailAddress;
	@Excel(name = "保障区域")
	private String guaranteeArea;
	@Excel(name = "保险卡号")
	private String cardNumber;
	@Excel(name = "是否有医疗保障")
	private String isYiliao;
	@Excel(name = "是否有人寿保障")
	private String isRenshou;
	@Excel(name = "是否有意外死亡/残疾保障")
	private String isYiwai;
	@Excel(name = "人寿平准保额")
	private String renshouBaoePin;
	@Excel(name = "人寿年薪倍数保额")
	private String renshouBaoeBei;
	@Excel(name = "意外死亡/残疾平准保额")
	private String sicanBaoePin;
	@Excel(name = "意外死亡/残疾年薪倍数保额")
	private String sicanBaoeBei;

	@Excel(name = "入职日期")
	private String entryDate;
	@Excel(name = "离职日期")
	private String leaveDate;
	@Excel(name = "增员日期")
	private String increaseDate;
	@Excel(name = "减员日期")
	private String attritionDate;
	@Excel(name = "是否在职")
	private String isJob;







	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	private static final long serialVersionUID = 1L;

	public String getEntryDate() {
		return entryDate;
	}

	public void setEntryDate(String entryDate) {
		this.entryDate = entryDate;
	}

	public String getLeaveDate() {
		return leaveDate;
	}

	public void setLeaveDate(String leaveDate) {
		this.leaveDate = leaveDate;
	}

	public String getIncreaseDate() {
		return increaseDate;
	}

	public void setIncreaseDate(String increaseDate) {
		this.increaseDate = increaseDate;
	}

	public String getAttritionDate() {
		return attritionDate;
	}

	public void setAttritionDate(String attritionDate) {
		this.attritionDate = attritionDate;
	}

	public String getIsJob() {
		return isJob;
	}

	public void setIsJob(String isJob) {
		this.isJob = isJob;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getIsYiliao() {
		return isYiliao;
	}

	public void setIsYiliao(String isYiliao) {
		this.isYiliao = isYiliao;
	}

	public String getIsRenshou() {
		return isRenshou;
	}

	public void setIsRenshou(String isRenshou) {
		this.isRenshou = isRenshou;
	}

	public String getIsYiwai() {
		return isYiwai;
	}

	public void setIsYiwai(String isYiwai) {
		this.isYiwai = isYiwai;
	}

	public String getRenshouBaoePin() {
		return renshouBaoePin;
	}

	public void setRenshouBaoePin(String renshouBaoePin) {
		this.renshouBaoePin = renshouBaoePin;
	}

	public String getRenshouBaoeBei() {
		return renshouBaoeBei;
	}

	public void setRenshouBaoeBei(String renshouBaoeBei) {
		this.renshouBaoeBei = renshouBaoeBei;
	}

	public String getSicanBaoePin() {
		return sicanBaoePin;
	}

	public void setSicanBaoePin(String sicanBaoePin) {
		this.sicanBaoePin = sicanBaoePin;
	}

	public String getSicanBaoeBei() {
		return sicanBaoeBei;
	}

	public void setSicanBaoeBei(String sicanBaoeBei) {
		this.sicanBaoeBei = sicanBaoeBei;
	}

	public String getThreeReceived() {
		return threeReceived;
	}

	public void setThreeReceived(String threeReceived) {
		this.threeReceived = threeReceived;
	}

	public String getFamilyNo() {
		return familyNo;
	}

	public void setFamilyNo(String familyNo) {
		this.familyNo = familyNo;
	}

	public String getCardEndtime() {
		return cardEndtime;
	}

	public void setCardEndtime(String cardEndtime) {
		this.cardEndtime = cardEndtime;
	}

	public String getFenGroup() {
		return fenGroup;
	}

	public void setFenGroup(String fenGroup) {
		this.fenGroup = fenGroup;
	}

	public String getMailAddress() {
		return mailAddress;
	}

	public void setMailAddress(String mailAddress) {
		this.mailAddress = mailAddress;
	}

	public String getGuaranteeArea() {
		return guaranteeArea;
	}

	public void setGuaranteeArea(String guaranteeArea) {
		this.guaranteeArea = guaranteeArea;
	}

	public String getChild1Name() {
		return child1Name;
	}

	public void setChild1Name(String child1Name) {
		this.child1Name = child1Name;
	}

	public String getChild2Name() {
		return child2Name;
	}

	public void setChild2Name(String child2Name) {
		this.child2Name = child2Name;
	}

	public String getCoupleName() {
		return coupleName;
	}

	public void setCoupleName(String coupleName) {
		this.coupleName = coupleName;
	}

	public String getChild1Birth() {
		return child1Birth;
	}

	public void setChild1Birth(String child1Birth) {
		this.child1Birth = child1Birth;
	}

	public String getChild2Birth() {
		return child2Birth;
	}

	public void setChild2Birth(String child2Birth) {
		this.child2Birth = child2Birth;
	}

	public String getCoupleBirth() {
		return coupleBirth;
	}

	public void setCoupleBirth(String coupleBirth) {
		this.coupleBirth = coupleBirth;
	}

	public String getChild1Idcard() {
		return child1Idcard;
	}

	public void setChild1Idcard(String child1Idcard) {
		this.child1Idcard = child1Idcard;
	}

	public String getChild2Idcard() {
		return child2Idcard;
	}

	public void setChild2Idcard(String child2Idcard) {
		this.child2Idcard = child2Idcard;
	}

	public String getCoupleIdcard() {
		return coupleIdcard;
	}

	public void setCoupleIdcard(String coupleIdcard) {
		this.coupleIdcard = coupleIdcard;
	}

	public String getChild1Sex() {
		return child1Sex;
	}

	public void setChild1Sex(String child1Sex) {
		this.child1Sex = child1Sex;
	}

	public String getChild2Sex() {
		return child2Sex;
	}

	public void setChild2Sex(String child2Sex) {
		this.child2Sex = child2Sex;
	}

	public String getCoupleSex() {
		return coupleSex;
	}

	public void setCoupleSex(String coupleSex) {
		this.coupleSex = coupleSex;
	}

	public String getChild1Status() {
		return child1Status;
	}

	public void setChild1Status(String child1Status) {
		this.child1Status = child1Status;
	}

	public String getChild2Status() {
		return child2Status;
	}

	public void setChild2Status(String child2Status) {
		this.child2Status = child2Status;
	}

	public String getCoupleStatus() {
		return coupleStatus;
	}

	public void setCoupleStatus(String coupleStatus) {
		this.coupleStatus = coupleStatus;
	}

	public String getChild1Category() {
		return child1Category;
	}

	public void setChild1Category(String child1Category) {
		this.child1Category = child1Category;
	}

	public String getChild2Category() {
		return child2Category;
	}

	public void setChild2Category(String child2Category) {
		this.child2Category = child2Category;
	}

	public String getCoupleCategory() {
		return coupleCategory;
	}

	public void setCoupleCategory(String coupleCategory) {
		this.coupleCategory = coupleCategory;
	}

	@Override
	public String getRemark() {
		return remark;
	}

	@Override
	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getZhuCardtype() {
		return zhuCardtype;
	}

	public void setZhuCardtype(String zhuCardtype) {
		this.zhuCardtype = zhuCardtype;
	}

	public String getZhuIdcard() {
		return zhuIdcard;
	}

	public void setZhuIdcard(String zhuIdcard) {
		this.zhuIdcard = zhuIdcard;
	}

	public String getPersonMoney() {
		return personMoney;
	}

	public void setPersonMoney(String personMoney) {
		this.personMoney = personMoney;
	}

	public String getTeVorcher() {
		return teVorcher;
	}

	public void setTeVorcher(String teVorcher) {
		this.teVorcher = teVorcher;
	}

	public String getYibaoType() {
		return yibaoType;
	}

	public void setYibaoType(String yibaoType) {
		this.yibaoType = yibaoType;
	}

	public String getBranchTwo() {
		return branchTwo;
	}

	public void setBranchTwo(String branchTwo) {
		this.branchTwo = branchTwo;
	}

	public String getBranchThree() {
		return branchThree;
	}

	public void setBranchThree(String branchThree) {
		this.branchThree = branchThree;
	}

	public String getBranchFour() {
		return branchFour;
	}

	public void setBranchFour(String branchFour) {
		this.branchFour = branchFour;
	}

	public String getNationality() {
		return nationality;
	}

	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	public String getCoverageCode() {
		return coverageCode;
	}

	public void setCoverageCode(String coverageCode) {
		this.coverageCode = coverageCode;
	}

	public String getDental() {
		return dental;
	}

	public void setDental(String dental) {
		this.dental = dental;
	}

	public String getWellness() {
		return wellness;
	}

	public void setWellness(String wellness) {
		this.wellness = wellness;
	}

	public String getVision() {
		return vision;
	}

	public void setVision(String vision) {
		this.vision = vision;
	}

	public String getWar() {
		return war;
	}

	public void setWar(String war) {
		this.war = war;
	}

	public String getMaternity() {
		return maternity;
	}

	public void setMaternity(String maternity) {
		this.maternity = maternity;
	}

	public String getBeforeBaofei() {
		return beforeBaofei;
	}

	public void setBeforeBaofei(String beforeBaofei) {
		this.beforeBaofei = beforeBaofei;
	}

	public String getBenefits() {
		return benefits;
	}

	public void setBenefits(String benefits) {
		this.benefits = benefits;
	}

	public String getPayWay() {
		return payWay;
	}

	public void setPayWay(String payWay) {
		this.payWay = payWay;
	}

	public String getWorkEmail() {
		return workEmail;
	}

	public void setWorkEmail(String workEmail) {
		this.workEmail = workEmail;
	}

	public String getPersonalEmail() {
		return personalEmail;
	}

	public void setPersonalEmail(String personalEmail) {
		this.personalEmail = personalEmail;
	}

	public String getOfficePhone() {
		return officePhone;
	}

	public void setOfficePhone(String officePhone) {
		this.officePhone = officePhone;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getPost() {
		return post;
	}

	public void setPost(String post) {
		this.post = post;
	}

	public String getIsShebao() {
		return isShebao;
	}

	public void setIsShebao(String isShebao) {
		this.isShebao = isShebao;
	}

	public String getChangeDate() {
		return changeDate;
	}

	public void setChangeDate(String changeDate) {
		this.changeDate = changeDate;
	}

	public String getRefundBaofei() {
		return refundBaofei;
	}

	public void setRefundBaofei(String refundBaofei) {
		this.refundBaofei = refundBaofei;
	}

	public String getInsuredNature() {
		return insuredNature;
	}

	public void setInsuredNature(String insuredNature) {
		this.insuredNature = insuredNature;
	}

	public String getLivePlace() {
		return livePlace;
	}

	public void setLivePlace(String livePlace) {
		this.livePlace = livePlace;
	}

	public String getInsuranceReason() {
		return insuranceReason;
	}

	public void setInsuranceReason(String insuranceReason) {
		this.insuranceReason = insuranceReason;
	}

	public String getDuiyingemployeeName() {
		return duiyingemployeeName;
	}

	public void setDuiyingemployeeName(String duiyingemployeeName) {
		this.duiyingemployeeName = duiyingemployeeName;
	}

	public String getKaipiaoName() {
		return kaipiaoName;
	}

	public void setKaipiaoName(String kaipiaoName) {
		this.kaipiaoName = kaipiaoName;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getZhikaName() {
		return zhikaName;
	}

	public void setZhikaName(String zhikaName) {
		this.zhikaName = zhikaName;
	}

	public String getWorkType() {
		return workType;
	}

	public void setWorkType(String workType) {
		this.workType = workType;
	}

	public String getWorkCode() {
		return workCode;
	}

	public void setWorkCode(String workCode) {
		this.workCode = workCode;
	}

	public String getMarryDate() {
		return marryDate;
	}

	public void setMarryDate(String marryDate) {
		this.marryDate = marryDate;
	}

	public String getYearSaraly() {
		return yearSaraly;
	}

	public void setYearSaraly(String yearSaraly) {
		this.yearSaraly = yearSaraly;
	}

	public String getIsUsplan() {
		return isUsplan;
	}

	public void setIsUsplan(String isUsplan) {
		this.isUsplan = isUsplan;
	}

	public String getPingMing() {
		return pingMing;
	}

	public void setPingMing(String pingMing) {
		this.pingMing = pingMing;
	}

	public String getPingMidming() {
		return pingMidming;
	}

	public void setPingMidming(String pingMidming) {
		this.pingMidming = pingMidming;
	}

	public String getPingXing() {
		return pingXing;
	}

	public void setPingXing(String pingXing) {
		this.pingXing = pingXing;
	}

	public String getMarryStatue() {
		return marryStatue;
	}

	public void setMarryStatue(String marryStatue) {
		this.marryStatue = marryStatue;
	}

	public String getPeopleNo() {
		return peopleNo;
	}

	public void setPeopleNo(String peopleNo) {
		this.peopleNo = peopleNo;
	}

	public String getEmpNo() {
		return empNo;
	}

	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getPeopleNameZhu() {
		return peopleNameZhu;
	}

	public void setPeopleNameZhu(String peopleNameZhu) {
		this.peopleNameZhu = peopleNameZhu;
	}

	public String getPeopleName() {
		return peopleName;
	}

	public void setPeopleName(String peopleName) {
		this.peopleName = peopleName;
	}

	public String getIdcard() {
		return idcard;
	}

	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getBaofei() {
		return baofei;
	}

	public void setBaofei(String baofei) {
		this.baofei = baofei;
	}

	public String getYiliaoBaofei() {
		return yiliaoBaofei;
	}

	public void setYiliaoBaofei(String yiliaoBaofei) {
		this.yiliaoBaofei = yiliaoBaofei;
	}

	public String getZhongjiBaofei() {
		return zhongjiBaofei;
	}

	public void setZhongjiBaofei(String zhongjiBaofei) {
		this.zhongjiBaofei = zhongjiBaofei;
	}

	public String getShengguBaofei() {
		return shengguBaofei;
	}

	public void setShengguBaofei(String shengguBaofei) {
		this.shengguBaofei = shengguBaofei;
	}

	public String getYiwaiBaofei() {
		return yiwaiBaofei;
	}

	public void setYiwaiBaofei(String yiwaiBaofei) {
		this.yiwaiBaofei = yiwaiBaofei;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankNo() {
		return bankNo;
	}

	public void setBankNo(String bankNo) {
		this.bankNo = bankNo;
	}

	public String getOpenProvince() {
		return openProvince;
	}

	public void setOpenProvince(String openProvince) {
		this.openProvince = openProvince;
	}

	public String getOpenCity() {
		return openCity;
	}

	public void setOpenCity(String openCity) {
		this.openCity = openCity;
	}

	public String getWorkPlace() {
		return workPlace;
	}

	public void setWorkPlace(String workPlace) {
		this.workPlace = workPlace;
	}

	public String getShebaoPlace() {
		return shebaoPlace;
	}

	public void setShebaoPlace(String shebaoPlace) {
		this.shebaoPlace = shebaoPlace;
	}

	public String getPolicyNum() {
		return policyNum;
	}

	public void setPolicyNum(String policyNum) {
		this.policyNum = policyNum;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getIdcardType() {
		return idcardType;
	}

	public void setIdcardType(String idcardType) {
		this.idcardType = idcardType;
	}

	public String getBankbrName() {
		return bankbrName;
	}

	public void setBankbrName(String bankbrName) {
		this.bankbrName = bankbrName;
	}

	public String getBanksubName() {
		return banksubName;
	}

	public void setBanksubName(String banksubName) {
		this.banksubName = banksubName;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String getCreateBy() {
		return createBy;
	}

	@Override
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	@Override
	public Date getCreateTime() {
		return createTime;
	}

	@Override
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Override
	public String getUpdateBy() {
		return updateBy;
	}

	@Override
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	@Override
	public Date getUpdateTime() {
		return updateTime;
	}

	@Override
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getOrderType() {
		return orderType;
	}

	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}

	public String getInsuredType() {
		return insuredType;
	}

	public void setInsuredType(String insuredType) {
		this.insuredType = insuredType;
	}

	public String getPlanPeopleId() {
		return planPeopleId;
	}

	public void setPlanPeopleId(String planPeopleId) {
		this.planPeopleId = planPeopleId;
	}

	public String getPlanPeopleName() {
		return planPeopleName;
	}

	public void setPlanPeopleName(String planPeopleName) {
		this.planPeopleName = planPeopleName;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getSalary() {
		return salary;
	}

	public void setSalary(String salary) {
		this.salary = salary;
	}

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public String getChangeType() {
		return changeType;
	}

	public void setChangeType(String changeType) {
		this.changeType = changeType;
	}

	public String getMedicalType() {
		return medicalType;
	}

	public void setMedicalType(String medicalType) {
		this.medicalType = medicalType;
	}

	public String getYiwaiBaoe() {
		return yiwaiBaoe;
	}

	public void setYiwaiBaoe(String yiwaiBaoe) {
		this.yiwaiBaoe = yiwaiBaoe;
	}

	public String getZhongjiBaoe() {
		return zhongjiBaoe;
	}

	public void setZhongjiBaoe(String zhongjiBaoe) {
		this.zhongjiBaoe = zhongjiBaoe;
	}

	public String getShengguBaoe() {
		return shengguBaoe;
	}

	public void setShengguBaoe(String shengguBaoe) {
		this.shengguBaoe = shengguBaoe;
	}

	public String getEnterpriseCode() {
		return enterpriseCode;
	}

	public void setEnterpriseCode(String enterpriseCode) {
		this.enterpriseCode = enterpriseCode;
	}
}
