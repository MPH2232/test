package com.ruoyi.project.system.customer.mapper;

/**
 * Created by x on 2018/8/7.
 */


import com.ruoyi.project.system.customer.domain.CustomerContacts;

import java.util.List;

/**
 *联系人信息表   数据层
 */
public interface CustomerContactsMapper {
    /**
     * 查询企业客户数据集合
     *
     * @param customercustomer 企业客户信息
     * @return 企业客户数据集合
     */
    public List<CustomerContacts> selectCustomerContactsList(CustomerContacts customercustomer);

    /**
     * 客户所有信息
     *
     * @return 客户列表
     */
    public List<CustomerContacts> selectCustomerContactsAll();


    /**
     * 根据客户表Id查询联系人信息
     *
     * @param customerId 客户表Id
     * @return 联系人集合信息
     */
    public List<CustomerContacts> selectCustomerContactsByCustomerId(int customerId);

    /**
     * 通过客户ID联系人信息
     *
     * @param id 客户id
     * @return 联系人信息
     */
    public CustomerContacts selectCustomerConstomerById(Long id);

    /**
     * 新增联系人信息
     *
     * @param customercontacts 联系人信息
     * @return 结果
     */
    public int insertCustomerContacts(CustomerContacts customercontacts);


    /**
     * 修改联系人信息
     *
     * @param customercontacts 联系人信息
     * @return 结果
     */
    public int updateCustomerContacts(CustomerContacts customercontacts);

    /**
     * 批量删除联系人信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteCustomerContactsByIds(Long[] ids);



    /**
     * 查询联系人数据集合
     *
     * @param customerId 联系人信息
     * @return 联系人数据集合
     */
    public List<CustomerContacts> selectCustomerContactsListInfo(int customerId);


}


























