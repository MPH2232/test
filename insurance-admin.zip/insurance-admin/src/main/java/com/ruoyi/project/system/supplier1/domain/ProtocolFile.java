package com.ruoyi.project.system.supplier1.domain;

/**
 * Created by x on 2018/9/20.
 */
public class ProtocolFile {
    /** 协议ID */
    private String protocolId;

    /** 文件名称" */
    private String protocolFileName;

    /** 文件类型 */
    private String protocolFileType;

    /** 路径*/
    private String protocolFileLujing;

    public String getProtocolId() {
        return protocolId;
    }

    public void setProtocolId(String protocolId) {
        this.protocolId = protocolId;
    }

    public String getProtocolFileName() {
        return protocolFileName;
    }

    public void setProtocolFileName(String protocolFileName) {
        this.protocolFileName = protocolFileName;
    }

    public String getProtocolFileType() {
        return protocolFileType;
    }

    public void setProtocolFileType(String protocolFileType) {
        this.protocolFileType = protocolFileType;
    }

    public String getProtocolFileLujing() {
        return protocolFileLujing;
    }

    public void setProtocolFileLujing(String protocolFileLujing) {
        this.protocolFileLujing = protocolFileLujing;
    }
}
