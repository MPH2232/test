package com.ruoyi.project.system.adjust.controller;
import com.ruoyi.common.utils.NewFileUploadUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.framework.web.page.TableDataInfo;

import com.ruoyi.project.homepage.homepage.damain.AdjustUser;
import com.ruoyi.project.homepage.homepage.damain.NewsAgency;
import com.ruoyi.project.homepage.homepage.damain.OrderUser;
import com.ruoyi.project.homepage.homepage.service.INewsAgencyService;
import com.ruoyi.project.homepage.homepage.service.IOrderUserService;
import com.ruoyi.project.order.order.domain.Order;
import com.ruoyi.project.order.order.service.IOrderService;
import com.ruoyi.project.system.adjust.service.IAdjustService;
import com.ruoyi.project.system.dept.domain.Dept;
import com.ruoyi.project.system.user.domain.User;
import com.ruoyi.project.system.user.service.IUserService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import javax.servlet.http.HttpServletRequest;
import java.util.*;
import java.util.List;


/**
 * 渠道信息操作处理
 *
 * @author ruoyi
 */
@Controller
@RequestMapping("/system/adjust")
public class AdjustController extends BaseController {
    private String prefix = "system/adjust";
    @Autowired
    private IUserService userService;
    @Autowired
    private IOrderService orderService;
    @Autowired
    private IOrderUserService orderUserService;

    @Autowired
    private IAdjustService adjustService;
    @Autowired
    private INewsAgencyService newsAgencyService;


    @RequiresPermissions("system:adjust:view")
    @GetMapping()
    public String operlog() {
        return prefix + "/adjustIndex";
    }



    //导出excel
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(OrderUser orderUser) throws Exception {
        try {
            List<OrderUser> list =orderUserService.selectOrderList1(orderUser);
            ExcelUtil<OrderUser> util = new ExcelUtil<OrderUser>(OrderUser.class);
            return util.exportExcel(list, "orderUser");
        } catch (Exception e) {
            return error("导出Excel失败，请联系网站管理员！");
        }
    }

    //根据登陆人不同显示要调整的业务员
    @RequiresPermissions("system:adjust:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AdjustUser adjustUser)
    {
        //获取登录人
        User users=getUser();
        List<AdjustUser> list = new ArrayList<AdjustUser>();
        String name= userService.selectUserRoleGroup(users.getUserId());
        startPage();
        if(name.contains("管理员")){
            //管理员
            list = adjustService.selectAdjustList(adjustUser);
        }else if(name.equals("主管")){
            //主管
            list = adjustService.selectCustomerListCharge(users.getDeptId());
        }else if(name.equals("总监")){
            //总监
            list = adjustService.selectCustomerListMajordomo(users.getDeptId());
        }else {
            //业务员
            list = adjustService.selectCustomerListSalesman(users.getUserId());
        }
        return getDataTable(list);
    }



    /**
     * 业务员调整页面
     * @param id
     * @param mmap
     * @return
     */
    @GetMapping("/detail/{id}")
    public String detail(@PathVariable("id") Long id, ModelMap mmap)
    {
        mmap.put("adjustUser",adjustService.selectAdjustById(id));
        mmap.put("id",id);
        return "system/adjust/adjustUser";
    }



    /**
     * 显示订单
     * @param
     * @return
     */
    @RequiresPermissions("system:adjust:edit")
    @PostMapping("/listOrder")
    @ResponseBody
    public TableDataInfo list(OrderUser orderUser) {
        startPage();
        List<OrderUser> lists = new ArrayList<OrderUser>();
        List<OrderUser> list = orderUserService.selectOrderList1(orderUser);
        for(OrderUser orderUser1 :list) {
            Order order2 = orderService.selectOrderById(orderUser1.getId());
            //调整过的订单不显示
              if(order2.getSalesmanTrim()==null || order2.getSalesmanTrim().equals("")){
                  lists = orderUserService.selectOrderUserList(orderUser);
              }
      }
      //如果没有订单，备注写由于没有订单，可以去掉不调整
        if(list.size()==0){
            AdjustUser adjustUser = adjustService.selectAdjustById1(Long.valueOf(orderUser.getUserId()));
            adjustUser.setRemark("由于没有订单");
            adjustUser.setAdjustStatus("已调整");
            //只改变了调整状态
            adjustService.updateAdjustStatus(adjustUser);
            NewsAgency newsAgency = newsAgencyService.selectNewsAgencyById1(Long.valueOf(orderUser.getUserId()));
            newsAgency.setStatus("1");
            newsAgencyService.changeNewsAgencyStatus(newsAgency);
        } else if(lists.size()==0){
            //  判断订单，订单全部调整过的更改状态
              AdjustUser adjustUser = adjustService.selectAdjustById1(Long.valueOf(orderUser.getUserId()));
              adjustUser.setAdjustStatus("已调整");
              adjustService.updateAdjustStatus(adjustUser);
              NewsAgency newsAgency = newsAgencyService.selectNewsAgencyById1(Long.valueOf(orderUser.getUserId()));
              newsAgency.setStatus("1");
              newsAgencyService.changeNewsAgencyStatus(newsAgency);
      }
        return getDataTable(lists);
    }


    /**
     * 调整业务员
     * @param
     * @param mmap
     * @return
     */
    @RequiresPermissions("system:adjust:adjust")
    @GetMapping("/add/{userId}/{ids}")
    public String add(@PathVariable("ids")String ids, ModelMap mmap, User user,@PathVariable("userId")String buserId)
    {
        //获取登陆人信息
        User user1=getUser();
        List<User> list;
        Boolean deptUp=false;
        AdjustUser adjust = adjustService.selectAdjustById1(Long.valueOf(buserId));
        mmap.put("adjustUser", adjustService.selectAdjustById1(Long.valueOf(buserId)));
//      mmap.put("id",buserId);
        mmap.put("adminId", user1.getUserId());
        mmap.put("adminName", user1.getUserName());
        //获取职级
        String name = adjust.getPostName();
        if(name.contains("总监")){
            mmap.put("userList", userService.selectUserListZongjian(user));
        } else if(name.contains("主管")){
            user.setDeptId(adjust.getDeptId());
            user.setDeptId(adjust.getParentId());
            mmap.put("userList",userService.selectUserZhuGuan(user));
        }else if(name.contains("业务员")) {
            //根据自己部门id查询所在部门的在职人员
            user.setDeptId(adjust.getDeptId());
            user.setParentId(adjust.getDeptId());
            mmap.put("userList",userService.selectUserList1(user));
        }
        mmap.put("ids",ids);
        return prefix + "/add";
    }

    /**
     * 保存调整更改
     *
     * @param adjustUser
     * @return
     */
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave( AdjustUser adjustUser,String ids) {
        //获取订单Id
       String[] orderIds= ids.split(",");
       String id = orderIds[0];
//       Order order = orderService.selectOrderById(Math.toIntExact(id));
        Order order = orderService.selectOrderByOrderId(id);
       for(String orderId : orderIds){
//           Order order1 = orderService.selectOrderById(Integer.valueOf(orderId));
           Order order1 = orderService.selectOrderByOrderId(orderId);
           order1.setSalesmanName(adjustUser.getAftUser());
           order1.setSalesmanTrim(adjustUser.getRemark());
    //根据userName插入userId
           String strUser="";
           List<User> userList = userService.selectUserStatusAll();
           for(User users : userList){
               strUser +=users.getUserName()+',';
           }
           String arrUser [] = strUser.split(",");
           if(strUser.contains(adjustUser.getAftUser())) {
               for (int index = 0; index < arrUser.length; index++) {
                   if (arrUser[index].equals(adjustUser.getAftUser())) {
                       order1.setSalesmanId(Math.toIntExact(userList.get(index).getUserId()));
                   }
               }
           }
            orderService.updateSalesmanName(order1);
       }
       //当调整的订单业务员一样时，以张三，李四保存
        AdjustUser adjustUser1 = adjustService.selectAdjustUserByBuserId(Math.toIntExact(adjustUser.getBuserId()));
      if(Long.valueOf(order.getUserId()).equals(adjustUser.getBuserId())){
        //拼接接收人，去除重复的接收人姓名
        if(adjustUser.getAftUser().contains(adjustUser1.getAftUser())){
            adjustUser1.setAftUser(adjustUser.getAftUser());
            adjustUser1.setRemark(adjustUser.getRemark());
        }
        else {
            adjustUser1.setAftUser(adjustUser.getAftUser() + "," + adjustUser1.getAftUser());
            adjustUser1.setRemark(adjustUser.getRemark() + ";" + adjustUser1.getRemark());
            // adjustService.updateAdjustUser(adjustUser1);
        }
     }
        return toAjax(adjustService.updateAdjustUser(adjustUser1));
    }

    /**
     * 查看页面
     * @param id
     * @param mmap
     * @return
     */
    @RequiresPermissions("system:adjust:cmd")
    @GetMapping("/query/{id}")
    public String look(@PathVariable("id") Long id, ModelMap mmap) {
        mmap.put("adjustUser", adjustService.selectAdjustById(id));
        return prefix + "/query";
    }

    /**
     * 不调整页面
     * @param id
     * @param mmap
     * @return
     */
    @RequiresPermissions("system:adjust:noadjust")
    @GetMapping("/edit/{id}")
    public String add(@PathVariable("id") Long id, ModelMap mmap)
    {
       mmap.put("adjustUser", adjustService.selectAdjustById1(id));
        return prefix + "/edit";
    }


    /**
     * 保存不调整原因
     *
     * @param adjustUser
     * @return
     */

//    @PostMapping("/edit")
//    @ResponseBody
//    public AjaxResult editSave(AdjustUser adjustUser,NewsAgency newsAgency) {
//
////        List<NewsAgency> lists = newsAgencyService.selectNewsAgencyList(newsAgency);
////        for(NewsAgency newsAgency1:lists){
////            AdjustUser adjustUser1=adjustService.selectAdjustUserByBuserId(newsAgency1.getProposerId());
////            if(adjustUser1!=null){
////                if (adjustUser.getRemark()!=null && adjustUser.getBuserId().equals(adjustUser1.getBuserId())){
////                    newsAgency1.setStatus("1");
////                    adjustUser.setAdjustStatus("已调整");
////                    adjustService.updateAdjustStatus(adjustUser);
////                }else{
////                    newsAgency1.setStatus("0");
////                }
////                newsAgencyService.changeNewsAgencyStatus(newsAgency1);
////            }
////        }
//        return toAjax(adjustService.updateAdjust(adjustUser));
//    }


    /*显示上传页面*/
    @RequiresPermissions("system:adjust:upload")
    @GetMapping("/upload/{buserId}")
    public String upload(AdjustUser adjustUser, ModelMap mmap) {
        AdjustUser adjustUser1= adjustService.selectAdjustUserByBuserId(Math.toIntExact(adjustUser.getBuserId()));
        mmap.put("adjustUser", adjustUser1);
        return prefix + "/upload";
    }



    /**
     * 导入excel文件
     * */
    @PostMapping("/uploadSave")
    @ResponseBody
    @Transactional
    public AjaxResult excelSave(Order order, @RequestParam("uploadFile") MultipartFile file, HttpServletRequest request,AdjustUser adjustUser,NewsAgency newsAgency)
    {
        String message="";
        //判断文件是否为空
        if(file==null){
            message="文件不能为空！";
            return toAjaxMes(0,message);
        }
        //获取文件名
        String fileName=file.getOriginalFilename();
        //验证文件名是否合格
        if(!NewFileUploadUtils.validateExcel(fileName)){
            message="文件必须是excel格式！";
            return toAjaxMes(0,message);
        }
        //进一步判断文件内容是否为空（即判断其大小是否为0或其名称是否为null）
        long size=file.getSize();
        if(StringUtils.isEmpty(fileName) || size==0){
            message="文件不能为空！";
            return toAjaxMes(0,message);
        }
        //批量导入
        message = orderUserService.batchImport(order,file,adjustUser,newsAgency);
        if(message.contains("行")){
            return error(message);
        }else{
            return success(message);
        }
       // return toAjaxMes(1,message);
    }










}