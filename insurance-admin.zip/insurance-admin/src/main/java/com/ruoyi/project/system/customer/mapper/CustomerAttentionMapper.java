package com.ruoyi.project.system.customer.mapper;

/**
 * Created by x on 2018/8/7.
 */


import com.ruoyi.project.system.customer.domain.CustomerAttention;

import java.util.List;

/**
 *收件人信息表   数据层
 */
public interface CustomerAttentionMapper {
    /**
     * 查询收件人数据集合
     *
     * @param customerAttention 收件人信息
     * @return 收件人数据集合
     */
    public List<CustomerAttention> selectCustomerAttentionList(CustomerAttention customerAttention);

    /**
     * 收件人所有信息
     *
     * @return 收件人列表
     */
    public List<CustomerAttention> selectCustomerAttentionAll();


    /**
     * 根据客户表Id查询收件人信息
     *
     * @param customerId 客户表Id
     * @return 收件人集合信息
     */
    public List<CustomerAttention> selectCustomerAttentionByCustomerId(int customerId);

    /**
     * 通过客户ID查询收件人信息
     *
     * @param id 客户id
     * @return 收件人信息
     */
    public CustomerAttention selectCustomerAttentionById(Long id);

    /**
     * 新增收件人信息
     *
     * @param customerAttention 收件人信息
     * @return 结果
     */
    public int insertCustomerAttention(CustomerAttention customerAttention);


    /**
     * 修改收件人信息
     *
     * @param customerAttention 收件人信息
     * @return 结果
     */
    public int updateCustomerAttention(CustomerAttention customerAttention);


    /**
     * 批量删除收件人信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteCustomerAttentionByIds(Long[] ids);


    /**
     * 查询收件人数据集合
     *
     * @param customerId 收件人信息
     * @return 收件人数据集合
     */
    public List<CustomerAttention> selectCustomerAttentionListInfo(int customerId);


}


























