package com.ruoyi.project.finance.finance.mapper;

import com.ruoyi.project.finance.finance.domain.Finance;
import com.ruoyi.project.order.order.domain.Order;
import com.ruoyi.project.system.notice.domain.Notice;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;

/**
 * 保险订单 数据层
 * 
 * @author ruoyi
 * @date 2018-08-13
 */
public interface FinanceMapper {


	/**
     * 查询为认款清单
     */
	public List<Finance> selectFinanceList(Finance finance);

	public Finance selectFinanceById(Long id);

	/**
	 * 为认款清单新增
	 */
	public int insertFinance(Finance finance);


	/**
	 * 修改认款清单
	 */
	public int updateFinance(Finance finance);

	/**
	 * 批量删除认款清单
	 * @param ids 需要删除的数据ID
	 * @return 结果
	 */
	public int deleteFinanceByIds(String[] ids);




}