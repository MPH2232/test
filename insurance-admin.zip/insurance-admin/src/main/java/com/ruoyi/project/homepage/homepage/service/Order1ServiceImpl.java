package com.ruoyi.project.homepage.homepage.service;

import com.ruoyi.common.support.Convert;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.project.homepage.homepage.damain.Order1;
import com.ruoyi.project.homepage.homepage.mapper.Order1Mapper;
import com.ruoyi.project.order.order.domain.Order;
import com.ruoyi.project.order.order.mapper.OrderMapper;
import com.ruoyi.project.order.order.service.IOrderService;
import com.ruoyi.project.system.channel.domain.Channel;
import com.ruoyi.project.system.channel.mapper.ChannelMapper;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.mapper.CustomerMapper;
import com.ruoyi.project.system.supplier1.domain.Supplier;
import com.ruoyi.project.system.supplier1.mapper.Supplier1Mapper;
import com.ruoyi.project.system.user.domain.User;
import com.ruoyi.project.system.user.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

/**
 * 保险订单 服务层实现
 * 
 * @author ruoyi
 * @date 2018-08-13
 */
@Service
public class Order1ServiceImpl implements IOrder1Service {

    @Autowired
    public Order1Mapper ordermapper;
    @Override
    public List<Order1> selectOrder1List(Order1 order1) {
        return ordermapper.selectOrder1List(order1);
    }

    @Override
    public List<Order1> selectOrder2List(Order1 order2) {
        return ordermapper.selectOrder2List(order2);
    }

    /*管理员*/

    @Override
    public List<Order1> selectOrderGlyList(int status) {
        return ordermapper.selectOrderListInfoAdmin(status);
    }

    /*主管*/
    @Override
    public List<Order1> selectOrderZhuguanList(long deptId,long statu) {
        return ordermapper.selectOrderListInfozhu(deptId,statu);
    }

    /*总监*/
    @Override
    public List<Order1> selectOrderMajordomoList(long deptId,long stat) {
        return ordermapper.selectOrderListInfoMajordomo(deptId,stat);
    }

    /**
     *业务员
     */
    @Override
    public List<Order1> selectOrderYwyList(long userIdd,long statuss) {
        return ordermapper.selectOrderListInfoye(userIdd,statuss);
    }
}
