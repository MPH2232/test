package com.ruoyi.project.system.product.mapper;

import com.ruoyi.project.system.product.domain.CommisionBili;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;

/**
 * Created by x on 2018/9/12.
 */
public interface ProductCommisionMapper {

    public int insertCommisionBiliList(@Param("list") List<CommisionBili> commisionBili);

    public List<CommisionBili> selectCommisionBiliInfo(Long productId);

    public int updateCommisionBili(@Param("list") List<CommisionBili> commisionBili);

}

