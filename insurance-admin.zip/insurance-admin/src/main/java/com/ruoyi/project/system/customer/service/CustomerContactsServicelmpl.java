package com.ruoyi.project.system.customer.service;

import com.ruoyi.common.support.Convert;
import com.ruoyi.common.utils.security.ShiroUtils;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.domain.CustomerContacts;
import com.ruoyi.project.system.customer.mapper.CustomerContactsMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by x on 2018/8/8.
 */
@Service
public class CustomerContactsServicelmpl implements lCustomerContactsService {

    @Autowired
    private CustomerContactsMapper customerContactsMapper;

    @Override
    public List<CustomerContacts> selectCustomerContactsList(CustomerContacts customercontacts) {
        return customerContactsMapper.selectCustomerContactsList(customercontacts);
    }

    /*查询所有联系人信息*/
    @Override
    public List<CustomerContacts> selectCustomerContactsAll() {
        return customerContactsMapper.selectCustomerContactsAll();
    }

    /**
     * 通过id查询联系人信息
     * @param id
     * @return
     */
    @Override
    public CustomerContacts selectCustomerContactsById(Long id) {
        return customerContactsMapper.selectCustomerConstomerById(id);
    }


    /*通过客户表Id查询联系人信息*/
    @Override
    public List<CustomerContacts> selectCustomerContactsByCustomerId(int customerId) {
        return customerContactsMapper.selectCustomerContactsByCustomerId(customerId);
    }


    /*新增联系人信息*/
    @Override
    public int insertCustomerContacts(CustomerContacts customercontacts) {
        customercontacts.setCreateBy(ShiroUtils.getLoginName());
        return customerContactsMapper.insertCustomerContacts(customercontacts);
    }

    /*修改联系人信息*/
    @Override
    public int updateCustomerContacts(CustomerContacts customercontacts) {
        customercontacts.setUpdateBy(ShiroUtils.getLoginName());
        return customerContactsMapper.updateCustomerContacts(customercontacts);
    }

    /*批量删除联系人信息*/

    @Override
    public int deleteCustomerContactsByIds(String ids) throws Exception {
        Long[] customerContactsIds = Convert.toLongArray(ids);
        for (Long id : customerContactsIds)
        {
            CustomerContacts customerContacts = selectCustomerContactsById(id);
        }
        return customerContactsMapper.deleteCustomerContactsByIds(customerContactsIds);
    }

}





