package com.ruoyi.project.system.supplier1.mapper;

import com.ruoyi.project.system.dict.domain.DictData;
import com.ruoyi.project.system.supplier1.domain.Protocol;

import java.util.Date;
import java.util.List;

/**
 * 协议 数据层
 * 
 * @author ruoyi
 */
public interface Protocol1Mapper
{

    /**
     * 查询所有协议
     *
     * @return 协议列表
     */
    public List<Protocol> selectProtocolAll();


    /**
     *根据关联字段批量删除协议
     * @param suprotocolIds
     * @return
     */
    public int deleteProtocolBySuprotocolIds(String[] suprotocolIds);
    /**
     * 批量删除协议信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteProtocolByIds(String[] ids);

    /**
     * 新增协议信息
     *
     * @param protocol 协议信息
     * @return 结果
     */
    public int insertProtocol(Protocol protocol);

    /**
     * 修改协议信息
     *
     * @param protocol 协议信息
     * @return 结果
     */
    public int updateProtocol(Protocol protocol);

    /**
     * 新增协议信息插入集合list
     *
     * @param protocol 协议信息
     * @return 结果
     */

    public List<Protocol> selectProtocolList(Protocol protocol);

    public Protocol selectProtocolById(Long protocolId);

    public int deleteProtocolById(Long protocolId);

    /**
     * 根据关联字段查协调实体集合
     * @param protocolId
     * @return
     */
    public List<Protocol> selectProtocol(String protocolId);

    public List<Protocol> selectProtocolListBySuprotocolIds(String suprotocolId);

    public Protocol selectProtocolDateBySuprotocolIds(String suprotocolId);

    public int updateProtocolStatus(Protocol protocol);

}
