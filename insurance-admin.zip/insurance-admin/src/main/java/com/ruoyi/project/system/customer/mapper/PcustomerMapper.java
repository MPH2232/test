package com.ruoyi.project.system.customer.mapper;

/**
 * Created by x on 2018/8/7.
 */


import com.ruoyi.project.system.customer.domain.Pcustomer;

import java.util.HashMap;
import java.util.List;

/**
 * 客户表   数据层
 */
public interface PcustomerMapper {
    /**
     * 查询个人客户数据集
     * @param pcustomer 个人客户信息
     * @return 个人客户数据集合
     */
    public List<Pcustomer> selectPersonCustomerList1(Pcustomer pcustomer);


    public int addPersonCustomer(HashMap<String,Object> map);


}
