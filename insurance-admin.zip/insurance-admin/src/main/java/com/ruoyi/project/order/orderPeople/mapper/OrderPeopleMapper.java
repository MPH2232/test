package com.ruoyi.project.order.orderPeople.mapper;

import com.ruoyi.project.order.orderPeople.domain.OrderPeople;
import com.ruoyi.project.order.orderPeople.domain.OrderPeopleCount;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;

/**
 * 人员清单，关联订单， 数据层
 * 
 * @author ruoyi
 * @date 2018-08-23
 */
public interface OrderPeopleMapper 
{
	/**
     * 查询人员清单，关联订单，信息
     * 
     * @param id 人员清单，关联订单，ID
     * @return 人员清单，关联订单，信息
     */
	public OrderPeople selectOrderPeopleById(Integer id);

	public  List<OrderPeopleCount>  selectOrderPeopleByPlans(@Param("orderId") String orderId, @Param("orderType") String orderType);

	/**
     * 查询人员清单，关联订单，列表
     * 
     * @param orderPeople 人员清单，关联订单，信息
     * @return 人员清单，关联订单，集合
     */
	public List<OrderPeople> selectOrderPeopleList(OrderPeople orderPeople);
	
	/**
     * 新增人员清单，关联订单，
     * 
     * @param orderPeople 人员清单，关联订单，信息
     * @return 结果
     */
	public int insertOrderPeople(OrderPeople orderPeople);
	
	/**
     * 修改人员清单，关联订单，
     * 
     * @param orderPeople 人员清单，关联订单，信息
     * @return 结果
     */
	public int updateOrderPeople(OrderPeople orderPeople);
	
	/**
     * 删除人员清单，关联订单，
     * 
     * @param id 人员清单，关联订单，ID
     * @return 结果
     */
	public int deleteOrderPeopleById(Integer id);
	
	/**
     * 批量删除人员清单，关联订单，
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteOrderPeopleByIds(String[] ids);

	/**
	 * 批量删除人员清单，关联订单，
	 *
	 * @param orderid 需要删除的数据ID
	 * @return 结果
	 */
	public int deleteOrderPeopleByOrderId(String orderid);

	public int addOrderPeople(HashMap<String,Object> map);

	public int insertOrderPeopleList(List<OrderPeople> orderPeopleList);

	public int deleteOrderPeopleByPolicyNum(String policyNum);
}