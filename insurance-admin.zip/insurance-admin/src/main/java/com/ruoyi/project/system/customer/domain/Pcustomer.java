package com.ruoyi.project.system.customer.domain;

import com.ruoyi.framework.aspectj.lang.annotation.Excel;

/**
 * Created by x on 2018/9/4.
 */
public class Pcustomer {

    /*公司名称*/
    @Excel(name = "客户名称")
    private String customerName;
    /*证件类型*/
    @Excel(name = "证件类型")
    private String cardType;
    /*证件号码*/
    @Excel(name = "证件号码")
    private String cardNum;
    /*生日*/
    @Excel(name = "生日")
    private String shengri;
    /*性别*/
    @Excel(name = "性别")
    private String sex;
    /*联系人邮箱*/
    @Excel(name = "联系人邮箱")
    private String contactsEmail;
    /*邮寄地址*/
    @Excel(name = "邮寄地址")
    private String customerMail;
    /*联系人电话*/
    @Excel(name = "联系人电话")
    private String contactsPhone;
    /*联系人微信号*/
    @Excel(name = "联系人微信号")
    private String contactsWeixin;
    /*开票公司下公司名称*/
    @Excel(name = "开票公司下公司名称")
    private String paytaxesName;
    /*信用代码*/
    @Excel(name = "信用代码")
    private String paytaxesCode;
    /*是否为增值税一般纳税人*/
    @Excel(name = "增值税纳税人")
    private String paytaxes;
    /*税务登记地址*/
    @Excel(name = "税务登记地址")
    private String paytaxesAdd;
    /*开票信息公司电话*/
    @Excel(name = "开票信息公司电话")
    private String paytaxesPhone;
    /*开票信息开户行*/
    @Excel(name = "开票信息开户行")
    private String paytaxesBank;
    /*开票信息开户支行*/
    @Excel(name = "开票信息开户支行")
    private String paytaxesBankSon;
    /*开票信息开户账号*/
    @Excel(name = "开票信息开户账号")
    private String paytaxesNumber;
    /*保费开户户名*/
    @Excel(name = "保费开户户名")
    private String premiumName;
    /*保费开户行*/
    @Excel(name = "保费开户行")
    private String premiumBank;
    /*保费开户支行*/
    @Excel(name = "保费开户支行")
    private String premiumBankSon;
    /*保费开户账号*/
    @Excel(name = "保费开户行账号")
    private String premiumNumber;
    /*客户类型*/
 //   @Excel(name = "客户类型")
    private String customerType;
  //  @Excel(name = "客户id")
    /*个人客户id*/
    private int id;
    //业务员id
    private Long userId;

    private static final long serialVersionUID = 1L;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getPaytaxesBankSon() {
        return paytaxesBankSon;
    }

    public void setPaytaxesBankSon(String paytaxesBankSon) {
        this.paytaxesBankSon = paytaxesBankSon;
    }

    public String getPremiumBankSon() {
        return premiumBankSon;
    }

    public void setPremiumBankSon(String premiumBankSon) {
        this.premiumBankSon = premiumBankSon;
    }

    public String getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getCardNum() {
        return cardNum;
    }

    public void setCardNum(String cardNum) {
        this.cardNum = cardNum;
    }

    public String getShengri() {
        return shengri;
    }

    public void setShengri(String shengri) {
        this.shengri = shengri;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getContactsEmail() {
        return contactsEmail;
    }

    public void setContactsEmail(String contactsEmail) {
        this.contactsEmail = contactsEmail;
    }

    public String getCustomerMail() {
        return customerMail;
    }

    public void setCustomerMail(String customerMail) {
        this.customerMail = customerMail;
    }

    public String  getContactsPhone() {
        return contactsPhone;
    }

    public void setContactsPhone(String contactsPhone) {
        this.contactsPhone = contactsPhone;
    }

    public String getContactsWeixin() {
        return contactsWeixin;
    }

    public void setContactsWeixin(String contactsWeixin) {
        this.contactsWeixin = contactsWeixin;
    }

    public String getPaytaxesName() {
        return paytaxesName;
    }

    public void setPaytaxesName(String paytaxesName) {
        this.paytaxesName = paytaxesName;
    }

    public String getPaytaxesCode() {
        return paytaxesCode;
    }

    public void setPaytaxesCode(String paytaxesCode) {
        this.paytaxesCode = paytaxesCode;
    }

    public String getPaytaxes() {
        return paytaxes;
    }

    public void setPaytaxes(String paytaxes) {
        this.paytaxes = paytaxes;
    }

    public String getPaytaxesAdd() {
        return paytaxesAdd;
    }

    public void setPaytaxesAdd(String paytaxesAdd) {
        this.paytaxesAdd = paytaxesAdd;
    }

    public String getPaytaxesPhone() {
        return paytaxesPhone;
    }

    public void setPaytaxesPhone(String paytaxesPhone) {
        this.paytaxesPhone = paytaxesPhone;
    }

    public String getPaytaxesBank() {
        return paytaxesBank;
    }

    public void setPaytaxesBank(String paytaxesBank) {
        this.paytaxesBank = paytaxesBank;
    }

    public String getPaytaxesNumber() {
        return paytaxesNumber;
    }

    public void setPaytaxesNumber(String paytaxesNumber) {
        this.paytaxesNumber = paytaxesNumber;
    }

    public String getPremiumName() {
        return premiumName;
    }

    public void setPremiumName(String premiumName) {
        this.premiumName = premiumName;
    }

    public String getPremiumBank() {
        return premiumBank;
    }

    public void setPremiumBank(String premiumBank) {
        this.premiumBank = premiumBank;
    }

    public String getPremiumNumber() {
        return premiumNumber;
    }

    public void setPremiumNumber(String premiumNumber) {
        this.premiumNumber = premiumNumber;
    }

    @Override
    public String toString() {
        return "Pcustomer{" +
                "customerName='" + customerName + '\'' +
                ", cardType='" + cardType + '\'' +
                ", cardNum='" + cardNum + '\'' +
                ", shengri='" + shengri + '\'' +
                ", sex='" + sex + '\'' +
                ", contactsEmail='" + contactsEmail + '\'' +
                ", customerMail='" + customerMail + '\'' +
                ", contactsPhone='" + contactsPhone + '\'' +
                ", contactsWeixin='" + contactsWeixin + '\'' +
                ", paytaxesName='" + paytaxesName + '\'' +
                ", paytaxesCode='" + paytaxesCode + '\'' +
                ", paytaxes='" + paytaxes + '\'' +
                ", paytaxesAdd='" + paytaxesAdd + '\'' +
                ", paytaxesPhone='" + paytaxesPhone + '\'' +
                ", paytaxesBank='" + paytaxesBank + '\'' +
                ", paytaxesBankSon='" + paytaxesBankSon + '\'' +
                ", paytaxesNumber='" + paytaxesNumber + '\'' +
                ", premiumName='" + premiumName + '\'' +
                ", premiumBank='" + premiumBank + '\'' +
                ", premiumBankSon='" + premiumBankSon + '\'' +
                ", premiumNumber='" + premiumNumber + '\'' +
                ", customerType='" + customerType + '\'' +
                ", id=" + id +
                '}';
    }
}
