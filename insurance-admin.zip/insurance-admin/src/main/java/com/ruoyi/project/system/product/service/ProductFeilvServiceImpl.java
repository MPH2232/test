package com.ruoyi.project.system.product.service;

import com.ruoyi.common.support.Convert;
import com.ruoyi.project.system.product.domain.Feilv;
import com.ruoyi.project.system.product.domain.Product;
import com.ruoyi.project.system.product.mapper.ProductFeilvMapper;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by x on 2018/8/7.
 */
@Service
public class ProductFeilvServiceImpl implements IProductFeilvService {

    @Autowired
    private ProductFeilvMapper productFeilvMapper;

    @Override
    public List<Feilv> selectFeilvList(Feilv feilv) {
        return productFeilvMapper.selectFeilvList(feilv);
    };

    @Override
    public List<Feilv> selectFeilvsByName(String productName) {
        return productFeilvMapper.selectFeilvsByName(productName);
    };

    @Override
    public List<Feilv> selectFeilvListById(Long productId){

        return  productFeilvMapper.selectFeilvListById(productId);
    };

    @Override
    public Feilv selectFeilvById(Long productId) {
        return productFeilvMapper.selectFeilvById(productId);
    };

//    @Override
//    public Long[] selectIdsByProductName(String productName) {
//        return productFeilvMapper.selectIdsByProductName(productName);
//    };

    @Override
    public int addFeilv(HashMap<String, Object> map) {
/*        feilv.setCreateBy(ShiroUtils.getLoginName());*/
//        String sta = (String) map.get("status");
//        String status = sta.substring(0, 1);
//        map.put("status", status);
//        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
//        String createTime = (String) map.get("createTime");
//        createTime = df.format(new Date());
//        map.put("createTime", createTime);
//        String mes=(String) map.get("mes");
        return productFeilvMapper.addFeilv(map);
    };

    @Override
    public int deleteFeilvByIds(String ids) throws Exception {
        Long[] feilvIds = Convert.toLongArray(ids);
        for (Long feilvId : feilvIds) {
            Feilv feilv = selectFeilvById(feilvId);
            if (countFeilvById(feilvId) > 0) {
                //throw new Exception(String.format("%1$s已分配,不能删除", product.getProductName()));
            }
        }
        return productFeilvMapper.deleteFeilvByIds(feilvIds);
    };

    @Override
    public int countFeilvById(Long feilvId) {
        return productFeilvMapper.countFeilvById(feilvId);
    };

    @Override
    public int delete(String productName,Date startTime,Date endTime){
        HashMap map = new HashMap();
        map.put("productName",productName);
        map.put("startTime",startTime);
        map.put("endTime",endTime);
        return productFeilvMapper.delete(map);
    };


    @Override
    public int updateFeilv(Feilv feilv){
        return productFeilvMapper.updateFeilv(feilv);
    };




}






