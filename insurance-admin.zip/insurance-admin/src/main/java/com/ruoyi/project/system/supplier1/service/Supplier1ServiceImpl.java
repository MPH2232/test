package com.ruoyi.project.system.supplier1.service;//package com.ruoyi.project.system.supplier1.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.project.system.supplier1.domain.Protocol;
import com.ruoyi.project.system.supplier1.domain.Supplier;

import com.ruoyi.project.system.supplier1.mapper.Protocol1Mapper;
import com.ruoyi.project.system.supplier1.mapper.Supplier1Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.common.support.Convert;
import com.ruoyi.common.utils.security.ShiroUtils;

/**
 * 字典 业务层处理
 *
 * @author ruoyi
 */
@Service
public class Supplier1ServiceImpl implements ISupplier1Service
{
    @Autowired
    private Supplier1Mapper supplier1Mapper;

    @Autowired
    private Protocol1Mapper protocolMapper;

    /**
     * 查询供应商信息集合
     *
     * @param supplier 供应商信息
     * @return 供应商信息集合
     */
    @Override
    public List<Supplier> selectSupplierList(Supplier supplier)
    {
        return supplier1Mapper.selectSupplierList(supplier);
    }

    /**
     * 查询所有供应商
     *
     * @return 供应商列表
     */
    @Override
    public List<Supplier> selectSupplierAll()
    {
        return supplier1Mapper.selectSupplierAll();
    }

    /**
     * 通过供应商ID查询供应商信息
     *
     * @param supplierId 供应商ID
     * @return 角色对象信息
     */
    @Override
    public Supplier selectSupplierById(Long supplierId)
    {
        return supplier1Mapper.selectSupplierById(supplierId);
    }

    /**
     * 批量删除供应商信息
     *
     * @param ids 需要删除的数据ID
     * @throws Exception
     */
    @Override
    public int deleteSupplierByIds(String ids) throws Exception
    {
        Long[] supplierIds = Convert.toLongArray(ids);
        return supplier1Mapper.deleteSupplierByIds(supplierIds);
    }

    @Override
    public int insertSupplier(Supplier supplier) {
        Date date=new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        supplier.setProtocolId(sdf.format(date));
        return supplier1Mapper.insertSupplier(supplier);
    }

//    @Override
//    public int insertSupplier(Supplier1 supplier, List<Protocol1> protocol) {
//        supplier.setCreateBy(ShiroUtils.getLoginName());
//        Date date=new Date();
//        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
//        supplier.setProtocolId(sdf.format(date));
//        for(int i=0;i<protocol.size();i++){
//            protocol.get(i).setSuprotocolId(sdf.format(date));
//        }
//        protocol1Mapper.insertProtocolList(protocol);
//        return supplier1Mapper.insertSupplier(supplier);
//    }


    /**
     * 修改保存供应商信息
     *
     * @param supplier 供应商信息
     * @return 结果
     */
    @Override
    public int updateSupplier(Supplier supplier)
    {
        supplier.setUpdateBy(ShiroUtils.getLoginName());
        return supplier1Mapper.updateSupplier(supplier);
    }

    @Override
    public int updateSupplierStatus(Supplier supplier) {
        supplier.setUpdateBy(ShiroUtils.getLoginName());
        return supplier1Mapper.updateSupplierStatus(supplier);
    }

    /**
     * 校验供应商名称是否唯一
     *
     * @return 结果
     */
    @Override
    public String checkSupplierNameUnique(Supplier sup)
    {
        Long supplierId = StringUtils.isNull(sup.getSupplierId()) ? -1L : sup.getSupplierId();
        Supplier supplier = supplier1Mapper.checkSupplierNameUnique(sup.getSupplierName());
        if (StringUtils.isNotNull(supplier) && !supplier.getSupplierId().equals(supplierId))
        {
            return UserConstants.SUPPLIER_NAME_NOT_UNIQUE; //报错不唯一，重复
        }
        return UserConstants.SUPPLIER_NAME_UNIQUE;//不报错，唯一，不重复
    }

    @Override
    public Supplier selectPaytaxesBankBysupplierName(String supplierName) {
        return supplier1Mapper.selectPaytaxesBankBysupplierName(supplierName);
    }

}
