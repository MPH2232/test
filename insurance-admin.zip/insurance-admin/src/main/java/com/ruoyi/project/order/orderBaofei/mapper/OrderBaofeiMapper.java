package com.ruoyi.project.order.orderBaofei.mapper;

import com.ruoyi.project.order.orderBaofei.domain.OrderBaofei;
import java.util.List;	

/**
 * 订单分期--关联计划id,--关联订单id--关联保全 数据层
 * 
 * @author ruoyi
 * @date 2018-09-21
 */
public interface OrderBaofeiMapper 
{
	/**
     * 查询订单分期--关联计划id,--关联订单id--关联保全信息
     * 
     * @param id 订单分期--关联计划id,--关联订单id--关联保全ID
     * @return 订单分期--关联计划id,--关联订单id--关联保全信息
     */
	public OrderBaofei selectOrderBaofeiById(Integer id);
	
	/**
     * 查询订单分期--关联计划id,--关联订单id--关联保全列表
     * 
     * @param orderBaofei 订单分期--关联计划id,--关联订单id--关联保全信息
     * @return 订单分期--关联计划id,--关联订单id--关联保全集合
     */
	public List<OrderBaofei> selectOrderBaofeiList(OrderBaofei orderBaofei);
	
	/**
     * 新增订单分期--关联计划id,--关联订单id--关联保全
     * 
     * @param orderBaofei 订单分期--关联计划id,--关联订单id--关联保全信息
     * @return 结果
     */
	public int insertOrderBaofei(OrderBaofei orderBaofei);
	public int insertOrderBaofeiList(List<OrderBaofei> orderBaofei);
	/**
     * 修改订单分期--关联计划id,--关联订单id--关联保全
     * 
     * @param orderBaofei 订单分期--关联计划id,--关联订单id--关联保全信息
     * @return 结果
     */
	public int updateOrderBaofei(OrderBaofei orderBaofei);
	
	/**
     * 删除订单分期--关联计划id,--关联订单id--关联保全
     * 
     * @param id 订单分期--关联计划id,--关联订单id--关联保全ID
     * @return 结果
     */
	public int deleteOrderBaofeiById(Integer id);
	
	/**
     * 批量删除订单分期--关联计划id,--关联订单id--关联保全
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteOrderBaofeiByIds(String[] ids);

	//1114
	public List<OrderBaofei> selectOrderBaofeiByOrderFeiqiId(String orderFenqiId);
	
}