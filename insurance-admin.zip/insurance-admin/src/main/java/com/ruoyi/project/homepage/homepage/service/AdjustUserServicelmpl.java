package com.ruoyi.project.homepage.homepage.service;

import com.ruoyi.project.homepage.homepage.damain.AdjustUser;
import com.ruoyi.project.homepage.homepage.damain.NewsAgency;
import com.ruoyi.project.homepage.homepage.mapper.AdjustUserMapper;
import com.ruoyi.project.homepage.homepage.mapper.NewsAgencyMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by x on 2018/9/17.
 */
@Service
public class AdjustUserServicelmpl implements IAdjustUserService{

    /**
     * 查询调整业务员消息
     * @return
     */
    @Autowired
    private AdjustUserMapper adjustUserMapper;



    @Override
    public AdjustUser selectAdjustUserByBuserId(Integer buserId) {
        return adjustUserMapper.selectAdjustUserByBuserId(buserId);
    }



    @Override
    public AdjustUser selectAdjustUserByName(String proposerName) {
        return adjustUserMapper.selectAdjustUserByName(proposerName);
    }

    @Override
    public int insertAdjustUser(AdjustUser adjustUser) {
        return adjustUserMapper.insertAdjustUser(adjustUser);
    }
}
