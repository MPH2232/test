package com.ruoyi.project.system.product.service;


import com.ruoyi.project.system.product.domain.Product;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * Created by x on 2018/8/7.
 * 产品信息 服务层
 */
public interface IProductService {

    public List<Product> selectProductList(Product product);

    public List<Product> selectProductAll();

    /*产品类型集合*/
    public List selectProductTyPe();

    /*产品名称集合*/
    public List selectInsuranceName();

    /*产品信息添加*/
    public int insertProduct(Product product);

    /*产品信息更改*/
    public int updateProduct(Product product);

    /*根据id查询产品信息*/
    public Product selectProductById(Long productId);

    /*删除产品信息*/
    public int deleteProductByIds(String ids) throws Exception;

    /*计算选中的产品记录*/
    public int countProductById(Long productId);

    /*比例运算(乘100)*/
    public String transform1(String string);

    /*比例运算(除100)*/
    public String transform2(String string);

    /*首页展示产品信息*/
    public void judgement1(List<Product> list);

    /*根据id查询产品信息信息-编辑*/
    public Product judgement2(String productId);

    /*根据id查询产品信息信息-删除*/
    public Product judgement4(String productId);

    /*校验产品名称唯一性*/
    public String checkProductUnique(Product product);

    public int selectProductFeilv(Product product);


    public int selectMaxId();
}
