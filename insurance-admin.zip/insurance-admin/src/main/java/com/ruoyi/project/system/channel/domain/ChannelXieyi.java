package com.ruoyi.project.system.channel.domain;


import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

import java.util.Date;

/**
 * 协议对象 f_channel
 * 
 * @author ruoyi
 */
public class ChannelXieyi extends BaseEntity
{
    /** 文件名称" */
    private String channelId;

    /** 文件名称" */
    private String channelXieyiname;

    /** 文件类型 */
    private String channelXieyitype;


    /** 路径*/
    private String channellujing;

    public String getChannellujing() {
        return channellujing;
    }

    public void setChannellujing(String channellujing) {
        this.channellujing = channellujing;
    }

    public String getChannelId() {
        return channelId;
    }

    public void setChannelId(String channelId) {
        this.channelId = channelId;
    }

    public String getChannelXieyiname() {
        return channelXieyiname;
    }

    public void setChannelXieyiname(String channelXieyiname) {
        this.channelXieyiname = channelXieyiname;
    }

    public String getChannelXieyitype() {
        return channelXieyitype;
    }

    public void setChannelXieyitype(String channelXieyitype) {
        this.channelXieyitype = channelXieyitype;
    }
}
