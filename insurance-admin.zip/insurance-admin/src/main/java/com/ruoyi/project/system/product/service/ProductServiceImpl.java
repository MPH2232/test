package com.ruoyi.project.system.product.service;

import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.support.Convert;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.security.ShiroUtils;
import com.ruoyi.project.system.product.domain.Feilv;
import com.ruoyi.project.system.product.domain.Product;
import com.ruoyi.project.system.product.mapper.ProductFeilvMapper;
import com.ruoyi.project.system.product.mapper.ProductMapper;
import com.ruoyi.project.system.supplier1.domain.Supplier;
import com.ruoyi.project.system.supplier.mapper.SupplierMapper;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;


import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static java.math.BigDecimal.ROUND_UNNECESSARY;

/**
 * Created by x on 2018/8/7.
 */
@Service
public class ProductServiceImpl implements IProductService {
    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private SupplierMapper supplierMapper;


    @Override
    public List<Product> selectProductList(Product product) {
        return productMapper.selectProductList(product);
    }

    @Override
    public List<Product> selectProductAll() {
        return productMapper.selectProductAll();
    }

    /*产品信息添加*/
    @Override
    public int insertProduct(Product product) {
        product.setCreateBy(ShiroUtils.getLoginName());
        Supplier supplier= supplierMapper.selectSupplierById(Long.parseLong(product.getInsuranceId().toString()));
        product.setInsuranceName(supplier.getSupplierName());
        return productMapper.insertProduct(product);
    }

    /*产品信息更新*/
    @Override
    public int updateProduct(Product product) {
        product.setUpdateBy(ShiroUtils.getLoginName());
        Supplier supplier= supplierMapper.selectSupplierById(Long.parseLong(product.getInsuranceId().toString()));
        product.setInsuranceName(supplier.getSupplierName());
        //将数据库中的3个比例除以100放回数据库
        product.setPcBili(transform2(product.getPcBili()));
//        product.setCommisionBili(transform2(product.getCommisionBili()));
        product.setMemberBili(transform2(product.getMemberBili()));
        return productMapper.updateProduct(product);
    }

    //根据产品id返回产品信息
    @Override
    public Product selectProductById(Long productId) {
        Product product=productMapper.selectProductById(productId);
        return product;
    }

    //比例运算(乘100)
    @Override
    public String transform1(String string)
    {
        BigDecimal bd1=new BigDecimal(String.valueOf(string));
        BigDecimal bd2=new BigDecimal(String.valueOf("100"));
        return Double.toString(bd1.multiply(bd2).doubleValue());
    }

    //比例运算(除100)
    @Override
    public String transform2(String string)
    {
    BigDecimal b = new BigDecimal(String.valueOf(string));
    BigDecimal c = new BigDecimal(String.valueOf(100));
    return Double.toString( b.divide(c,6,ROUND_UNNECESSARY).doubleValue());
    }

    //根据产品id返回产品数量
    @Override
    public int countProductById(Long productId) {
        return productMapper.countProductById(productId);
    }

    //批量删除产品
    @Override
    public int deleteProductByIds(String ids) throws Exception {
        Long[] productIds = Convert.toLongArray(ids);
        for (Long productId : productIds) {
            Product product = selectProductById(productId);
            if (countProductById(productId) > 0) {
                //throw new Exception(String.format("%1$s已分配,不能删除", product.getProductName()));
            }
        }
        return productMapper.deleteProductByIds(productIds);
    }

    /*首页展示产品信息*/
    @Override
    public void judgement1(List<Product> list){
        for (Product product:list) {
           judgement3(product);
        }
    }

    /*根据id查询产品信息信息-编辑*/
    @Override
    public Product judgement2(String productId){
        long productid = Long.parseLong(productId);
        Product product=productMapper.selectProductById(productid);
        //将数据库中的3个比例乘100显示到页面
        product.setPcBili(transform1(product.getPcBili()));
//        product.setCommisionBili(transform1(product.getCommisionBili()));
        product.setMemberBili(transform1(product.getMemberBili()));
        return product;
    }

    /*根据id查询产品信息信息-删除*/
    @Override
    public Product judgement4(String productId){
        long productid = Long.parseLong(productId);
        Product product=productMapper.selectProductById(productid);
        judgement3(product);
        //将数据库中的3个比例乘以100显示到页面
        product.setPcBili(transform1(product.getPcBili()));
        product.setMemberBili(transform1(product.getMemberBili()));
        return product;
    }

    /*对产品信息的属性进行设置*/
    public void judgement3(Product product){
        if("0".equals(product.getInsuranceTime())){
            product.setInsuranceTime("短期");
        }else if("1".equals(product.getInsuranceTime())){
            product.setInsuranceTime("1年");
        }else {
            product.setInsuranceTime("长期");
        }

    }

    /*校验产品名称唯一性*/
    @Override
    public String checkProductUnique(Product product){
        product.getProductId();
        Long productId= StringUtils.isNull(product.getProductId()) ? -1L : product.getProductId();
        Product product1=productMapper.checkProductUnique(product.getProductName());
        if (StringUtils.isNotNull(product1) && !product1.getProductId().equals(productId))
        {
            return UserConstants.DICT_TYPE_NOT_UNIQUE;
        }
        return UserConstants.DICT_TYPE_UNIQUE;
    }


    /*产品类型集合*/
    public List selectProductTyPe(){
        List<Product> products=productMapper.selectProductAll();
        List listTemp = new ArrayList();
        for(int i=0;i<products.size();i++){
          Product product=  products.get(i);
            if(!listTemp.contains(product.getProductType())){
                listTemp.add(product.getProductType());
            }
        }
        return listTemp;
    }

    /*产品名称集合*/
    public List selectInsuranceName(){
        List<Product> products=productMapper.selectProductAll();
        List listTemp = new ArrayList();
        for(int i=0;i<products.size();i++){
            Product product=  products.get(i);
            if(!listTemp.contains(product.getInsuranceName())){
                listTemp.add(product.getInsuranceName());
            }
        }
        return listTemp;
    }
    /*查询产品下是否有费率，标准和定制*/
    @Override
    public int selectProductFeilv(Product product) {
        Product productu= productMapper.selectProductByName(product.getProductName());
        if(productu.getProductPro().equals("标准")){
            return productMapper.selectProductFeilv(productu);
        }else{
            //定制
            return productMapper.selectProductFeilvDing(productu);
        }
    }

    @Override
    public int selectMaxId() {
        return productMapper.selectMaxId();
    }

}
