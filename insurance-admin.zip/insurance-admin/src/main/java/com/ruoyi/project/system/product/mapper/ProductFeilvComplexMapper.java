package com.ruoyi.project.system.product.mapper;


import com.ruoyi.project.system.product.domain.FeilvComplex;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.HashMap;
import java.util.List;


/**
 * Created by x on 2018/8/7.
 * 产品信息 数据层
 */
public interface ProductFeilvComplexMapper {

    public List<FeilvComplex> selectFeilvComplexList(Long productId);

    /**
     * 新增费率，关联高端产品
     */
    public int insertFeilvComplex(FeilvComplex feilvComplex);

    /**
     * 根据产品id删除高端费率
     */
    public int deleteFeilvComplexByProductId(Long productId);

    public List<FeilvComplex> selectFeilvComplexList1(FeilvComplex feilvComplex);

    public int insertFeilvComplexList(List<FeilvComplex> feilvComplexList);

    public int deleteFeilvComplexByProductIdAndEndTime(@Param("productId") Long productId,@Param("endTime")Date endTime);

}
