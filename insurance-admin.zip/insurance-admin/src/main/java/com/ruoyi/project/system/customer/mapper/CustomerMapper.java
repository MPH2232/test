package com.ruoyi.project.system.customer.mapper;

/**
 * Created by x on 2018/8/7.
 */


import com.ruoyi.project.system.customer.domain.Customer;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;

/**
 * 客户表   数据层
 */
public interface CustomerMapper {
    /**
     * 查询企业客户数据集合
     *
     * @param customer 企业客户信息
     * @return 企业客户数据集合
     */
    public List<Customer> selectCustomerList(Customer customer);

    /**
     * 查询个人客户数据集
     * @param customer 个人客户信息
     * @return 个人客户数据集合
     */
    public List<Customer> selectPersonCustomerList(Customer customer);

    /**
     * 客户所有信息
     *
     * @return 客户列表
     */
    public List<Customer> selectCustomerAll();

    /**
     * 客户所有岗位
     * 下拉框专用值
     * @return 客户列表
     */
    public List<Customer> selectCustomerAllOption(String customerType);


    /**
     * 新增企业客户信息
     *
     * @param customer 客户信息////
     * @return 结果
     */
    public int insertCustomer(Customer customer);

    /**
     * 新增个人客户信息
     * @param customer 客户信息
     * @return 结果
     */
    public int insertPersonCustomer(Customer customer);

    /**
     * 修改企业客户信息
     *
     * @param customer 客户信息
     * @return 结果
     */
    public int updateCustomer(Customer customer);

    /**
     * 修改个人客户信息
     *
     * @param customer 客户信息
     * @return 结果
     */
    public int updatePersonCustomer(Customer customer);

    /**
     * 通过客户ID查询客户信息
     *
     * @param id 客户id
     * @return 客户信息
     */
    public Customer selectCustomerById(Long id);

    /**
     * 批量删除客户信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteCustomerByIds(Long[] ids);

    /**
     * 批量添加个人客户信息
     */
    public int   addCustomerContacts (HashMap<String,Object> map);

    /**
     * 校验证件号码是否唯一
     *
     * @param cardNum 证件号码
     * @return 结果
     */
    public Customer checkCardNumUnique(String cardNum);

    public List<Customer> selectCustomersAll();


    /**
     * 主管查询企业客户
     */
    public List<Customer> selectCustomerListCharge(@Param("deptId")long deptId, @Param("customer")Customer customer);

    /**
     * 总监查询企业客户
     */
    public List<Customer> selectCustomerListMajordomo(@Param("deptId")long deptId,@Param("customer")Customer customer);

    /**
     * 业务员查询企业客户
     */
    public List<Customer> selectCustomerListSalesman(@Param("userIdd")long userIdd, @Param("customer")Customer customer);



    /**
     * 主管查询个人客户信息
     */
    public List<Customer> selectPersonCustomerListCharge(@Param("deptId")long deptId, @Param("customer")Customer customer);

    /**
     * 总监查询个人客户信息
     */
    public List<Customer> selectPersonCustomerListMajordomo(@Param("deptId")long deptId,@Param("customer")Customer customer);

    /**
     * 业务员查询个人客户信息
     */
    public List<Customer> selectPersonCustomerListSalesman(@Param("userId")long userId, @Param("customer")Customer customer);

}
