package com.ruoyi.project.homepage.homepage.service;


import com.ruoyi.common.utils.NewFileUploadUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.project.homepage.homepage.damain.AdjustUser;
import com.ruoyi.project.homepage.homepage.damain.NewsAgency;
import com.ruoyi.project.homepage.homepage.damain.OrderUser;
import com.ruoyi.project.homepage.homepage.mapper.NewsAgencyMapper;
import com.ruoyi.project.homepage.homepage.mapper.OrderUserMapper;
import com.ruoyi.project.order.order.domain.Order;
import com.ruoyi.project.order.order.mapper.OrderMapper;
import com.ruoyi.project.system.adjust.mapper.AdjustMapper;
import com.ruoyi.project.system.user.domain.User;
import com.ruoyi.project.system.user.mapper.UserMapper;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by x on 2018/9/17.
 */
@Service
public class OrderUserServicelmpl implements IOrderUserService{

    @Autowired
    private OrderUserMapper orderUserMapper;
    @Autowired
    private OrderMapper orderMapper;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private AdjustMapper adjustMapper;
    @Autowired
    private NewsAgencyMapper newsAgencyMapper;
    /**
     * 查询所有订单集合
     * @param orderUser
     * @return
     */
    @Override
    public List<OrderUser> selectOrderUserList(OrderUser orderUser) {
        return orderUserMapper.selectOrderUserList(orderUser);
    }

    @Override
    public List<OrderUser> selectOrderList1(OrderUser orderUser) {
        return orderUserMapper.selectOrderList1(orderUser);
    }



    @Override
    public OrderUser selectOrderUserById(Integer id) {
        return orderUserMapper.selectOrderUserById(id);
    }



    @Override
    public String batchImport(Order order, MultipartFile mfile,AdjustUser adjustUser,NewsAgency newsAgency) {
        //初始化输入流
        InputStream is = null;
        try{
            //将上传的文件写入新建的文件中
//			mfile.transferTo(tempFile);
            //装载流
            is = mfile.getInputStream();
//			POIFSFileSystem fs = new POIFSFileSystem(mfile.getInputStream());
//			HSSFWorkbook wb= new HSSFWorkbook(fs);
            Workbook book = null;
            if(NewFileUploadUtils.isExcel2003(mfile.getOriginalFilename())){
                book = new HSSFWorkbook(is);
            }else{
                book = new XSSFWorkbook(is);
            }
            //获取第一个sheet页
//			HSSFSheet sheet = hw.getSheetAt(0);
            //根据新建的文件实例化输入流
//			is = mfile.getInputStream();
            //根据版本选择创建Workbook的方式
//			Workbook wb = WorkbookFactory.create(is);
//			Sheet sheet = wb.getSheet("人员清单");
//			if (!sheetName.trim().equals(""))
//			{
//				sheet = workbook.getSheet(sheetName); // 如果指定sheet名,则取指定sheet中的内容.
//			}
//			if (sheet == null)
//			{
//				sheet = workbook.getSheetAt(0); // 如果传入的sheet名不存在则默认指向第1个sheet.
//			}
            //根据excel里面的内容读取知识库信息
            return readExcelValue(book,order,adjustUser,newsAgency);
        }catch(Exception e){
            e.printStackTrace();
        } finally{
            if(is !=null)
            {
                try{
                    is.close();
                }catch(IOException e){
                    is = null;
                    e.printStackTrace();
                }
            }
        }
        return "导入出错！请检查数据格式！";
    }

    @Override
    public int updateSalesmanName(Order order) {
        return orderMapper.updateSalesmanName(order);
    }



    /**
     * 解析Excel里面的数据
     *
     * @param wb
     * @return
     */
    private String readExcelValue(Workbook wb, Order orders,AdjustUser adjustUser,NewsAgency newsAgency) {

        //错误信息接收器
        String errorMsg = "";
        //得到第一个shell
        Sheet sheet = wb.getSheetAt(0);
//		Sheet sheet = wb.getSheetAt(0);
        //得到Excel的行数
        int totalRows = sheet.getPhysicalNumberOfRows();
        //总列数
        int totalCells = 0;
        //得到Excel的列数(前提是有行数)，从第1行算起
        if (totalRows >= 1 && sheet.getRow(1) != null) {
            totalCells = sheet.getRow(1).getLastCellNum();
        }
        List<Order> userKnowledgeBaseList = new ArrayList<Order>();
        Order order;
        String orderid = "";
        String br = "<br/>";
//        AdjustUser adjustUser1;
        //业务员
        String strUser = "";
        String strName = "";
        String strTrim = "";
        List<User> userList = userMapper.selectUserStatusAll();
        for(User users : userList){
            strUser +=users.getUserName()+',';
        }
        String arrUser [] = strUser.split(",");

        //循环Excel行数,从第2行开始。标题不入库
        for (int r = 1; r < totalRows; r++) {
            String rowMessage = "";
            Row row = sheet.getRow(r);
            if (row == null) {
                errorMsg += br + "第" + (r + 1) + "行数据有问题，请仔细检查！";
                continue;
            }
            order = new Order();
            orderid = orders.getOrderId();
            order.setOrderId(orders.getOrderId());
            //  orderUser.setOrderType(orderPeoples.getOrderType());
            //循环Excel的列
            for (int c = 0; c < totalCells; c++) {
                Cell cell = row.getCell(c);
                if (null != cell) {
                    row.getCell(c).setCellType(Cell.CELL_TYPE_STRING);
//                    if (c == 0) {
//                        //订单号
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessage += "id不能为空；";
//                        } else if (cell.getStringCellValue().length() > 100) {
//                            rowMessage += "id的字数不能超过30；";
//                        }
//                        order.setId(Integer.valueOf(cell.getStringCellValue()));
//                    }else
                        if (c == 0) {
                        //订单号
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "订单号不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "订单号的字数不能超过30；";
                        }
                        order.setOrderId(cell.getStringCellValue());
                    } else if (c == 1) {
                        //调整前业务员
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "调整前业务员不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "调整前业务员的字数不能超过1000；";
                        }
                        order.setUserName(cell.getStringCellValue());
                    } else if (c ==2) {
                        //客户名称
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "客户名称不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "客户名称的字数不能超过1000；";
                        }
                        order.setCustomerName(cell.getStringCellValue());
                    } else if (c == 3) {
                        //生效日期
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "生效日期不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "生效日期的字数不能超过1000；";
                        }
                        order.setStartTime(cell.getStringCellValue());
                    } else if (c == 4) {
                        //失效日期
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "失效日期不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "失效日期的字数不能超过1000；";
                        }
                        order.setEndTime(cell.getStringCellValue());
                    }else if (c == 5) {
                        //缴费方式
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "缴费方式不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "缴费方式的字数不能超过1000；";
                        }
                        order.setPayMode(cell.getStringCellValue());
                    }else if (c == 6) {
                        //保险公司
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "保险公司不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "保险公司的字数不能超过1000；";
                        }
                        order.setInsureCompany(cell.getStringCellValue());
                    }else if (c == 7) {
                        //接收人
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "接收人不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "接收人的字数不能超过1000；";
                        } else if (!strUser.contains(cell.getStringCellValue())){
                            rowMessage += "业务员还没有添加；";
                        }
                        //设置业务员id
                        if(strUser.contains(cell.getStringCellValue())) {
                            for (int index = 0; index < arrUser.length; index++) {
                                if (arrUser[index].equals(cell.getStringCellValue())) {
                                    order.setSalesmanId(Math.toIntExact(userList.get(index).getUserId()));
                                }
                            }
                        }
                        order.setSalesmanName(cell.getStringCellValue());
                    }
//
                } else {
                    rowMessage += "第" + (c + 1) + "列数据有问题，请仔细检查；";
                }
            }
            //拼接每行的错误提示
            if (!StringUtils.isEmpty(rowMessage)) {
                errorMsg += br + "第" + (r + 1) + "行，" + rowMessage;
            } else {
                //从代办消息处处理批量上传的
//                NewsAgency newsAgency1 = newsAgencyMapper.selectNewsAgencyById1(Long.valueOf(newsAgency.getProposerId()));
//               AdjustUser adjustUser2= adjustMapper.selectAdjustUserByBuserId(Math.toIntExact(adjustUser.getBuserId()));
//                if(order.getSalesmanName()!=null || order.getSalesmanTrim().equals("")){
//                    order.setSalesmanTrim(order.getUserName()+newsAgency1.getApplicationDate()+"至"+order.getSalesmanName());
//                    strName+=order.getSalesmanName();
//                    strTrim+=order.getSalesmanTrim();
//                }
                //从调整业务员模块处，根据上传订单的信息插入到对应的业务员调整表
                AdjustUser adjustUser2= adjustMapper.selectAdjustUserByBuserId(Math.toIntExact(adjustUser.getBuserId()));
                if(order.getSalesmanName()!=null || order.getSalesmanName().equals("")){
                    order.setSalesmanTrim(order.getUserName()+adjustUser2.getAdjustDates()+"至"+order.getSalesmanName());
                    strName+=order.getSalesmanName();
                    strTrim+=order.getSalesmanTrim();
                }
                    adjustUser2.setAftUser(strName);
                    adjustUser2.setRemark(strTrim);
                    adjustMapper.updateAdjustUser(adjustUser2);
                    userKnowledgeBaseList.add(order);
            }
    }

        if (StringUtils.isEmpty(errorMsg)) {
            // this.deleteOrderPeopleByOrderId(orderid);
            for (Order userKnowledgeBase : userKnowledgeBaseList) {
                this.updateSalesmanName(userKnowledgeBase);
          }
            errorMsg = "导入成功，共" + userKnowledgeBaseList.size() + "条数据！";
      }
        return errorMsg;
    }
}
