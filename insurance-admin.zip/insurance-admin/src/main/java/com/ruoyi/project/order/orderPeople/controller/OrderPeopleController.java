package com.ruoyi.project.order.orderPeople.controller;

import java.util.List;

import com.ruoyi.common.utils.NewFileUploadUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.project.order.order.domain.Order;
import com.ruoyi.project.order.order.service.IOrderService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.project.order.orderPeople.domain.OrderPeople;
import com.ruoyi.project.order.orderPeople.service.IOrderPeopleService;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.framework.web.domain.AjaxResult;
import org.springframework.web.multipart.MultipartFile;

/**
 * 人员清单，关联订单， 信息操作处理
 * 
 * @author ruoyi
 * @date 2018-08-23
 */
@Controller
@RequestMapping("/order/orderPeople")
public class OrderPeopleController extends BaseController
{
    private String prefix = "order/orderPeople";
	
	@Autowired
	private IOrderPeopleService orderPeopleService;

	@Autowired
	private IOrderService orderService;
	
	@RequiresPermissions("order:orderPeople:view")
	@GetMapping()
	public String orderPeople()
	{
	    return prefix + "/orderPeople";
	}
	
	/**
	 * 查询人员清单，关联订单，列表
	 */
	@RequiresPermissions("order:orderPeople:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(OrderPeople orderPeople)
	{
		startPage();
        List<OrderPeople> list = orderPeopleService.selectOrderPeopleList(orderPeople);
		return getDataTable(list);
	}
	
	/**
	 * 新增人员清单，关联订单，
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存人员清单，关联订单，
	 */
	@RequiresPermissions("order:orderPeople:add")
	@Log(title = "人员清单，关联订单，", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(OrderPeople orderPeople)
	{		
		return toAjax(orderPeopleService.insertOrderPeople(orderPeople));
	}

	/**
	 * 新增人员清单，关联订单，
	 */
	@GetMapping("/excel/{id}")
	public String excel(@PathVariable("id") Integer id,ModelMap mmap)
	{
		Order order = orderService.selectOrderById(id);
		mmap.put("order", order);
		if(1==order.getCustomerSo()){
			mmap.put("orderId", order.getRenewId());//1续保
		}else{
			mmap.put("orderId", order.getOrderId());//0新保
		}
		return prefix + "/excel";
	}

	/**
	 * 导入人员清单数据
	 */
	@RequiresPermissions("order:orderPeople:excel")
	@PostMapping("/excelSave")
	@ResponseBody
	public AjaxResult excelSave(OrderPeople orderPeople,@RequestParam("uploadFile") MultipartFile file)
	{
		String message="";
		//判断文件是否为空
		if(file==null){
			message="文件不能为空！";
			return toAjaxMes(0,message);
		}

		//获取文件名
		String fileName=file.getOriginalFilename();

		//验证文件名是否合格
		if(!NewFileUploadUtils.validateExcel(fileName)){
			message="文件必须是excel格式！";
			return toAjaxMes(0,message);
		}

		//进一步判断文件内容是否为空（即判断其大小是否为0或其名称是否为null）
		long size=file.getSize();
		if(StringUtils.isEmpty(fileName) || size==0){
			message="文件不能为空！";
			return toAjaxMes(0,message);
		}

		//批量导入
		message = orderPeopleService.batchImport(orderPeople,file);

		if(message.contains("行")){
			return error(message);
		}else{
			return success(message);
		}
	}

	/**
	 * 修改人员清单，关联订单，
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		OrderPeople orderPeople = orderPeopleService.selectOrderPeopleById(id);
		mmap.put("orderPeople", orderPeople);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存人员清单，关联订单，
	 */
	@RequiresPermissions("order:orderPeople:edit")
	@Log(title = "人员清单，关联订单，", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(OrderPeople orderPeople)
	{		
		return toAjax(orderPeopleService.updateOrderPeople(orderPeople));
	}
	
	/**
	 * 删除人员清单，关联订单，
	 */
	@RequiresPermissions("order:orderPeople:remove")
	@Log(title = "人员清单，关联订单，", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(orderPeopleService.deleteOrderPeopleByIds(ids));
	}

	@Log(title = "人员清单", action = BusinessType.EXPORT)
	@PostMapping("/export")
	@ResponseBody
	public AjaxResult export(OrderPeople orderPeople) throws Exception
	{
		try
		{
			List<OrderPeople> list = orderPeopleService.selectOrderPeopleList(orderPeople);
			ExcelUtil<OrderPeople> util = new ExcelUtil<OrderPeople>(OrderPeople.class);
			return util.exportExcel(list, "orderPeople");
		}
		catch (Exception e)
		{
			return error("导出Excel失败，请联系网站管理员！");
		}
	}
	
}
