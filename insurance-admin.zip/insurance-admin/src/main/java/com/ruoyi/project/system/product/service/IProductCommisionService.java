package com.ruoyi.project.system.product.service;


import com.ruoyi.project.system.product.domain.CommisionBili;
import com.ruoyi.project.system.product.domain.Feilv;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;

/**
 * Created by x on 2018/8/7.
 * 产品信息 服务层
 */
public interface IProductCommisionService {

    public int insertCommisionBiliList(List<CommisionBili> commisionBili);

    public List<CommisionBili> selectCommisionBiliInfo(Long productId);

    public int updateCommisionBili(@Param("list") List<CommisionBili> commisionBili);




















}
