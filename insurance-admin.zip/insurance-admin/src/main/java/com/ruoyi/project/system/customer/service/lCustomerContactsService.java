package com.ruoyi.project.system.customer.service;


import com.ruoyi.project.system.customer.domain.CustomerContacts;

import java.util.List;

/**
 * Created by x on 2018/8/8.
 */

public interface lCustomerContactsService {
    /**
     * 查询联系人信息集合
     *
     * @param customercontacts 联系人信息
     * @return 联系人信息集合
     */
    public List<CustomerContacts> selectCustomerContactsList(CustomerContacts customercontacts);

    /**
     * 查询所有联系人
     *
     * @return 联系人列表
     */
    public List<CustomerContacts> selectCustomerContactsAll();

    /**
     * 通过id联系人信息
     * @param id
     * @return
     */
    public CustomerContacts selectCustomerContactsById(Long id);


    /**
     * 根据客户表id联系人信息
     * @param customerId 客户表id
     * @return 联系人集合信息
     */
    public List<CustomerContacts> selectCustomerContactsByCustomerId(int customerId);

    /**
     * 新增保存联系人信息
     *
     * @param customercontacts 联系人信息
     * @return 结果
     */
    public int insertCustomerContacts(CustomerContacts customercontacts);

    /**
     * 修改保存联系人信息
     *
     * @param customercontacts 联系人信息
     * @return 结果
     */
    public int updateCustomerContacts(CustomerContacts customercontacts);


    /**
     * 批量删除联系人信息
     *
     * @param ids 需要删除的数据ID
     */
    public int deleteCustomerContactsByIds(String ids) throws Exception;

}
