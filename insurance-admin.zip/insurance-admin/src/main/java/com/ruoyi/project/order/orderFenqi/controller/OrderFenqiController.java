package com.ruoyi.project.order.orderFenqi.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.project.order.orderFenqi.domain.OrderFenqi;
import com.ruoyi.project.order.orderFenqi.service.IOrderFenqiService;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.framework.web.domain.AjaxResult;

/**
 * 订单分期--关联计划id,--关联订单id--关联保全 信息操作处理
 * 
 * @author ruoyi
 * @date 2018-09-17
 */
@Controller
@RequestMapping("/order/orderFenqi")
public class OrderFenqiController extends BaseController
{
    private String prefix = "order/orderFenqi";
	
	@Autowired
	private IOrderFenqiService orderFenqiService;
	
	@RequiresPermissions("order:orderFenqi:view")
	@GetMapping()
	public String orderFenqi()
	{
	    return prefix + "/orderFenqi";
	}
	
	/**
	 * 查询订单分期--关联计划id,--关联订单id--关联保全列表
	 */
	@RequiresPermissions("order:orderFenqi:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(OrderFenqi orderFenqi)
	{
		startPage();
        List<OrderFenqi> list = orderFenqiService.selectOrderFenqiList(orderFenqi);
		return getDataTable(list);
	}
	
	/**
	 * 新增订单分期--关联计划id,--关联订单id--关联保全
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存订单分期--关联计划id,--关联订单id--关联保全
	 */
	@RequiresPermissions("order:orderFenqi:add")
	@Log(title = "订单分期--关联计划id,--关联订单id--关联保全", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(OrderFenqi orderFenqi)
	{		
		return toAjax(orderFenqiService.insertOrderFenqi(orderFenqi));
	}

	/**
	 * 修改订单分期--关联计划id,--关联订单id--关联保全
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		OrderFenqi orderFenqi = orderFenqiService.selectOrderFenqiById(id);
		mmap.put("orderFenqi", orderFenqi);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存订单分期--关联计划id,--关联订单id--关联保全
	 */
	@RequiresPermissions("order:orderFenqi:edit")
	@Log(title = "订单分期--关联计划id,--关联订单id--关联保全", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(OrderFenqi orderFenqi)
	{		
		return toAjax(orderFenqiService.updateOrderFenqi(orderFenqi));
	}
	
	/**
	 * 删除订单分期--关联计划id,--关联订单id--关联保全
	 */
	@RequiresPermissions("order:orderFenqi:remove")
	@Log(title = "订单分期--关联计划id,--关联订单id--关联保全", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(orderFenqiService.deleteOrderFenqiByIds(ids));
	}
	
}
