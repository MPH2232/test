package com.ruoyi.project.order.order.service;

import com.ruoyi.project.homepage.homepage.damain.Order1;
import com.ruoyi.project.order.order.domain.Order;
import com.ruoyi.project.order.orderPeople.domain.OrderPeople;
import com.ruoyi.project.order.orderproductPlan.domain.OrderProductPlan;
import org.springframework.web.multipart.MultipartFile;
import java.util.HashMap;
import java.util.List;

/**
 * 保险订单 服务层
 * 
 * @author ruoyi
 * @date 2018-08-13
 */
public interface IOrderService 
{
	/**
     * 查询保险订单信息
     * 
     * @param id 保险订单ID
     * @return 保险订单信息
     */
	public Order selectOrderById(Integer id);
	/**
	 * 查询保险订单信息
	 *
	 * @param renewId 保险子订单ID
	 * @return 保险订单信息
	 */
	public Order selectOrderByRenewId(String renewId);
	//1116
	public Order selectOrderByOrderId(String orderId);

	/**
     * 查询保险订单列表
     * 
     * @param order 保险订单信息
     * @return 保险订单集合
     */
	public List<Order> selectOrderList(Order order);
	
	/**
     * 新增保险订单
     * 
     * @param order 保险订单信息
     * @return 结果
     */
	public int insertOrder(Order order);
	
	/**
     * 修改保险订单
     * 
     * @param order 保险订单信息
     * @return 结果
     */
	public int updateOrder(Order order);

	/**
	 * 修改流程状态
	 *
	 * @param status 保险订单信息
	 * @return 结果
	 */
	public int updateOrderStatus(int orderid,int status);


	/**
     * 删除保险订单信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteOrderByIds(String ids);

	public int addOrder(HashMap<String,Object> map);

	public int renewalOrder(Order order);

	/*管理员*/
	public List<Order> selectOrderGlyList(int status);

	/*主管*/
	public List<Order> selectOrderZhuguanList(long deptId,long statu);
	/*总监*/
	public List<Order> selectOrderMajordomoList(long deptId,long stat);
	/**
	 * 业务员
	 */
	public List <Order> selectOrderYwyList( long userIdd,long statuss);

	/*主管包含其他查询条件*/
	public List<Order> selectOrderListZhu(Order order);
	/*总监包含其他查询条件*/
	public List<Order> selectOrderListZongjian(Order order);

	public String batchImport(Order order, OrderProductPlan orderProductPlan, OrderPeople orderPeople, MultipartFile mfile);

	public int insertOrderList(List<Order> orderList);

	//续保
	public String batchImport1(Order order,MultipartFile mfile);

	public int deleteOrderByPolicyNum(String policyNum);

	public Order selectOrderIdByPolicyNum(String policyNum);

	//调整业务员时修改接收人和描述
	public int updateSalesmanName(Order order);
	/**
	 * 查询保险订单列表
	 *
	 * @param order 保险订单信息
	 * @return 保险订单集合
	 */
	public List<Order> selectOrder(Order order);

}
