package com.ruoyi.project.order.uploadImage.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.order.uploadImage.mapper.UploadImageMapper;
import com.ruoyi.project.order.uploadImage.domain.UploadImage;
import com.ruoyi.project.order.uploadImage.service.IUploadImageService;
import com.ruoyi.common.support.Convert;

/**
 * 影像件管理 服务层实现
 * 
 * @author ruoyi
 * @date 2018-08-22
 */
@Service
public class UploadImageServiceImpl implements IUploadImageService 
{
	@Autowired
	private UploadImageMapper uploadImageMapper;

	/**
     * 查询影像件管理信息
     * 
     * @param id 影像件管理ID
     * @return 影像件管理信息
     */
    @Override
	public UploadImage selectUploadImageById(Integer id)
	{
	    return uploadImageMapper.selectUploadImageById(id);
	}

	/**
	 * 查询影像件管理信息
	 *
	 * @param id 影像件管理ID
	 * @return 影像件管理信息
	 */
	@Override
	public UploadImage selectUploadImageOrderId(String id,String shouye)
	{
		return uploadImageMapper.selectUploadImageOrderId(id,shouye);
	}

	/**
     * 查询影像件管理列表
     * 
     * @param uploadImage 影像件管理信息
     * @return 影像件管理集合
     */
	@Override
	public List<UploadImage> selectUploadImageList(UploadImage uploadImage)
	{
	    return uploadImageMapper.selectUploadImageList(uploadImage);
	}
	
    /**
     * 新增影像件管理
     * 
     * @param uploadImage 影像件管理信息
     * @return 结果
     */
	@Override
	public int insertUploadImage(UploadImage uploadImage)
	{
	    return uploadImageMapper.insertUploadImage(uploadImage);
	}
	
	/**
     * 修改影像件管理
     * 
     * @param uploadImage 影像件管理信息
     * @return 结果
     */
	@Override
	public int updateUploadImage(UploadImage uploadImage)
	{
	    return uploadImageMapper.updateUploadImage(uploadImage);
	}
	/**
	 * 修改影像件管理，只更新时间
	 *
	 * @param uploadImage 影像件管理信息
	 * @return 结果
	 */
	@Override
	public int updateUploadImageTime(UploadImage uploadImage)
	{
		return uploadImageMapper.updateUploadImageTime(uploadImage);
	}

	/**
     * 删除影像件管理对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteUploadImageByIds(String ids)
	{
		return uploadImageMapper.deleteUploadImageByIds(Convert.toStrArray(ids));
	}
	
}
