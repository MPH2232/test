package com.ruoyi.project.system.customer.service;

import com.ruoyi.common.support.Convert;
import com.ruoyi.common.utils.security.ShiroUtils;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.domain.CustomerAttention;
import com.ruoyi.project.system.customer.domain.CustomerContacts;
import com.ruoyi.project.system.customer.mapper.CustomerAttentionMapper;
import com.ruoyi.project.system.customer.mapper.CustomerContactsMapper;
import com.ruoyi.project.system.customer.mapper.CustomerMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by x on 2018/8/8.
 */
@Service
public class CustomerServicelmpl implements lCustomerService {

    @Autowired
    private CustomerMapper customerMapper;

    @Autowired
    private CustomerContactsMapper customerContactsMapper;

    @Autowired
    private CustomerAttentionMapper customerAttentionMapper;



    @Override
    public List<Customer> selectCustomerList(Customer customer) {
        return customerMapper.selectCustomerList(customer);
    }
    /*查询所有客户信息*/
    @Override
    public List<Customer> selectCustomerAll() {
        return customerMapper.selectCustomerAll();
    }

    /*查询下拉框所有客户*/
    @Override
    public List<Customer> selectCustomerAllOption(String type) {
        return customerMapper.selectCustomerAllOption(type);
    }

    /*新增客户信息*/
    @Override
    public int insertCustomer(Customer customer) {
        customer.setCustomerType("0");
        customer.setCreateBy(ShiroUtils.getLoginName());
        return customerMapper.insertCustomer(customer);
    }
    /*修改客户信息*/
    @Override
    public int updateCustomer(Customer customer) {
        customer.setUpdateBy(ShiroUtils.getLoginName());

        return customerMapper.updateCustomer(customer);
    }

    /*查询客户信息*/
    @Override
    public Customer selectCustomerById(long id) {
        return customerMapper.selectCustomerById(id);
    }

    /*删除客户信息*/
    @Override
    public int deleteCustomerByIds(String ids) throws Exception {
           Long[] customerIds = Convert.toLongArray(ids);
        for (Long id : customerIds)
    {
        Customer customer = selectCustomerById(id);
    }
        return customerMapper.deleteCustomerByIds(customerIds);
}

    /**
     * 查询联系人信息
     * @param customerId
     * @return
     */
    @Override
    public List<CustomerContacts> selectCustomerContactsListInfo(int customerId) {
        return customerContactsMapper.selectCustomerContactsListInfo(customerId);
    }

    /**
     * 查询收件人信息
     * @param customerId
     * @return
     */
    @Override
    public List<CustomerAttention> selectCustomerAttentionListInfo(int customerId) {
        return customerAttentionMapper.selectCustomerAttentionListInfo(customerId);
    }

    @Override
    public List<Customer> selectCustomersAll() {
        return customerMapper.selectCustomersAll();
    }


    /**
     * 总监
     */
    @Override
    public List<Customer> selectCustomerListMajordomo(long deptId, Customer customer) {
        return customerMapper.selectCustomerListMajordomo(deptId,customer);
    }

    /**
     * 主管
     */
    @Override
    public List<Customer> selectCustomerListCharge(long deptId, Customer customer) {
        return customerMapper.selectCustomerListCharge(deptId,customer);
    }

    /**
     * 业务员
     */
    @Override
    public List<Customer> selectCustomerListSalesman(long userIdd, Customer customer) {
        return customerMapper.selectCustomerListSalesman(userIdd,customer);
    }

}

