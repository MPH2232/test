package com.ruoyi.project.homepage.homepage.damain;

/**
 * Created by x on 2018/9/17.
 */
public class NewsAgency {
    private Long id;
    /*接收人id*/
    private Integer sendeeId;
    /*接收人姓名*/
    private String sendeeName;
    /*申请人id*/
    private Integer proposerId;
    /*申请人姓名*/
    private String proposerName;
    /*部门id*/
    private Long deptId;
    /*部门名称*/
    private String deptName;
    /*团队*/
    private Long teamId;
    /*团队名称*/
    private String teamName;
    /*申请日期*/
    private String applicationDate;
    /*消息内容*/
    private String messageContent;
    /*更新时间*/
    private String updateTime;
    /*待办类型*/
    private String agentType;
    /*职级*/
    private String roleName;
    /*手机号*/
    private String phoneNum;
    /*备注*/
    private String remark;
    /*待办状态*/
    private String status;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getSendeeId() {
        return sendeeId;
    }

    public void setSendeeId(Integer sendeeId) {
        this.sendeeId = sendeeId;
    }

    public Integer getProposerId() {
        return proposerId;
    }

    public void setProposerId(Integer proposerId) {
        this.proposerId = proposerId;
    }

    public String getSendeeName() {
        return sendeeName;
    }

    public void setSendeeName(String sendeeName) {
        this.sendeeName = sendeeName;
    }


    public String getProposerName() {
        return proposerName;
    }

    public void setProposerName(String proposerName) {
        this.proposerName = proposerName;
    }

    public Long getTeamId() {
        return teamId;
    }

    public void setTeamId(Long teamId) {
        this.teamId = teamId;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public Long getDeptId() {
        return deptId;
    }

    public void setDeptId(Long deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getApplicationDate() {
        return applicationDate;
    }

    public void setApplicationDate(String applicationDate) {
        this.applicationDate = applicationDate;
    }

    public String getMessageContent() {
        return messageContent;
    }

    public void setMessageContent(String messageContent) {
        this.messageContent = messageContent;
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime;
    }

    public String getAgentType() {
        return agentType;
    }

    public void setAgentType(String agentType) {
        this.agentType = agentType;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    @Override
    public String toString() {
        return "NewsAgency{" +
                "id=" + id +
                ", sendeeId=" + sendeeId +
                ", sendeeName='" + sendeeName + '\'' +
                ", proposerId=" + proposerId +
                ", proposerName='" + proposerName + '\'' +
                ", deptName='" + deptName + '\'' +
                ", applicationDate='" + applicationDate + '\'' +
                ", messageContent='" + messageContent + '\'' +
                ", updateTime='" + updateTime + '\'' +
                ", agentType='" + agentType + '\'' +
                ", remark='" + remark + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
