package com.ruoyi.project.order.order.service;

import java.util.HashMap;
import java.util.List;
import java.io.IOException;
import java.io.InputStream;
import com.ruoyi.common.utils.NewFileUploadUtils;
import com.ruoyi.common.utils.PublicUtils;
import com.ruoyi.common.utils.poi.*;
import com.ruoyi.project.order.orderPeople.domain.OrderPeople;
import com.ruoyi.project.order.orderproductPlan.domain.OrderProductPlan;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.project.homepage.homepage.damain.Order1;
import com.ruoyi.project.system.channel.domain.Channel;
import com.ruoyi.project.system.channel.mapper.ChannelMapper;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.mapper.CustomerMapper;
import com.ruoyi.project.system.supplier1.domain.Supplier;
import com.ruoyi.project.system.supplier1.mapper.Supplier1Mapper;
import com.ruoyi.project.system.user.domain.User;
import com.ruoyi.project.system.user.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.order.order.mapper.OrderMapper;
import com.ruoyi.project.order.order.domain.Order;
import com.ruoyi.project.order.order.service.IOrderService;
import com.ruoyi.common.support.Convert;

/**
 * 保险订单 服务层实现
 * 
 * @author ruoyi
 * @date 2018-08-13
 */
@Service
public class OrderServiceImpl implements IOrderService 
{
	@Autowired
	private OrderMapper orderMapper;

	@Autowired
	private Supplier1Mapper supplier1Mapper;

	@Autowired
	private UserMapper userMapper;

	@Autowired
	private CustomerMapper customerMapper;

	@Autowired
	private ChannelMapper channelMapper;
	/**
     * 查询保险订单信息
     * 
     * @param id 保险订单ID
     * @return 保险订单信息
     */
    @Override
	public Order selectOrderById(Integer id)
	{
	    return orderMapper.selectOrderById(id);
	}

	@Override
	public Order selectOrderByRenewId(String id)
	{
		return orderMapper.selectOrderByRenewId(id);
	}

	/**
     * 查询保险订单列表
     * 
     * @param order 保险订单信息
     * @return 保险订单集合
     */
	@Override
	public List<Order> selectOrderList(Order order)
	{
	    return orderMapper.selectOrderList(order);
	}
	
    /**
     * 新增保险订单
     * 
     * @param order 保险订单信息
     * @return 结果
     */
	@Override
	public int insertOrder(Order order)
	{
		Supplier supplier=supplier1Mapper.selectSupplierById(Long.parseLong(order.getInsureId().toString()));
		order.setInsureCompany(supplier.getSupplierName());
		order.setOrderId(DateUtils.dateTimeSSS()+ PublicUtils.getRandom());

		User user=userMapper.selectUserById(Long.parseLong(order.getUserId().toString()));
		order.setUserName(user.getUserName());

		Customer customer=customerMapper.selectCustomerById(Long.parseLong(order.getCustomerId().toString()));
		order.setCustomerName(customer.getCustomerName());
		if(order.getCustomerSo()==2){
			//选择渠道
			Channel channel=channelMapper.selectChannelById(Long.parseLong(order.getChannelId().toString()));
			order.setChannelName(channel.getChannelName());
		}
	    return orderMapper.insertOrder(order);
	}
	
	/**
     * 修改保险订单
     * 
     * @param order 保险订单信息
     * @return 结果
     */
	@Override
	public int updateOrder(Order order)
	{
	    return orderMapper.updateOrder(order);
	}

	/**
	 * 修改流程状态
	 *
	 * @param order 保险订单信息
	 * @return 结果
	 */
	@Override
	public int updateOrderStatus(int orderid,int order)
	{
		return orderMapper.updateOrderStatus(orderid,order);
	}



	/**
     * 删除保险订单对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteOrderByIds(String ids)
	{
		return orderMapper.deleteOrderByIds(Convert.toStrArray(ids));
	}

	@Override
	public int addOrder(HashMap<String, Object> map) {
		return orderMapper.addOrder(map);
	}

	@Override
	public int renewalOrder(Order order) {
		order.setRenewId(DateUtils.dateTimeSSS()+PublicUtils.getRandom());
		order.setCustomerSo(1);
		order.setStatus(0);
		return orderMapper.insertOrder(order);
	}

	/*管理员*/
	@Override
	public List<Order> selectOrderGlyList(int status) {
		return orderMapper.selectOrderListInfoAdmin(status);
	}
   /*主管*/
	@Override
	public List<Order> selectOrderZhuguanList(long deptId, long statu) {
		return orderMapper.selectOrderListInfozhu(deptId,statu);
	}
	/*总监*/
	@Override
	public List<Order> selectOrderMajordomoList(long deptId, long stat) {
		return orderMapper.selectOrderListInfoMajordomo(deptId,stat);
	}
	/*业务员*/
	@Override
	public List<Order> selectOrderYwyList(long userIdd, long statuss) {
		return orderMapper.selectOrderListInfoye(userIdd,statuss);
	}

	/*主管包含其他查询条件*/
	@Override
	public List<Order> selectOrderListZhu(Order order) {
		return orderMapper.selectOrderListZhu(order);
	}
	/*总监包含其他查询条件*/
	@Override
	public List<Order> selectOrderListZongjian(Order order) {
		return orderMapper.selectOrderListZongjian(order);
	}

	@Override
	public String batchImport(Order order, OrderProductPlan orderProductPlan, OrderPeople orderPeople, MultipartFile mfile) {
		//获取Excel的名字
		String fileName = mfile.getOriginalFilename();
		//初始化输入流
		String msg="";
		InputStream is = null;
		try{
			is = mfile.getInputStream();
			Workbook book = null;
			if(NewFileUploadUtils.isExcel2003(mfile.getOriginalFilename())){
				book = new HSSFWorkbook(is);
			}else{
				book = new XSSFWorkbook(is);
			}
			if(fileName.contains("中意")){
				BatchZhongYiOrderUtil batchZhongYiOrderUtil = new BatchZhongYiOrderUtil();
				msg = batchZhongYiOrderUtil.readExcel(book,order,orderProductPlan,orderPeople);
			}else if(fileName.contains("平安健康")){
				BatchPingAnJianKangOrderUtil batchPingAnJianKangOrderUtil = new BatchPingAnJianKangOrderUtil();
				msg = batchPingAnJianKangOrderUtil.readExcel(book,order,orderProductPlan,orderPeople);
			}else if(fileName.contains("利宝")){
				BatchLiBaoOrderUtil batchLiBaoOrderUtil = new BatchLiBaoOrderUtil();
				msg = batchLiBaoOrderUtil.readExcel(book,order,orderProductPlan,orderPeople);
			}else if(fileName.contains("大地")){
				BatchDaDiOrderUtil batchDaDiOrderUtil = new BatchDaDiOrderUtil();
				msg = batchDaDiOrderUtil.readExcel(book,order,orderProductPlan,orderPeople);
			}
			//根据excel里面的内容读取知识库信息
//			ExcelOrderAgainUtil excelOrderAgainUtil = new ExcelOrderAgainUtil();
//			msg = excelOrderAgainUtil.readExcel(book,order,orderProductPlan,orderPeople);
		}catch(Exception e){
			e.printStackTrace();
		} finally{
			if(is !=null)
			{
				try{
					is.close();
				}catch(IOException e){
					is = null;
					e.printStackTrace();
				}
			}
		}
		return msg;
	}

	@Override
	public int insertOrderList(List<Order> orderList) {
		return orderMapper.insertOrderList(orderList);
	}

	@Override
	public int deleteOrderByPolicyNum(String policyNum) {
		return orderMapper.deleteOrderByPolicyNum(policyNum);
	}

	@Override
	public Order selectOrderIdByPolicyNum(String policyNum) {
		return orderMapper.selectOrderIdByPolicyNum(policyNum);
	}

	//调整业务员时修改接收人和描述
	@Override
	public int updateSalesmanName(Order order) {
		return orderMapper.updateSalesmanName(order);
	}

	@Override
	public List<Order> selectOrder(Order order) {
		return orderMapper.selectOrder(order);
	}

	@Override
	public Order selectOrderByOrderId(String orderId) {
		return orderMapper.selectOrderByOrderId(orderId);
	}

	//续保
	@Override
	public String batchImport1(Order order, MultipartFile mfile) {
		//获取Excel的名字
		String fileName = mfile.getOriginalFilename();
		//初始化输入流
		String msg="";
		InputStream is = null;
		try{
			is = mfile.getInputStream();
			Workbook book = null;
			if(NewFileUploadUtils.isExcel2003(mfile.getOriginalFilename())){
				book = new HSSFWorkbook(is);
			}else{
				book = new XSSFWorkbook(is);
			}
			//根据excel里面的内容读取知识库信息
			ExcelOrderRenewalUtil excelOrderRenewalUtil = new ExcelOrderRenewalUtil();
			msg = excelOrderRenewalUtil.readExcel(book,order);
		}catch(Exception e){
			e.printStackTrace();
		} finally{
			if(is !=null)
			{
				try{
					is.close();
				}catch(IOException e){
					is = null;
					e.printStackTrace();
				}
			}
		}
		return msg;
	}
}
