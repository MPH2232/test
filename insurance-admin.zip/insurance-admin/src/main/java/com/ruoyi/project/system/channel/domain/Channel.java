package com.ruoyi.project.system.channel.domain;


import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;


import java.util.Date;

/**
 * 渠道对象 f_channel
 * 
 * @author ruoyi
 */
public class Channel extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 渠道 */
//    @Excel(name = "渠道")
    private Long channelId;

    /** 渠道序号 */
    @Excel(name = "渠道名称")
    private String channelName;
    /** 业务员Id */
//    @Excel(name = "渠道")
    private Long userId;

    /** 业务员名称 */
    @Excel(name = "业务员")
    private String userName;
    /** 渠道编码 */
//    @Excel(name = "渠道编码")
//    private String channelNum;

    /** 合作协议 */
//    @Excel(name = "合作协议")
    private String protocol;

    /** 合作协议 */
//    @Excel(name = "linux上传路径")
    private String linuxPath;

    /** 渠道分成比例 */
    @Excel(name = "渠道分成比例")
    private String fenBiLi;

    /** 渠道日期*/
//    @Excel(name = "渠道日期")
    private String channelDate;

    /** 合作协议到期日期 */
    @Excel(name = "合作协议到期日期")
    private String protocolDate;

    /** 状态（0正常 1停用） */
    @Excel(name = "状态")
    private String status;

    /** 数据 */
    private int countData;

    public Long getChannelId() {
        return channelId;
    }

    public void setChannelId(Long channelId) {
        this.channelId = channelId;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

//    public String getChannelNum() {
//        return channelNum;
//    }
//
//    public void setChannelNum(String channelNum) {
//        this.channelNum = channelNum;
//    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public String getFenBiLi() {
        return fenBiLi;
    }

    public void setFenBiLi(String fenBiLi) {
        this.fenBiLi = fenBiLi;
    }

    public String getChannelDate() {
        return channelDate;
    }

    public void setChannelDate(String channelDate) {
        this.channelDate = channelDate;
    }

    public String getProtocolDate() {
        return protocolDate;
    }

    public void setProtocolDate(String protocolDate) {
        this.protocolDate = protocolDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getCountData() {
        return countData;
    }

    public void setCountData(int countData) {
        this.countData = countData;
    }

    public String getLinuxPath() {
        return linuxPath;
    }

    public void setLinuxPath(String linuxPath) {
        this.linuxPath = linuxPath;
    }

    @Override
    public String toString() {
        return "Channel{" +
                "channelId=" + channelId +
                ", channelName='" + channelName + '\'' +
//                ", channelNum='" + channelNum + '\'' +
                ", protocol='" + protocol + '\'' +
                ", fenBiLi='" + fenBiLi + '\'' +
                ", channelDate=" + channelDate +
                ", status='" + status + '\'' +
                ", protocolDate='" + protocolDate + '\'' +
                '}';
    }
}
