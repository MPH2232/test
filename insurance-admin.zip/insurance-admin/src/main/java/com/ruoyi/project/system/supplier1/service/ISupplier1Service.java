package com.ruoyi.project.system.supplier1.service;

import com.ruoyi.project.system.supplier1.domain.Supplier;



import java.util.List;

/**
 * 字典 业务层
 * 
 * @author ruoyi
 */
public interface ISupplier1Service
{
    /**
     * 查询供应商信息集合
     *
     * @param supplier 供应商信息
     * @return 供应商信息集合
     */
    public List<Supplier> selectSupplierList(Supplier supplier);
    /**
     * 查询所有供应商
     *
     * @return 供应商列表
     */
    public List<Supplier> selectSupplierAll();
    /**
     * 通过供应商ID查询供应商信息
     *
     * @param supplierId 供应商ID
     * @return 角色对象信息
     */
    public Supplier selectSupplierById(Long supplierId);

    /**
     * 批量删除供应商信息
     *
     * @param ids 需要删除的数据ID
     */
    public int deleteSupplierByIds(String ids) throws Exception;

    /**
     * 新增保存字典类型信息
     *
     * @param supplier 供应商信息
     * @return 结果
     */
    public int insertSupplier(Supplier supplier);
    /**
     * 修改保存供应商信息
     *
     * @param supplier 供应商信息
     * @return 结果
     */
    public int updateSupplier(Supplier supplier);

    /**
     * 修改供应商状态
     * @param supplier
     * @return
     */
    public int updateSupplierStatus(Supplier supplier);


    /**
     * 校验供应商名称是否唯一
     *
     * @return 结果
     */
    public String checkSupplierNameUnique(Supplier supplier);

    public Supplier selectPaytaxesBankBysupplierName(String supplierName);
}
