package com.ruoyi.project.system.supplier1.controller;

import com.ruoyi.common.utils.BankUtil;
import com.ruoyi.common.utils.DeleteFile;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.project.system.supplier1.domain.Protocol;
import com.ruoyi.project.system.supplier1.domain.Supplier;
import com.ruoyi.project.system.supplier1.service.IProtocolService;
import com.ruoyi.project.system.supplier1.service.ISupplier1Service;
import com.xiaoleilu.hutool.http.HttpUtil;
import com.xiaoleilu.hutool.json.JSONObject;
import com.xiaoleilu.hutool.util.ReUtil;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 供应商信息
 * 
 * @author ruoyi
 */
@Controller
@RequestMapping("/system/supplier1")
public class Supplier1Controller extends BaseController
{
    private String prefix = "system/supplier1/sup";

    @RequiresPermissions("system:supplier1:view")
    @GetMapping()
    public String dictType()
    {
        return prefix + "/sup";
    }

    @Autowired
    private ISupplier1Service supplier1Service;

    @Autowired
    private IProtocolService protocolService;

    @PostMapping("/list")
    @RequiresPermissions("system:supplier1:list")
    @ResponseBody
    public TableDataInfo list(Supplier supplier)
    {
        startPage();
        List<Supplier> list = supplier1Service.selectSupplierList(supplier);
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        for (Supplier supplier1:list){
            Protocol protocol=protocolService.selectProtocolDateBySuprotocolIds(supplier1.getProtocolId());
            if(protocol!=null){
                if (((protocol.getProtocolTime())).before(date)){
                    System.out.print("停用");
                    supplier1.setStatus("1");
                }else{
                    System.out.print("正常");
                    supplier1.setStatus("0");
                }
                supplier1Service.updateSupplierStatus(supplier1);
            }
        }
        return getDataTable(list);
    }


    @Log(title = "供应商", action = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Supplier supplier) throws Exception
    {
        try
        {
            List<Supplier> list = supplier1Service.selectSupplierList(supplier);
            ExcelUtil<Supplier> util = new ExcelUtil<Supplier>(Supplier.class);
            return util.exportExcel(list, "supplier");
        }
        catch (Exception e)
        {
            return error("导出Excel失败，请联系网站管理员！");
        }
    }

    /**
     * 新增供应商
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存供应商
     */
    @Log(title = "供应商", action = BusinessType.INSERT)
    @RequiresPermissions("system:supplier1:add")
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Supplier supplier)
    {
        return toAjax(supplier1Service.insertSupplier(supplier));
    }


    /**
     * 修改供应商
     */
    @GetMapping("/edit/{supplierId}")
    public String edit(@PathVariable("supplierId") Long supplierId, ModelMap mmap)
    {
        mmap.put("supplier", supplier1Service.selectSupplierById(supplierId));
        return prefix + "/edit";
    }

    /**
     * 修改保存字典类型
     */
    @Log(title = "供应商", action = BusinessType.UPDATE)
    @RequiresPermissions("system:supplier1:edit")
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Supplier supplier)
    {
        return toAjax(supplier1Service.updateSupplier(supplier));
    }


    @Log(title = "供应商", action = BusinessType.DELETE)
    @RequiresPermissions("system:supplier1:remove")
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        String[] array = ids.split(",");
        for (String arr : array) {
            //通过供应商ids查询得到关联字段protocolId=suprotocolIds
            String suprotocolIds = supplier1Service.selectSupplierById(Long.valueOf(arr)).getProtocolId();
            //根据suprotocolIds拿到protocols实体的List
            List<Protocol> protocols = protocolService.selectProtocolListBySuprotocolIds(suprotocolIds);
            //循环取到protocol
            for (Protocol protocol : protocols) {
                //取到协议对应的路径
                String path = protocol.getProtocolFile();
                //如果协议的路径不是空
                if (path != null) {
                    //删除文件夹及中的文件
                    DeleteFile.delAllFile(path);
                    DeleteFile.delFolder(path);
                }
            }
            //如果对应的协议不是空
            if (suprotocolIds != null) {
                //根据suprotocolIds删除对应的协议
                protocolService.deleteProtocolBySuprotocolIds(suprotocolIds);
            }
        }
        try {
            return toAjax(supplier1Service.deleteSupplierByIds(ids));
        } catch (Exception e) {
            return error(e.getMessage());
        }
    }

    /**
     * 查询供应商详细
     */
    @GetMapping("/detail/{supplierId}")
    public String detail(@PathVariable("supplierId") Long supplierId, ModelMap mmap)
    {
        mmap.put("supplier", supplier1Service.selectSupplierById(supplierId));
        mmap.put("supplierList",supplier1Service.selectSupplierAll());
        return "system/protocol/protocol";
    }

    /**
     * 查看供应商
     */
    @GetMapping("/look/{supplierId}")
    public String look(@PathVariable("supplierId") Long supplierId, ModelMap mmap)
    {
        mmap.put("supplier",supplier1Service.selectSupplierById(supplierId));
        return prefix + "/look";
    }
    /**
     * 校验供应商名称
     */
    @PostMapping("/checkSupplierNameUnique")
    @ResponseBody
    public String checkSupplierNameUnique(Supplier supplier)
    {
        String uniqueFlag = "0";
        if (supplier != null)
        {
            uniqueFlag = supplier1Service.checkSupplierNameUnique(supplier);
        }
        return uniqueFlag;
    }

    /**
     * 根据银行卡号查开户行
     */
    @PostMapping("/findPaytaxesBank")
    @ResponseBody
    public String findPaytaxesBank(Supplier supplier){
        String title=BankUtil.getNameOfBank(supplier.getPaytaxesNumber());
        if(title==""){
            try{
                //获取到银行卡号
                String bankNo=supplier.getPaytaxesNumber();
                //银行代码请求接口 url
                String url = "https://ccdcapi.alipay.com/validateAndCacheCardInfo.json?_input_charset=utf-8&cardNo="+bankNo+"&cardBinCheck=true";
                //发送请求，得到 josn 类型的字符串
                String result = HttpUtil.get(url);
                // 转为 Json 对象
                JSONObject json = new JSONObject(result);
                //获取到 bank 代码
                String bank = String.valueOf(json.get("bank"));
                //爬取支付宝银行合作商页面
                String listContent = HttpUtil.get("http://ab.alipay.com/i/yinhang.htm","gb2312");
                //过滤得到需要的银行名称
                List<String> titles = ReUtil.findAll("<span title=\"(.*?)\" class=\"icon "+bank+"\">(.*?)</span>", listContent, 2);
                for (String title1 : titles) {
                    //打印银行名称
                    System.out.print(title1);
                    title=title1;
                }
            }catch(Exception e){
                return title;
            }
        }
        return title;
    }

    @PostMapping("/findPremiumBank")
    @ResponseBody
    public String findPremiumBank(Supplier supplier){
        String title=BankUtil.getNameOfBank(supplier.getPremiumNumber());
        if(title==""){
            try{
                //获取到银行卡号
                String bankNo=supplier.getPaytaxesNumber();
                //银行代码请求接口 url
                String url = "https://ccdcapi.alipay.com/validateAndCacheCardInfo.json?_input_charset=utf-8&cardNo="+bankNo+"&cardBinCheck=true";
                //发送请求，得到 josn 类型的字符串
                String result = HttpUtil.get(url);
                // 转为 Json 对象
                JSONObject json = new JSONObject(result);
                //获取到 bank 代码
                String bank = String.valueOf(json.get("bank"));
                //爬取支付宝银行合作商页面
                String listContent = HttpUtil.get("http://ab.alipay.com/i/yinhang.htm","gb2312");
                //过滤得到需要的银行名称
                List<String> titles = ReUtil.findAll("<span title=\"(.*?)\" class=\"icon "+bank+"\">(.*?)</span>", listContent, 2);
                for (String title1 : titles) {
                    //打印银行名称
                    System.out.print(title1);
                    title=title1;
                }
            }catch(Exception e){
                return title;
            }
        }
        return title;
    }
}
