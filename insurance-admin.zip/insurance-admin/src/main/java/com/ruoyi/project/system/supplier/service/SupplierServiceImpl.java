package com.ruoyi.project.system.supplier.service;

import com.ruoyi.common.support.Convert;
import com.ruoyi.common.utils.security.ShiroUtils;
import com.ruoyi.project.system.supplier1.domain.Protocol;
import com.ruoyi.project.system.supplier1.domain.Supplier;
import com.ruoyi.project.system.supplier.mapper.ProtocolMapper;
import com.ruoyi.project.system.supplier.mapper.SupplierMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * 岗位信息 服务层处理
 * 
 * @author ruoyi
 */
@Service
public class SupplierServiceImpl implements ISupplierService
{
    @Autowired
    private SupplierMapper supplierMapper;

    @Autowired
    private ProtocolMapper protocolMapper;

    /**
     * 查询供应商信息集合
     * 
     * @param supplier 供应商信息
     * @return 供应商信息集合
     */
    @Override
    public List<Supplier> selectSupplierList(Supplier supplier)
    {
        return supplierMapper.selectSupplierList(supplier);
    }

    /**
     * 查询所有供应商
     * 
     * @return 供应商列表
     */
    @Override
    public List<Supplier> selectSupplierAll()
    {
        return supplierMapper.selectSupplierAll();
    }

    /**
     * 下拉框使用值
     * @return 供应商列表
     */
    @Override
    public List<Supplier> selectSupplierAllOption()
    {
        return supplierMapper.selectSupplierAllOption();
    }




    /**
     * 根据用户ID查询岗位
     * 
     * @param userId 用户ID
     * @return 岗位列表
     */
    /*@Override
    public List<Post> selectPostsByUserId(Long userId)
    {
        List<Post> userPosts = supplierMapper.selectPostsByUserId(userId);
        List<Post> posts = supplierMapper.selectPostAll();
        for (Post post : posts)
        {
            for (Post userRole : userPosts)
            {
                if (post.getPostId() == userRole.getPostId())
                {
                    post.setFlag(true);
                    break;
                }
            }
        }
        return posts;
    }*/

    /**
     * 通过供应商ID查询供应商信息
     * 
     * @param supplierId 供应商ID
     * @return 角色对象信息
     */
    @Override
    public Supplier selectSupplierById(Long supplierId)
    {
        return supplierMapper.selectSupplierById(supplierId);
    }

    /**
     * 批量删除供应商信息
     * 
     * @param ids 需要删除的数据ID
     * @throws Exception
     */
    @Override
    public int deleteSupplierByIds(String ids) throws Exception
    {
        Long[] supplierIds = Convert.toLongArray(ids);
        /*for (Long supplierId : supplierIds)
        {
            Supplier1 supplier = selectSupplierById(supplierId);
            if (countUserSupplierById(supplierId) > 0)
            {
                throw new Exception(String.format("%1$s已分配,不能删除", supplier.getSupplierName()));
            }
        }*/
        return supplierMapper.deleteSupplierByIds(supplierIds);
    }


    /**
     * 新增保存供应商信息
     *
     * @param supplier 供应商信息
     * @return 结果
     */
   /* @Override
    @Transactional
    public int insertSupplier(Supplier1 supplier,Protocol1 protocol)
    {
        supplier.setCreateBy(ShiroUtils.getLoginName());
        Date date=new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        List<Protocol1> protocols=new ArrayList<Protocol1>();
        supplier.setProtocolId(sdf.format(date));
        protocols.get(0).setSuprotocolId(sdf.format(date));
        protocols.get(1).setSuprotocolId(sdf.format(date));
        protocolMapper.insertProtocolList(protocols);
        return supplierMapper.insertSupplier(supplier);
    }*/

    /**
     * 新增保存供应商信息
     *
     * @param supplier 供应商信息
     * @return 结果
     */
    @Override
    @Transactional
    public int insertProtocolList(Supplier supplier, List<Protocol> protocol)
    {
        supplier.setCreateBy(ShiroUtils.getLoginName());
        Date date=new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        supplier.setProtocolId(sdf.format(date));
        for(int i=0;i<protocol.size();i++){
            protocol.get(i).setSuprotocolId(sdf.format(date));
        }
//        protocol.get(0).setSuprotocolId(sdf.format(date));
//        protocol.get(1).setSuprotocolId(sdf.format(date));
        protocolMapper.insertProtocolList(protocol);
        return supplierMapper.insertSupplier(supplier);
    }
    /**
     * 新增保存供应商信息
     *
     */
    @Override
    public List<Protocol> selectProtocolList(String protocolId){
        return protocolMapper.selectProtocolList(protocolId);
    }
    /**
     * 修改保存供应商信息
     * 
     * @param supplier 供应商信息
     * @return 结果
     */
    @Override
    public int updateSupplier(Supplier supplier)
    {
        supplier.setUpdateBy(ShiroUtils.getLoginName());
        return supplierMapper.updateSupplier(supplier);
    }



}
