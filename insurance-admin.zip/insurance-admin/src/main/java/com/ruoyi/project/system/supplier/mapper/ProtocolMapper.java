package com.ruoyi.project.system.supplier.mapper;
import com.ruoyi.project.system.supplier1.domain.Protocol;

import java.util.List;

/**
 * 协议信息 数据层
 * 
 * @author ruoyi
 */
public interface ProtocolMapper
{

    /**
     * 查询所有协议
     * 
     * @return 协议列表
     */
    public List<Protocol> selectProtocolAll();

    /**
     * 根据用户ID查询协议
     * 
     * @param userId 用户ID
     * @return 协议列表
     */
   // public List<Supplier1> selectSuppliersByUserId(Long userId);

    /**
     * 通过协议ID查询协议信息
     * 
     * @param protocolId 协议ID
     * @return 角色对象信息
     */
    public Protocol selectProtocolById(Long protocolId);

    /**
     * 批量删除协议信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteProtocolByIds(Long[] ids);

    /**
     * 修改协议信息
     * 
     * @param protocol 协议信息
     * @return 结果
     */
    public int updateProtocol(Protocol protocol);

    /**
     * 新增协议信息
     * 
     * @param protocol 协议信息
     * @return 结果
     */
    public int insertProtocol(Protocol protocol);

    /**
     * 新增协议信息插入集合list
     *
     * @param protocol 协议信息
     * @return 结果
     */
    public int insertProtocolList(List<Protocol> protocol);
    /**
     * 查询协议数据集合
     *
     * @param protocolId 协议信息
     * @return 协议数据集合
     */
    public List<Protocol> selectProtocolList(String protocolId);

}
