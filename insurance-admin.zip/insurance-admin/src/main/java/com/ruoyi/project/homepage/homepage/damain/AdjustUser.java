package com.ruoyi.project.homepage.homepage.damain;
import java.util.Date;

/**
 * Created by x on 2018/9/18.
 */
public class AdjustUser {
    private static final long serialVersionUID = 1L;
    /** id */
    private Long Id;

    /** 调整后业务员id*/
    private Long auserId;

    /** 调整后业务员*/
    private String aftUser;

    /**  调整前业务员id*/
    private Long buserId;

    /** 调整前业务员 */
    private String befUser;

    /** 离职日期 */
    private String adjustDate;

    /** 操作人 */
    private String operator;

    /** 备注 */
    private String remark;

    /** 部门id */
    private Long deptId;

    /** 部门id */
    private Long parentId;

    /** 部门名称 */
    private String deptName;

    /** 调整状态*/
    private String adjustStatus;

    /** 手机号码*/
    private String phoneNum;

    /** 职级名称*/
    private String postName;

    /** 团队*/
    private Long teamId;

    /** 调整状态*/
    private String teamName;

    /** 离职日期 */
    private String adjustDates;

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public String getAftUser() {
        return aftUser;
    }

    public void setAftUser(String aftUser) {
        this.aftUser = aftUser;
    }

    public String getBefUser() {
        return befUser;
    }

    public void setBefUser(String befUser) {
        this.befUser = befUser;
    }

    public String getAdjustDate() {
        return adjustDate;
    }

    public void setAdjustDate(String adjustDate) {
        this.adjustDate = adjustDate;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public Long getAuserId() {
        return auserId;
    }

    public void setAuserId(Long auserId) {
        this.auserId = auserId;
    }

    public Long getBuserId() {
        return buserId;
    }

    public void setBuserId(Long buserId) {
        this.buserId = buserId;
    }

    public Long getDeptId() {
        return deptId;
    }

    public void setDeptId(Long deptId) {
        this.deptId = deptId;
    }

    public Long getParentId() {
        return parentId;
    }

    public void setParentId(Long parentId) {
        this.parentId = parentId;
    }

    public String getAdjustStatus() {
        return adjustStatus;
    }

    public void setAdjustStatus(String adjustStatus) {
        this.adjustStatus = adjustStatus;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public String getPostName() {
        return postName;
    }

    public void setPostName(String postName) {
        this.postName = postName;
    }

    public Long getTeamId() {
        return teamId;
    }

    public void setTeamId(Long teamId) {
        this.teamId = teamId;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public String getAdjustDates() {
        return adjustDates;
    }

    public void setAdjustDates(String adjustDates) {
        this.adjustDates = adjustDates;
    }
}