package com.ruoyi.project.order.orderpolicy.domain;

import com.ruoyi.framework.web.domain.BaseEntity;
import java.util.Date;

/**
 * 订单关联保全管理表 f_orderpolicy
 * 
 * @author ruoyi
 * @date 2018-08-13
 */
public class Orderpolicy extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** id（子订单id） */
	private Integer id;
	/** 订单表关联保全表id */
	private Integer orderPolicyId;
	/** 订单保费 */
	private String orderCharge;
	/** 创建者 */
	private String createBy;
	/** 创建时间 */
	private Date createTime;
	/** 更新者 */
	private String updateBy;
	/** 更新时间 */
	private Date updateTime;
	/** 产品分期计划表id */
	private String productPlanId;
	/** 保全来源，，0新保保全，1续保保全, */
	private Integer policyType;
	/** 保全关联分期表 */
	private String orderFenqiId;

	/**
	 * 设置：id（子订单id）
	 */
	public void setId(Integer id) 
	{
		this.id = id;
	}
	
	/**
	 * 获取：id（子订单id）
	 */
	public Integer getId() 
	{
		return id;
	}
	
	/**
	 * 设置：订单表关联保全表id
	 */
	public void setOrderPolicyId(Integer orderPolicyId) 
	{
		this.orderPolicyId = orderPolicyId;
	}
	
	/**
	 * 获取：订单表关联保全表id
	 */
	public Integer getOrderPolicyId() 
	{
		return orderPolicyId;
	}
	
	/**
	 * 设置：订单保费
	 */
	public void setOrderCharge(String orderCharge) 
	{
		this.orderCharge = orderCharge;
	}
	
	/**
	 * 获取：订单保费
	 */
	public String getOrderCharge() 
	{
		return orderCharge;
	}
	
	/**
	 * 设置：创建者
	 */
	public void setCreateBy(String createBy) 
	{
		this.createBy = createBy;
	}
	
	/**
	 * 获取：创建者
	 */
	public String getCreateBy() 
	{
		return createBy;
	}
	
	/**
	 * 设置：创建时间
	 */
	public void setCreateTime(Date createTime) 
	{
		this.createTime = createTime;
	}
	
	/**
	 * 获取：创建时间
	 */
	public Date getCreateTime() 
	{
		return createTime;
	}
	
	/**
	 * 设置：更新者
	 */
	public void setUpdateBy(String updateBy) 
	{
		this.updateBy = updateBy;
	}
	
	/**
	 * 获取：更新者
	 */
	public String getUpdateBy() 
	{
		return updateBy;
	}
	
	/**
	 * 设置：更新时间
	 */
	public void setUpdateTime(Date updateTime) 
	{
		this.updateTime = updateTime;
	}
	
	/**
	 * 获取：更新时间
	 */
	public Date getUpdateTime() 
	{
		return updateTime;
	}
	
	/**
	 * 设置：产品分期计划表id
	 */
	public void setProductPlanId(String productPlanId) 
	{
		this.productPlanId = productPlanId;
	}
	
	/**
	 * 获取：产品分期计划表id
	 */
	public String getProductPlanId() 
	{
		return productPlanId;
	}
	
	/**
	 * 设置：保全来源，，0新保保全，1续保保全,
	 */
	public void setPolicyType(Integer policyType) 
	{
		this.policyType = policyType;
	}
	
	/**
	 * 获取：保全来源，，0新保保全，1续保保全,
	 */
	public Integer getPolicyType() 
	{
		return policyType;
	}
	
	/**
	 * 设置：保全关联分期表
	 */
	public void setOrderFenqiId(String orderFenqiId) 
	{
		this.orderFenqiId = orderFenqiId;
	}
	
	/**
	 * 获取：保全关联分期表
	 */
	public String getOrderFenqiId() 
	{
		return orderFenqiId;
	}
	
}
