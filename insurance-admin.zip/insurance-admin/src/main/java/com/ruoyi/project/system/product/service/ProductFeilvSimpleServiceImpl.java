package com.ruoyi.project.system.product.service;

import com.ruoyi.common.support.Convert;
import com.ruoyi.common.utils.NewFileUploadUtils;
import com.ruoyi.common.utils.poi.ExcelProductSimpleUtil;
import com.ruoyi.project.system.product.domain.ProductFeilvSimple;
import com.ruoyi.project.system.product.mapper.ProductFeilvSimpleMapper;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;

/**
 * 产品-简单费率（定制产品） 服务层实现
 * 
 * @author ruoyi
 * @date 2018-10-19
 */
@Service
public class ProductFeilvSimpleServiceImpl implements IProductFeilvSimpleService 
{
	@Autowired
	private ProductFeilvSimpleMapper productFeilvSimpleMapper;

	/**
     * 查询产品-简单费率（定制产品）信息
     * 
     * @param id 产品-简单费率（定制产品）ID
     * @return 产品-简单费率（定制产品）信息
     */
    @Override
	public ProductFeilvSimple selectProductFeilvSimpleById(Integer id)
	{
	    return productFeilvSimpleMapper.selectProductFeilvSimpleById(id);
	}
	
	/**
     * 查询产品-简单费率（定制产品）列表
     * 
     * @param productFeilvSimple 产品-简单费率（定制产品）信息
     * @return 产品-简单费率（定制产品）集合
     */
	@Override
	public List<ProductFeilvSimple> selectProductFeilvSimpleList(ProductFeilvSimple productFeilvSimple)
	{
	    return productFeilvSimpleMapper.selectProductFeilvSimpleList(productFeilvSimple);
	}
	
    /**
     * 新增产品-简单费率（定制产品）
     * 
     * @param productFeilvSimple 产品-简单费率（定制产品）信息
     * @return 结果
     */
	@Override
	public int insertProductFeilvSimple(ProductFeilvSimple productFeilvSimple)
	{
	    return productFeilvSimpleMapper.insertProductFeilvSimple(productFeilvSimple);
	}
	
	/**
     * 修改产品-简单费率（定制产品）
     * 
     * @param productFeilvSimple 产品-简单费率（定制产品）信息
     * @return 结果
     */
	@Override
	public int updateProductFeilvSimple(ProductFeilvSimple productFeilvSimple)
	{
	    return productFeilvSimpleMapper.updateProductFeilvSimple(productFeilvSimple);
	}

	/**
     * 删除产品-简单费率（定制产品）对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteProductFeilvSimpleByIds(String ids)
	{
		return productFeilvSimpleMapper.deleteProductFeilvSimpleByIds(Convert.toStrArray(ids));
	}

	@Transactional
	public String batchImport(ProductFeilvSimple productFeilvSimple, MultipartFile mfile) {
		//初始化输入流
		String msg="";
		InputStream is = null;
		try{
			is = mfile.getInputStream();
			Workbook book = null;
			if(NewFileUploadUtils.isExcel2003(mfile.getOriginalFilename())){
				book = new HSSFWorkbook(is);
			}else{
				book = new XSSFWorkbook(is);
			}
			//根据excel里面的内容读取知识库信息
			ExcelProductSimpleUtil excelProductSimpleUtil = new ExcelProductSimpleUtil();
			msg = excelProductSimpleUtil.readExcel(book,productFeilvSimple);

		}catch(Exception e){
			e.printStackTrace();
		} finally{
			if(is !=null)
			{
				try{
					is.close();
				}catch(IOException e){
					is = null;
					e.printStackTrace();
				}
			}
		}
		return msg;
	}

	@Override
	public int insertProductFeilvSimpleList(List<ProductFeilvSimple> productFeilvSimpleList) {
		return productFeilvSimpleMapper.insertProductFeilvSimpleList(productFeilvSimpleList);
	}

	@Override
	public int deleteProductFeilvSimpleByProductIdAndEndTime(Long productId, Date endTime) {
		return productFeilvSimpleMapper.deleteProductFeilvSimpleByProductIdAndEndTime(productId, endTime);
	}

}
