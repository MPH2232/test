package com.ruoyi.project.system.supplier1.service;//package com.ruoyi.project.system.supplier1.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.ruoyi.project.system.dict.service.IDictDataService;
import com.ruoyi.project.system.supplier1.domain.Protocol;
import com.ruoyi.project.system.supplier1.mapper.Protocol1Mapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.common.support.Convert;
import com.ruoyi.common.utils.security.ShiroUtils;
import com.ruoyi.project.system.dict.domain.DictData;
import com.ruoyi.project.system.dict.mapper.DictDataMapper;

/**
 * 协议 业务层处理
 *
 * @author ruoyi
 */
@Service
public class ProtocolServiceImpl implements IProtocolService
{
    @Autowired
    private Protocol1Mapper protocolMapper;

    /**
     * 根据条件分页查询协议数据
     *
     * @param protocol 字典数据信息
     * @return 字典数据集合信息
     */
    @Override
    public List<Protocol> selectProtocolList( Protocol protocol)
    {
        return protocolMapper.selectProtocolList(protocol);
    }

    @Override
    public List<Protocol> selectProtocol(String protocolId){
//        Protocol protocol=protocolMapper.selectProtocolDateBySuprotocolIds(protocolId);
        List<Protocol> protocols = protocolMapper.selectProtocolListBySuprotocolIds(protocolId);
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        System.out.print(sdf.format(date));
        for(Protocol protocol:protocols){
            if (((protocol.getProtocolTime())).before(date)){
                System.out.print("停用");
                protocol.setStatus("1");
            }else{
                System.out.print("正常");
                protocol.setStatus("0");
            }
            protocolMapper.updateProtocolStatus(protocol);
        }
//        protocolMapper.updateProtocol(protocol);
        return protocolMapper.selectProtocol(protocolId);
    }

    @Override
    public List<Protocol> selectProtocolListBySuprotocolIds(String suprotocolId) {
        return protocolMapper.selectProtocolListBySuprotocolIds(suprotocolId);
    }

    /**
     * 根据关联字段批量删除协议
     * @param suprotocolIds
     * @return
     */
    @Override
    public int deleteProtocolBySuprotocolIds(String suprotocolIds) {
        return protocolMapper.deleteProtocolBySuprotocolIds(Convert.toStrArray(suprotocolIds));
    }

    /**
     * 根据协议数据ID查询信息
     *
     * @param protocolId 协议数据ID
     * @return 协议数据
     */
    @Override
    public Protocol selectProtocolById(Long protocolId)
    {
        return protocolMapper.selectProtocolById(protocolId);
    }

    /**
     * 通过字典ID删除协议数据信息
     *
     * @param protocolId 协议数据ID
     * @return 结果
     */
    @Override
    public int deleteProtocolById(Long protocolId)
    {
        return protocolMapper.deleteProtocolById(protocolId);
    }

    /**
     * 批量删除协议数据
     *
     * @param ids 需要删除的数据
     * @return 结果
     */
    @Override
    public int deleteProtocolByIds(String ids)
    {
        return protocolMapper.deleteProtocolByIds(Convert.toStrArray(ids));
    }

    /**
     * 新增保存协议数据信息
     *
     * @param protocol 协议数据信息
     * @return 结果
     */
    @Override
    public int insertProtocol(Protocol protocol)
    {
        protocol.setCreateBy(ShiroUtils.getLoginName());
        return protocolMapper.insertProtocol(protocol);
    }

    /**
     * 修改保存协议数据信息
     *
     * @param protocol 协议数据信息
     * @return 结果
     */
    @Override
    public int updateProtocol(Protocol protocol)
    {
        protocol.setUpdateBy(ShiroUtils.getLoginName());
        return protocolMapper.updateProtocol(protocol);
    }

    @Override
    public int updateProtocolStatus(Protocol protocol) {
        protocol.setUpdateBy(ShiroUtils.getLoginName());
        return protocolMapper.updateProtocolStatus(protocol);
    }

    @Override
    public List<Protocol> selectProtocolAll(){
        return protocolMapper.selectProtocolAll();
    }


    @Override
    public void showProtocolType(List<Protocol> list) {
        for (Protocol protocol:list) {
            zhuanHuan(protocol);
        }
    }

    @Override
    public Protocol selectProtocolDateBySuprotocolIds(String protocolId) {
       return protocolMapper.selectProtocolDateBySuprotocolIds(protocolId);
    }


    /*对协议信息的部分属性进行设置*/
    public void zhuanHuan(Protocol protocol) {
        if ("0".equals(protocol.getProtocolType())) {
            protocol.setProtocolType("主协议");
        } else {
            protocol.setProtocolType("补充协议");
        }
    }

}
