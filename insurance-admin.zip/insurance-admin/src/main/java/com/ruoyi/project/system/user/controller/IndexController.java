package com.ruoyi.project.system.user.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.framework.web.service.DictService;
import com.ruoyi.project.homepage.homepage.damain.NewsAgency;
import com.ruoyi.project.homepage.homepage.damain.Order1;
import com.ruoyi.project.homepage.homepage.service.INewsAgencyService;
import com.ruoyi.project.homepage.homepage.service.IOrder1Service;
import com.ruoyi.project.order.order.domain.Order;
import com.ruoyi.project.order.order.service.IOrderService;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.domain.CustomerAttention;
import com.ruoyi.project.system.customer.domain.CustomerContacts;
import com.ruoyi.project.system.customer.service.lCustomerContactsService;
import com.ruoyi.project.system.customer.service.lCustomerService;
import com.ruoyi.project.system.notice.domain.Notice;
import com.ruoyi.project.system.notice.service.INoticeService;
import com.ruoyi.project.system.user.service.IUserService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import com.ruoyi.framework.config.RuoYiConfig;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.project.system.menu.domain.Menu;
import com.ruoyi.project.system.menu.service.IMenuService;
import com.ruoyi.project.system.user.domain.User;

/**
 * 首页 业务处理
 * 
 * @author ruoyi
 */
@Controller
public class IndexController extends BaseController
{
    @Autowired
    private IMenuService menuService;

    @Autowired
    private RuoYiConfig ruoYiConfig;
    /**/
    @Autowired
    private INewsAgencyService iNewsAgencyService;
    /**/
    @Autowired
    private IUserService userService;
    /*1*/
    @Autowired
    private IOrderService orderService;
    @Autowired
    private INoticeService noticeService;
    @Autowired
    private lCustomerService customerService;

    // 系统首页
    @GetMapping("/index")
    public String index(ModelMap mmap)
    {
        // 取身份信息
        User user = getUser();
        // 根据用户id取出菜单
        List<Menu> menus = menuService.selectMenusByUserId(user.getUserId());
        mmap.put("menus", menus);
        mmap.put("user", user);
        mmap.put("copyrightYear", ruoYiConfig.getCopyrightYear());

        //待办消息条数
        NewsAgency newsAgency=new NewsAgency();
        List<NewsAgency> list = iNewsAgencyService.selectNewsAgencyList(newsAgency);
        mmap.put("asd",list.size());
        return "index";
    }


    // 系统介绍
    @GetMapping("/system/main")
    public String main(ModelMap mmap) {
        // 取身份信息
        User user = getUser();
        /**
         * 待处理的订单显示条数
         */
        //获取身份
       String name= userService.selectUserRoleGroup(user.getUserId());
       Customer customer = new Customer();
        if(name.contains("管理员")){
            //管理员
            List <Order> list =orderService.selectOrderGlyList(0);
            List <Order>list1 =orderService.selectOrderGlyList(1);
            List <Order>list2 =orderService.selectOrderGlyList(2);
            List <Order>list3 =orderService.selectOrderGlyList(3);
            List <Order>list4 =orderService.selectOrderGlyList(4);
            //企业客户
            List <Customer>list5=customerService.selectCustomerList(customer);
            if(list5.size()>5){
                List<Customer>newList=list5.subList(0,5);
                mmap.put("customer",newList);
            }else {
                mmap.put("customer",list5);
            }
            mmap.put("cou",list.size());
            mmap.put("premium",list1.size());
            mmap.put("insured",list2.size());
            mmap.put("information",list3.size());
            mmap.put("completedOrder",list4.size());
            //企业客户
//            mmap.put("customer",newList);
        }else if(name.equals("主管")){
            //主管
            List <Order> list=orderService.selectOrderZhuguanList(user.getDeptId(),0);
            List <Order> list1=orderService.selectOrderZhuguanList(user.getDeptId(),1);
            List <Order> list2=orderService.selectOrderZhuguanList(user.getDeptId(),2);
            List <Order>list3 =orderService.selectOrderZhuguanList(user.getDeptId(),3);
            List <Order>list4 =orderService.selectOrderZhuguanList(user.getDeptId(),4);
            //企业客户
            List <Customer>list5=customerService.selectCustomerListCharge(user.getDeptId(),customer);
            if(list5.size()>5){
                List<Customer>newList=list5.subList(0,5);
                mmap.put("customer",newList);
            }else {
                mmap.put("customer",list5);
            }
            mmap.put("cou",list.size());
            mmap.put("premium",list1.size());
            mmap.put("insured",list2.size());
            mmap.put("information",list3.size());
            mmap.put("completedOrder",list4.size());
        }else if(name.equals("总监")){
            //总监
            List <Order> list = orderService.selectOrderMajordomoList(user.getDeptId(),0);
            List <Order> list1 = orderService.selectOrderMajordomoList(user.getDeptId(),1);
            List <Order> list2 = orderService.selectOrderMajordomoList(user.getDeptId(),2);
            List <Order> list3 = orderService.selectOrderMajordomoList(user.getDeptId(),3);
            List <Order> list4 = orderService.selectOrderMajordomoList(user.getDeptId(),4);
            //企业客户
            List <Customer>list5=customerService.selectCustomerListMajordomo(user.getDeptId(),customer);
            if(list5.size()>5){
                List<Customer>newList=list5.subList(0,5);
                mmap.put("customer",newList);
            }else {
                mmap.put("customer",list5);
            }
            mmap.put("cou",list.size());
            mmap.put("premium",list1.size());
            mmap.put("insured",list2.size());
            mmap.put("information",list3.size());
            mmap.put("completedOrder",list4.size());
        }else {
            //业务员
            List <Order> list=orderService.selectOrderYwyList(user.getUserId(),0);
            List <Order> list1=orderService.selectOrderYwyList(user.getUserId(),1);
            List <Order> list2=orderService.selectOrderYwyList(user.getUserId(),2);
            List <Order> list3=orderService.selectOrderYwyList(user.getUserId(),3);
            List <Order> list4=orderService.selectOrderYwyList(user.getUserId(),4);
            //企业客户
            List <Customer>list5=customerService.selectCustomerListSalesman(user.getUserId(),customer);
            if(list5.size()>5){
                List<Customer>newList=list5.subList(0,5);
                mmap.put("customer",newList);
            }else {
                mmap.put("customer",list5);
            }
            mmap.put("cou",list.size());
            mmap.put("premium",list1.size());
            mmap.put("insured",list2.size());
            mmap.put("information",list3.size());
            mmap.put("completedOrder",list4.size());
        }
        mmap.put("version", ruoYiConfig.getVersion());
         //新闻消息展示
        Notice notice = new Notice();
        List<Notice> list =noticeService.selectNewsList(notice);
        mmap.put("notice", list);
        //公文消息展示
        List<Notice> list1 = noticeService.selectDocumentList(notice);
        mmap.put("document",list1);
        if(name.equals("财务")){
            return "finance";
        }
        return "main";
    }

    /**
     *待办消息展示
     */
    @GetMapping("/system/user/agency")
    public String detail(Long id, ModelMap mmap)
    {
        return "newsagency/newsagency";
    }
    @PostMapping("newsagency/list")
    @ResponseBody
    public TableDataInfo list(NewsAgency newsAgency) {
        startPage();
        // 取身份信息
        List<NewsAgency> list = iNewsAgencyService.selectNewsAgencyList(newsAgency);
        return getDataTable(list);
    }

    /**
     *待提交订单
     */
    @GetMapping("/order/order/order/agency/{status}")
    public String detail2(@PathVariable("status")String status,ModelMap mmap) {
        mmap.put("status",status);
        return "order/order/orderIndex";
    }

    /**
     * 待认收保费
     */
    @GetMapping("/order/order/order/premium/{status}")
    public String premium(@PathVariable("status")int status,ModelMap mmap) {
        List <Order> userName =orderService.selectOrderGlyList(status);
        mmap.put("userName",userName);
        mmap.put("status",status);
        return "order/order/orderIndex";
    }

    /**
     * 待寄送保险卡
     */
    @GetMapping("/order/order/order/insure/{status}")
    public String insure(@PathVariable("status")String status,ModelMap mmap) {
        mmap.put("status",status);
        return "order/order/orderIndex";
    }

    /**
     * 待寄送保单/发票
     */
    @GetMapping("/order/order/order/information/{status}")
    public String information(@PathVariable("status")String status,ModelMap mmap) {
        mmap.put("status",status);
        return "order/order/orderIndex";
    }

    /**
     * 已完成的订单
     */
    @GetMapping("/order/order/order/completeOrder/{status}")
    public String completeOrder(@PathVariable("status")String status,ModelMap mmap) {
        mmap.put("status",status);
        return "order/order/orderIndex";
    }

    /**
     * 公司新闻
     */
      @GetMapping("/newsagency/news/news/{noticeId}")
    public String news(@PathVariable("noticeId")Long noticeId,ModelMap mmap) {
        mmap.put("news", noticeService.selectNoticeById(noticeId));
        return "newsagency/news";
    }

    /**
     * 显示更多公司新闻/公文
     */
    @GetMapping("/newsagency/moreNews/news/{noticeType}")
    public String moreNews(@PathVariable("noticeType")Long noticeType,ModelMap mmap) {
        mmap.put("noticeType",noticeType);
        return "newsagency/moreNews";
    }

    /**
     * 客户信息
     */
    @GetMapping("/newsagency/customer/customer/{id}")
    public String customer(@PathVariable("id")Long customerId,ModelMap mmap) {
        Customer customer= customerService.selectCustomerById(customerId);
        List<CustomerContacts> contacts =customerService.selectCustomerContactsListInfo(customer.getId());
        List<CustomerAttention> attention = customerService.selectCustomerAttentionListInfo(customer.getId());
        mmap.put("customer", customer);
        mmap.put("contacts",contacts);
        mmap.put("attention",attention);
        return "newsagency/customer";
    }

    /**
     * 显示更多客户信息
     */
    @GetMapping("/newsagency/moreCustomer/customer/{customerType}")
    public String moreCustomer(@PathVariable("customerType")Long customerType,ModelMap mmap) {
        mmap.put("noticeType",customerType);
        return "newsagency/moreCustomer";
    }
}
