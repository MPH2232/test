package com.ruoyi.project.system.adjust.mapper;

import com.ruoyi.project.homepage.homepage.damain.AdjustUser;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 业务员调整 数据层
 * 
 * @author ruoyi
 */
public interface AdjustMapper
{

    /**
     *插入业务员信息
     * 
     * @param adjustUser
     * @return 结果
     */
    public int insertAdjustByUser(AdjustUser adjustUser);
    /*管理员*/
    public List<AdjustUser> selectAdjustList(AdjustUser adjustUser);


    public AdjustUser selectAdjustById(Long id);

    public AdjustUser selectAdjustById1(Long buserId);

    /*主管*/
    public List<AdjustUser> selectAdjustListZongjian(AdjustUser adjustUser);
    /*总监*/
    public List<AdjustUser> selectAdjustMajordomoList(AdjustUser adjustUser);
    /**
     * 业务员
     */
    public List <AdjustUser> selectAdjustYwyList(AdjustUser adjustUser);

    /**
     * 更改（保存）
     * @param adjustUser
     * @return
     */
    public int updateAdjust(AdjustUser adjustUser);



    /**
     * 通过id查询业务员调整
     * @param
     * @return
     */
    public AdjustUser selectAdjustUserByBuserId(Integer buserId );


    /**
     * 插入业务员调整信息
     * @param adjustUser
     * @return
     */
    public  int insertAdjustUser(AdjustUser adjustUser);

    /**
     * 主管查询企业客户
     */
    public List<AdjustUser> selectCustomerListCharge(@Param("deptId")long deptId);

    /**
     * 总监查询企业客户
     */
    public List<AdjustUser> selectCustomerListMajordomo(@Param("deptId")long deptId);

    /**
     * 业务员查询企业客户
     */
    public List<AdjustUser> selectCustomerListSalesman(@Param("userIdd")long userIdd);

    public  int insertAftUser(AdjustUser adjustUser);

    public int updateAdjustStatus(AdjustUser adjustUser);

    public int updateAdjustUser(AdjustUser adjustUser);
}
