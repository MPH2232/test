package com.ruoyi.project.system.product.mapper;

import com.ruoyi.project.system.product.domain.Feilv;
import com.ruoyi.project.system.product.domain.Product;
import java.util.List;


/**
 * Created by x on 2018/8/7.
 * 产品信息 数据层
 */
public interface ProductMapper {

    public List<Product> selectProductList(Product product);

    public List<Product> selectProductAll();

    /*产品信息添加*/
    public int insertProduct(Product product);

    public int updateProduct(Product product);

    /*根据产品id查询产品信息*/
    public Product selectProductById(Long productId);

    public int deleteProductByIds(Long[] ids);

    public int countProductById(Long productId);

    public Product checkProductUnique(String productName);

    public int selectProductFeilv(Product product);
    public int selectProductFeilvDing(Product product);
    /*根据产品名称查询产品信息*/
    public Product selectProductByName(String productName);


    public int selectMaxId();
}
