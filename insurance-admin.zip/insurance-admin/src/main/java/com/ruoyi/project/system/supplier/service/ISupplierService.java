package com.ruoyi.project.system.supplier.service;

import com.ruoyi.project.system.supplier1.domain.Protocol;
import com.ruoyi.project.system.supplier1.domain.Supplier;

import java.util.List;

/**
 * 供应商信息 服务层
 * 
 * @author ruoyi
 */
public interface ISupplierService
{
    /**
     * 查询供应商信息集合
     * 
     * @param supplier 供应商信息
     * @return 供应商信息集合
     */
    public List<Supplier> selectSupplierList(Supplier supplier);

    /**
     * 查询所有供应商
     * 
     * @return 供应商列表
     */
    public List<Supplier> selectSupplierAll();

    /**
     * 查询所有供应商名称和id。
     * 下拉框使用值
     * @return 供应商列表
     */
    public List<Supplier> selectSupplierAllOption();



    /**
     * 根据用户ID查询岗位
     * 
     * @param userId 用户ID
     * @return 岗位列表
     */
    //public List<Supplier1> selectSuppliersByUserId(Long userId);

    /**
     * 通过供应商ID查询供应商信息
     * 
     * @param supplierId 供应商ID
     * @return 角色对象信息
     */
    public Supplier selectSupplierById(Long supplierId);

    /**
     * 批量删除供应商信息
     * 
     * @param ids 需要删除的数据ID
     */
    public int deleteSupplierByIds(String ids) throws Exception;

    /**
     * 新增保存供应商信息
     * 
     * @param supplier 供应商信息
     * @return 结果
     */
   /* public int insertSupplier(Supplier1 supplier,Protocol1 protocol);*/

    /**
     * 新增保存供应商信息集合list
     *
     * @param supplier 供应商信息
     * @return 结果
     */
    public int insertProtocolList(Supplier supplier, List<Protocol> protocol);

    /**
     * 修改保存供应商信息
     * 
     * @param supplier 供应商信息
     * @return 结果
     */
    public int updateSupplier(Supplier supplier);


    public List<Protocol> selectProtocolList(String protocolId);
}
