package com.ruoyi.project.system.customer.service;


import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.domain.CustomerAttention;
import com.ruoyi.project.system.customer.domain.CustomerContacts;

import java.util.List;

/**
 * Created by x on 2018/8/8.
 */

public interface lCustomerService {
    /**
     * 查询企业客户信息集合
     *
     * @param customer 企业客户信息
     * @return 企业客户信息集合
     */
    public List<Customer> selectCustomerList(Customer customer);
    /**
     * 查询所有客户
     *
     * @return 客户列表
     */
    public List<Customer> selectCustomerAll();


    /**
     * 查询所有客户
     *
     * @return 客户列表
     */
    public List<Customer> selectCustomerAllOption(String type);
    /**
     * 通过id查询企业客户信息
     * @param id
     * @return
     * 1
     */
    public Customer selectCustomerById(long id);

    /**
     * 新增保存企业客户信息
     *
     * @param customer 客户信息
     * @return 结果
     */
    public int insertCustomer(Customer customer);

    /**
     * 修改保存企业客户信息
     *
     * @param customer 岗位信息
     * @return 结果
     */
    public int updateCustomer(Customer customer);

    /**
     * 批量删除客户信息
     *
     * @param ids 需要删除的数据ID
     */
    public int deleteCustomerByIds(String ids) throws Exception;

    /**
     * 查询联系人信息
     * @param customerId
     * @return
     */
    public List<CustomerContacts> selectCustomerContactsListInfo(int customerId);

    /**
     * 查询收件人信息
     * @param customerId
     * @return
     */
    public List<CustomerAttention> selectCustomerAttentionListInfo(int customerId);

    public List<Customer> selectCustomersAll();

    /**
     *总监查询企业客户信息
     *
     */
    public List<Customer> selectCustomerListMajordomo(long deptId,Customer customer);

    /**
     * 主管查看企业客户信息
     */
    public List<Customer> selectCustomerListCharge(long deptId,Customer customer);

    /**
     *业务员查询企业客户信息
     *
     */
    public List<Customer> selectCustomerListSalesman(long userIdd,Customer customer);



}
