package com.ruoyi.project.system.customer.service;


import com.ruoyi.project.system.customer.domain.CustomerAttention;

import java.util.List;

/**
 * Created by x on 2018/8/8.
 */

public interface lCustomerAttentionService {
    /**
     * 查询收件人信息集合
     *
     * @param customerAttention 收件人信息
     * @return 收件人信息集合
     */
    public List<CustomerAttention> selectCustomerAttentionList(CustomerAttention customerAttention);

    /**
     * 查询所有收件人
     *
     * @return 收件人列表
     */
    public List<CustomerAttention> selectCustomerAttentionAll();

    /**
     * 通过id 收件人信息
     * @param id
     * @return
     */
    public CustomerAttention selectCustomerAttentionById(Long id);

    /**
     * 根据客户表Id查询收件人信息
     * @param customerId 客户表Id
     * @return 收件人集合信息
     */
    public List<CustomerAttention> selectCustomerAttentionByCustomerId(int customerId);


    /**
     * 新增保存收件人信息
     *
     * @param customerAttention 收件人信息
     * @return 结果
     */
    public int insertCustomerAttention(CustomerAttention customerAttention);

    /**
     * 修改保存收件人信息
     *
     * @param customerAttention 收件人信息
     * @return 结果
     */
    public int updateCustomerAttention(CustomerAttention customerAttention);


    /**
     * 批量删除联系人信息
     */
    public int deleteCustomerAttentionByIds(String ids) throws Exception;


    
}
