package com.ruoyi.project.system.supplier1.domain;

import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * 供应商对象实体
 * 
 * @author ruoyi
 */
public class Supplier extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 供应商ID */
//    @Excel(name = "供应商序号")
    private Long supplierId;

    /** 供应商名称 */
    @Excel(name = "供应商名称")
    private String supplierName;

    /** 保险公司简称 */
    @Excel(name = "保险公司简称")
    private String supplierText;

    /** 显示顺序 */
//    @Excel(name = "显示顺序")
    private String orderNum;

    /** 公司电话 */
    @Excel(name = "公司电话")
    private String supplierPhone;

    /** 法人代表 */
    @Excel(name = "法人代表")
    private String leader;

    /** 联系人姓名 */
    @Excel(name = "联系人姓名")
    private String contactsName;

    /** 联系人职责描述 */
    @Excel(name = "联系人职责描述")
    private String contactsDescribe;

    /** 联系人职位 */
    @Excel(name = "联系人职位")
    private String contactsPosition;

    /** 联系人手机 */
    @Excel(name = "联系人手机")
    private String contactsPhone;

    /** 联系人邮箱 */
    @Excel(name = "联系人邮箱")
    private String contactsEmail;

    /** 是否为增值税一般纳税人 */
    @Excel(name = "是否为增值税一般纳税人 ")
    private String paytaxes;

    /** 税务登记地址 */
    @Excel(name = "税务登记地址")
    private String paytaxesAdd;

    /** 开票信息公司电话 */
    @Excel(name = "开票信息公司电话")
    private String paytaxesPhone;

    /** 开票信息开户行 */
    @Excel(name = "开票信息开户行")
    private String paytaxesBank;

    /** 开票信息开户行 */
    @Excel(name = "开票信息开户行分行")
    private String paytaxesBankSon;

    /** 开票信息开户账号 */
    @Excel(name = "开票信息开户账号")
    private String paytaxesNumber;

    /** 保费开户行 */
    @Excel(name = "保费开户行")
    private String premiumBank;

    /** 保费开户行 */
    @Excel(name = "保费开户行分行")
    private String premiumBankSon;

    /** 保费开户账号 */
    @Excel(name = "保费开户账号")
    private String premiumNumber;

    /** 保费开户户名 */
    @Excel(name = "保费开户户名")
    private String premiumName;

    /** 合作协议关联id */
    @Excel(name = "合作协议关联id")
    private String protocolId;

    /** 渠道状态（0正常 1停用） */
//    @Excel(name = "供应商状态")
    private String status;

    /** 联系地址 */
    @Excel(name = "联系地址")
    private String contactsAddress;

    /** 备注 */
    @Excel(name = "备注")
    private String remark;
    /** 统一社会信用代码 */
    @Excel(name = "统一社会信用代码")
    private String creditCode;
    /** 保全邮箱 */
    @Excel(name = "保全邮箱")
    private String baoquanEmail;
    /** 理赔地址 */
    @Excel(name = "理赔地址")
    private String lipeiAddress;
    /** 收件人 */
    @Excel(name = "收件人")
    private String addressee;
    /** 部门 */
    @Excel(name = "部门")
    private String dept;
    /** 抬头 */
    @Excel(name = "抬头")
    private String taitou;
    /** 税号 */
    @Excel(name = "税号")
    private String suihao;
    /** 联系人电话 */
    @Excel(name = "联系人电话")
    private String contactsTel;

    /** 协议获取前端值 */
    private String xieyiList;

    private int countData;



    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Long getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(Long supplierId) {
        this.supplierId = supplierId;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getSupplierText() {
        return supplierText;
    }

    public void setSupplierText(String supplierText) {
        this.supplierText = supplierText;
    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public String getSupplierPhone() {
        return supplierPhone;
    }

    public void setSupplierPhone(String supplierPhone) {
        this.supplierPhone = supplierPhone;
    }

    public String getLeader() {
        return leader;
    }

    public void setLeader(String leader) {
        this.leader = leader;
    }

    public String getContactsName() {
        return contactsName;
    }

    public void setContactsName(String contactsName) {
        this.contactsName = contactsName;
    }

    public String getContactsDescribe() {
        return contactsDescribe;
    }

    public void setContactsDescribe(String contactsDescribe) {
        this.contactsDescribe = contactsDescribe;
    }

    public String getContactsPosition() {
        return contactsPosition;
    }

    public void setContactsPosition(String contactsPosition) {
        this.contactsPosition = contactsPosition;
    }

    public String getContactsPhone() {
        return contactsPhone;
    }

    public void setContactsPhone(String contactsPhone) {
        this.contactsPhone = contactsPhone;
    }

    public String getContactsEmail() {
        return contactsEmail;
    }

    public void setContactsEmail(String contactsEmail) {
        this.contactsEmail = contactsEmail;
    }

    public String getPaytaxes() {
        return paytaxes;
    }

    public void setPaytaxes(String paytaxes) {
        this.paytaxes = paytaxes;
    }

    public String getPaytaxesAdd() {
        return paytaxesAdd;
    }

    public void setPaytaxesAdd(String paytaxesAdd) {
        this.paytaxesAdd = paytaxesAdd;
    }

    public String getPaytaxesPhone() {
        return paytaxesPhone;
    }

    public void setPaytaxesPhone(String paytaxesPhone) {
        this.paytaxesPhone = paytaxesPhone;
    }

    public String getPaytaxesBank() {
        return paytaxesBank;
    }

    public void setPaytaxesBank(String paytaxesBank) {
        this.paytaxesBank = paytaxesBank;
    }

    public String getPaytaxesNumber() {
        return paytaxesNumber;
    }

    public void setPaytaxesNumber(String paytaxesNumber) {
        this.paytaxesNumber = paytaxesNumber;
    }

    public String getPremiumBank() {
        return premiumBank;
    }

    public void setPremiumBank(String premiumBank) {
        this.premiumBank = premiumBank;
    }

    public String getPremiumNumber() {
        return premiumNumber;
    }

    public void setPremiumNumber(String premiumNumber) {
        this.premiumNumber = premiumNumber;
    }

    public String getPremiumName() {
        return premiumName;
    }

    public void setPremiumName(String premiumName) {
        this.premiumName = premiumName;
    }

    public String getProtocolId() {
        return protocolId;
    }

    public void setProtocolId(String protocolId) {
        this.protocolId = protocolId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getContactsAddress() {
        return contactsAddress;
    }

    public void setContactsAddress(String contactsAddress) {
        this.contactsAddress = contactsAddress;
    }

    @Override
    public String getRemark() {
        return remark;
    }

    @Override
    public void setRemark(String remark) {
        this.remark = remark;
    }


    public String getXieyiList() {
        return xieyiList;
    }

    public void setXieyiList(String xieyiList) {
        this.xieyiList = xieyiList;
    }

    public int getCountData() {
        return countData;
    }

    public void setCountData(int countData) {
        this.countData = countData;
    }

    public String getPaytaxesBankSon() {
        return paytaxesBankSon;
    }

    public void setPaytaxesBankSon(String paytaxesBankSon) {
        this.paytaxesBankSon = paytaxesBankSon;
    }

    public String getPremiumBankSon() {
        return premiumBankSon;
    }

    public void setPremiumBankSon(String premiumBankSon) {
        this.premiumBankSon = premiumBankSon;
    }

    public String getCreditCode() {
        return creditCode;
    }

    public void setCreditCode(String creditCode) {
        this.creditCode = creditCode;
    }

    public String getBaoquanEmail() {
        return baoquanEmail;
    }

    public void setBaoquanEmail(String baoquanEmail) {
        this.baoquanEmail = baoquanEmail;
    }

    public String getLipeiAddress() {
        return lipeiAddress;
    }

    public void setLipeiAddress(String lipeiAddress) {
        this.lipeiAddress = lipeiAddress;
    }

    public String getAddressee() {
        return addressee;
    }

    public void setAddressee(String addressee) {
        this.addressee = addressee;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getTaitou() {
        return taitou;
    }

    public void setTaitou(String taitou) {
        this.taitou = taitou;
    }

    public String getSuihao() {
        return suihao;
    }

    public void setSuihao(String suihao) {
        this.suihao = suihao;
    }

    public String getContactsTel() {
        return contactsTel;
    }

    public void setContactsTel(String contactsTel) {
        this.contactsTel = contactsTel;
    }
}
