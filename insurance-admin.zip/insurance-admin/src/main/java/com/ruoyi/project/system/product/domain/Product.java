package com.ruoyi.project.system.product.domain;

import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import io.swagger.models.auth.In;

import java.util.Date;

/**
 * Created by x on 2018/8/7.
 * 产品对象
 */
public class Product {
//    @Excel(name = "产品id")
    private Long productId;       //产品id
    @Excel(name = "产品名称")
    private String productName;     //产品名称
    @Excel(name = "保险公司名称")
    private String insuranceName;   //保险公司名称
    @Excel(name = "保险公司id")
    private Long insuranceId;   //保险公司id
    @Excel(name = "险种名称")
    private String productKind;      //产品编码
    @Excel(name = "产品方案")
    private String productPro;
    @Excel(name = "产品类型")
    private String productType;    //产品类型
    @Excel(name = "保险行次")
    private String insuranceCi;    //保险行次
    @Excel(name = "保险期间")
    private String insuranceTime;  //保险期间（0短期，1一年，2长期）
    @Excel(name = "期限")
    private String timeQiXian;     //若是长期，期限是终身或者具体岁数65
    @Excel(name = "PC比例")
    private String pcBili;        //PC比例
    @Excel(name = "会员费百分比")
    private String memberBili;    //会员百分比
    @Excel(name = "是否生成续保订单")
    private String xuBao;         //是否生成续保订单（0是，1否）
    @Excel(name = "是否填写保单号")
    private String baoDanhao;     //是否填写保单号（0是，1否）
    @Excel(name = "产品状态")
    private String status;       //产品状态（0正常 1停用）
    @Excel(name = "创建者")
    private String createBy;     //创建者
    @Excel(name = "创建时间")
    private Date createTime;     //创建时间
    @Excel(name = "更新者")
    private String updateBy;     //更新者
    @Excel(name = "更新时间")
    private Date updateTime;     //更新时间
    @Excel(name = "费率")
    private String feilv;     //是否使用费率表（0是，1否）
    @Excel(name = "是否是简单费率表")
    private String isSimple;     //是否是简单费率表（0复杂，1简单，不使用2）
//    @Excel(name = "关联保险表-保险公司名称")
    private String supplierName ;     //保险公司名称
//    @Excel(name = "关联保险表-保险公司id")
    private String supplierId ;     //保险公司id
//    @Excel(name = "关联保单表-产品使用计数结果")
    private Integer countData;

    public String getIsSimple() {
        return isSimple;
    }

    public void setIsSimple(String isSimple) {
        this.isSimple = isSimple;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getInsuranceName() {
        return insuranceName;
    }

    public void setInsuranceName(String insuranceName) {
        this.insuranceName = insuranceName;
    }

    public Long getInsuranceId() {
        return insuranceId;
    }

    public void setInsuranceId(Long insuranceId) {
        this.insuranceId = insuranceId;
    }

    public String getProductKind() {
        return productKind;
    }

    public void setProductKind(String productKind) {
        this.productKind = productKind;
    }

    public String getProductPro() {
        return productPro;
    }

    public void setProductPro(String productPro) {
        this.productPro = productPro;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public String getInsuranceCi() {
        return insuranceCi;
    }

    public void setInsuranceCi(String insuranceCi) {
        this.insuranceCi = insuranceCi;
    }

    public String getInsuranceTime() {
        return insuranceTime;
    }

    public void setInsuranceTime(String insuranceTime) {
        this.insuranceTime = insuranceTime;
    }

    public String getTimeQiXian() {
        return timeQiXian;
    }

    public void setTimeQiXian(String timeQiXian) {
        this.timeQiXian = timeQiXian;
    }

    public String getPcBili() {
        return pcBili;
    }

    public void setPcBili(String pcBili) {
        this.pcBili = pcBili;
    }

    public String getMemberBili() {
        return memberBili;
    }

    public void setMemberBili(String memberBili) {
        this.memberBili = memberBili;
    }

    public String getXuBao() {
        return xuBao;
    }

    public void setXuBao(String xuBao) {
        this.xuBao = xuBao;
    }

    public String getBaoDanhao() {
        return baoDanhao;
    }

    public void setBaoDanhao(String baoDanhao) {
        this.baoDanhao = baoDanhao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getFeilv() {
        return feilv;
    }

    public void setFeilv(String feilv) {
        this.feilv = feilv;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public Integer getCountData() {
        return countData;
    }

    public void setCountData(Integer countData) {
        this.countData = countData;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Product product = (Product) o;

        if (!productId.equals(product.productId)) return false;
        if (!productName.equals(product.productName)) return false;
        if (!insuranceName.equals(product.insuranceName)) return false;
        if (!insuranceId.equals(product.insuranceId)) return false;
        if (!productKind.equals(product.productKind)) return false;
        if (!productType.equals(product.productType)) return false;
        if (!insuranceCi.equals(product.insuranceCi)) return false;
        if (!insuranceTime.equals(product.insuranceTime)) return false;
        if (!timeQiXian.equals(product.timeQiXian)) return false;
        if (!pcBili.equals(product.pcBili)) return false;
        if (!memberBili.equals(product.memberBili)) return false;
        if (!xuBao.equals(product.xuBao)) return false;
        if (!baoDanhao.equals(product.baoDanhao)) return false;
        if (!status.equals(product.status)) return false;
        if (!createBy.equals(product.createBy)) return false;
        if (!createTime.equals(product.createTime)) return false;
        if (!updateBy.equals(product.updateBy)) return false;
        if (!updateTime.equals(product.updateTime)) return false;
        if (!feilv.equals(product.feilv)) return false;
        if (!supplierName.equals(product.supplierName)) return false;
        if (!supplierId.equals(product.supplierId)) return false;
        return countData.equals(product.countData);
    }

    @Override
    public int hashCode() {
        int result = productId.hashCode();
        result = 31 * result + productName.hashCode();
        result = 31 * result + insuranceName.hashCode();
        result = 31 * result + insuranceId.hashCode();
        result = 31 * result + productKind.hashCode();
        result = 31 * result + productType.hashCode();
        result = 31 * result + insuranceCi.hashCode();
        result = 31 * result + insuranceTime.hashCode();
        result = 31 * result + timeQiXian.hashCode();
        result = 31 * result + pcBili.hashCode();
        result = 31 * result + memberBili.hashCode();
        result = 31 * result + xuBao.hashCode();
        result = 31 * result + baoDanhao.hashCode();
        result = 31 * result + status.hashCode();
        result = 31 * result + createBy.hashCode();
        result = 31 * result + createTime.hashCode();
        result = 31 * result + updateBy.hashCode();
        result = 31 * result + updateTime.hashCode();
        result = 31 * result + feilv.hashCode();
        result = 31 * result + supplierName.hashCode();
        result = 31 * result + supplierId.hashCode();
        result = 31 * result + countData.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "Product{" +
                "productId=" + productId +
                ", productName='" + productName + '\'' +
                ", insuranceName='" + insuranceName + '\'' +
                ", insuranceId=" + insuranceId +
                ", productKind='" + productKind + '\'' +
                ", productType='" + productType + '\'' +
                ", insuranceCi='" + insuranceCi + '\'' +
                ", insuranceTime='" + insuranceTime + '\'' +
                ", timeQiXian='" + timeQiXian + '\'' +
                ", pcBili='" + pcBili + '\'' +
                ", memberBili='" + memberBili + '\'' +
                ", xuBao='" + xuBao + '\'' +
                ", baoDanhao='" + baoDanhao + '\'' +
                ", status='" + status + '\'' +
                ", createBy='" + createBy + '\'' +
                ", createTime=" + createTime +
                ", updateBy='" + updateBy + '\'' +
                ", updateTime=" + updateTime +
                ", feilv='" + feilv + '\'' +
                ", supplierName='" + supplierName + '\'' +
                ", supplierId='" + supplierId + '\'' +
                ", countData=" + countData +
                '}';
    }


}
