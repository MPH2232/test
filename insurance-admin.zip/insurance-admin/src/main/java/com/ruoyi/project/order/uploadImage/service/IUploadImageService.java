package com.ruoyi.project.order.uploadImage.service;

import com.ruoyi.project.order.uploadImage.domain.UploadImage;
import java.util.List;

/**
 * 影像件管理 服务层
 * 
 * @author ruoyi
 * @date 2018-08-22
 */
public interface IUploadImageService 
{
	/**
     * 查询影像件管理信息
     * 
     * @param id 影像件管理ID
     * @return 影像件管理信息
     */
	public UploadImage selectUploadImageById(Integer id);

	/**
	 * 查询影像件管理信息
	 *
	 * @param orderId
	 * @return 影像件管理信息
	 */
	public UploadImage selectUploadImageOrderId(String orderId,String shouye);
	
	/**
     * 查询影像件管理列表
     * 
     * @param uploadImage 影像件管理信息
     * @return 影像件管理集合
     */
	public List<UploadImage> selectUploadImageList(UploadImage uploadImage);
	
	/**
     * 新增影像件管理
     * 
     * @param uploadImage 影像件管理信息
     * @return 结果
     */
	public int insertUploadImage(UploadImage uploadImage);
	
	/**
     * 修改影像件管理
     * 
     * @param uploadImage 影像件管理信息
     * @return 结果
     */
	public int updateUploadImage(UploadImage uploadImage);

	/**
	 * 修改影像件管理，只更新时间
	 *
	 * @param uploadImage 影像件管理信息
	 * @return 结果
	 */
	public int updateUploadImageTime(UploadImage uploadImage);

	/**
     * 删除影像件管理信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteUploadImageByIds(String ids);
	
}
