package com.ruoyi.project.system.supplier1.domain;

import com.ruoyi.framework.aspectj.lang.annotation.Excel;

import java.util.Date;

/**
 * 协议表实体对象
 * 
 * @author ruoyi
 */
public class Protocol
{
    private static final long serialVersionUID = 1L;

    private Long protocolId;

    private String suprotocolId;
    @Excel(name = "协议类型")
    private String protocolType;
    @Excel(name = "协议名称")
    private String protocolName;

    private String protocolFile;

    @Excel(name = "协议到期日")
    private Date protocolTime;
    @Excel(name = "协议状态")
    private String status;

    private String createBy;

    private String updateBy;

    private Date createTime;

    private Date updateTime;

    private String linuxPath;

    private String protocolDetailed ;//协议详情--多条协议--获取到转换json or map



    public static long getSerialVersionUID() {
        return serialVersionUID;
    }


    public Long getProtocolId() {
        return protocolId;
    }

    public void setProtocolId(Long protocolId) {
        this.protocolId = protocolId;
    }

    public String getSuprotocolId() {
        return suprotocolId;
    }

    public void setSuprotocolId(String suprotocolId) {
        this.suprotocolId = suprotocolId;
    }

    public String getProtocolType() {
        return protocolType;
    }

    public void setProtocolType(String protocolType) {
        this.protocolType = protocolType;
    }

    public String getLinuxPath() {
        return linuxPath;
    }

    public void setLinuxPath(String linuxPath) {
        this.linuxPath = linuxPath;
    }

    public String getProtocolName() {
        return protocolName;
    }

    public void setProtocolName(String protocolName) {
        this.protocolName = protocolName;
    }

    public String getProtocolFile() {
        return protocolFile;
    }

    public void setProtocolFile(String protocolFile) {
        this.protocolFile = protocolFile;
    }

    public Date getProtocolTime() {
        return protocolTime;
    }

    public void setProtocolTime(Date protocolTime) {
        this.protocolTime = protocolTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getProtocolDetailed() {
        return protocolDetailed;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public void setProtocolDetailed(String protocolDetailed) {
        this.protocolDetailed = protocolDetailed;
    }


}
