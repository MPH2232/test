package com.ruoyi.project.system.customer.domain;

import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

/**
 * Created by x on 2018/8/7.
 */
public class Customer extends BaseEntity {
    private static final long serialVersionUID = 1L;
    /*供应商id*/
    @Excel(name = "客户Id")
    private int id;
    /*公司名称*/
    @Excel(name = "公司名称")
    private String customerName;
//    /*公司简称*/
//    @Excel(name = "公司简称")
//    private String customerText;
    /*联系地址*/
    @Excel(name = "联系地址")
    private String orderNum;
    /*公司传真*/
    @Excel(name = "公司传真")
    private String customerFax;
    /*法人代表*/
    @Excel(name = "法人代表")
    private String leader;
    /*备注*/
    @Excel(name = "备注")
    private String remark;
    /*联系人姓名*/
    @Excel(name = "联系人姓名")
    private String contactsName;
    /*联系人部门*/
    @Excel(name = "联系人部门")
    private String contactsDept;
    /*联系人职位*/
    @Excel(name = "联系人职位")
    private String contactsPosition;
    /*联系人电话*/
    @Excel(name = "联系人电话")
    private String contactsPhone;
    /*联系人微信号*/
    @Excel(name = "联系人微信号")
    private String contactsWeixin;
    /*联系人邮箱*/
    @Excel(name = "联系人邮箱")
    private String contactsEmail;
    /*是否为增值税一般纳税人*/
    @Excel(name = "增值税纳税人")
    private String paytaxes;
    /*税务登记地址*/
    @Excel(name = "税务登记地址")
    private String paytaxesAdd;
    /*开票信息公司电话*/
    @Excel(name = "开票信息公司电话")
    private String paytaxesPhone;
    /*开票信息开户行*/
    @Excel(name = "开票信息开户行")
    private String paytaxesBank;
    /*开票信息开户支行*/
    private String paytaxesBankSon;
    /*开票信息开户账号*/
    @Excel(name = "开票信息开户账号")
    private String paytaxesNumber;
    /*保费开户行*/
    @Excel(name = "保费开户行")
    private String premiumBank;

    /*保费开户支行*/
    private String premiumBankSon;
    /*保费开户账号*/
    @Excel(name = "保费开户行账号")
    private String premiumNumber;
    /*保费开户户名*/
    @Excel(name = "保费开户户名")
    private String premiumName;
    /*用户状态*/
    @Excel(name = "用户状态")
    private Long status;
    /*创建者*/
    @Excel(name = "创建者")
    private String createBy;
    //private String createTime;
   // private String updateBy;
   // private String updateTime;
    /*联系人职责*/
    @Excel(name = "联系人职责")
    private String contactsDescribe;
    /*开票公司下公司名称*/
    @Excel(name = "开票公司下公司名称")
    private String paytaxesName;
    /*客户类型*/
    @Excel(name = "客户类型")
    private String customerType;
    /*邮寄地址*/
    @Excel(name = "邮寄地址")
    private String customerMail;
    /*收件人*/
    @Excel(name = "收件人")
    private String customerColl;
    /*收件人联系方式*/
    @Excel(name = "收件人联系方式")
    private Long customerCollPhone;
    /*证件类型*/
    @Excel(name = "证件类型")
    private String cardType;
    /*证件号码*/
    @Excel(name = "证件号码")
    private String cardNum;
    /*生日*/
    @Excel(name = "生日")
    private String shengri;
    /*性别*/
    @Excel(name = "性别")
    private String sex;
    /*信用代码*/
    @Excel(name = "税号")
    private String paytaxesCode;
    /*联系人电话*/
    @Excel(name="联系人电话")
    private String contactNumber;

    /*统一社会信用代码*/
    private String creditCode;

    private int countData;

    /*业务员id*/
    private long userId;

    /*业务员名称*/
    private String userName;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public long getUserId() {
        return userId;
    }
    public void setUserId(long userId) {
        this.userId = userId;
    }

    public String getCreditCode() {
        return creditCode;
    }

    public void setCreditCode(String creditCode) {
        this.creditCode = creditCode;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getPaytaxesBankSon() {
        return paytaxesBankSon;
    }

    public void setPaytaxesBankSon(String paytaxesBankSon) {
        this.paytaxesBankSon = paytaxesBankSon;
    }

    public String getPremiumBankSon() {
        return premiumBankSon;
    }

    public void setPremiumBankSon(String premiumBankSon) {
        this.premiumBankSon = premiumBankSon;
    }

    public String getPaytaxesCode() {
        return paytaxesCode;
    }

    public void setPaytaxesCode(String paytaxesCode) {
        this.paytaxesCode = paytaxesCode;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getId() {return id;}

    public void setId(int id) {
        this.id = id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

//    public String getCustomerText() {
//        return customerText;
//    }
//
//    public void setCustomerText(String customerText) {
//        this.customerText = customerText;
//    }

    public String getOrderNum() {
        return orderNum;
    }

    public void setOrderNum(String orderNum) {
        this.orderNum = orderNum;
    }

    public String getCustomerFax() {
        return customerFax;
    }

    public void setCustomerFax(String customerFax) {
        this.customerFax = customerFax;
    }

    public String getLeader() {
        return leader;
    }

    public void setLeader(String leader) {
        this.leader = leader;
    }

    @Override
    public String getRemark() {
        return remark;
    }

    @Override
    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getContactsName() {
        return contactsName;
    }

    public void setContactsName(String contactsName) {
        this.contactsName = contactsName;
    }

    public String getContactsDept() {
        return contactsDept;
    }

    public void setContactsDept(String contactsDept) {
        this.contactsDept = contactsDept;
    }

    public String getContactsPosition() {
        return contactsPosition;
    }

    public void setContactsPosition(String contactsPosition) {
        this.contactsPosition = contactsPosition;
    }

    public String getContactsPhone() {
        return contactsPhone;
    }

    public void setContactsPhone(String  contactsPhone) {
        this.contactsPhone = contactsPhone;
    }

    public String getContactsWeixin() {
        return contactsWeixin;
    }

    public void setContactsWeixin(String contactsWeixin) {
        this.contactsWeixin = contactsWeixin;
    }

    public String getContactsEmail() {
        return contactsEmail;
    }

    public void setContactsEmail(String contactsEmail) {
        this.contactsEmail = contactsEmail;
    }

    public String getPaytaxes() {
        return paytaxes;
    }

    public void setPaytaxes(String paytaxes) {
        this.paytaxes = paytaxes;
    }

    public String getPaytaxesAdd() {
        return paytaxesAdd;
    }

    public void setPaytaxesAdd(String paytaxesAdd) {
        this.paytaxesAdd = paytaxesAdd;
    }

    public String getPaytaxesPhone() {
        return paytaxesPhone;
    }

    public void setPaytaxesPhone(String paytaxesPhone) {
        this.paytaxesPhone = paytaxesPhone;
    }

    public String getPaytaxesBank() {
        return paytaxesBank;
    }

    public void setPaytaxesBank(String paytaxesBank) {
        this.paytaxesBank = paytaxesBank;
    }

    public String  getPaytaxesNumber() {
        return paytaxesNumber;
    }

    public void setPaytaxesNumber(String  paytaxesNumber) {
        this.paytaxesNumber = paytaxesNumber;
    }

    public String getPremiumBank() {
        return premiumBank;
    }

    public void setPremiumBank(String premiumBank) {
        this.premiumBank = premiumBank;
    }

    public String getPremiumNumber() {
        return premiumNumber;
    }

    public void setPremiumNumber(String premiumNumber) {
        this.premiumNumber = premiumNumber;
    }

    public String getPremiumName() {
        return premiumName;
    }

    public void setPremiumName(String premiumName) {
        this.premiumName = premiumName;
    }

    public Long getStatus() {
        return status;
    }

    public void setStatus(Long status) {
        this.status = status;
    }


    @Override
    public String getCreateBy() {
        return createBy;
    }

    @Override
    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }


    public String getContactsDescribe() {
        return contactsDescribe;
    }

    public void setContactsDescribe(String contactsDescribe) {
        this.contactsDescribe = contactsDescribe;
    }

    public String getPaytaxesName() {
        return paytaxesName;
    }

    public void setPaytaxesName(String paytaxesName) {
        this.paytaxesName = paytaxesName;
    }

    public String  getCustomerType() {
        return customerType;
    }

    public void setCustomerType(String customerType) {
        this.customerType = customerType;
    }

    public String getCustomerMail() {
        return customerMail;
    }

    public void setCustomerMail(String customerMail) {
        this.customerMail = customerMail;
    }

    public String getCustomerColl() {
        return customerColl;
    }

    public void setCustomerColl(String customerColl) {
        this.customerColl = customerColl;
    }

    public Long getCustomerCollPhone() {
        return customerCollPhone;
    }

    public void setCustomerCollPhone(Long customerCollPhone) {
        this.customerCollPhone = customerCollPhone;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getCardNum() {
        return cardNum;
    }

    public void setCardNum(String cardNum) {
        this.cardNum = cardNum;
    }

    public String getShengri() {
        return shengri;
    }

    public void setShengri(String shengri) {
        this.shengri = shengri;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getCountData() {
        return countData;
    }

    public void setCountData(int countData) {
        this.countData = countData;
    }



    @Override
    public String toString() {
        return "Customer{" +
                "id=" + id +
                ", customerName='" + customerName + '\'' +
//                ", customerText='" + customerText + '\'' +
                ", orderNum='" + orderNum + '\'' +
                ", customerFax='" + customerFax + '\'' +
                ", leader='" + leader + '\'' +
                ", remark='" + remark + '\'' +
                ", contactsName='" + contactsName + '\'' +
                ", contactsDept='" + contactsDept + '\'' +
                ", contactsPosition='" + contactsPosition + '\'' +
                ", contactsPhone='" + contactsPhone + '\'' +
                ", contactsWeixin='" + contactsWeixin + '\'' +
                ", contactsEmail='" + contactsEmail + '\'' +
                ", paytaxes='" + paytaxes + '\'' +
                ", paytaxesAdd='" + paytaxesAdd + '\'' +
                ", paytaxesPhone='" + paytaxesPhone + '\'' +
                ", paytaxesBank='" + paytaxesBank + '\'' +
                ", paytaxesBankSon='" + paytaxesBankSon + '\'' +
                ", paytaxesNumber='" + paytaxesNumber + '\'' +
                ", premiumBank='" + premiumBank + '\'' +
                ", premiumBankSon='" + premiumBankSon + '\'' +
                ", premiumNumber='" + premiumNumber + '\'' +
                ", premiumName='" + premiumName + '\'' +
                ", status=" + status +
                ", createBy='" + createBy + '\'' +
                ", contactsDescribe='" + contactsDescribe + '\'' +
                ", paytaxesName='" + paytaxesName + '\'' +
                ", customerType='" + customerType + '\'' +
                ", customerMail='" + customerMail + '\'' +
                ", customerColl='" + customerColl + '\'' +
                ", customerCollPhone=" + customerCollPhone +
                ", cardType='" + cardType + '\'' +
                ", cardNum='" + cardNum + '\'' +
                ", shengri='" + shengri + '\'' +
                ", sex='" + sex + '\'' +
                ", paytaxesCode='" + paytaxesCode + '\'' +
                ", countData=" + countData +
                '}';
    }
}
