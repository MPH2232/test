package com.ruoyi.project.homepage.homepage.service;

import com.ruoyi.project.homepage.homepage.damain.AdjustUser;
import com.ruoyi.project.homepage.homepage.damain.NewsAgency;
import com.ruoyi.project.homepage.homepage.damain.OrderUser;
import com.ruoyi.project.order.order.domain.Order;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

/**
 * Created by x on 2018/9/17.
 */
public interface IOrderUserService {
    /**
     * 查询所有待办消息
     * @return
     */
    public List<OrderUser> selectOrderUserList(OrderUser orderUser);
    public List<OrderUser> selectOrderList1(OrderUser orderUser);



    /**
     * 通过id查询订单
     * @param id
     * @return
     */
    public OrderUser selectOrderUserById(Integer id);



    /**
     * 上传excel文件到临时目录后并开始解析1022
     * @param
     * @param mfile
     * @return
     */
    public String batchImport(Order order, MultipartFile mfile, AdjustUser adjustUser, NewsAgency newsAgency);

   public int updateSalesmanName(Order order);



}
