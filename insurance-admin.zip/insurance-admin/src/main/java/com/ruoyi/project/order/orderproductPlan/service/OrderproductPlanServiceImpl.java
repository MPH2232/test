package com.ruoyi.project.order.orderproductPlan.service;

import java.util.HashMap;
import java.util.List;

import com.ruoyi.project.order.orderPeople.domain.ProductCount;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.order.orderproductPlan.mapper.OrderproductPlanMapper;
import com.ruoyi.project.order.orderproductPlan.domain.OrderProductPlan;
import com.ruoyi.common.support.Convert;

/**
 * 订单关联计划--详细产品--关联分期id--关联保全 服务层实现
 * 
 * @author ruoyi
 * @date 2018-08-31
 */
@Service
public class OrderproductPlanServiceImpl implements IOrderproductPlanService 
{
	@Autowired
	private OrderproductPlanMapper orderproductPlanMapper;

	/**
     * 查询订单关联计划--详细产品--关联分期id--关联保全信息
     * 
     * @param id 订单关联计划--详细产品--关联分期id--关联保全ID
     * @return 订单关联计划--详细产品--关联分期id--关联保全信息
     */
    @Override
	public OrderProductPlan selectOrderproductPlanById(Integer id)
	{
	    return orderproductPlanMapper.selectOrderproductPlanById(id);
	}

	public String selectcheckPlanByName(String name,String orderid){
		int count=orderproductPlanMapper.selectcheckPlanByName(name,orderid);
		if (count > 0)
		{
			return "1";
		}
		return "0";
	}

	public String selectcheckCengjiByName(String name,String orderid){
		int count=orderproductPlanMapper.selectcheckCengjiByName(name,orderid);
		if (count > 0)
		{
			return "1";
		}
		return "0";
	}

	/**
     * 查询订单关联计划--详细产品--关联分期id--关联保全列表
     * 
     * @param orderproductPlan 订单关联计划--详细产品--关联分期id--关联保全信息
     * @return 订单关联计划--详细产品--关联分期id--关联保全集合
     */
	@Override
	public List<OrderProductPlan> selectOrderproductPlanList(OrderProductPlan orderproductPlan)
	{
	    return orderproductPlanMapper.selectOrderproductPlanList(orderproductPlan);
	}
	@Override
	public List<ProductCount> selectproductList(OrderProductPlan orderproductPlan)
	{
		return orderproductPlanMapper.selectproductList(orderproductPlan);
	}
	@Override
	public List<OrderProductPlan> selectProductGaoduan(String gaoduan,String orderid)
	{
		return orderproductPlanMapper.selectProductGaoduan(gaoduan,orderid);
	}

    /**
     * 新增订单关联计划--详细产品--关联分期id--关联保全
     * 
     * @param orderproductPlan 订单关联计划--详细产品--关联分期id--关联保全信息
     * @return 结果
     */
	@Override
	public int insertOrderproductPlan(OrderProductPlan orderproductPlan)
	{
	    return orderproductPlanMapper.insertOrderproductPlan(orderproductPlan);
	}

	/**
	 * 新增订单关联计划--详细产品--关联分期id--关联保全
	 *
	 * @param orderproductPlan 订单关联计划--详细产品--关联分期id--关联保全信息
	 * @return 结果
	 */
	@Override
	public int insertOrderproductPlanList(List<OrderProductPlan> orderproductPlan)
	{
		return orderproductPlanMapper.insertOrderproductPlanList(orderproductPlan);
	}
	
	/**
     * 修改订单关联计划--详细产品--关联分期id--关联保全
     * 
     * @param orderproductPlan 订单关联计划--详细产品--关联分期id--关联保全信息
     * @return 结果
     */
	@Override
	public int updateOrderproductPlan(OrderProductPlan orderproductPlan)
	{
	    return orderproductPlanMapper.updateOrderproductPlan(orderproductPlan);
	}

	/**
     * 删除订单关联计划--详细产品--关联分期id--关联保全对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteOrderproductPlanByIds(String ids)
	{
		return orderproductPlanMapper.deleteOrderproductPlanByIds(Convert.toStrArray(ids));
	}

	@Override
	public int addOrderproductPlan(HashMap<String, Object> map) {
		return orderproductPlanMapper.addOrderproductPlan(map);
	}

	@Override
	public int insertOrderProductPlanList(List<OrderProductPlan> orderProductPlanList) {
		return orderproductPlanMapper.insertOrderproductPlanList(orderProductPlanList);
	}

	@Override
	public int deleteOrderProductPlanByOrderProductId(String orderProductId) {
		return orderproductPlanMapper.deleteOrderProductPlanByOrderProductId(orderProductId);
	}

	@Override
	public List<OrderProductPlan> selectOrderProductPlanAll() {
		return orderproductPlanMapper.selectOrderProductPlanAll();
	}

}
