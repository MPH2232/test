package com.ruoyi.project.homepage.homepage.damain;

import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

import java.util.Date;

/**
 * 保险订单表 f_order
 * 
 * @author ruoyi
 * @date 2018-08-14
 */
public class OrderUser extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** id */
//	@Excel(name = "id")
	private Integer id;
	/** 订单编号 */
	@Excel(name = "订单编号")
	private String orderId;
	/** 状态（0正常 1作废） */
//	@Excel(name = "状态")
	private Integer status;
	/** 业务员 */
	@Excel(name = "业务员")
	private String userName;
	/** 业务员id */
//	@Excel(name = "业务员id")
	private Integer userId;
	/** 保险公司关联id */
//	@Excel(name = "保险公司关联id")
	private Integer insureId;
	/** 保险公司 */
	@Excel(name = "保险公司")
	private String insureCompany;
	private Long deptId;
	/** 所属部门 */
//	@Excel(name = "所属部门")
	private String teamName;
	/** 客户名称 */
	@Excel(name = "客户名称")
	private String customerName;
	/** 客户id */
//	@Excel(name = "客户id")
	private Integer customerId;
	/** 生效日期 */
	@Excel(name = "生效日期")
	private String startTime;
	/** 失效日期 */
	@Excel(name = "失效日期")
	private String endTime;
	/** 缴费方式（0一次交，1月缴，2季交，3半年交，4） */
	@Excel(name = "缴费方式")
	private String payMode;
	//调整后业务员
	@Excel(name = "调整后业务员")
	private String salesmanName;
	//调整后业务员id
	//@Excel(name = "调整后业务员id")
	private int salesmanId;
	//调整后业务员描述
	//@Excel(name = "调整后业务员")
	private String salesmanTrim;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getPayMode() {
		return payMode;
	}

	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}
	public Integer getInsureId() {
		return insureId;
	}

	public void setInsureId(Integer insureId) {
		this.insureId = insureId;
	}

	public String getInsureCompany() {
		return insureCompany;
	}

	public void setInsureCompany(String insureCompany) {
		this.insureCompany = insureCompany;
	}


	public String getSalesmanName() {
		return salesmanName;
	}

	public void setSalesmanName(String salesmanName) {
		this.salesmanName = salesmanName;
	}

	public int getSalesmanId() {
		return salesmanId;
	}

	public void setSalesmanId(int salesmanId) {
		this.salesmanId = salesmanId;
	}

	public String getSalesmanTrim() {
		return salesmanTrim;
	}

	public void setSalesmanTrim(String salesmanTrim) {
		this.salesmanTrim = salesmanTrim;
	}

	public Long getDeptId() {
		return deptId;
	}

	public void setDeptId(Long deptId) {
		this.deptId = deptId;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
}
