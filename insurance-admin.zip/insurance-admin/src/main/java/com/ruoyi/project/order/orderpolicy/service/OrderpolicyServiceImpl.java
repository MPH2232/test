package com.ruoyi.project.order.orderpolicy.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.order.orderpolicy.mapper.OrderpolicyMapper;
import com.ruoyi.project.order.orderpolicy.domain.Orderpolicy;
import com.ruoyi.project.order.orderpolicy.service.IOrderpolicyService;
import com.ruoyi.common.support.Convert;

/**
 * 订单关联保全管理 服务层实现
 * 
 * @author ruoyi
 * @date 2018-08-13
 */
@Service
public class OrderpolicyServiceImpl implements IOrderpolicyService 
{
	@Autowired
	private OrderpolicyMapper orderpolicyMapper;

	/**
     * 查询订单关联保全管理信息
     * 
     * @param id 订单关联保全管理ID
     * @return 订单关联保全管理信息
     */
    @Override
	public Orderpolicy selectOrderpolicyById(Integer id)
	{
	    return orderpolicyMapper.selectOrderpolicyById(id);
	}
	
	/**
     * 查询订单关联保全管理列表
     * 
     * @param orderpolicy 订单关联保全管理信息
     * @return 订单关联保全管理集合
     */
	@Override
	public List<Orderpolicy> selectOrderpolicyList(Orderpolicy orderpolicy)
	{
	    return orderpolicyMapper.selectOrderpolicyList(orderpolicy);
	}
	
    /**
     * 新增订单关联保全管理
     * 
     * @param orderpolicy 订单关联保全管理信息
     * @return 结果
     */
	@Override
	public int insertOrderpolicy(Orderpolicy orderpolicy)
	{
	    return orderpolicyMapper.insertOrderpolicy(orderpolicy);
	}
	
	/**
     * 修改订单关联保全管理
     * 
     * @param orderpolicy 订单关联保全管理信息
     * @return 结果
     */
	@Override
	public int updateOrderpolicy(Orderpolicy orderpolicy)
	{
	    return orderpolicyMapper.updateOrderpolicy(orderpolicy);
	}

	/**
     * 删除订单关联保全管理对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteOrderpolicyByIds(String ids)
	{
		return orderpolicyMapper.deleteOrderpolicyByIds(Convert.toStrArray(ids));
	}
	
}
