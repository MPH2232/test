package com.ruoyi.project.order.order.domain;

import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.web.domain.BaseEntity;

import java.util.Date;

/**
 * 保险订单表 f_order
 * 
 * @author ruoyi
 * @date 2018-08-14
 */
public class Order extends BaseEntity
{
	/** 保单识别码 */
	@Excel(name = "保单识别码")
	private String policyNum;
	/** 业务员 */
	@Excel(name = "业务员")
	private String userName;
	/** 保险公司 */
	@Excel(name = "保险公司")
	private String insureCompany;
	/** 客户名称 */
	@Excel(name = "客户名称")
	private String customerName;
	/** 客户类型 */
	@Excel(name = "客户类型")
	private Integer customerType;
	/** 客户来源，0新保，1续保，2渠道，3自行拓展，4客户介绍，5现有客户再开发 */
	@Excel(name = "客户来源")
	private Integer customerSo;
	/** 渠道名称 */
	@Excel(name = "渠道名称")
	private String channelName;
	/** 续保提醒日期 */
	@Excel(name = "续保提醒日期")
	private String xubaoTime;
	/** 生效日期 */
	@Excel(name = "生效日期")
	private String startTime;
	/** 失效日期 */
	@Excel(name = "失效日期")
	private String endTime;
	/** 缴费方式（0一次交，1月缴，2季交，3半年交，4） */
	@Excel(name = "缴费方式")
	private String payMode;
	/** 付费至（0保险公司。1fesco,2方胜） */
	@Excel(name = "付费至")
	private String payTo;

	/** id */
	@Excel(name = "id")
	private Integer id;
	/** 订单编号 */
	@Excel(name = "订单编号")
	private String orderId;
	/** 续保子订单编号 */
	@Excel(name = "续保子订单编号")
	private String renewId;
	/** 保单编号 */
	@Excel(name = "保单编号")
	private String policyId;
	/** 订单关联计划表详细表（包含多个产品） */
	@Excel(name = "订单关联计划表详细表")
	private String orderProductId;
	/** 保险公司关联id */
	@Excel(name = "保险公司关联id")
	private Integer insureId;
	/** 状态（0正常 1作废） */
	@Excel(name = "状态")
	private Integer status;
	/** 投保公司 */
	@Excel(name = "投保公司")
	private String toinsureCompany;
	/** 投保公司关联id */
	@Excel(name = "投保公司关联id")
	private Integer toinsureId;
	/** 备注 */
	@Excel(name = "备注")
	private String remark;
	/** 所属团队 */
	@Excel(name = "所属团队")
	private String teamName;
	/** 所属团队关联id */
	@Excel(name = "所属团队关联id")
	private Integer teamId;
	/** 业务员id */
	@Excel(name = "业务员id")
	private Integer userId;
	/** 客户id */
	@Excel(name = "客户id")
	private Integer customerId;
	/** 渠道id */
	@Excel(name = "渠道id")
	private Integer channelId;
	/** 保单人数 */
	@Excel(name = "保单人数")
	private Integer peopleNum;
	/** 业务员调整描述 */
	@Excel(name = "业务员调整描述")
	private String salesmanTrim;
	/** 保全表关联id（包括计划表id） */
	@Excel(name = "保全表关联id")
	private String policyUpdateId;
	/** 分期表关联id */
	@Excel(name = "分期表关联id")
	private String orderFenqiId;
	/** 所属部门 */
	@Excel(name = "所属部门")
	private String deptName;
	@Excel(name = "订单类型")
	//是0新保，1续保，2新保保全，3续保保全
	private int orderType;
	//订单的操作节点状态0基础信息，1计划，2上传投保资料，3上传人员清单，4生成订单，5保费认收，6寄送保险卡，7寄送保单，8完成订单
	private int orderNodeStatus;
	//调整后业务员
	private String salesmanName;
	//调整后业务员id
	private int salesmanId;
	private Long deptId;
	//是否为批量
	private String isBatch;
	//虚拟批单号
	private String batchNumber;

	private static final long serialVersionUID = 1L;

	public String getIsBatch() {
		return isBatch;
	}

	public void setIsBatch(String isBatch) {
		this.isBatch = isBatch;
	}

	public String getBatchNumber() {
		return batchNumber;
	}

	public void setBatchNumber(String batchNumber) {
		this.batchNumber = batchNumber;
	}

	public String getSalesmanName() {
		return salesmanName;
	}

	public void setSalesmanName(String salesmanName) {
		this.salesmanName = salesmanName;
	}

	public int getSalesmanId() {
		return salesmanId;
	}

	public void setSalesmanId(int salesmanId) {
		this.salesmanId = salesmanId;
	}

	public Long getDeptId() {
		return deptId;
	}

	public void setDeptId(Long deptId) {
		this.deptId = deptId;
	}

	public int getOrderNodeStatus() {
		return orderNodeStatus;
	}

	public void setOrderNodeStatus(int orderNodeStatus) {
		this.orderNodeStatus = orderNodeStatus;
	}

	public int getOrderType() {
		return orderType;
	}

	public void setOrderType(int orderType) {
		this.orderType = orderType;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public static long getSerialVersionUID() {
		return serialVersionUID;
	}

	/**
	 * 设置：id
	 */
	public void setId(Integer id) 
	{
		this.id = id;
	}
	
	/**
	 * 获取：id
	 */
	public Integer getId() 
	{
		return id;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	/**
	 * 设置：保单编号
	 */
	public void setPolicyId(String policyId)
	{
		this.policyId = policyId;
	}

	/**
	 * 获取：保单编号
	 */
	public String getPolicyId()
	{
		return policyId;
	}

	/**
	 * 设置：订单关联计划表详细表（包含多个产品）
	 */
	public void setOrderProductId(String orderProductId) 
	{
		this.orderProductId = orderProductId;
	}
	
	/**
	 * 获取：订单关联计划表详细表（包含多个产品）
	 */
	public String getOrderProductId() 
	{
		return orderProductId;
	}
	
	/**
	 * 设置：保险公司关联id
	 */
	public void setInsureId(Integer insureId)
	{
		this.insureId = insureId;
	}
	
	/**
	 * 获取：保险公司关联id
	 */
	public Integer getInsureId() 
	{
		return insureId;
	}
	
	/**
	 * 设置：保险公司
	 */
	public void setInsureCompany(String insureCompany) 
	{
		this.insureCompany = insureCompany;
	}
	
	/**
	 * 获取：保险公司
	 */
	public String getInsureCompany() 
	{
		return insureCompany;
	}
	
	/**
	 * 设置：状态（0正常 1作废）
	 */
	public void setStatus(Integer status) 
	{
		this.status = status;
	}
	
	/**
	 * 获取：状态（0正常 1作废）
	 */
	public Integer getStatus() 
	{
		return status;
	}
	
	/**
	 * 设置：投保公司
	 */
	public void setToinsureCompany(String toinsureCompany) 
	{
		this.toinsureCompany = toinsureCompany;
	}
	
	/**
	 * 获取：投保公司
	 */
	public String getToinsureCompany() 
	{
		return toinsureCompany;
	}
	
	/**
	 * 设置：投保公司关联id
	 */
	public void setToinsureId(Integer toinsureId) 
	{
		this.toinsureId = toinsureId;
	}
	
	/**
	 * 获取：投保公司关联id
	 */
	public Integer getToinsureId() 
	{
		return toinsureId;
	}
	/**
	 * 设置：备注
	 */
	public void setRemark(String remark) 
	{
		this.remark = remark;
	}
	
	/**
	 * 获取：备注
	 */
	public String getRemark() 
	{
		return remark;
	}
	
	/**
	 * 设置：所属团队
	 */
	public void setTeamName(String teamName) 
	{
		this.teamName = teamName;
	}
	
	/**
	 * 获取：所属团队
	 */
	public String getTeamName() 
	{
		return teamName;
	}
	
	/**
	 * 设置：所属团队关联id
	 */
	public void setTeamId(Integer teamId) 
	{
		this.teamId = teamId;
	}
	
	/**
	 * 获取：所属团队关联id
	 */
	public Integer getTeamId() 
	{
		return teamId;
	}
	
	/**
	 * 设置：业务员
	 */
	public void setUserName(String userName) 
	{
		this.userName = userName;
	}
	
	/**
	 * 获取：业务员
	 */
	public String getUserName() 
	{
		return userName;
	}
	
	/**
	 * 设置：业务员id
	 */
	public void setUserId(Integer userId) 
	{
		this.userId = userId;
	}
	
	/**
	 * 获取：业务员id
	 */
	public Integer getUserId() 
	{
		return userId;
	}
	
	/**
	 * 设置：客户名称
	 */
	public void setCustomerName(String customerName) 
	{
		this.customerName = customerName;
	}
	
	/**
	 * 获取：客户名称
	 */
	public String getCustomerName() 
	{
		return customerName;
	}
	
	/**
	 * 设置：客户id
	 */
	public void setCustomerId(Integer customerId) 
	{
		this.customerId = customerId;
	}
	
	/**
	 * 获取：客户id
	 */
	public Integer getCustomerId() 
	{
		return customerId;
	}
	
	/**
	 * 设置：客户类型
	 */
	public void setCustomerType(Integer customerType) 
	{
		this.customerType = customerType;
	}
	
	/**
	 * 获取：客户类型
	 */
	public Integer getCustomerType() 
	{
		return customerType;
	}
	
	/**
	 * 设置：渠道名称
	 */
	public void setChannelName(String channelName) 
	{
		this.channelName = channelName;
	}
	
	/**
	 * 获取：渠道名称
	 */
	public String getChannelName() 
	{
		return channelName;
	}
	
	/**
	 * 设置：渠道id
	 */
	public void setChannelId(Integer channelId) 
	{
		this.channelId = channelId;
	}
	
	/**
	 * 获取：渠道id
	 */
	public Integer getChannelId() 
	{
		return channelId;
	}
	
	/**
	 * 设置：客户来源，0新保，1续保，2渠道，3自行拓展，4客户介绍，5现有客户再开发
	 */
	public void setCustomerSo(Integer customerSo) 
	{
		this.customerSo = customerSo;
	}
	
	/**
	 * 获取：客户来源，0新保，1续保，2渠道，3自行拓展，4客户介绍，5现有客户再开发
	 */
	public Integer getCustomerSo() 
	{
		return customerSo;
	}
	
	/**
	 * 设置：保单识别码
	 */
	public void setPolicyNum(String policyNum) 
	{
		this.policyNum = policyNum;
	}
	
	/**
	 * 获取：保单识别码
	 */
	public String getPolicyNum() 
	{
		return policyNum;
	}

	public String getXubaoTime() {
		return xubaoTime;
	}

	public void setXubaoTime(String xubaoTime) {
		this.xubaoTime = xubaoTime;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	/**
	 * 设置：缴费方式（0一次交，1月缴，2季交，3半年交，4）
	 */
	public void setPayMode(String payMode) 
	{
		this.payMode = payMode;
	}
	
	/**
	 * 获取：缴费方式（0一次交，1月缴，2季交，3半年交，4）
	 */
	public String getPayMode() 
	{
		return payMode;
	}
	
	/**
	 * 设置：付费至（0保险公司。1fesco,2方胜）
	 */
	public void setPayTo(String payTo) 
	{
		this.payTo = payTo;
	}
	
	/**
	 * 获取：付费至（0保险公司。1fesco,2方胜）
	 */
	public String getPayTo() 
	{
		return payTo;
	}
	
	/**
	 * 设置：保单人数
	 */
	public void setPeopleNum(Integer peopleNum) 
	{
		this.peopleNum = peopleNum;
	}
	
	/**
	 * 获取：保单人数
	 */
	public Integer getPeopleNum() 
	{
		return peopleNum;
	}
	
	/**
	 * 设置：业务员调整描述
	 */
	public void setSalesmanTrim(String salesmanTrim) 
	{
		this.salesmanTrim = salesmanTrim;
	}
	
	/**
	 * 获取：业务员调整描述
	 */
	public String getSalesmanTrim() 
	{
		return salesmanTrim;
	}
	
	/**
	 * 设置：保全表关联id（包括计划表id）
	 */
	public void setPolicyUpdateId(String policyUpdateId) 
	{
		this.policyUpdateId = policyUpdateId;
	}
	
	/**
	 * 获取：保全表关联id（包括计划表id）
	 */
	public String getPolicyUpdateId() 
	{
		return policyUpdateId;
	}
	
	/**
	 * 设置：分期表关联id
	 */
	public void setOrderFenqiId(String orderFenqiId) 
	{
		this.orderFenqiId = orderFenqiId;
	}
	
	/**
	 * 获取：分期表关联id
	 */
	public String getOrderFenqiId() 
	{
		return orderFenqiId;
	}

	public String getRenewId() {
		return renewId;
	}

	public void setRenewId(String renewId) {
		this.renewId = renewId;
	}
}
