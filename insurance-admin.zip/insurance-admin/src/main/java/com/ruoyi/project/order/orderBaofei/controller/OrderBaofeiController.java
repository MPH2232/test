package com.ruoyi.project.order.orderBaofei.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.project.order.orderBaofei.domain.OrderBaofei;
import com.ruoyi.project.order.orderBaofei.service.IOrderBaofeiService;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.framework.web.domain.AjaxResult;

/**
 * 订单分期--关联计划id,--关联订单id--关联保全 信息操作处理
 * 
 * @author ruoyi
 * @date 2018-09-21
 */
@Controller
@RequestMapping("/order/orderBaofei")
public class OrderBaofeiController extends BaseController
{
    private String prefix = "order/orderBaofei";
	
	@Autowired
	private IOrderBaofeiService orderBaofeiService;
	
	@RequiresPermissions("order:orderBaofei:view")
	@GetMapping()
	public String orderBaofei()
	{
	    return prefix + "/orderBaofei";
	}
	
	/**
	 * 查询订单分期--关联计划id,--关联订单id--关联保全列表
	 */
	@RequiresPermissions("order:orderBaofei:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(OrderBaofei orderBaofei)
	{
		startPage();
        List<OrderBaofei> list = orderBaofeiService.selectOrderBaofeiList(orderBaofei);
		return getDataTable(list);
	}
	
	/**
	 * 新增订单分期--关联计划id,--关联订单id--关联保全
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存订单分期--关联计划id,--关联订单id--关联保全
	 */
	@RequiresPermissions("order:orderBaofei:add")
	@Log(title = "订单分期--关联计划id,--关联订单id--关联保全", action = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(OrderBaofei orderBaofei)
	{		
		return toAjax(orderBaofeiService.insertOrderBaofei(orderBaofei));
	}

	/**
	 * 修改订单分期--关联计划id,--关联订单id--关联保全
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		OrderBaofei orderBaofei = orderBaofeiService.selectOrderBaofeiById(id);
		mmap.put("orderBaofei", orderBaofei);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存订单分期--关联计划id,--关联订单id--关联保全
	 */
	@RequiresPermissions("order:orderBaofei:edit")
	@Log(title = "订单分期--关联计划id,--关联订单id--关联保全", action = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(OrderBaofei orderBaofei)
	{		
		return toAjax(orderBaofeiService.updateOrderBaofei(orderBaofei));
	}
	
	/**
	 * 删除订单分期--关联计划id,--关联订单id--关联保全
	 */
	@RequiresPermissions("order:orderBaofei:remove")
	@Log(title = "订单分期--关联计划id,--关联订单id--关联保全", action = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(orderBaofeiService.deleteOrderBaofeiByIds(ids));
	}
	
}
