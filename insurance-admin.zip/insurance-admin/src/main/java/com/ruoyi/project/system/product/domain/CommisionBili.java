package com.ruoyi.project.system.product.domain;

import java.util.Date;

/**
 * Created by x on 2018/9/11.
 */
public class CommisionBili {
    /*佣金比例id*/
    private Long id;
    /*产品名称*/
    private Long productId;
    /*佣金比例*/
    private String bili;
    /*佣金年度*/
    private String commisionYear;
    /*创建者*/
    private String createBy;
    /*创建时间*/
    private Date createTime;
    /*更新者*/
    private String updateBy;
    /*更新时间*/
    private Date updateTime;
    /*佣金数据集合*/
    private String chanpingList;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getBili() {
        return bili;
    }

    public void setBili(String bili) {
        this.bili = bili;
    }

    public String getCommisionYear() {
        return commisionYear;
    }

    public void setCommisionYear(String commisionYear) {
        this.commisionYear = commisionYear;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getChanpingList() {
        return chanpingList;
    }

    public void setChanpingList(String chanpingList) {
        this.chanpingList = chanpingList;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CommisionBili that = (CommisionBili) o;

        if (!id.equals(that.id)) return false;
        if (!productId.equals(that.productId)) return false;
        if (!bili.equals(that.bili)) return false;
        if (!commisionYear.equals(that.commisionYear)) return false;
        if (!createBy.equals(that.createBy)) return false;
        if (!createTime.equals(that.createTime)) return false;
        if (!updateBy.equals(that.updateBy)) return false;
        if (!updateTime.equals(that.updateTime)) return false;
        return chanpingList.equals(that.chanpingList);
    }

    @Override
    public int hashCode() {
        int result = id.hashCode();
        result = 31 * result + productId.hashCode();
        result = 31 * result + bili.hashCode();
        result = 31 * result + commisionYear.hashCode();
        result = 31 * result + createBy.hashCode();
        result = 31 * result + createTime.hashCode();
        result = 31 * result + updateBy.hashCode();
        result = 31 * result + updateTime.hashCode();
        result = 31 * result + chanpingList.hashCode();
        return result;
    }

    @Override
    public String toString() {
        return "CommisionBili{" +
                "id=" + id +
                ", productId=" + productId +
                ", bili='" + bili + '\'' +
                ", commisionYear='" + commisionYear + '\'' +
                ", createBy='" + createBy + '\'' +
                ", createTime=" + createTime +
                ", updateBy='" + updateBy + '\'' +
                ", updateTime=" + updateTime +
                ", chanpingList='" + chanpingList + '\'' +
                '}';
    }



}
