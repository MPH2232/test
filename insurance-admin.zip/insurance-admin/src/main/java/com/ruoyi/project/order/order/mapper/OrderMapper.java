package com.ruoyi.project.order.order.mapper;

import com.ruoyi.project.homepage.homepage.damain.Order1;
import com.ruoyi.project.order.order.domain.Order;
import org.apache.ibatis.annotations.Param;

import java.util.HashMap;
import java.util.List;

/**
 * 保险订单 数据层
 * 
 * @author ruoyi
 * @date 2018-08-13
 */
public interface OrderMapper 
{
	/**
     * 查询保险订单信息
     * 
     * @param id 保险订单ID
     * @return 保险订单信息
     */
	public Order selectOrderById(Integer id);
	public Order selectOrderByRenewId(String id);
	//1116
	public Order selectOrderByOrderId(String id);

	/**
     * 查询保险订单列表
     * 
     * @param order 保险订单信息
     * @return 保险订单集合
     */
	public List<Order> selectOrderList(Order order);
	
	/**
     * 新增保险订单
     * 
     * @param order 保险订单信息
     * @return 结果
     */
	public int insertOrder(Order order);
	
	/**
     * 修改保险订单
     * 
     * @param order 保险订单信息
     * @return 结果
     */
	public int updateOrder(Order order);

	/**
	 * 修改流程状态	 *
	 * @param status 保险订单信息
	 * @return 结果
	 */
	public int updateOrderStatus(@Param("orderid") int orderid, @Param("status") int status);

	/**
     * 删除保险订单
     * 
     * @param id 保险订单ID
     * @return 结果
     */
	public int deleteOrderById(Integer id);
	
	/**
     * 批量删除保险订单
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteOrderByIds(String[] ids);

	public int addOrder(HashMap<String,Object> map);




	/**
	 * 管理员
	 */
	public List<Order>selectOrderListInfoAdmin(int status);

	/**
	 * 主管
	 */
	public List<Order> selectOrderListInfozhu(@Param("deptId")long deptId, @Param("statu")long statu);

	/**
	 * 总监
	 */
	public List<Order> selectOrderListInfoMajordomo(@Param("deptId")long deptId,@Param("stat")long stat);

	/**
	 * 业务员
	 */
	public List<Order> selectOrderListInfoye(@Param("userIdd")long userIdd, @Param("statuss")long statuss);

	/*主管包含其他查询条件*/
	public List<Order> selectOrderListZhu(Order order);
	/*总监包含其他查询条件*/
	public List<Order> selectOrderListZongjian(Order order);

	public int insertOrderList(List<Order> orderList);

	public int deleteOrderByPolicyNum(String policyNum);

	public Order selectOrderIdByPolicyNum(@Param("policyNum") String policyNum);

	//调整业务员时修改接收人和描述
	public int updateSalesmanName(Order order);
	/**
	 * 查询保险订单列表
	 *
	 * @param order 保险订单信息
	 * @return 保险订单集合
	 */
	public List<Order> selectOrder(Order order);
}