package com.ruoyi.project.system.product.controller;

import com.ruoyi.common.utils.InsuranceCiUtil;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.project.system.product.domain.CommisionBili;
import com.ruoyi.project.system.product.domain.Feilv;
import com.ruoyi.project.system.product.domain.Product;

import com.ruoyi.project.system.product.service.IProductCommisionService;
import com.ruoyi.project.system.product.service.IProductFeilvService;
import com.ruoyi.project.system.product.service.IProductService;
import com.ruoyi.project.system.supplier1.domain.Supplier;
import com.ruoyi.project.system.supplier.service.ISupplierService;
import javafx.beans.binding.ListBinding;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

/**
 * 产品信息操作处理
 * 
 * @author ruoyi
 */
@Controller
@RequestMapping("/system/product")
public class ProductController extends BaseController
{
    private String prefix = "system/product";

    @Autowired
    private IProductService productService;
    @Autowired
    private ISupplierService supplierService;
    @Autowired
    private IProductFeilvService productFeilvService;
    @Autowired
    private IProductCommisionService productCommisionServices;

    /*
    * 产品首页展示
    */
    @RequiresPermissions("system:product:view")
    @GetMapping()
    public String operlog(Product product,ModelMap mmap)
    {
/*        List<Supplier> lists=supplierService.selectSupplierAll();
        mmap.put("lists",lists);*/
        List insuranceNames=productService.selectInsuranceName();
        mmap.put("insuranceNames",insuranceNames);
        List productTyPes=productService.selectProductTyPe();
        mmap.put("productTyPes",productTyPes);
        return prefix + "/product";
    }

    @RequiresPermissions("system:product:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Product product)
    {
        startPage();
        List<Product> list = productService.selectProductList(product);
        productService.judgement1(list);
        return getDataTable(list);
    }

    /*
    *产品信息删除
    */
    @RequiresPermissions("system:product:remove")
    @Log(title = "产品管理", action = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        try
        {
            return toAjax(productService.deleteProductByIds(ids));
        }
        catch (Exception e)
        {
            return error(e.getMessage());
        }
    }

    /**
     * 产品信息新增
     */
    @GetMapping("/add")
    public String add(Product product,ModelMap map)
    {

        List<Supplier> lists=supplierService.selectSupplierAll();
        int id = productService.selectMaxId()+1;
        for (int i=0;i<lists.size();i++) {
            Supplier supplier=lists.get(i);
            if("1".equals(supplier.getStatus())){
               lists.remove(i);
            }
        }
        map.put("lists",lists);
        map.put("id",id);
        return prefix + "/add";
    }

    @RequiresPermissions("system:product:add")
    @Log(title = "产品管理", action = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Product product,CommisionBili commisions) {
        int su=0;
        product.setPcBili(productService.transform2(product.getPcBili()));
        product.setMemberBili(productService.transform2(product.getMemberBili()));
        int m=productService.insertProduct(product);
        JSONArray jsonchanping = JSONArray.fromObject(commisions.getChanpingList());
        List<CommisionBili> commisionBilis = new ArrayList<CommisionBili>();
        CommisionBili comm = new CommisionBili();
        int j = 1;
        for (int i = 0; i < jsonchanping.size(); i++) {
            comm.setProductId(product.getProductId());
            JSONObject jo = JSONObject.fromObject(jsonchanping.get(i));
            String name = jo.getString("name");
            String value = jo.getString("value");
            if (name.contains("bili")) {
                comm.setBili(productService.transform2(value));
            }
            if (name.contains("commisionYear")) {
                comm.setCommisionYear(value);
            }
            if (j % 2 == 0) {
                commisionBilis.add(comm);
                comm = new CommisionBili();
            }
            j++;
        }
        comm = null;
        int k=productCommisionServices.insertCommisionBiliList(commisionBilis);
        su=m*k;
        return toAjax(su);
    }


    /**
     * 查询指定保险公司下的产品
     */
    @PostMapping("/select")
    @ResponseBody
    public List select(Product product,ModelMap map)
    {
        List<Product> lists = productService.selectProductList(product);
        map.put("lists",lists);
        return lists;
    }

    /**
     * 查询产品是否有费率
     */
    @PostMapping("/selectfeilv")
    @ResponseBody
    public AjaxResult selectfeilv(Product product,ModelMap map)
    {

       int counts = productService.selectProductFeilv(product);
//        map.put("lists",lists);
        AjaxResult json = new AjaxResult();
        if(counts>0){
            //有费率
            json.put("code", 1);
            json.put("msg", "有费率");
        }else{
            //没有费率表
            json.put("code", 0);
            json.put("msg", "没有费率");
        }
        return json;
    }

    /**
     * 产品信息编辑
     */
    @GetMapping("/edit/{productId}")
    public String edit(@PathVariable("productId") String productId,ModelMap mmap,Product product)
    {
        List<Supplier> lists=supplierService.selectSupplierAll();
        mmap.put("lists",lists);
        mmap.put("product", productService.judgement2(productId));
/*        List<CommisionBili> commisionBilis= productCommisionServices.selectCommisionBiliInfo(Long.valueOf(productId));
        System.out.println(commisionBilis);
        mmap.put("commisionBilis",commisionBilis);*/
        return prefix + "/edit";
    }

    @RequiresPermissions("system:product:edit")
    @Log(title = "产品管理", action = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Product product,ModelMap mmap)
    {
        System.out.println(product.toString());
        return toAjax(productService.updateProduct(product));
    }

    /*
    *产品信息查看
    */
    @GetMapping("/query/{productId}")
    public String query(@PathVariable("productId") String productId, ModelMap mmap)
    {
        mmap.put("product", productService.judgement4(productId));
        return prefix + "/query";
    }

    @RequiresPermissions("system:product:query")
    @Log(title="产品管理",action=BusinessType.UPDATE)
    @PostMapping("/query")
    @ResponseBody
    public AjaxResult query(Product product){
        return toAjax(productService.updateProduct(product));

    }

    /*
    *将页面信息以excel格式导出
    */
    @Log(title = "产品管理", action = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Product product) throws Exception
    {
        try
        {
            List<Product> list = productService.selectProductList(product);
            ExcelUtil<Product> util = new ExcelUtil<Product>(Product.class);
            return util.exportExcel(list, "product");
        }
        catch (Exception e)
        {
            return error("导出Excel失败，请联系网站管理员！");
        }
    }

    /**
     * 查询标准费率详细
     */
    @RequiresPermissions("system:product:list")
    @GetMapping("/detail/{productId}")
    public String detail(@PathVariable("productId") Long productId, ModelMap mmap)
    {
        mmap.put("product", productService.selectProductById(productId));
        mmap.put("productList", productService.selectProductAll());
        return "system/product/data/data";
    }

    /**
     * 查询定制费率详细
     */
    @RequiresPermissions("system:product:list")
    @GetMapping("/detail2/{productId}")
    public String detail2(@PathVariable("productId") Long productId, ModelMap mmap)
    {
        mmap.put("product", productService.selectProductById(productId));
        mmap.put("productList", productService.selectProductAll());
        return "system/product/data/data2";
    }

    /**
     * 订单跳转到费率详细页面
     */
    @RequiresPermissions("system:product:list")
    @GetMapping("/uploadfeilv/{productId}")
    public String uploadfeilv(@PathVariable("productId") Long productId, ModelMap mmap)
    {
        Product   product =productService.selectProductById(productId);
        mmap.put("product", product);
        mmap.put("productList", productService.selectProductAll());
        if( product.getProductPro().equals("标准")){
            return "system/product/data/data";
        }else{
            return "system/product/data/data2";
        }
    }

    /**
     * 校验产品名称唯一性
     */
    @PostMapping("/checkProductUnique")
    @ResponseBody
    public String checkProductUnique(Product product)
    {
        String uniqueFlag = "0";
        if (product != null)
        {
            uniqueFlag = productService.checkProductUnique(product);
        }
        return uniqueFlag;
    }

    /**
     * 查看产品佣金信息
     */
    @RequiresPermissions("system:product:commision")
    @GetMapping("/commision/{productId}")
    public String check(@PathVariable("productId") Long productId, ModelMap mmap) {
        Product product= productService.selectProductById(productId);
        System.out.println(product.getProductName());
        mmap.put("product", product);
        List<CommisionBili> commisionBilis= productCommisionServices.selectCommisionBiliInfo(product.getProductId());
        System.out.println(commisionBilis);
        mmap.put("commisionBilis",commisionBilis);
        return prefix + "/commision";
    }

    /*修改产品佣金信息*/
    @RequiresPermissions("system:product:commision")
    @Log(title = "佣金信息", action = BusinessType.UPDATE)
    @PostMapping("/commision")
    @ResponseBody
    public AjaxResult edit(Product product,CommisionBili commisions) {
        System.out.println(product.getProductId());
        System.out.println(commisions);
        JSONArray jsonchanping = JSONArray.fromObject(commisions.getChanpingList());
        List<CommisionBili> commisionBilis = new ArrayList<CommisionBili>();
        CommisionBili comm = new CommisionBili();
        int j = 1;
        for (int i = 0; i < jsonchanping.size(); i++) {
            comm.setProductId(product.getProductId());
            JSONObject jo = JSONObject.fromObject(jsonchanping.get(i));
            String name = jo.getString("name");
            String value = jo.getString("value");
            if (name.contains("id")) {
                comm.setId(Long.parseLong(value));
            }
            if (name.contains("bili")) {
                comm.setBili(productService.transform2(value));
            }
            if (name.contains("commisionYear")) {
                comm.setCommisionYear(value);
            }
            if (j % 3 == 0) {
                commisionBilis.add(comm);
                comm = new CommisionBili();
            }
            j++;
        }
        comm = null;
        System.out.println(commisionBilis);
        int x=productCommisionServices.updateCommisionBili(commisionBilis);
        return toAjax(x);
    }

    @PostMapping("/findInsuranceCi")
    @ResponseBody
    public String findPremiumBank(Product product){
        String title= InsuranceCiUtil.getInsuranceCi(product.getProductKind());
        return title;
    }


}
