package com.ruoyi.project.system.product.service;

import com.ruoyi.common.utils.NewFileUploadUtils;
import com.ruoyi.common.utils.poi.ExcelProductUtil;
import com.ruoyi.project.system.product.domain.FeilvComplex;
import com.ruoyi.project.system.product.mapper.ProductFeilvComplexMapper;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.security.PublicKey;
import java.util.Date;
import java.util.HashMap;
import java.util.List;


/**
 * Created by x on 2018/8/7.
 */
@Service
public class ProductFeilvComplexServiceImpl implements IProductFeilvComplexService {
    @Autowired
    private ProductFeilvComplexMapper productFeilvComplexMapper;
    @Override
    public List<FeilvComplex> selectFeilvComplexList(Long productId){
        return productFeilvComplexMapper.selectFeilvComplexList(productId);
    }

    @Transactional
    public String batchImport(FeilvComplex feilvComplex, MultipartFile mfile) {
        String msg="";
        //初始化输入流
        InputStream is = null;
        try{
            is = mfile.getInputStream();
            Workbook book = null;
            if(NewFileUploadUtils.isExcel2003(mfile.getOriginalFilename())){
                book = new HSSFWorkbook(is);
            }else{
                book = new XSSFWorkbook(is);
            }
            //根据excel里面的内容读取知识库信息
            ExcelProductUtil excelProductUtil = new ExcelProductUtil();
            msg = excelProductUtil.readExcel(book,feilvComplex);
        }catch(Exception e){
            e.printStackTrace();
        } finally{
            if(is !=null)
            {
                try{
                    is.close();
                }catch(IOException e){
                    is = null;
                    e.printStackTrace();
                }
            }
        }
        return msg;
    }

    @Override
    public int insertFeilvComplex(FeilvComplex feilvComplex) {
        return productFeilvComplexMapper.insertFeilvComplex(feilvComplex);
    }

    @Override
    public int deleteFeilvComplexByProductId(Long productId) {
        return productFeilvComplexMapper.deleteFeilvComplexByProductId(productId);
    }

    @Override
    public List<FeilvComplex> selectFeilvComplexList1(FeilvComplex feilvComplex) {
        return productFeilvComplexMapper.selectFeilvComplexList1(feilvComplex);
    }

    @Override
    public int insertFeilvComplexList(List<FeilvComplex> feilvComplexList) {
        return productFeilvComplexMapper.insertFeilvComplexList(feilvComplexList);
    }

    @Override
    public int deleteFeilvComplexByProductIdAndEndTime(Long productId, Date endTime) {
        return productFeilvComplexMapper.deleteFeilvComplexByProductIdAndEndTime(productId, endTime);
    }


}






