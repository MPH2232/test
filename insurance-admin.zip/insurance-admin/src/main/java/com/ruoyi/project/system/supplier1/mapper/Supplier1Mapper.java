package com.ruoyi.project.system.supplier1.mapper;

import com.ruoyi.project.system.supplier1.domain.Supplier;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * 字典表 数据层
 * 
 * @author ruoyi
 */
@Mapper
public interface Supplier1Mapper
{
    /**
     * 查询供应商数据集合
     *
     * @param supplier 供应商信息
     * @return 供应商数据集合
     */
    public List<Supplier> selectSupplierList(Supplier supplier);

    /**
     * 查询所有供应商
     *
     * @return 供应商列表
     */
    public List<Supplier> selectSupplierAll();

    /**
     * 根据用户ID查询供应商
     *
     * @param userId 用户ID
     * @return 供应商列表
     */
    // public List<Supplier1> selectSuppliersByUserId(Long userId);

    /**
     * 通过供应商ID查询供应商信息
     *
     * @param supplierId 供应商ID
     * @return 角色对象信息
     */
    public Supplier selectSupplierById(Long supplierId);

    /**
     * 批量删除供应商信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteSupplierByIds(Long[] ids);

    /**
     * 修改供应商信息
     *
     * @param supplier 供应商信息
     * @return 结果
     */
    public int updateSupplier(Supplier supplier);

    /**
     * 修改供应商状态
     * @param supplier
     * @return
     */
    public int updateSupplierStatus(Supplier supplier);

    /**
     * 新增供应商信息
     *
     * @param supplier 供应商信息
     * @return 结果
     */
    public int insertSupplier(Supplier supplier);

    /**
     * 校验供应商名称是否唯一
     *
     * @return 结果
     */
    public Supplier checkSupplierNameUnique(String supplierName);

    public Supplier selectPaytaxesBankBysupplierName(String supplierName);

}
