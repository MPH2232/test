package com.ruoyi.project.homepage.homepage.service;

import com.ruoyi.project.homepage.homepage.damain.AdjustUser;
import com.ruoyi.project.homepage.homepage.damain.NewsAgency;

import java.util.List;

/**
 * Created by x on 2018/9/17.
 */
public interface IAdjustUserService {


    /**
     * 通过业务员id查询业务员调整信息
     * @param proposerId
     * @return
     */
    public AdjustUser selectAdjustUserByBuserId(Integer buserId);


    /**
     * 通过name查询业务员调整
     * @param proposerName
     * @return
     */
    public AdjustUser selectAdjustUserByName(String proposerName );

    /**
     * 插入业务员调整信息
     * @param adjustUser
     * @return
     */
    public int insertAdjustUser(AdjustUser adjustUser);

}
