package com.ruoyi.project.finance.finance.service;

import com.ruoyi.common.support.Convert;
import com.ruoyi.common.utils.NewFileUploadUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.project.finance.finance.domain.Finance;
import com.ruoyi.project.finance.finance.mapper.FinanceMapper;
import com.ruoyi.project.order.orderPeople.domain.OrderPeople;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.notice.domain.Notice;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;



@Service
public class FinanceServiceImpl implements IFinanceService
{
    @Autowired
    private FinanceMapper financeMapper;

    /**
     * 查询认收清单信息
     * @param finance
     */
    @Override
    public List<Finance> selectFinaceList(Finance finance) {
        System.out.println(finance.getFinanceStatus());
        return financeMapper.selectFinanceList(finance);
    }

    @Override
    public Finance selectFinanceById(Long id) {
        return financeMapper.selectFinanceById(id);
    }

    /**
     * 为认款清单新增
     */
    @Override
    public int insertFinance(Finance finance) {
        return financeMapper.insertFinance(finance);
    }

    /**
     * 修改认款清单
     */
    @Override
    public int updateFinance(Finance finance) {
        return financeMapper.updateFinance(finance);
    }
    //删除
    @Override
    public int deleteFinanceByIds(String ids) {
        return financeMapper.deleteFinanceByIds(Convert.toStrArray(ids));
    }


    /**
     * 上传excel文件到临时目录后并开始解析
     * @param finance
     * @param mfile
     * @return
     */
    @Transactional
    public String batchImport(Finance finance, MultipartFile mfile){
        //初始化输入流
        InputStream is = null;
        try{
            //将上传的文件写入新建的文件中
            is = mfile.getInputStream();
            Workbook book = null;
            if(NewFileUploadUtils.isExcel2003(mfile.getOriginalFilename())){
                book = new HSSFWorkbook(is);
            }else{
                book = new XSSFWorkbook(is);
            }
            //根据excel里面的内容读取知识库信息
            return readExcelValue(book,finance);
        }catch(Exception e){
            e.printStackTrace();
        } finally{
            if(is !=null)
            {
                try{
                    is.close();
                }catch(IOException e){
                    is = null;
                    e.printStackTrace();
                }
            }
        }
        return "导入出错！请检查数据格式！";
    }


    /**
     * 解析Excel里面的数据
     * @param wb
     * @return
     */
    private String readExcelValue(Workbook wb,Finance finances) {

        //错误信息接收器
        String errorMsg = "";
        //得到第一个shell
        Sheet sheet = wb.getSheetAt(0);
        //得到Excel的行数
        int totalRows = sheet.getPhysicalNumberOfRows();
        //总列数
        int totalCells = 0;
        //得到Excel的列数(前提是有行数)，从第2行算起
        if (totalRows >= 2 && sheet.getRow(1) != null) {
            totalCells = sheet.getRow(1).getLastCellNum();
        }
        List<Finance> userKnowledgeBaseList = new ArrayList<Finance>();
        Finance finance;
//        String financeid="";
        String br = "<br/>";

        //循环Excel行数,从第2行开始。标题不入库
        for (int r = 1; r < totalRows; r++) {
            String rowMessage = "";
            Row row = sheet.getRow(r);
            if (row == null) {
                errorMsg += br + "第" + (r + 1) + "行数据有问题，请仔细检查！";
                continue;
            }

            finance = new Finance();
//            financeid=finances.getId();
//            orderPeople.setOrderId(orderPeoples.getOrderId());
//            orderPeople.setOrderType(orderPeoples.getOrderType());
            //循环Excel的列
            for (int c = 0; c < totalCells; c++) {
                Cell cell = row.getCell(c);
                if (null != cell) {
                    row.getCell(c).setCellType(Cell.CELL_TYPE_STRING);
                    if (c == 0) {
                        //记账日期
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "记账日期不能为空；";
                        } else if (cell.getStringCellValue().length() > 60) {
                            rowMessage += "记账日期的字数不能超过60；";
                        }
                        finance.setAccountingDate(cell.getStringCellValue());
                    } else if (c == 1) {
                        //对方户名
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "对方户名不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "对方户名1000；";
                        }
                        finance.setAccountTitle(cell.getStringCellValue());
                    }else if (c == 2) {
                        //收入金额
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "收入金额不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "收入金额；";
                        }
                        finance.setCredit(cell.getStringCellValue());
                    }else if (c == 3) {
                        //摘要
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "摘要不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "摘要1000；";
                        }
                        finance.setDigest(cell.getStringCellValue());
                    }else if (c == 4) {
                        //附言
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "附言不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "附言1000；";
                        }
                        finance.setPostscript(cell.getStringCellValue());
                    }
//                    else if (c == 5) {
//                        //证件号
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessage += "证件号不能为空；";
//                        } else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessage += "证件号的字数不能超过1000；";
//                        }
//                        finance.setStatus(cell.getStringCellValue());
//                    }
                } else {
                    rowMessage += "第" + (c + 1) + "列数据有问题，请仔细检查；";
                }
            }
            //拼接每行的错误提示
            if (!StringUtils.isEmpty(rowMessage)) {
                errorMsg += br + "第" + (r + 1) + "行，" + rowMessage;
            } else {
                userKnowledgeBaseList.add(finance);
            }
        }

        //全部验证通过才导入到数据库
        if (StringUtils.isEmpty(errorMsg)) {
            for (Finance userKnowledgeBase : userKnowledgeBaseList) {
                this.insertFinance(userKnowledgeBase);
            }
            errorMsg = "导入成功，共" + userKnowledgeBaseList.size() + "条数据！";
        }
        return errorMsg;
    }






}

