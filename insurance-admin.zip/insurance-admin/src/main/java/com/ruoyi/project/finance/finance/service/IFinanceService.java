package com.ruoyi.project.finance.finance.service;

import com.ruoyi.project.finance.finance.domain.Finance;
import com.ruoyi.project.order.orderPeople.domain.OrderPeople;
import com.ruoyi.project.system.notice.domain.Notice;
import org.springframework.web.multipart.MultipartFile;


import java.util.List;

/**
 * 公告 服务层
 * 
 * @author ruoyi
 */
public interface IFinanceService {
    /**
     * 查询认收清单信息
     * @param finace
     */
    public List<Finance> selectFinaceList(Finance finace);

    /**
     * 查询认款清单信息
     */
    public Finance selectFinanceById(Long id);


    /**
     * 未认款清单新增
     */
    public int insertFinance(Finance finance);


    /**
     * 修改未认款清单
     */
    public int updateFinance(Finance finance);

    /**
     * 上传excel文件到临时目录后并开始解析
     * @param finance
     * @param mfile
     * @return
     */
    public String batchImport(Finance finance, MultipartFile mfile);


    /**
     * 删除
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteFinanceByIds(String ids) throws Exception;




//
//    /**
//     * 修改公告
//     *
//     * @param notice 公告信息
//     * @return 结果
//     */
//    public int updateNotice(Notice notice);




}
