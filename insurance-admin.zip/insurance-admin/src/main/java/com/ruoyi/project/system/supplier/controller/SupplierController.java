package com.ruoyi.project.system.supplier.controller;

import com.ruoyi.common.support.Convert;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.project.system.supplier1.domain.Protocol;
import com.ruoyi.project.system.supplier1.domain.Supplier;
import com.ruoyi.project.system.supplier.service.ISupplierService;
import com.ruoyi.project.system.supplier.util.FileUtil;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


/**
 * 供应商信息操作处理
 * 
 * @author ruoyi
 */
@Controller
@RequestMapping("/system/supplier")
public class SupplierController extends BaseController
{
    private String prefix = "system/supplier";

    @Autowired
    private ISupplierService supplierService;

    @RequiresPermissions("system:supplier:view")
    @GetMapping()
    public String operlog()
    {
        return prefix + "/supplier";
    }

    @RequiresPermissions("system:supplier:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Supplier supplier)
    {
        startPage();
        List<Supplier> list = supplierService.selectSupplierList(supplier);
        return getDataTable(list);
    }

    @Log(title = "供应商", action = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Supplier supplier) throws Exception
    {
        try
        {
            List<Supplier> list = supplierService.selectSupplierList(supplier);
            ExcelUtil<Supplier> util = new ExcelUtil<Supplier>(Supplier.class);
            return util.exportExcel(list, "supplier");
        }
        catch (Exception e)
        {
            return error("导出Excel失败，请联系网站管理员！");
        }
    }

    @RequiresPermissions("system:supplier:remove")
    @Log(title = "供应商", action = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        try
        {
            return toAjax(supplierService.deleteSupplierByIds(ids));
        }
        catch (Exception e)
        {
            return error(e.getMessage());
        }
    }

    /**
     * 新增供应商
     */
    @GetMapping("/add")
    public String add()
    {
        return prefix + "/add";
    }

    /**
     * 新增保存供应商
     */
    @RequiresPermissions("system:supplier:add")
    @Log(title = "供应商", action = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Supplier supplier)
    {
//        JSONObject jsonObject = JSONObject.parseObject(protocol.getProtocolDetailed());
//        JSONObject jsonObject = JSONObject.fromObject(supplier.getXieyiList());
        JSONArray jsonxieyi = JSONArray.fromObject(supplier.getXieyiList());
        List<Protocol> protocols=new ArrayList<Protocol>();
        Protocol pro=new Protocol();
        int j=1;
        for(int i=0;i<jsonxieyi.size();i++){
            JSONObject jo = JSONObject.fromObject(jsonxieyi.get(i));
            //[{"name":"sup","value":"0"},{"name":"protocolTime","value":"20180810"},{"name":"type1","value":"1"},{"name":"protocolTime1","value":"20180810"}]
            String name = jo.getString("name");
            String value = jo.getString("value");
            if(name.contains("sup")){
                pro.setProtocolType(value);
            }else if(name.contains("file")){
                pro.setProtocolFile(value);
            }else{
                DateFormat format = new SimpleDateFormat("yyyyMMdd");
                try {
                    pro.setProtocolTime(format.parse(value));
                } catch (ParseException e) {
                    e.printStackTrace();
                };
            }
            if(j%2==0){
                protocols.add(pro);
                pro=new Protocol();
            }
            j++;
        }
        pro=null;
        return toAjax(supplierService.insertProtocolList(supplier,protocols));
    }

    /**
     * 修改供应商
     */
    @GetMapping("/edit/{supplierId}")
    public String edit(@PathVariable("supplierId") Long supplierId, ModelMap mmap)
    {
//        mmap.put("supplier", supplierService.selectSupplierById(supplierId));
        Supplier supplier=new Supplier();
        supplier= supplierService.selectSupplierById(supplierId);
        mmap.put("supplier",supplier);
        mmap.put("protocol", supplierService.selectProtocolList(supplier.getProtocolId()));
        return prefix + "/edit";
    }

    /**
     * 修改保存供应商
     */
    @RequiresPermissions("system:supplier:edit")
    @Log(title = "供应商", action = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Supplier supplier)
    {
        return toAjax(supplierService.updateSupplier(supplier));
    }

    /**
     * 查看供应商
     */
    @GetMapping("/look/{supplierId}")
    public String look(@PathVariable("supplierId") Long supplierId, ModelMap mmap)
    {
        Supplier supplier=new Supplier();
        supplier= supplierService.selectSupplierById(supplierId);
        mmap.put("supplier",supplier);
        mmap.put("protocol", supplierService.selectProtocolList(supplier.getProtocolId()));
        return prefix + "/look";
    }

    /**
     * 查看保存供应商
     */
    @RequiresPermissions("system:supplier:look")
    @Log(title = "供应商", action = BusinessType.UPDATE)
    @PostMapping("/look")
    @ResponseBody
    public AjaxResult look(Supplier supplier)
    {
        return toAjax(supplierService.updateSupplier(supplier));
    }



    //跳转到上传文件的页面
    @RequestMapping(value="/gouploadimg", method = RequestMethod.GET)
    public String goUploadImg() {
        //跳转到 templates 目录下的 uploadimg.html
        return "uploadimg";
    }

    //处理文件上传
    @RequestMapping(value="/testuploadimg", method = RequestMethod.POST)
    @ResponseBody
    public String uploadImg(@RequestParam("file") MultipartFile file, HttpServletRequest request) {
        String contentType = file.getContentType();
        String fileName = file.getOriginalFilename();
        System.out.println("fileName-->" + fileName);
        System.out.println("getContentType-->" + contentType);
        String filePath = request.getSession().getServletContext().getRealPath("imgupload/");
        try {
            FileUtil.uploadFile(file.getBytes(), filePath, fileName);
        } catch (Exception e) {
            // TODO: handle exception
        }
        //返回json
        return "uploadimg success";
    }

    @InitBinder
    public void initBinder(WebDataBinder binder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
    }
}
