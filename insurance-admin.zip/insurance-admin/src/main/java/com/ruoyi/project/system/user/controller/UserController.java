package com.ruoyi.project.system.user.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.project.homepage.homepage.damain.AdjustUser;
import com.ruoyi.project.system.adjust.service.IAdjustService;
import com.ruoyi.project.system.dept.domain.Dept;
import com.ruoyi.project.system.dept.service.IDeptService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.project.system.post.service.IPostService;
import com.ruoyi.project.system.role.service.IRoleService;
import com.ruoyi.project.system.user.domain.User;
import com.ruoyi.project.system.user.service.IUserService;

/**
 * 用户信息
 * 
 * @author ruoyi
 */
@Controller
@RequestMapping("/system/user")
public class UserController extends BaseController
{
    private String prefix = "system/user";

    @Autowired
    private IUserService userService;

    @Autowired
    private IRoleService roleService;

    @Autowired
    private IPostService postService;
    @Autowired
    private IDeptService deptService;
    @Autowired
    private IAdjustService adjustService;

    @RequiresPermissions("system:user:view")
    @GetMapping()
    public String user(ModelMap mmap)
    {
        User users=getUser();
        String name= userService.selectUserRoleGroup(users.getUserId());
        mmap.put("role", name);
        return prefix + "/user";
    }

    @RequiresPermissions("system:user:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(User user)
    {

        User users=getUser();
        List<User> list = new ArrayList<User>();
        String name= userService.selectUserRoleGroup(users.getUserId());
        startPage();
        Boolean deptUp=false;
        if(name.contains("管理员")){

            if(user.getParentId()!=null && user.getParentId()==100 ){

                list = userService.selectUserListZongjian(user);
            }else{
                list = userService.selectUserList(user);
            }
        }else if(name.contains("总监")){
           List<Dept> listDp = userService.selectDeptList(users.getDeptId());
            String ance =listDp.get(0).getAncestors();
            String[] anceList=ance.split(",");
            for(int i=0;i<anceList.length;i++){
                if(user.getDeptId()==null){
                    deptUp=true;
                }
                if( String.valueOf(user.getDeptId()).equals(anceList[i])){
                    deptUp=true;
                }
            }
            if(deptUp){
                //根据登录用户的deptId
                user.setDeptId(users.getDeptId());
                list = userService.selectUserListZongjian(user);
            }else{
                //根据点击传入的deptId
                list = userService.selectUserListZongjian(user);
            }
//            tree = deptService.selectDeptChildList(user.getDeptId());
        }else if(name.contains("主管")){
            //主管根据自己部门id查询数据
            user.setDeptId(users.getDeptId());
            user.setParentId(users.getDeptId());
            list = userService.selectUserList(user);
//            tree = deptService.selectDeptTree();
        }else if(name.contains("业务员")){
            //业务员只能看到自己
            User userId=new User();
            userId.setUserId(users.getUserId());
            list = userService.selectUserList(userId);
//            tree = deptService.selectDeptTree();
        }else{
            list = userService.selectUserList(user);
        }

        return getDataTable(list);
    }

    @Log(title = "用户管理", action = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(User user) throws Exception
    {
        try
        {
            List<User> list = userService.selectUserList(user);
            ExcelUtil<User> util = new ExcelUtil<User>(User.class);
            return util.exportExcel(list, "user");
        }
        catch (Exception e)
        {
            return error("导出Excel失败，请联系网站管理员！");
        }
    }

    /**
     * 新增用户
     */
    @GetMapping("/add")
    public String add(ModelMap mmap)
    {
        mmap.put("roles", roleService.selectRoleAll());
        mmap.put("posts", postService.selectPostAll());
        return prefix + "/add";
    }

    /**
     * 新增保存用户
     */
    @RequiresPermissions("system:user:add")
    @Log(title = "用户管理", action = BusinessType.INSERT)
    @PostMapping("/add")
    @Transactional(rollbackFor = Exception.class)
    @ResponseBody
    public AjaxResult addSave(User user)
    {
        if (StringUtils.isNotNull(user.getUserId()) && User.isAdmin(user.getUserId()))
        {
            return error("不允许修改超级管理员用户");
        }
        user.setEntryTime(  DateUtils.dateTime("yyyy-MM-dd",   user.getStartTimeStr()));
        return toAjax(userService.insertUser(user));
    }
    /**
     * 查看用户
     */
    @GetMapping("/query/{userId}")
    public String query(@PathVariable("userId") Long userId, ModelMap mmap)
    {
        mmap.put("user", userService.selectUserById(userId));
        mmap.put("roles", roleService.selectRolesByUserId(userId));
        mmap.put("posts", postService.selectPostsByUserId(userId));
        return prefix + "/query";
    }

    /**
     * 修改用户
     */
    @GetMapping("/edit/{userId}")
    public String edit(@PathVariable("userId") Long userId, ModelMap mmap)
    {
        mmap.put("user", userService.selectUserById(userId));
        mmap.put("roles", roleService.selectRolesByUserId(userId));
        mmap.put("posts", postService.selectPostsByUserId(userId));
        return prefix + "/edit";
    }

    /**
     * 修改保存用户
     */
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(User user)  {
        if (StringUtils.isNotNull(user.getUserId()) && User.isAdmin(user.getUserId()))
        {
            return error("不允许修改超级管理员用户");
        }
        if("1".equals(user.getStatus())){
            user.setDepartureTime(DateUtils.dateTime("yyyy-MM-dd",  user.getEndTimeStr()));
            AdjustUser adjustUser = new AdjustUser();
            adjustUser.setBefUser(user.getUserName());
            adjustUser.setBuserId(user.getUserId());
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
          //  Date startTime = new SimpleDateFormat("yyyy-MM-dd").parse(user.getDepartureTime()));
           adjustUser.setAdjustDate(String.valueOf(user.getDepartureTime()));
            adjustUser.setDeptId(user.getDeptId());
            //部门
            deptService.selectDeptName(user.getDeptId()).getDeptName();
            adjustUser.setDeptName(deptService.selectDeptName(user.getDeptId()).getDeptName());
            //获取职级
            adjustUser.setPostName( userService.selectUserRoleGroup(user.getUserId()));
            adjustUser.setParentId(user.getParentId());
            adjustUser.setPhoneNum(user.getPhonenumber());
            adjustUser.setAdjustStatus("未调整");
            adjustService.insertAdjustUser(adjustUser);
        }
        return toAjax(userService.updateUser(user));
    }

    @RequiresPermissions("system:user:resetPwd")
    @Log(title = "重置密码", action = BusinessType.UPDATE)
    @GetMapping("/resetPwd/{userId}")
    public String resetPwd(@PathVariable("userId") Long userId, ModelMap mmap)
    {
        mmap.put("user", userService.selectUserById(userId));
        return prefix + "/resetPwd";
    }

    @RequiresPermissions("system:user:resetPwd")
    @Log(title = "重置密码", action = BusinessType.UPDATE)
    @PostMapping("/resetPwd")
    @ResponseBody
    public AjaxResult resetPwd(User user)
    {
        return toAjax(userService.resetUserPwd(user));
    }

    @RequiresPermissions("system:user:remove")
    @Log(title = "用户管理", action = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        try
        {
            return toAjax(userService.deleteUserByIds(ids));
        }
        catch (Exception e)
        {
            return error(e.getMessage());
        }
    }

    /**
     * 校验用户名
     */
    @PostMapping("/checkLoginNameUnique")
    @ResponseBody
    public String checkLoginNameUnique(User user)
    {
        String uniqueFlag = "0";
        if (user != null)
        {
            uniqueFlag = userService.checkLoginNameUnique(user.getLoginName());
        }
        return uniqueFlag;
    }

    /**
     * 校验手机号码
     */
    @PostMapping("/checkPhoneUnique")
    @ResponseBody
    public String checkPhoneUnique(User user)
    {
        String uniqueFlag = "0";
        if (user != null)
        {
            uniqueFlag = userService.checkPhoneUnique(user);
        }
        return uniqueFlag;
    }

    /**
     * 校验email邮箱
     */
    @PostMapping("/checkEmailUnique")
    @ResponseBody
    public String checkEmailUnique(User user)
    {
        String uniqueFlag = "0";
        if (user != null)
        {
            uniqueFlag = userService.checkEmailUnique(user);
        }
        return uniqueFlag;
    }
}