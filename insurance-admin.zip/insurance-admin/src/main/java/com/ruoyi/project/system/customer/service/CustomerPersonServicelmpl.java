package com.ruoyi.project.system.customer.service;

import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.utils.NewFileUploadUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.security.ShiroUtils;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.domain.Pcustomer;
import com.ruoyi.project.system.customer.mapper.CustomerMapper;
import com.ruoyi.project.system.customer.mapper.PcustomerMapper;
import com.ruoyi.project.system.dict.domain.DictType;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.ruoyi.common.utils.security.ShiroUtils.getUserId;

/**
 * Created by x on 2018/8/8.
 */
@Service
public class CustomerPersonServicelmpl implements lCustomerPersonService {

    @Autowired
    private CustomerMapper customerPersonMapper;

    @Autowired
    private PcustomerMapper customerPersonMapper1;
    /*查询个人客户集合*/
    @Override
    public List<Customer> selectPersonCustomerList(Customer customer) {
        return customerPersonMapper.selectPersonCustomerList(customer);
    }


    /*查询个人客户集合*/
    //批量查询
    @Override
    public List<Pcustomer> selectPersonCustomerList1(Pcustomer pcustomer) {
        return customerPersonMapper1.selectPersonCustomerList1(pcustomer);
    }
    /*新增个人客户信息*/
    @Override
    public int insertPersonCustomer(Customer customer) {
        customer.setCreateBy(ShiroUtils.getLoginName());
        customer.setCustomerType("1");
        return customerPersonMapper.insertPersonCustomer(customer);
    }

    /*修改保存个人客户信息*/
    @Override
    public int updatePersonCustomer(Customer customer) {
        customer.setCreateBy(ShiroUtils.getLoginName());
        return customerPersonMapper.updatePersonCustomer(customer);
    }

    /**
     * 通过id查询个人客户信息
     */
    @Override
    public Customer selectPersonCustomerById(Long id) {
        return customerPersonMapper.selectCustomerById(id);
    }

    /**
     * 检验证件号码是否唯一
     * @param cardNum 证件号码
     * @return
     */
    @Override
    public String checkCardNumUnique(Customer personCustomer) {
        Long id = StringUtils.isNull(personCustomer.getId()) ? -1L : personCustomer.getId();
        Customer cardNum = customerPersonMapper.checkCardNumUnique(personCustomer.getCardNum());
        if (StringUtils.isNotNull(cardNum) && cardNum.getId() != id)
        {
            return UserConstants.DICT_TYPE_NOT_UNIQUE;
        }
        return UserConstants.DICT_TYPE_UNIQUE;
    }

    /**
     * 批量添加个人客户信息
     * @param map
     * @return
     */
    @Override
    public int addPersonCustomer(HashMap<String, Object> map) {
        map.put("customerType","1");
        map.put("userId",getUserId());
        return customerPersonMapper1.addPersonCustomer(map);
    }

    /**
     * 总监
     */
    @Override
    public List<Customer> selectPersonCustomerListMajordomo(long deptId, Customer customer) {
        return customerPersonMapper.selectPersonCustomerListMajordomo(deptId,customer);
    }

    /**
     * 主管
     */
    @Override
    public List<Customer> selectselectPersonCustomerListCharge(long deptId, Customer customer) {
        return customerPersonMapper.selectPersonCustomerListCharge(deptId,customer);
    }

    /**
     * 业务员
     */
    @Override
    public List<Customer> selectselectPersonCustomerListSalesman(long userId, Customer customer) {
        return customerPersonMapper.selectPersonCustomerListSalesman(userId,customer);
    }



}