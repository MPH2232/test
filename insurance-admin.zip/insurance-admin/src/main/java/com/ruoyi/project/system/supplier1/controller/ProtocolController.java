package com.ruoyi.project.system.supplier1.controller;


import com.ruoyi.common.utils.DeleteFile;
import com.ruoyi.common.utils.FileToZip;
import com.ruoyi.common.utils.NewFileUploadUtils;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.framework.aspectj.lang.annotation.Log;
import com.ruoyi.framework.aspectj.lang.constant.BusinessType;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.framework.web.page.TableDataInfo;
import com.ruoyi.project.system.supplier1.domain.Protocol;
import com.ruoyi.project.system.supplier1.domain.ProtocolFile;
import com.ruoyi.project.system.supplier1.service.IProtocolService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 数据协议信息
 * 
 * @author ruoyi
 */
@Controller
@RequestMapping("/system/protocol")
public class ProtocolController extends BaseController
{
    private String prefix = "system/protocol";

    @RequiresPermissions("system:supplier1:view")
    @GetMapping()
    public String protocol()
    {
        return prefix + "/protocol";
    }

    @Autowired
    private IProtocolService protocolService;

    @RequiresPermissions("system:protocol:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(Protocol protocol)
    {
        startPage();
        List<Protocol> list = protocolService.selectProtocol(protocol.getSuprotocolId());
        protocolService.showProtocolType(list);
        return getDataTable(list);
    }


    @Log(title = "协议数据", action = BusinessType.EXPORT)
    @PostMapping("/export")
    @ResponseBody
    public AjaxResult export(Protocol protocol) throws Exception
    {
        try
        {
            List<Protocol> list = protocolService.selectProtocolList(protocol);
            ExcelUtil<Protocol> util = new ExcelUtil<Protocol>(Protocol.class);
            return util.exportExcel(list, "protocol");
        }
        catch (Exception e)
        {
            return error("导出Excel失败，请联系网站管理员！");
        }
    }

    /**
     * 新增协议信息
     */
    @GetMapping("/add/{protocolId}")
    public String add(@PathVariable("protocolId") String protocolId, ModelMap mmap)
    {
        mmap.put("protocol",protocolId);
        return prefix + "/add";
    }

    /**
     * 新增保存协议信息
     */
    @Log(title = "协议数据", action = BusinessType.INSERT)
    @RequiresPermissions("system:supplier1:add")
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(Protocol protocol)
    {
        return toAjax(protocolService.insertProtocol(protocol));
    }

    /**
     * 修改协议信息
     */
    @GetMapping("/edit/{protocolId}")
    public String edit(@PathVariable("protocolId") Long protocolId, ModelMap mmap)
    {
        mmap.put("protocol", protocolService.selectProtocolById(protocolId));
        return prefix + "/edit";
    }

    /**
     * 修改保存协议信息
     */
    @Log(title = "协议数据", action = BusinessType.UPDATE)
    @RequiresPermissions("system:supplier1:edit")
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(Protocol protocol)
    {
        return toAjax(protocolService.updateProtocol(protocol));
    }

    /**
     * 删除保存协议信息
     */
    @Log(title = "协议数据", action = BusinessType.DELETE)
    @RequiresPermissions("system:supplier1:remove")
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids)
    {
        String[] array=ids.split(",");
        for(String arr:array){
            String path=protocolService.selectProtocolById(Long.valueOf(arr)).getProtocolFile();
            if(path!=null){
                DeleteFile.delAllFile(path);
                DeleteFile.delFolder(path);
            }
        }
        return toAjax(protocolService.deleteProtocolByIds(ids));
    }


    /**
     * 时间转换
     * @param binder
     */
    @InitBinder
    public void initBinder(WebDataBinder binder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
    }


    private static final Logger log = LoggerFactory.getLogger(ProtocolController.class);

    /**
     * 跳转上传页面
     * @param protocol
     * @param mmap
     * @return
     */
    @RequiresPermissions("system:protocol:upload")
    @GetMapping("/upload/{protocolId}")
    public String upload(Protocol protocol, ModelMap mmap) {
        protocol=protocolService.selectProtocolById(protocol.getProtocolId());
        mmap.put("protocol", protocol);
        return prefix + "/upload";
    }

    /**
     * 上传影像件
     */
    @PostMapping("/uploadSave")
    @ResponseBody
    public AjaxResult uploadSave(Protocol protocol, @RequestParam("uploadFile") MultipartFile[] file) {
        Map map = new HashMap();
        int su = 0;
        String xu = "";
        try {
//            if (uploadImage.getCustomerSo() != 0) {
//                uploadImage.setOrderId(uploadImage.getRenewId());
//                xu = "续保";
//            }
            if (file.length > 0) {
                //多文件上传
                map = NewFileUploadUtils.uploadNewMany(file, "gys"+String.valueOf(protocol.getProtocolId()));
                log.info("====上传影像件状态===" + xu + "==" + map.get("mes") + "协议号：" + protocol.getProtocolId());

                if (map.get("mes").toString().contains("成功")) {
                    if ("0" == map.get("separator")) {
                        //已经存在的数据
                        su = protocolService.updateProtocol(protocol);
                    } else {
                        String osName = System.getProperties().getProperty("os.name");
                        if (osName.equals("Linux")) {
                            protocol.setLinuxPath(map.get("path").toString());
                        } else {
                            protocol.setProtocolFile(map.get("path").toString());
                        }
//                        uploadImage.setOrderType(uploadImage.getCustomerSo() + "");
//                        protocol.setProtocolFile(map.get("path").toString());
                        su = protocolService.updateProtocol(protocol);
                    }
                }
            } else {
                map.put("mes", "请选择上传文件!");
            }
        } catch (Exception e) {
            log.error("上传影像异常", e);
            return error("上传影像件失败,请稍后重试!");
        }
        return toAjaxMes(su, map.get("mes").toString());
    }


    //待生成的zip包名
//    String zipName = String.valueOf(new Date().getTime());
    @RequiresPermissions("system:protocol:download")
    @GetMapping("/download/{protocolId}")
    @ResponseBody
    public String download(HttpServletResponse response,Protocol protocol) {
        try {
            //待生成的zip包名
            String zipName = "gys"+String.valueOf(protocol.getProtocolId());
            //数据库中文件的保存路径
            String sourceFilePath="";
//                    protocolService.selectProtocolById(protocol.getProtocolId()).getProtocolFile();
            if(sourceFilePath!=null){
                //待生成的zip保存路径
                String osName = System.getProperties().getProperty("os.name");
                System.out.println("----系统是---"+osName);
                String filePath = "";
                String zipFilePath ="";
//                String zipFilePath = "D:\\yasuobao";
                String path="";
                if (osName.equals("Linux")) {
                    filePath = "/var/opt/yasuobao/";
                    zipFilePath="/var/opt/yasuobao";
                    sourceFilePath=protocolService.selectProtocolById(protocol.getProtocolId()).getLinuxPath();
                } else {
                    filePath = "D:/yasuobao\\";
                    zipFilePath = "D:/yasuobao";
                    sourceFilePath=protocolService.selectProtocolById(protocol.getProtocolId()).getProtocolFile();
                }
                path=filePath+zipName+".zip";
                //压缩
                FileToZip.fileToZip(sourceFilePath , zipFilePath , zipName);
                //压缩包的绝对路径+完整压缩包名字
//                String path="D:\\yasuobao\\"+zipName+".zip";
                // path是指欲下载的文件的路径。
                File file = new File(path);
                // 取得文件名。
                String filename = file.getName();
                // 取得文件的后缀名。
                String ext = filename.substring(filename.lastIndexOf(".") + 1).toUpperCase();
                // 以流的形式下载文件。
                InputStream fis = new BufferedInputStream(new FileInputStream(path));
                byte[] buffer = new byte[fis.available()];
                fis.read(buffer);
                fis.close();
                // 清空response
                response.reset();
                // 设置response的Header
                response.addHeader("Content-Disposition", "attachment;filename=" + new String(filename.getBytes()));
                response.addHeader("Content-Length", "" + file.length());
                OutputStream toClient = new BufferedOutputStream(response.getOutputStream());
                response.setContentType("application/octet-stream");
                toClient.write(buffer);
                toClient.flush();
                toClient.close();
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return "对不起！该条协议您还没有上传影像不能进行下载！";
//        return response;
    }

    /**
     *预览跳转页面
     */
    @GetMapping("/yulan/{protocolId}")
    public String yulan(@PathVariable("protocolId") Long protocolId, ModelMap mmap) {
        mmap.put("protocol", protocolId);
        return "system/protocol/down";
    }

    /**
     *预览
     */
    @PostMapping("/listFile")
    @ResponseBody
    public TableDataInfo listFile(ProtocolFile protocolFile, ModelMap mmap) {
        List<ProtocolFile> lists = new ArrayList<ProtocolFile>();
        startPage();
        String path="profile/gys"+String.valueOf(protocolFile.getProtocolId());
        List<File> files = NewFileUploadUtils.getFiles("D:/profile" + "/gys" + String.valueOf(protocolFile.getProtocolId()));
        for (File f : files) {
            System.out.println(f.getName());
            String fName = f.getName().trim();
            ProtocolFile pf = new ProtocolFile();
            String fileName = fName.substring(fName.lastIndexOf("\\") + 1);
            String[] arr = fileName.split("\\.");
            String name = arr[0];
            if (protocolFile.getProtocolFileName() == null) {
                String type = arr[1];
                pf.setProtocolId(protocolFile.getProtocolId());
                pf.setProtocolFileName(name);
                pf.setProtocolFileLujing(path);
                pf.setProtocolFileType(type);
            } else {
                if (protocolFile.getProtocolFileName().equals("")) {
                    String type = arr[1];
                    pf.setProtocolId(protocolFile.getProtocolId());
                    pf.setProtocolFileLujing(path);
                    pf.setProtocolFileName(name);
                    pf.setProtocolFileType(type);
                } else {
                    if (name.contains(protocolFile.getProtocolFileName())) {
                        String type = arr[1];
                        pf.setProtocolId(protocolFile.getProtocolId());
                        pf.setProtocolFileLujing(path);
                        pf.setProtocolFileName(name);
                        pf.setProtocolFileLujing(type);
                    }
                }
            }
            lists.add(pf);
        }
        return getDataTable(lists);
    }
}
