package com.ruoyi.project.system.supplier1.service;

import com.ruoyi.project.system.supplier1.domain.Protocol;

import java.util.List;

/**
 * 字典 业务层
 * 
 * @author ruoyi
 */
public interface IProtocolService
{

    /**
     * 根据条件分页查询协议
     *
     * @param protocol 协议数据信息
     * @return 协议数据集合信息
     */
    public List<Protocol> selectProtocolList(Protocol protocol);

    public List<Protocol> selectProtocol(String protocolId);

    public List<Protocol> selectProtocolListBySuprotocolIds(String suprotocolId);

    /**
     * 根据关联字段批量删除协议
     * @param suprotocolIds
     * @return
     */
    public int deleteProtocolBySuprotocolIds(String suprotocolIds);

    /**
     * 通过协议ID删除协议数据信息
     *
     * @param protocolId 协议ID
     * @return 结果
     */
    public int deleteProtocolById(Long protocolId);

    /**
     * 批量删除协议数据
     *
     * @param ids 需要删除的数据
     * @return 结果
     */
    public int deleteProtocolByIds(String ids);

    /**
     * 新增保存协议数据信息
     *
     * @param protocol 协议数据信息
     * @return 结果
     */
    public int insertProtocol(Protocol protocol);

    /**
     * 修改保存协议数据信息
     *
     * @param protocol 协议数据信息
     * @return 结果
     */
    public int updateProtocol(Protocol protocol);

    public int updateProtocolStatus(Protocol protocol);

    public Protocol selectProtocolById(Long protocolId);

    public List<Protocol> selectProtocolAll();

    /**
     * 展示协议类型数字换文字
     */
    public void showProtocolType(List<Protocol> list);

    public Protocol selectProtocolDateBySuprotocolIds(String protocolId);
}
