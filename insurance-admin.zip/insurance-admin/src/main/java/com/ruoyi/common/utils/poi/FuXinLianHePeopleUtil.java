package com.ruoyi.common.utils.poi;

import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.project.order.orderPeople.domain.OrderPeople;
import com.ruoyi.project.order.orderPeople.service.IOrderPeopleService;
import com.ruoyi.project.order.orderproductPlan.domain.OrderProductPlan;
import com.ruoyi.project.order.orderproductPlan.service.IOrderproductPlanService;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.service.lCustomerService;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

/**
 * Excel相关处理人员清单导入
 *
 * @author ruoyi
 */
@Component
public class FuXinLianHePeopleUtil {

    private static final Logger log = LoggerFactory.getLogger(FuXinLianHePeopleUtil.class);

    @Autowired
    private lCustomerService customerService;

    @Autowired
    private IOrderproductPlanService orderproductPlanService;

    @Autowired
    private IOrderPeopleService orderPeopleService;

    private static FuXinLianHePeopleUtil excelOrderAgainUtil;

    @PostConstruct     //关键二   通过@PostConstruct 和 @PreDestroy 方法 实现初始化和销毁bean之前进行的操作
    public void init() {
        excelOrderAgainUtil = this;
        excelOrderAgainUtil.orderproductPlanService = this.orderproductPlanService;
        excelOrderAgainUtil.orderPeopleService = this.orderPeopleService;
        excelOrderAgainUtil.customerService = this.customerService;
    }


    /**
     * 解析Excel里面的数据
     *
     * @param wb
     * @return
     */
    public String readExcel(Workbook wb,OrderPeople orderPeoples) throws CloneNotSupportedException {
        //客户名称
        String strCustomer = "";
        List<Customer> customerList = excelOrderAgainUtil.customerService.selectCustomersAll();
        for(Customer customers : customerList){
            strCustomer +=customers.getCustomerName()+',';
        }
        String arrCustomer [] = strCustomer.split(",");
//        计划名称
        String strOrderProductPlan = "";
        List<OrderProductPlan> orderProductPlansList = excelOrderAgainUtil.orderproductPlanService.selectOrderProductPlanAll();
        for(OrderProductPlan orderProductPlanss : orderProductPlansList){
            strOrderProductPlan +=orderProductPlanss.getPlanName()+',';
        }
        String arrOrderProductPlan [] = strOrderProductPlan.split(",");

        //错误信息接收器
        String errorMsg = "";
        //最大的list
        List<OrderPeople> orderPeopleList = new ArrayList<OrderPeople>();

        OrderPeople orderPeople;

        String br = "<br/>";

        //得到第一个shell
        Sheet sheets = wb.getSheetAt(0);
        //得到Excel的行数
        int totalRowss = sheets.getPhysicalNumberOfRows();
        //总列数
        int totalCellss = sheets.getRow(0).getLastCellNum();

        String orderid="";

        //循环Excel行数,从第2行开始。标题不入库
        for (int r = 1; r < totalRowss; r++) {
            String rowMessages = "";
            Row row = sheets.getRow(r);
            if (row == null) {
                errorMsg += br+ "第" + (r + 1) + "行数据有问题，请仔细检查！";
                continue;
            }
            orderPeople = new OrderPeople();
            orderid=orderPeoples.getOrderId();
            orderPeople.setOrderId(orderPeoples.getOrderId());
            orderPeople.setOrderType(orderPeoples.getOrderType());
            //循环Excel的列
            for (int c = 0; c < totalCellss; c++) {
                Cell cell = row.getCell(c);
                if (null != cell) {
                    row.getCell(c).setCellType(Cell.CELL_TYPE_STRING);
                    if (c == 0) {
                        //序号
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "序号不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "列序号位数不能超过1000；";
                        }
                        orderPeople.setPeopleNo(cell.getStringCellValue());

                    } else if (c == 1) {
                        //公司名称
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "公司名称不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "公司名称位数不能超过1000；";
                        }
                        else if (!strCustomer.contains(cell.getStringCellValue())){
                            rowMessages += "公司名称还没有添加；";
                        }
                        orderPeople.setBranch(cell.getStringCellValue());

                    } else if (c == 2) {
                        //被保险人姓名
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "被保险人姓名不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "被保险人姓名位数不能超过1000；";
                        }
                        orderPeople.setPeopleName(cell.getStringCellValue());

                    } else if (c == 3) {
                        //证件类型
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "证件类型不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "证件类型位数不能超过1000；";
                        }
                        orderPeople.setIdcardType(cell.getStringCellValue());

                    } else if (c == 4) {
                        //证件号码
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "证件号码不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.SHENG_FEN_ZHENG)) {
                            rowMessages += "证件号码格式错误；";
                        }
                        orderPeople.setIdcard(cell.getStringCellValue());

                    } else if (c == 5) {
                        //性别
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "性别不能为空；";
                        }
                        else if (!cell.getStringCellValue().equals("男") && !cell.getStringCellValue().equals("女")) {
                            rowMessages += "性别只能输入男或者女；";
                        }
                        orderPeople.setSex(cell.getStringCellValue());

                    } else if (c == 6) {
                        //出生日期
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "出生日期不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.SHENG_RI)) {
                            rowMessages += "出生日期格式错误；";
                        }
                        orderPeople.setBirth(cell.getStringCellValue());

                    } else if (c == 7) {
                        //年龄
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "年龄不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "年龄位数不能超过1000；";
                        }
                        orderPeople.setAge(cell.getStringCellValue());

                    } else if (c == 8) {
                        //职业
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "职业不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "职业位数不能超过1000；";
                        }
                        orderPeople.setPost(cell.getStringCellValue());

                    } else if (c == 9) {
                        //是否参加社保
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "是否参加社保不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "是否参加社保位数不能超过1000；";
                        }
                        orderPeople.setIsShebao(cell.getStringCellValue());

                    } else if (c == 10) {
                        //社保地
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "社保所在地不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "社保所在地位数不能超过1000；";
                        }
                        orderPeople.setShebaoPlace(cell.getStringCellValue());

                    } else if (c == 11) {
                        //与主被保险人关系
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "与主被保险人关系不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "与主被保险人关系位数不能超过1000；";
                        }
                        orderPeople.setRelationship(cell.getStringCellValue());

                    } else if (c == 12) {
                        //主被保险人姓名
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "主被保险人姓名不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "主被保险人姓名位数不能超过1000；";
                        }
                        orderPeople.setPeopleNameZhu(cell.getStringCellValue());

                    } else if (c == 13) {
                        //方案类型
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "方案类型不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "方案类型位数不能超过1000；";
                        }
                        else if (!strOrderProductPlan.contains(cell.getStringCellValue())){
                            rowMessages += "方案类型还没有添加；";
                        }
                        orderPeople.setPlanName(cell.getStringCellValue());

                    } else if (c == 14) {
                        //变更类型（加保/减保）
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "变更类型关系不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "变更类型位数不能超过1000；";
                        }
                        orderPeople.setChangeType(cell.getStringCellValue());

                    } else if (c == 15) {
                        //变更生效日期
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "生效日期不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.SHENG_RI)) {
                            rowMessages += "生效日期格式错误；";
                        }
                        orderPeople.setStartTime(cell.getStringCellValue());

                    } else if (c == 16) {
                        //应退保费

//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "开票单位名称不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "开票单位名称不能超过1000；";
//                        }
                        orderPeople.setRefundBaofei(cell.getStringCellValue());

                    } else if (c == 17) {
                        //手机号码
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "手机号码不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.MOBILE_PHONE_NUMBER_PATTERN)) {
                            rowMessages += "手机号码格式错误；";
                        }
                        orderPeople.setPhone(cell.getStringCellValue());

                    } else if (c == 18) {
                        //邮箱
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "电子邮箱不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.EMAIL_PATTERN)) {
                            rowMessages += "电子邮箱格式错误；";
                        }
                        orderPeople.setEmail(cell.getStringCellValue());

                    } else if (c == 19) {
                        //开户银行(精确至分行)
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "开户行不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "开户行位数不能超过1000；";
                        }
                        orderPeople.setBankName(cell.getStringCellValue());

                    } else if (c == 20) {
                        //开户名
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "银行开户名不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "银行开户名位数不能超过1000；";
                        }
                        orderPeople.setAccountName(cell.getStringCellValue());

                    } else if (c == 21) {
                        //帐号
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "银行帐号不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.YIN_HANG_KA)) {
                            rowMessages += "银行帐号格式错误；";
                        }
                        orderPeople.setBankNo(cell.getStringCellValue());

                    }  else if (c == 22) {
                        //医疗保费
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "医疗保费不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "医疗保费位数不能超过1000；";
//                        }
                        orderPeople.setYiliaoBaofei(cell.getStringCellValue());

                    } else if (c == 23) {
                        //意外保费
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "意外保费不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "意外保费位数不能超过1000；";
//                        }
                        orderPeople.setYiwaiBaofei(cell.getStringCellValue());

                    } else if (c == 24) {
                        //重疾保费
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "重疾保费不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "重疾保费位数不能超过1000；";
//                        }
                        orderPeople.setZhongjiBaofei(cell.getStringCellValue());

                    } else if (c == 25) {
                        //疾病身故保费
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "疾病身故保费不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "疾病身故保费位数不能超过1000；";
//                        }
                        orderPeople.setShengguBaofei(cell.getStringCellValue());

                    } else if (c == 26) {
                        //总保费
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "总保费不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "总保费位数不能超过1000；";
//                        }
                        orderPeople.setBaofei(cell.getStringCellValue());
                        orderPeopleList.add(orderPeople);
                    }

                } else {
                    rowMessages += "第" + (c + 1) + "列数据有问题，请仔细检查；";
                }
            }
            //拼接每行的错误提示
            if (!StringUtils.isEmpty(rowMessages)) {
                errorMsg +=  "第" + (r + 1) + "行，" + rowMessages + br;
            }
        }

        //全部验证通过才导入到数据库
        if (StringUtils.isEmpty(errorMsg)) {

            excelOrderAgainUtil.orderPeopleService.deleteOrderPeopleByOrderId(orderid);
            excelOrderAgainUtil.orderPeopleService.insertOrderPeopleList(orderPeopleList);

            errorMsg = "导入成功！";
            return errorMsg;
        }else{
            return errorMsg;
        }
    }
}

