package com.ruoyi.common.utils.poi;

import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.PublicUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.project.order.order.domain.Order;
import com.ruoyi.project.order.order.service.IOrderService;
import com.ruoyi.project.order.orderPeople.domain.OrderPeople;
import com.ruoyi.project.order.orderPeople.service.IOrderPeopleService;
import com.ruoyi.project.order.orderproductPlan.domain.OrderProductPlan;
import com.ruoyi.project.order.orderproductPlan.service.IOrderproductPlanService;
import com.ruoyi.project.system.channel.domain.Channel;
import com.ruoyi.project.system.channel.service.IChannelService;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.service.lCustomerService;
import com.ruoyi.project.system.product.domain.Product;
import com.ruoyi.project.system.product.domain.ProductFeilvSimple;
import com.ruoyi.project.system.product.service.IProductService;
import com.ruoyi.project.system.supplier1.domain.Supplier;
import com.ruoyi.project.system.supplier1.service.ISupplier1Service;
import com.ruoyi.project.system.user.domain.User;
import com.ruoyi.project.system.user.service.IUserService;
import org.apache.poi.ss.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

/**
 * Excel相关处理订单批量导入
 *
 * @author ruoyi
 */
@Component
public class ExcelOrderRenewalUtil {

    private static final Logger log = LoggerFactory.getLogger(ExcelOrderRenewalUtil.class);

    @Autowired
    private ISupplier1Service supplier1Service;

    @Autowired
    private IUserService userService;

    @Autowired
    private lCustomerService customerService;

    @Autowired
    private IProductService productService;

    @Autowired
    private IChannelService channelService;

    @Autowired
    private IOrderService orderService;

    @Autowired
    private IOrderproductPlanService orderproductPlanService;

    @Autowired
    private IOrderPeopleService orderPeopleService;

    private static ExcelOrderRenewalUtil excelOrderRenewalUtil;

    @PostConstruct     //关键二   通过@PostConstruct 和 @PreDestroy 方法 实现初始化和销毁bean之前进行的操作
    public void init() {
        excelOrderRenewalUtil = this;
        excelOrderRenewalUtil.orderService = this.orderService;   // 初使化时将已静态化的testService实例化
        excelOrderRenewalUtil.orderproductPlanService = this.orderproductPlanService;
        excelOrderRenewalUtil.orderPeopleService = this.orderPeopleService;
        excelOrderRenewalUtil.supplier1Service = this.supplier1Service;
        excelOrderRenewalUtil.userService = this.userService;
        excelOrderRenewalUtil.customerService = this.customerService;
        excelOrderRenewalUtil.productService = this.productService;
        excelOrderRenewalUtil.channelService = this.channelService;
    }

    /**
     * 解析Excel里面的数据
     *
     * @param wb
     * @return
     */
    public String readExcel(Workbook wb, Order orders) throws CloneNotSupportedException {
        //保险公司
        String strSupplier = "";
        List<Supplier> supplerList = excelOrderRenewalUtil.supplier1Service.selectSupplierAll();
        for(Supplier suppliers : supplerList){
            strSupplier +=suppliers.getSupplierName()+',';
        }
        String arrSupplier [] = strSupplier.split(",");

        //业务员
        String strUser = "";
        List<User> userList = excelOrderRenewalUtil.userService.selectUserAll();
        for(User users : userList){
            strUser +=users.getUserName()+',';
        }
        String arrUser [] = strUser.split(",");


        //错误信息接收器
        String errorMsg = "";
        //得到第一个shell
        Sheet sheet = wb.getSheetAt(0);
        //得到Excel的行数
        int totalRows = sheet.getPhysicalNumberOfRows();
        //总列数
        int totalCells = 0;
        //得到Excel的列数(前提是有行数)，从第2行算起
        if (totalRows >= 2 && sheet.getRow(1) != null) {
            totalCells = sheet.getRow(1).getLastCellNum();
        }
        List<Order> orderList = new ArrayList<Order>();
        Order order;
//        String financeid="";
        String br = "<br/>";
        String id = "";

        //循环Excel行数,从第2行开始。标题不入库
        for (int r = 1; r < totalRows; r++) {
            String rowMessage = "";
            Row row = sheet.getRow(r);
            if (row == null) {
                errorMsg += br + "第" + (r + 1) + "行数据有问题，请仔细检查！";
                continue;
            }
            order = new Order();


            id = DateUtils.dateTimeSSS()+ PublicUtils.getRandom();
            order = new Order();
            order.setRenewId(id);
            order.setStatus(0);

            //循环Excel的列
            for (int c = 0; c < totalCells; c++) {
                Cell cell = row.getCell(c);
                if (null != cell) {
                    row.getCell(c).setCellType(Cell.CELL_TYPE_STRING);
                    if(c == 0){
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "订单号不能为空；";
                        } else if (cell.getStringCellValue().length() > 60) {
                            rowMessage += "订单号的字数不能超过60；";
                        }
                        order.setOrderId(cell.getStringCellValue());
                    }
                    else if (c == 1) {
                        //记账日期
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "保单识别码不能为空；";
                        } else if (cell.getStringCellValue().length() > 60) {
                            rowMessage += "保单识别码的字数不能超过60；";
                        }
                        order.setPolicyNum(cell.getStringCellValue());
                    } else if (c == 2) {
                        //业务员
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "业务员不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "业务员的字数不能超过1000；";
                        }
                        //设置业务员id和团队名字和团队id
                        if(strUser.contains(cell.getStringCellValue())) {
                            for (int index = 0; index < arrUser.length; index++) {
                                if (arrUser[index].equals(cell.getStringCellValue())) {
                                    order.setUserId(Math.toIntExact(userList.get(index).getUserId()));
                                    order.setTeamId(Math.toIntExact(userList.get(index).getDeptId()));
                                    order.setTeamName(userList.get(index).getDept().getDeptName());
                                }
                            }
                        }


                        order.setUserName(cell.getStringCellValue());
                    }else if (c == 3) {
                        //保险公司
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "保险公司不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "保险公司的字数不能超过1000；";
                        }
                        //设置保险公司id
                        if(strSupplier.contains(cell.getStringCellValue())) {
                            for (int index = 0; index < arrSupplier.length; index++) {
                                if (arrSupplier[index].equals(cell.getStringCellValue())) {
                                    order.setInsureId(Math.toIntExact(supplerList.get(index).getSupplierId()));
                                }
                            }
                        }
                        order.setInsureCompany(cell.getStringCellValue());
                    }else if (c == 4) {
                        //客户名称
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "客户名称不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "客户名称不能超过1000；";
                        }
                        order.setCustomerName(cell.getStringCellValue());
                    }else if (c == 5) {
                        //客户类型
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "客户类型不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "客户类型的字数不能超过1000；";
                        }
                        order.setCustomerType(0);
                    }else if (c == 6) {
                        //客户来源
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "客户来源不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "客户来源的字数不能超过1000；";
                        } else if (cell.getStringCellValue().equals("新保")) {
                            order.setCustomerSo(0);
                        } else if (cell.getStringCellValue().equals("续保")) {
                            order.setCustomerSo(1);
                        } else if (cell.getStringCellValue().equals("渠道")) {
                            order.setCustomerSo(2);
                        } else if (cell.getStringCellValue().equals("自行拓展")) {
                            order.setCustomerSo(3);
                        } else if (cell.getStringCellValue().equals("客户介绍")) {
                            order.setCustomerSo(4);
                        } else if (cell.getStringCellValue().equals("现有客户再开发")) {
                            order.setCustomerSo(5);
                        }
                    }else if (c == 7) {
                        //渠道名称
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "渠道名称不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "渠道名称的字数不能超过1000；";
                        }
                        order.setChannelName(cell.getStringCellValue());
                    } else if (c == 8) {
                        //续保提醒日
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "续保提醒日不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "续保提醒日的字数不能超过1000；";
                        }
                        order.setXubaoTime(cell.getStringCellValue());

                    } else if (c == 9) {
                        //生效日期
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "生效日期不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "生效日期的字数不能超过1000；";
                        }
                        order.setStartTime(cell.getStringCellValue());
                    }else if (c == 10) {
                        //失效日期
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "失效日期不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "失效日期的字数不能超过1000；";
                        }
                        order.setEndTime(cell.getStringCellValue());
                    }else if (c == 11) {
                        //缴费方式
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "缴费方式不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "缴费方式的字数不能超过1000；";
                        } else if (cell.getStringCellValue().equals("趸交")) {
                            order.setPayMode("1");
                        } else if (cell.getStringCellValue().equals("月交")) {
                            order.setPayMode("12");
                        } else if (cell.getStringCellValue().equals("季交")) {
                            order.setPayMode("4");
                        } else if (cell.getStringCellValue().equals("四个月交")) {
                            order.setPayMode("3");
                        } else if (cell.getStringCellValue().equals("半年交")) {
                            order.setPayMode("2");
                        }
                    }else if (c == 12) {
                        //付费至
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "付费至不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "付费至的字数不能超过1000；";
                        } else if (cell.getStringCellValue().equals("保险公司")) {
                            order.setPayTo("0");
                        } else if (cell.getStringCellValue().equals("FESCO")) {
                            order.setPayTo("1");
                        } else if (cell.getStringCellValue().equals("方胜")) {
                            order.setPayTo("2");

                        }
                    }


                } else {
                    rowMessage += "第" + (c + 1) + "列数据有问题，请仔细检查；";
                }
            }
            //拼接每行的错误提示
            if (!StringUtils.isEmpty(rowMessage)) {
                errorMsg += br + "第" + (r + 1) + "行，" + rowMessage;
            } else {
                orderList.add(order);
            }
        }
        //全部通过验证才能导入到数据库中
        if (StringUtils.isEmpty(errorMsg)) {
            excelOrderRenewalUtil.orderService.insertOrderList(orderList);
            errorMsg = "导入成功，共" + orderList.size() + "条数据！";
        }
        return errorMsg;
    }
}

