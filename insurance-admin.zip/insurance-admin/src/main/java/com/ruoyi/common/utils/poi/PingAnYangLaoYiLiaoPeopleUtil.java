package com.ruoyi.common.utils.poi;

import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.project.order.orderPeople.domain.OrderPeople;
import com.ruoyi.project.order.orderPeople.service.IOrderPeopleService;
import com.ruoyi.project.order.orderproductPlan.domain.OrderProductPlan;
import com.ruoyi.project.order.orderproductPlan.service.IOrderproductPlanService;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.service.lCustomerService;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

/**
 * Excel相关处理人员清单导入
 *
 * @author ruoyi
 */
@Component
public class PingAnYangLaoYiLiaoPeopleUtil {

    private static final Logger log = LoggerFactory.getLogger(PingAnYangLaoYiLiaoPeopleUtil.class);

    @Autowired
    private lCustomerService customerService;

    @Autowired
    private IOrderproductPlanService orderproductPlanService;

    @Autowired
    private IOrderPeopleService orderPeopleService;

    private static PingAnYangLaoYiLiaoPeopleUtil excelOrderAgainUtil;

    @PostConstruct     //关键二   通过@PostConstruct 和 @PreDestroy 方法 实现初始化和销毁bean之前进行的操作
    public void init() {
        excelOrderAgainUtil = this;
        excelOrderAgainUtil.orderproductPlanService = this.orderproductPlanService;
        excelOrderAgainUtil.orderPeopleService = this.orderPeopleService;
        excelOrderAgainUtil.customerService = this.customerService;
    }


    /**
     * 解析Excel里面的数据
     *
     * @param wb
     * @return
     */
    public String readExcel(Workbook wb,OrderPeople orderPeoples) throws CloneNotSupportedException {
        //客户名称
        String strCustomer = "";
        List<Customer> customerList = excelOrderAgainUtil.customerService.selectCustomersAll();
        for(Customer customers : customerList){
            strCustomer +=customers.getCustomerName()+',';
        }
        String arrCustomer [] = strCustomer.split(",");
//        计划名称
        String strOrderProductPlan = "";
        List<OrderProductPlan> orderProductPlansList = excelOrderAgainUtil.orderproductPlanService.selectOrderProductPlanAll();
        for(OrderProductPlan orderProductPlanss : orderProductPlansList){
            strOrderProductPlan +=orderProductPlanss.getPlanName()+',';
        }
        String arrOrderProductPlan [] = strOrderProductPlan.split(",");

        //错误信息接收器
        String errorMsg = "";
        //最大的list
        List<OrderPeople> orderPeopleList = new ArrayList<OrderPeople>();

        OrderPeople orderPeople;

        String br = "<br/>";

        //得到第一个shell
        Sheet sheets = wb.getSheetAt(0);
        //得到Excel的行数
        int totalRowss = sheets.getPhysicalNumberOfRows();
        //总列数
        int totalCellss = sheets.getRow(0).getLastCellNum();

        String orderid="";

        //循环Excel行数,从第2行开始。标题不入库
        for (int r = 1; r < totalRowss; r++) {
            String rowMessages = "";
            Row row = sheets.getRow(r);
            if (row == null) {
                errorMsg += "第" + (r + 1) + "行数据有问题，请仔细检查！";
                continue;
            }
            orderPeople = new OrderPeople();
            orderid=orderPeoples.getOrderId();
            orderPeople.setOrderId(orderPeoples.getOrderId());
            orderPeople.setOrderType(orderPeoples.getOrderType());
            //循环Excel的列
            for (int c = 0; c < totalCellss; c++) {
                Cell cell = row.getCell(c);
                if (null != cell) {
                    row.getCell(c).setCellType(Cell.CELL_TYPE_STRING);
                    if (c == 0) {
                        //序号
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "序号不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "列序号位数不能超过1000；";
                        }
                        orderPeople.setPeopleNo(cell.getStringCellValue());

                    } else if (c == 1) {
                        //申请类型
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "申请类型不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "申请类型位数不能超过1000；";
                        }
                        orderPeople.setChangeType(cell.getStringCellValue());

                    } else if (c == 2) {
                        //生效日期
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "生效日期不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.SHENG_RI)) {
                            rowMessages += "生效日期格式错误；";
                        }
                        orderPeople.setStartTime(cell.getStringCellValue());

                    } else if (c == 3) {
                        //员工编号
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "员工编号不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "员工编号位数不能超过1000；";
                        }
                        orderPeople.setEmpNo(cell.getStringCellValue());

                    } else if (c == 4) {
                        //员工姓名
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "员工姓名不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "员工姓名位数不能超过1000；";
                        }
                        orderPeople.setPeopleName(cell.getStringCellValue());

                    } else if (c == 5) {
                        //员工加入层级
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "员工加入层级不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "员工加入层级位数不能超过1000；";
                        }
                        orderPeople.setCategory(cell.getStringCellValue());

                    } else if (c == 6) {
                        //证件号码
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "证件号码不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.SHENG_FEN_ZHENG)) {
                            rowMessages += "证件号码格式错误；";
                        }
                        orderPeople.setIdcard(cell.getStringCellValue());

                    } else if (c == 7) {
                        //性别
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "性别不能为空；";
                        }
                        else if (!cell.getStringCellValue().equals("男") && !cell.getStringCellValue().equals("女")) {
                            rowMessages += "性别只能输入男或者女；";
                        }
                        orderPeople.setSex(cell.getStringCellValue());

                    } else if (c == 8) {
                        //出生年月日
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "出生日期不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.SHENG_RI)) {
                            rowMessages += "出生日期格式错误；";
                        }
                        orderPeople.setBirth(cell.getStringCellValue());

                    } else if (c == 9) {
                        //开户行名称
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "银行开户名不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "银行开户名位数不能超过1000；";
                        }
                        orderPeople.setAccountName(cell.getStringCellValue());

                    } else if (c == 10) {
                        //银行账号
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "银行帐号不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.YIN_HANG_KA)) {
                            rowMessages += "银行帐号格式错误；";
                        }
                        orderPeople.setBankNo(cell.getStringCellValue());

                    } else if (c == 11) {
                        //部门
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "部门不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "部门费位数不能超过1000；";
                        }
                        orderPeople.setDeptName(cell.getStringCellValue());

                    } else if (c == 12) {
                        //电子邮箱
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "电子邮箱不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.EMAIL_PATTERN)) {
                            rowMessages += "电子邮箱格式错误；";
                        }
                        orderPeople.setEmail(cell.getStringCellValue());

                    } else if (c == 13) {
                        //社保地
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "社保所在地不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "社保所在地位数不能超过1000；";
                        }
                        orderPeople.setShebaoPlace(cell.getStringCellValue());

                    } else if (c == 14) {
                        //工作地
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "工作所在地不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "工作所在地位数不能超过1000；";
                        }
                        orderPeople.setWorkPlace(cell.getStringCellValue());

                    } else if (c == 15) {
                        //子女1姓名
                        orderPeople.setChild1Name(cell.getStringCellValue());

                    } else if (c == 16) {
                        //子女1出生日期/证件号
                        if(cell.getStringCellValue().contains("-")){
                            orderPeople.setChild1Birth(cell.getStringCellValue());
                        }else{
                            orderPeople.setChild1Idcard(cell.getStringCellValue());
                        }

                    } else if (c == 17) {
                        //子女1性别
                        orderPeople.setChild1Sex(cell.getStringCellValue());

                    } else if (c == 18) {
                        //子女1健康状态
                        orderPeople.setChild1Status(cell.getStringCellValue());

                    } else if (c == 19) {
                        //子女1加入层级
                        orderPeople.setChild1Category(cell.getStringCellValue());

                    } else if (c == 20) {
                        //连带子女2姓名
                        orderPeople.setChild2Name(cell.getStringCellValue());

                    } else if (c == 21) {
                        //连带子女2出生日期/证件号
                        if(cell.getStringCellValue().contains("-")){
                            orderPeople.setChild2Birth(cell.getStringCellValue());
                        }else{
                            orderPeople.setChild2Idcard(cell.getStringCellValue());
                        }

                    } else if (c == 22) {
                        //连带子女2性别
                        orderPeople.setChild2Sex(cell.getStringCellValue());

                    } else if (c == 23) {
                        //连带子女2健康状态
                        orderPeople.setChild2Status(cell.getStringCellValue());

                    } else if (c == 24) {
                        //子女2加入层级
                        orderPeople.setChild2Category(cell.getStringCellValue());

                    } else if (c == 25) {
                        //配偶姓名
                        orderPeople.setCoupleName(cell.getStringCellValue());

                    } else if (c == 26) {
                        //配偶出生日期/证件号
                        if(cell.getStringCellValue().contains("-")){
                            orderPeople.setCoupleBirth(cell.getStringCellValue());
                        }else{
                            orderPeople.setCoupleIdcard(cell.getStringCellValue());
                        }

                    } else if (c == 27) {
                        //配偶性别
                        orderPeople.setCoupleSex(cell.getStringCellValue());

                    } else if (c == 28) {
                        //配偶健康状态
                        orderPeople.setCoupleStatus(cell.getStringCellValue());

                    } else if (c == 29) {
                        //配偶加入层级
                        orderPeople.setCoupleCategory(cell.getStringCellValue());

                    } else if (c == 30) {
                        //备注
                        orderPeople.setRemark(cell.getStringCellValue());

                    } else if (c == 31) {
                        //医疗保费
                        orderPeople.setYiliaoBaofei(cell.getStringCellValue());

                    } else if (c == 32) {
                        //意外保费
                        orderPeople.setYiwaiBaofei(cell.getStringCellValue());

                    } else if (c == 33) {
                        //重疾保费
                        orderPeople.setZhongjiBaofei(cell.getStringCellValue());

                    } else if (c == 34) {
                        //疾病身故保费
                        orderPeople.setShengguBaofei(cell.getStringCellValue());

                    } else if (c == 35) {
                        //总保费
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "总保费不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "总保费位数不能超过1000；";
                        }
                        orderPeople.setBaofei(cell.getStringCellValue());
                        orderPeopleList.add(orderPeople);
                    }
                } else {
                    rowMessages += "第" + (c + 1) + "列数据有问题，请仔细检查；";
                }
            }
            //拼接每行的错误提示
            if (!StringUtils.isEmpty(rowMessages)) {
                errorMsg +=  "第" + (r + 1) + "行，" + rowMessages + br;
            }
        }

        //全部验证通过才导入到数据库
        if (StringUtils.isEmpty(errorMsg)) {

            excelOrderAgainUtil.orderPeopleService.deleteOrderPeopleByOrderId(orderid);
            excelOrderAgainUtil.orderPeopleService.insertOrderPeopleList(orderPeopleList);

            errorMsg = "导入成功！";
            return errorMsg;
        }else{
            return errorMsg;
        }
    }
}

