package com.ruoyi.common.utils.poi;

import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.project.order.orderPeople.domain.OrderPeople;
import com.ruoyi.project.order.orderPeople.service.IOrderPeopleService;
import com.ruoyi.project.order.orderproductPlan.domain.OrderProductPlan;
import com.ruoyi.project.order.orderproductPlan.service.IOrderproductPlanService;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.service.lCustomerService;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

/**
 * Excel相关处理人员清单导入
 *
 * @author ruoyi
 */
@Component
public class PingAnJianKangPeopleUtil {

    private static final Logger log = LoggerFactory.getLogger(PingAnJianKangPeopleUtil.class);

    @Autowired
    private lCustomerService customerService;

    @Autowired
    private IOrderproductPlanService orderproductPlanService;

    @Autowired
    private IOrderPeopleService orderPeopleService;

    private static PingAnJianKangPeopleUtil excelOrderAgainUtil;

    @PostConstruct     //关键二   通过@PostConstruct 和 @PreDestroy 方法 实现初始化和销毁bean之前进行的操作
    public void init() {
        excelOrderAgainUtil = this;
        excelOrderAgainUtil.orderproductPlanService = this.orderproductPlanService;
        excelOrderAgainUtil.orderPeopleService = this.orderPeopleService;
        excelOrderAgainUtil.customerService = this.customerService;
    }


    /**
     * 解析Excel里面的数据
     *
     * @param wb
     * @return
     */
    public String readExcel(Workbook wb,OrderPeople orderPeoples) throws CloneNotSupportedException {
        //客户名称
        String strCustomer = "";
        List<Customer> customerList = excelOrderAgainUtil.customerService.selectCustomersAll();
        for(Customer customers : customerList){
            strCustomer +=customers.getCustomerName()+',';
        }
        String arrCustomer [] = strCustomer.split(",");
//        计划名称
        String strOrderProductPlan = "";
        List<OrderProductPlan> orderProductPlansList = excelOrderAgainUtil.orderproductPlanService.selectOrderProductPlanAll();
        for(OrderProductPlan orderProductPlanss : orderProductPlansList){
            strOrderProductPlan +=orderProductPlanss.getPlanName()+',';
        }
        String arrOrderProductPlan [] = strOrderProductPlan.split(",");

        //错误信息接收器
        String errorMsg = "";
        //最大的list
        List<OrderPeople> orderPeopleList = new ArrayList<OrderPeople>();

        OrderPeople orderPeople;

        String br = "<br/>";

        //得到第一个shell
        Sheet sheets = wb.getSheetAt(0);
        //得到Excel的行数
        int totalRowss = sheets.getPhysicalNumberOfRows();
        //总列数
        int totalCellss = sheets.getRow(0).getLastCellNum();

        String orderid="";

        //循环Excel行数,从第2行开始。标题不入库
        for (int r = 1; r < totalRowss; r++) {
            String rowMessages = "";
            Row row = sheets.getRow(r);
            if (row == null) {
                errorMsg += br+ "第" + (r + 1) + "行数据有问题，请仔细检查！";
                continue;
            }
            orderPeople = new OrderPeople();
            orderid=orderPeoples.getOrderId();
            orderPeople.setOrderId(orderPeoples.getOrderId());
            orderPeople.setOrderType(orderPeoples.getOrderType());
            //循环Excel的列
            for (int c = 0; c < totalCellss; c++) {
                Cell cell = row.getCell(c);
                if (null != cell) {
                    row.getCell(c).setCellType(Cell.CELL_TYPE_STRING);
                    if (c == 0) {
                        //序号
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "序号不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "列序号位数不能超过1000；";
                        }
                        orderPeople.setPeopleNo(cell.getStringCellValue());

                    } else if (c == 1) {
                        //保障方案
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "保险计划不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "保险计划位数不能超过1000；";
                        }
//                        else if (!strOrderProductPlan.contains(cell.getStringCellValue())){
//                            rowMessages += "保险计划还没有添加；";
//                        }
                        orderPeople.setPlanName(cell.getStringCellValue());

                    } else if (c == 2) {
                        //被保险人姓名
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "被保险人姓名不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "被保险人姓名位数不能超过1000；";
                        }
                        orderPeople.setPeopleName(cell.getStringCellValue());

                    } else if (c == 3) {
                        //证件类型
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "证件类型不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "证件类型位数不能超过1000；";
                        }
                        orderPeople.setIdcardType(cell.getStringCellValue());

                    } else if (c == 4) {
                        //证件号
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "证件号码不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.SHENG_FEN_ZHENG)) {
                            rowMessages += "证件号码格式错误；";
                        }
                        orderPeople.setIdcard(cell.getStringCellValue());

                    } else if (c == 5) {
                        //性别
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "性别不能为空；";
                        }
                        else if (!cell.getStringCellValue().equals("男") && !cell.getStringCellValue().equals("女")) {
                            rowMessages += "性别只能输入男或者女；";
                        }
                        orderPeople.setSex(cell.getStringCellValue());

                    } else if (c == 6) {
                        //出生日期
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "出生日期不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.SHENG_RI)) {
                            rowMessages += "出生日期格式错误；";
                        }
                        orderPeople.setBirth(cell.getStringCellValue());

                    } else if (c == 7) {
                        //生效日期
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "生效日期不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.SHENG_RI)) {
                            rowMessages += "生效日期格式错误；";
                        }
                        orderPeople.setStartTime(cell.getStringCellValue());

                    } else if (c == 8) {
                        //居住省/直辖市
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "居住所在地不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "居住所在地位数不能超过1000；";
                        }
                        orderPeople.setLivePlace(cell.getStringCellValue());

                    } else if (c == 9) {
                        //投保原因
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "投保原因不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "投保原因位数不能超过1000；";
                        }
                        orderPeople.setInsuranceReason(cell.getStringCellValue());

                    } else if (c == 10) {
                        //高端险种被保险人性质
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "高端险种被保险人性质不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "高端险种被保险人性质位数不能超过1000；";
                        }
//                        else if (!strOrderProductPlan.contains(cell.getStringCellValue())){
//                            rowMessages += "保险计划还没有添加；";
//                        }
                        orderPeople.setInsuredNature(cell.getStringCellValue());

                    } else if (c == 11) {
                        //联系电话
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "手机号码不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.MOBILE_PHONE_NUMBER_PATTERN)) {
                            rowMessages += "手机号码格式错误；";
                        }
                        orderPeople.setPhone(cell.getStringCellValue());

//                    } else if (c == 12) {
//                        //意外保费
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "意外保费不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "意外保费位数不能超过1000；";
//                        }
//                        orderPeople.setYiwaiBaofei(cell.getStringCellValue());

                    } else if (c == 12) {
                        //家庭关系
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "与主被保险人关系不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "与主被保险人关系位数不能超过1000；";
                        }
                        orderPeople.setRelationship(cell.getStringCellValue());

                    } else if (c == 13) {
                        //对应员工姓名
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "对应员工姓名不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "对应员工姓名位数不能超过1000；";
//                        }
                        orderPeople.setDuiyingemployeeName(cell.getStringCellValue());

                    } else if (c == 14) {
                        //员工证件号
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "工号不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "列工号位数不能超过1000；";
//                        }
                        orderPeople.setEmpNo(cell.getStringCellValue());

                    } else if (c == 15) {
                        //结婚登记日
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "结婚登记日不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "结婚登记日位数不能超过1000；";
//                        }
                        orderPeople.setMarryDate(cell.getStringCellValue());

                    } else if (c == 16) {
                        //开票单位名称
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "开票单位名称不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "开票单位名称不能超过1000；";
//                        }
                        orderPeople.setKaipiaoName(cell.getStringCellValue());

                    } else if (c == 17) {
                        //月薪
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "月薪不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "月薪位数不能超过1000；";
//                        }
                        orderPeople.setSalary(cell.getStringCellValue());

                    } else if (c == 18) {
                        //年薪
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "年薪不能为空；";
//                        }
                        orderPeople.setYearSaraly(cell.getStringCellValue());

                    } else if (c == 19) {
                        //社保所在地
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "社保所在地不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "社保所在地位数不能超过1000；";
//                        }
                        orderPeople.setShebaoPlace(cell.getStringCellValue());

                    } else if (c == 20) {
                        //是否含美国区域计划
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "是否含美国区域计划不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "是否含美国区域计划位数不能超过1000；";
//                        }
                        orderPeople.setIsUsplan(cell.getStringCellValue());

                    } else if (c == 21) {
                        //婚姻状态
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "婚姻状态不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "婚姻状态位数不能超过1000；";
//                        }
                        orderPeople.setMarryStatue(cell.getStringCellValue());

                    } else if (c == 22) {
                        //拼音（英文）名
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "拼音（英文）名不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "拼音（英文）名位数不能超过1000；";
//                        }
                        orderPeople.setPingMing(cell.getStringCellValue());

                    } else if (c == 23) {
                        //拼音（英文）中间名
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "拼音（英文）中间名不能为空；";
//                        } else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "拼音（英文）中间名位数不能超过1000；";
//                        }
                        orderPeople.setPingMidming(cell.getStringCellValue());

                    }else if (c == 24) {
                        //拼音（英文）姓
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "拼音（英文）姓不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "拼音（英文）姓位数不能超过1000；";
//                        }
                        orderPeople.setPingXing(cell.getStringCellValue());

                    } else if (c == 25) {
                        //账户持有人
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "账户持有人不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "账户持有人位数不能超过1000；";
//                        }
                        orderPeople.setAccountName(cell.getStringCellValue());

                    } else if (c == 26) {
                        //开户银行名称
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "开户银行名称不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "开户银行名称位数不能超过1000；";
//                        }
                        orderPeople.setBankName(cell.getStringCellValue());

                    } else if (c == 27) {
                        //分行
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "分行不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "分行位数不能超过1000；";
//                        }
                        orderPeople.setBankbrName(cell.getStringCellValue());

                    } else if (c == 28) {
                        //账号
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "银行帐号不能为空；";
//                        }
//                        else if (!cell.getStringCellValue().matches(UserConstants.YIN_HANG_KA)) {
//                            rowMessages += "银行帐号格式错误；";
//                        }
                        orderPeople.setBankNo(cell.getStringCellValue());

                    } else if (c == 29) {
                        //E-mail
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "电子邮箱不能为空；";
//                        }
//                        else if (!cell.getStringCellValue().matches(UserConstants.EMAIL_PATTERN)) {
//                            rowMessages += "电子邮箱格式错误；";
//                        }
                        orderPeople.setEmail(cell.getStringCellValue());

                    } else if (c == 30) {
                        //员工编码
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "员工编码不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "员工编码位数不能超过1000；";
//                        }
                        orderPeople.setEmpNo(cell.getStringCellValue());

                    } else if (c == 31) {
                        //所属部门名称
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "所属部门名称不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "所属部门名称位数不能超过1000；";
//                        }
                        orderPeople.setDeptName(cell.getStringCellValue());

                    } else if (c == 32) {
                        //制卡姓名
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "制卡姓名不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "制卡姓名位数不能超过1000；";
//                        }
                        orderPeople.setZhikaName(cell.getStringCellValue());

                    } else if (c == 33) {
                        //职业类别
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "职业类别不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "职业类别位数不能超过1000；";
                        }
                        orderPeople.setWorkType(cell.getStringCellValue());

                    } else if (c == 34) {
                        //职业代码
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "职业代码不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "职业代码不能超过1000；";
                        }
                        orderPeople.setWorkCode(cell.getStringCellValue());

                    }  else if (c == 35) {
                        //医疗保费
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "医疗保费不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "医疗保费位数不能超过1000；";
//                        }
                        orderPeople.setYiliaoBaofei(cell.getStringCellValue());

                    } else if (c == 36) {
                        //意外保费
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "意外保费不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "意外保费位数不能超过1000；";
//                        }
                        orderPeople.setYiwaiBaofei(cell.getStringCellValue());

                    } else if (c == 37) {
                        //重疾保费
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "重疾保费不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "重疾保费位数不能超过1000；";
//                        }
                        orderPeople.setZhongjiBaofei(cell.getStringCellValue());

                    } else if (c == 38) {
                        //疾病身故保费
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "疾病身故保费不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "疾病身故保费位数不能超过1000；";
//                        }
                        orderPeople.setShengguBaofei(cell.getStringCellValue());

                    } else if (c == 39) {
                        //总保费
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessages = "总保费不能为空；";
//                        }
//                        else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessages += "总保费位数不能超过1000；";
//                        }
                        orderPeople.setBaofei(cell.getStringCellValue());
                        orderPeopleList.add(orderPeople);
                    }

                } else {
                    rowMessages += "第" + (c + 1) + "列数据有问题，请仔细检查；";
                }
            }
            //拼接每行的错误提示
            if (!StringUtils.isEmpty(rowMessages)) {
                errorMsg +=  "第" + (r + 1) + "行，" + rowMessages + br;
            }
        }

        //全部验证通过才导入到数据库
        if (StringUtils.isEmpty(errorMsg)) {

            excelOrderAgainUtil.orderPeopleService.deleteOrderPeopleByOrderId(orderid);
            excelOrderAgainUtil.orderPeopleService.insertOrderPeopleList(orderPeopleList);

            errorMsg = "导入成功！";
            return errorMsg;
        }else{
            return errorMsg;
        }
    }
}

