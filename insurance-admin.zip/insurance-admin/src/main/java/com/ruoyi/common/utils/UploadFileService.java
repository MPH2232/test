//package com.ruoyi.common.utils;
//
//import com.fm.activity.constant.CompleteConstant;
//import com.fm.activity.dao.CustomerMapper;
//import com.fm.activity.entity.Behavior;
//import com.fm.activity.entity.MediaResult;
//import com.fm.common.resultCode.ResultCodeEnum;
//import com.fm.common.userdefinedexception.UserDefinedException;
//import com.fm.common.util.ConfigUtils;
//import com.fm.common.util.JSONUtils;
//import com.fm.common.util.UUIDUtils;
//import com.fm.redis.service.RedisTool;
//import com.microsoft.azure.storage.CloudStorageAccount;
//import com.microsoft.azure.storage.StorageException;
//import com.microsoft.azure.storage.blob.*;
//import it.sauronsoftware.jave.Encoder;
//import it.sauronsoftware.jave.EncoderException;
//import it.sauronsoftware.jave.MultimediaInfo;
//import org.apache.commons.collections.CollectionUtils;
//import org.apache.commons.lang3.RandomUtils;
//import org.apache.commons.lang3.StringUtils;
//import org.apache.poi.hssf.usermodel.HSSFCell;
//import org.apache.poi.hssf.usermodel.HSSFWorkbook;
//import org.apache.poi.ss.usermodel.Cell;
//import org.apache.poi.ss.usermodel.Row;
//import org.apache.poi.ss.usermodel.Sheet;
//import org.apache.poi.ss.usermodel.Workbook;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import org.joda.time.DateTime;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.stereotype.Service;
//import org.springframework.web.multipart.MultipartFile;
//
//import javax.annotation.Resource;
//import java.io.*;
//import java.net.URISyntaxException;
//import java.net.URL;
//import java.nio.file.Files;
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.util.*;
//
//import org.apache.commons.net.ftp.FTPClient;
//import org.apache.commons.net.ftp.FTPReply;
//import sun.misc.BASE64Decoder;
//
//
///**
// * Created by yangfan on 2017/11/7.
// */
//
//@Service
//public class UploadFileService {
//
//    private static final Logger logger = LoggerFactory.getLogger(UploadFileService.class);
//
//    private static CloudBlobContainer container;
//
//    private static final String CONNECTION = ConfigUtils.getPropValues("azure.connection");
//
//    private static final String LOCALPATH = ConfigUtils.getPropValues("file.localpath");
//
//    static {
//        try {
//            /*CloudStorageAccount storageAccount = CloudStorageAccount.parse(CONNECTION);
//            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
//            container = blobClient.getContainerReference("files");
//            container.createIfNotExists();
//            BlobContainerPermissions containerPermissions = new BlobContainerPermissions();
//            containerPermissions.setPublicAccess(BlobContainerPublicAccessType.CONTAINER);
//            container.uploadPermissions(containerPermissions);*/
//        } catch (Exception e) {
//            logger.error("Blob初始化异常", e);
//        }
//    }
//
//    // 允许上传的格式
//    private static final String[] EXCEL_TYPE = new String[]{"xlsx", "xls"};
//    private static final String[] IMAGE_TYPE = new String[]{"jpg", "jpeg", "png"};
//    private static final String[] VIDEO_TYPE = new String[]{"mov", "mp4", "3gp","swf"};
//    private static final String[] AUDIO_TYPE = new String[]{"mp3"};
//
//
//    @Resource
//    private CustomerMapper customerMapper;
//
//    /**
//     * @Method 上传Excel文件
//     * @Author Tian Hao
//     * @Date 2017/11/12 11:30
//     */
//    public Map<String, Object> uploadExcel(MultipartFile file) throws UserDefinedException {
//        logger.info("UploadFileService 上传Excel文件");
//        for (String type : EXCEL_TYPE) {
//            String fileName = file.getOriginalFilename();
//            if (StringUtils.endsWithIgnoreCase(fileName, type)) {
//                try {
//                    InputStream uploadStream = file.getInputStream();
//                    Long fileSize = file.getSize();
//                    String url = uploadToBlob(uploadStream, fileName, fileSize);
//
//                    InputStream readStream = file.getInputStream();
//                    Set<Behavior> set = readExcel(readStream, fileName);
//                    if (CollectionUtils.isEmpty(set)) {
//                        throw new UserDefinedException(ResultCodeEnum.ERROR_16.getCode(), ResultCodeEnum.ERROR_16.getDesc());
//                    }
//                    // 将客户信息存到redis key返回前端 过期时间4小时
//                    String excelkey = UUIDUtils.generateUUID();
//                    redisTool.set(excelkey, JSONUtils.toJSONString(set), 14400);
//                    String enSize = String.format("%.2f", fileSize.doubleValue() / 1024 / 1024);
//
//                    Map<String, Object> map = new HashMap<>();
//                    map.put("enUrl", url);
//                    map.put("excelkey", excelkey);
//                    map.put("perTotal", set.size());
//                    map.put("excelName", fileName);
//                    map.put("enSize", enSize);
//                    return map;
//                } catch (IOException | StorageException | URISyntaxException e) {
//                    logger.error("UploadFileService 上传Excel文件异常");
//                    throw new UserDefinedException(ResultCodeEnum.ERROR_22.getCode(), ResultCodeEnum.ERROR_22.getDesc());
//                }
//            }
//        }
//        throw new UserDefinedException(ResultCodeEnum.ERROR_13.getCode(), ResultCodeEnum.ERROR_13.getDesc());
//    }
//
//    private Set<Behavior> readExcel(InputStream inputStream, String fileName) throws IOException, UserDefinedException {
//        // 实例化工作簿
//        Workbook wb = getWorkbook(inputStream, fileName);
//        // 获取第一个sheet
//        Sheet sheet = wb.getSheetAt(0);
//        // 读取sheet中的数据
//        return readSheet(sheet);
//    }
//
//    public Workbook getWorkbook(InputStream inputStream, String fileName) throws IOException {
//        boolean isExcel2003 = true;
//        if (fileName.matches("^.+\\.(?i)(xlsx)$")) {
//            isExcel2003 = false;
//        }
//        // 根据版本选择创建Workbook的方式
//        Workbook wb;
//        if (isExcel2003) {
//            // 当excel是2003时
//            wb = new HSSFWorkbook(inputStream);
//        } else {
//            // 当excel是2007时
//            wb = new XSSFWorkbook(inputStream);
//        }
//        return wb;
//    }
//
//    private Set<Behavior> readSheet(Sheet sheet) throws UserDefinedException {
//        if (sheet == null) {
//            throw new UserDefinedException(ResultCodeEnum.ERROR_17.getCode(), ResultCodeEnum.ERROR_17.getDesc());
//        }
//        // 行数
//        int totalRows = sheet.getPhysicalNumberOfRows();
//        // 如果行数小于两行（第一行为标题）
//        if (totalRows < 2) {
//            throw new UserDefinedException(ResultCodeEnum.ERROR_17.getCode(), ResultCodeEnum.ERROR_17.getDesc());
//        }
//        // 获取标题行
//        Row titleRow = sheet.getRow(0);
//        if (titleRow == null) {
//            throw new UserDefinedException(ResultCodeEnum.ERROR_17.getCode(), ResultCodeEnum.ERROR_17.getDesc());
//        }
//        // 列数
//        int totalCells = titleRow.getPhysicalNumberOfCells();
//        // 如果列数小于9列（用户上传的excel为9列字段）
//        if (totalCells < 9) {
//            throw new UserDefinedException(ResultCodeEnum.ERROR_39.getCode(), ResultCodeEnum.ERROR_39.getDesc());
//        }
//        Set<Behavior> custSet = new HashSet<>();
//        // 读取每一行的数据，从第二行开始，第一行为标题
//        for (int i = 1; i < totalRows; i++) {
//            Row row = sheet.getRow(i);
//            if (row != null) {
//                Behavior cust = readRow(row);
//                if (!custIsEmpty(cust)) {
//                    cust.setCuId(UUIDUtils.generateUUID());
//                    custSet.add(cust);
//                }
//            }
//        }
//        return custSet;
//    }
//
//    private Behavior readRow(Row row) {
//        Behavior cust = new Behavior();
//        for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
//            Cell cell = row.getCell(i);
//            if (cell != null) {
//                // 第一列不读
//                switch (i) {
//                    case 0:
//                        cust.setCuUser(getStringCellValue(cell));
//                        break;
//                    case 1:
//                        cust.setCuVin(getStringCellValue(cell));
//                        break;
//                    case 2:
//                        cust.setCuMobileNumber(getStringCellValue(cell));
//                        break;
//                    case 3:
//                        cust.setCuEmail(getStringCellValue(cell));
//                        break;
//                    case 4:
//                        cust.setCuCarModel(getStringCellValue(cell));
//                        break;
//                    case 5:
//                        cust.setCuCarYear(getStringCellValue(cell));
//                        break;
//                    case 6:
//                        cust.setCuFreeText(getStringCellValue(cell));
//                        break;
//                    case 7:
//                        cust.setCuFreeBroswing(getStringCellValue(cell));
//                        break;
//                    case 8:
//                        cust.setCuNotification(getStringCellValue(cell));
//                        break;
//                    default:
//                        break;
//                }
//            }
//        }
//        return cust;
//    }
//
//
//    private String uploadToBlob(InputStream inputStream, String fileName, Long size) throws StorageException, IOException, URISyntaxException {
//        /*CloudBlockBlob blob = null;
//        DateTime dateTime = new DateTime(new Date());
//        String newPath = dateTime.toString("yyyy") + "/" + dateTime.toString("MM") + "/" + dateTime.toString("dd");
//        String newName = dateTime.toString("yyyyMMddHHmmssSSSS") + RandomUtils.nextInt(100, 9999) + "." + StringUtils.substringAfterLast(fileName, ".");
//        blob = container.getBlockBlobReference(newPath + "/" + newName);
//        blob.upload(inputStream, size);
//        return blob.getUri().toString();*/
//        DateTime dateTime = new DateTime(new Date());
//        String newPath = dateTime.toString("yyyy") + "/" + dateTime.toString("MM") + "/" + dateTime.toString("dd");
//        String newName = dateTime.toString("yyyyMMddHHmmssSSSS") + RandomUtils.nextInt(100, 9999) + "." + StringUtils.substringAfterLast(fileName, ".");
//        String filePath= CompleteConstant.FILES_URL+newPath;
//        saveFile(inputStream,newName,size,filePath);
//        return CompleteConstant.FILES_DNS+filePath+"/"+newName;
//    }
//
//    /**
//     * 存储附件至服务器本地
//     * @param inputStream
//     * @param fileName
//     * @param size
//     */
//    private void saveFile(InputStream inputStream, String fileName,Long size,String filePath) {
//        int size_int=size.intValue();
//        OutputStream os = null;
//        try {
//            String path = filePath;
//            // 2、保存到临时文件
//            // 1K的数据缓冲
//            byte[] bs = new byte[size_int];
//            // 读取到的数据长度
//            int len;
//            // 输出的文件流保存到本地文件
//
//            File tempFile = new File(path);
//            if (!tempFile.exists()) {
//                tempFile.mkdirs();
//            }
//            os = new FileOutputStream(tempFile.getPath() + File.separator + fileName);
//            // 开始读取
//            while ((len = inputStream.read(bs)) != -1) {
//                os.write(bs, 0, len);
//            }
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            // 完毕，关闭所有链接
//            try {
//                os.close();
//                inputStream.close();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//
//
//    /**
//     * Description: 向FTP服务器上传文件
//     * @Version      1.0
//     * @param url FTP服务器hostname
//     * @param port  FTP服务器端口
//     * @param username FTP登录账号
//     * @param password  FTP登录密码
//     * @param path  FTP服务器保存目录
//     * @param filename  上传到FTP服务器上的文件名
//     * @param input   输入流
//     * @return 成功返回true，否则返回false *
//     */
//    public static boolean uploadFile(String url,// FTP服务器hostname
//                                     int port,// FTP服务器端口
//                                     String username, // FTP登录账号
//                                     String password, // FTP登录密码
//                                     String path, // FTP服务器保存目录
//                                     String filename, // 上传到FTP服务器上的文件名
//                                     InputStream input // 输入流
//    ){
//        boolean success = false;
//        FTPClient ftp = new FTPClient();
//        ftp.setControlEncoding("GBK");
//        try {
//            int reply;
//            ftp.connect(url, port);// 连接FTP服务器
//            // 如果采用默认端口，可以使用ftp.connect(url)的方式直接连接FTP服务器
//            ftp.login(username, password);// 登录
//            reply = ftp.getReplyCode();
//            if (!FTPReply.isPositiveCompletion(reply)) {
//                ftp.disconnect();
//                return success;
//            }
//            ftp.setFileType(FTPClient.BINARY_FILE_TYPE);
//            ftp.makeDirectory(path);
//            ftp.changeWorkingDirectory(path);
//            ftp.storeFile(filename, input);
//            input.close();
//            ftp.logout();
//            success = true;
//        } catch (IOException e) {
//            e.printStackTrace();
//        } finally {
//            if (ftp.isConnected()) {
//                try {
//                    ftp.disconnect();
//                } catch (IOException ioe) {
//                }
//            }
//        }
//        return success;
//    }
//
//    /**
//     * @Method 上传图片
//     * @Author gbl
//     * @Date 2017年11月11日13:52:30
//     */
//    public MediaResult uploadImage(MultipartFile uploadFile) throws UserDefinedException {
//        logger.info("AdManageService 上传图片");
//        if (uploadFile.getSize() > 5242880) {
//            throw new UserDefinedException(ResultCodeEnum.ERROR_25.getCode(), ResultCodeEnum.ERROR_25.getDesc());
//        }
//        MediaResult result = new MediaResult();
//        for (String type : IMAGE_TYPE) {
//            String fileName = uploadFile.getOriginalFilename();
//            if (StringUtils.endsWithIgnoreCase(fileName, type)) {
//                try {
//                    InputStream fileStream = uploadFile.getInputStream();
//                    Long fileSize = uploadFile.getSize();
//                    String url = uploadToBlob(fileStream, fileName, fileSize);
//                    String size = String.format("%.2f", fileSize.doubleValue() / 1024 / 1024);
//                    result.setEnUrl(url);
//                    result.setEnType(1);// 1图片，2音频，3视频
//                    result.setEnSize(size);
//                    return result;
//                } catch (IOException | StorageException | URISyntaxException e) {
//                    logger.error("UploadFileService 上传图片异常");
//                    throw new UserDefinedException(ResultCodeEnum.ERROR_22.getCode(), ResultCodeEnum.ERROR_22.getDesc());
//                }
//            }
//        }
//        throw new UserDefinedException(ResultCodeEnum.ERROR_13.getCode(), ResultCodeEnum.ERROR_13.getDesc());
//    }
//
//
//    /**
//     * @Method 上传图片
//     * @Author gbl
//     * @Date 2017年11月11日13:52:30
//     */
//    public MediaResult uploadImageBase64(String imageBase64) throws UserDefinedException {
//        logger.info("AdManageService 上传图片");
//        try {
//            BASE64Decoder d = new BASE64Decoder();
//            byte[] data = d.decodeBuffer(imageBase64);
//            if (data.length > 5242880) {
//                throw new UserDefinedException(ResultCodeEnum.ERROR_25.getCode(), ResultCodeEnum.ERROR_25.getDesc());
//            }
//            String fileName="Original.jpg";
//            Long fileSize =(long)data.length;
//            InputStream fileStream=new ByteArrayInputStream(data);
//            MediaResult result = new MediaResult();
//            String url = uploadToBlob(fileStream, fileName, fileSize);
//            String size = String.format("%.2f", fileSize.doubleValue() / 1024 / 1024);
//            result.setEnUrl(url);
//            result.setEnType(1);// 1图片，2音频，3视频
//            result.setEnSize(size);
//            return result;
//        }catch (IOException | StorageException | URISyntaxException e) {
//            logger.error("UploadFileService 上传图片异常");
//            throw new UserDefinedException(ResultCodeEnum.ERROR_22.getCode(), ResultCodeEnum.ERROR_22.getDesc());
//        }catch (Exception e){
//            throw new UserDefinedException(ResultCodeEnum.ERROR_13.getCode(), ResultCodeEnum.ERROR_13.getDesc());
//        }
//    }
//
//    /**
//     * @Method 上传视频
//     * @Author gbl
//     * @Date 2017年11月11日13:52:45
//     */
//    public List<MediaResult> uploadVideo(MultipartFile uploadFile) throws UserDefinedException {
//        logger.info("AdManageService 上传视频");
//        if (uploadFile.getSize() > 52428800) {
//            throw new UserDefinedException(ResultCodeEnum.ERROR_25.getCode(), ResultCodeEnum.ERROR_25.getDesc());
//        }
//        List<MediaResult> list=new ArrayList<>();
//        MediaResult result = new MediaResult();
//        for (String type : VIDEO_TYPE) {
//            String fileName = uploadFile.getOriginalFilename();
//            if (StringUtils.endsWithIgnoreCase(fileName, type)) {
//                try {
//                    InputStream fileStream = uploadFile.getInputStream();
//                    Long fileSize = uploadFile.getSize();
//                    String url = uploadToBlob(fileStream, fileName, fileSize);
//                    String time = "";
//                    if (!"swf".equals(type)){
//                        time = getMediaInfo(url, fileName);
//                    }else {
//                        time = "11";
//                    }
//                    String size = String.format("%.2f", fileSize.doubleValue() / 1024 / 1024);
//                    result.setEnUrl(url);
//                    result.setEnType(3);// 1图片，2音频，3视频
//                    result.setEnSize(size);
//                    result.setEnTime(time);
//                    result.setEnName(fileName);
//                    list.add(result);
//                    return list;
//                } catch (IOException | StorageException | URISyntaxException e) {
//                    logger.error("UploadFileService 上传视频异常",e);
//                    throw new UserDefinedException(ResultCodeEnum.ERROR_22.getCode(), ResultCodeEnum.ERROR_22.getDesc());
//                }
//            }
//        }
//        throw new UserDefinedException(ResultCodeEnum.ERROR_13.getCode(), ResultCodeEnum.ERROR_13.getDesc());
//    }
//
//    /**
//     * @Method 上传音频
//     * @Author gbl
//     * @Date 2017年11月11日13:52:55
//     */
//    public MediaResult uploadAudio(MultipartFile uploadFile) throws UserDefinedException {
//        logger.info("AdManageService 上传音频");
//        if (uploadFile.getSize() > 10485760) {
//            throw new UserDefinedException(ResultCodeEnum.ERROR_25.getCode(), ResultCodeEnum.ERROR_25.getDesc());
//        }
//        MediaResult result = new MediaResult();
//        for (String type : AUDIO_TYPE) {
//            String fileName = uploadFile.getOriginalFilename();
//            if (StringUtils.endsWithIgnoreCase(fileName, type)) {
//                try {
//                    InputStream fileStream = uploadFile.getInputStream();
//                    Long fileSize = uploadFile.getSize();
//                    String url = uploadToBlob(fileStream, fileName, fileSize);
//                    String time = getMediaInfo(url, fileName);
//                    String size = String.format("%.2f", fileSize.doubleValue() / 1024 / 1024);
//                    result.setEnUrl(url);
//                    result.setEnType(2);// 1图片，2音频，3视频
//                    result.setEnSize(size);
//                    result.setEnTime(time);
//                    return result;
//                } catch (IOException | StorageException | URISyntaxException e) {
//                    logger.error("UploadFileService 上传音频异常");
//                    throw new UserDefinedException(ResultCodeEnum.ERROR_22.getCode(), ResultCodeEnum.ERROR_22.getDesc());
//                }
//            }
//        }
//        throw new UserDefinedException(ResultCodeEnum.ERROR_13.getCode(), ResultCodeEnum.ERROR_13.getDesc());
//    }
//
//    /**
//     * @Method 获取音视频时长
//     * @Author Tian Hao
//     * @Date 2017/11/15 10:50
//     */
//    private String getMediaInfo(String url, String fileName) throws UserDefinedException {
//        logger.info("**************开始获取音频/视频时长*********** url:"+url+"   fileName:"+fileName);
//        String str_sub="https://ddhres-int.mercedes-benz.com.cn";
//
//        String filePath=url.substring(str_sub.length());
//        File outfile = new File(filePath);
//        logger.info("**************获取outfile成功***********");
//        try /*(InputStream inputStream = new URL(url).openStream();FileOutputStream fos = new FileOutputStream(outfile); )*/ {
//            Encoder encoder = new Encoder();
//            // 判断文件夹是否存在，不存在就创建
//            /*File localdir = new File(LOCALPATH);
//            if (!localdir.exists()) {
//                localdir.mkdir();
//            }*/
//            logger.info("**************创建file成功***********");
//            /*int b = 0;
//            // 读取字节并写到输出流中
//            while ((b = inputStream.read()) != -1) {
//                fos.write(b);
//                fos.flush();
//            }*/
//            // 获取文件的信息
//            MultimediaInfo info = encoder.getInfo(outfile);
//            logger.info("**************获取文件信息成功***********");
//            // 读取文件的时长
//            Long duration = info.getDuration();
//            String time = String.format("%.2f", duration.doubleValue() / 1000);
//            logger.info("**************获取时长成功*********** duration:"+duration);
//            Path path = Paths.get(LOCALPATH + fileName);
//            /*int i = 0;
//            while (outfile.exists()) {
//                Files.delete(path);
//                i++;
//                if (i > 10000) break;
//            }*/
//            logger.info("**************删除临时file成功***********");
//            return time;
//        } /*catch (IOException e) {
//            logger.error("音频上传失败",e);
//            throw new UserDefinedException(ResultCodeEnum.ERROR_28.getCode(), ResultCodeEnum.ERROR_28.getDesc());
//        }*/ catch (EncoderException e) {
//            logger.error("音频/视频上传失败",e);
//            throw new UserDefinedException(ResultCodeEnum.ERROR_29.getCode(), ResultCodeEnum.ERROR_29.getDesc());
//        }
//    }
//
//    private String getStringCellValue(Cell cell) {
//        if (cell == null) {
//            return "";
//        }
//        String strCell = "";
//        switch (cell.getCellType()) {
//            case HSSFCell.CELL_TYPE_STRING:
//                strCell = cell.getStringCellValue();
//                break;
//            case HSSFCell.CELL_TYPE_NUMERIC:
//                strCell = String.valueOf(cell.getNumericCellValue());
//                break;
//            case HSSFCell.CELL_TYPE_BOOLEAN:
//                strCell = String.valueOf(cell.getBooleanCellValue());
//                break;
//            case HSSFCell.CELL_TYPE_BLANK:
//                strCell = "";
//                break;
//            default:
//                strCell = "";
//                break;
//        }
//        return strCell;
//    }
//
//}
