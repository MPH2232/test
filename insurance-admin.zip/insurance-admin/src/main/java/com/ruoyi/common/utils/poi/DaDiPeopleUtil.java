package com.ruoyi.common.utils.poi;

import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.project.order.orderPeople.domain.OrderPeople;
import com.ruoyi.project.order.orderPeople.service.IOrderPeopleService;
import com.ruoyi.project.order.orderproductPlan.domain.OrderProductPlan;
import com.ruoyi.project.order.orderproductPlan.service.IOrderproductPlanService;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.service.lCustomerService;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

/**
 * Excel相关处理人员清单导入
 *
 * @author ruoyi
 */
@Component
public class DaDiPeopleUtil {

    private static final Logger log = LoggerFactory.getLogger(DaDiPeopleUtil.class);

    @Autowired
    private lCustomerService customerService;

    @Autowired
    private IOrderproductPlanService orderproductPlanService;

    @Autowired
    private IOrderPeopleService orderPeopleService;

    private static DaDiPeopleUtil excelOrderAgainUtil;

    @PostConstruct     //关键二   通过@PostConstruct 和 @PreDestroy 方法 实现初始化和销毁bean之前进行的操作
    public void init() {
        excelOrderAgainUtil = this;
        excelOrderAgainUtil.orderproductPlanService = this.orderproductPlanService;
        excelOrderAgainUtil.orderPeopleService = this.orderPeopleService;
        excelOrderAgainUtil.customerService = this.customerService;
    }


    /**
     * 解析Excel里面的数据
     *
     * @param wb
     * @return
     */
    public String readExcel(Workbook wb,OrderPeople orderPeoples) throws CloneNotSupportedException {
        //客户名称
        String strCustomer = "";
        List<Customer> customerList = excelOrderAgainUtil.customerService.selectCustomersAll();
        for(Customer customers : customerList){
            strCustomer +=customers.getCustomerName()+',';
        }
        String arrCustomer [] = strCustomer.split(",");
//        计划名称
        String strOrderProductPlan = "";
        List<OrderProductPlan> orderProductPlansList = excelOrderAgainUtil.orderproductPlanService.selectOrderProductPlanAll();
        for(OrderProductPlan orderProductPlanss : orderProductPlansList){
            strOrderProductPlan +=orderProductPlanss.getPlanName()+',';
        }
        String arrOrderProductPlan [] = strOrderProductPlan.split(",");

        //错误信息接收器
        String errorMsg = "";
        //最大的list
        List<OrderPeople> orderPeopleList = new ArrayList<OrderPeople>();

        OrderPeople orderPeople;

        String br = "<br/>";

        //得到第一个shell
        Sheet sheets = wb.getSheetAt(0);
        //得到Excel的行数
        int totalRowss = sheets.getPhysicalNumberOfRows();
        //总列数
        int totalCellss = sheets.getRow(0).getLastCellNum();

        String orderid="";

        //循环Excel行数,从第2行开始。标题不入库
        for (int r = 1; r < totalRowss; r++) {
            String rowMessages = "";
            Row row = sheets.getRow(r);
            if (row == null) {
                errorMsg += "第" + (r + 1) + "行数据有问题，请仔细检查！";
                continue;
            }
            orderPeople = new OrderPeople();
            orderid=orderPeoples.getOrderId();
            orderPeople.setOrderId(orderPeoples.getOrderId());
            orderPeople.setOrderType(orderPeoples.getOrderType());
            String xing = "";
            String ming = "";
            String jiaShuXing = "";
            String jiashuMing = "";
            //循环Excel的列
            for (int c = 0; c < totalCellss; c++) {
                Cell cell = row.getCell(c);
                if (null != cell) {
                    row.getCell(c).setCellType(Cell.CELL_TYPE_STRING);

                    if (c == 0) {
                        //序号
                        orderPeople.setPeopleNo(cell.getStringCellValue());

                    } else if (c == 1) {
                        //雇主
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "雇主不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "雇主位数不能超过1000；";
                        }
                        else if (!strCustomer.contains(cell.getStringCellValue())){
                            rowMessages += "雇主还没有添加；";
                        }
                        orderPeople.setBranch(cell.getStringCellValue());

                    } else if (c == 2) {
                        //编码
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "编码不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "编码位数不能超过1000；";
                        }
                        orderPeople.setCode(cell.getStringCellValue());

                    } else if (c == 3) {
                        //员工编号
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "员工编号不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "员工编号位数不能超过1000；";
                        }
                        orderPeople.setEmpNo(cell.getStringCellValue());

                    } else if (c == 4) {
                        //英文姓
                        orderPeople.setPingXing(cell.getStringCellValue());

                    } else if (c == 5) {
                        //英文名
                        orderPeople.setPingMing(cell.getStringCellValue());

                    } else if (c == 6) {
                        //中文姓
                        if(cell.getStringCellValue()!=""){
                            xing = cell.getStringCellValue();
                        }

                    } else if (c == 7) {
                        //中文名
                        if(cell.getStringCellValue()!=""){
                            ming = cell.getStringCellValue();
                            orderPeople.setPeopleName(xing + ming);
                        }

                    } else if (c == 8) {
                        //出生年月
                        if(cell.getStringCellValue()!=""){
                            orderPeople.setBirth(cell.getStringCellValue());
                        }

                    } else if (c == 9) {
                        //年龄
                        if(cell.getStringCellValue()!=""){
                            orderPeople.setAge(cell.getStringCellValue());
                        }

                    } else if (c == 10) {
                        //性别
                        if(cell.getStringCellValue()!=""){
                            if(cell.getStringCellValue().equals("F")){
                                orderPeople.setSex("女");
                            }else{
                                orderPeople.setSex("男");
                            }
                        }

                    } else if (c == 11) {
                        //国籍
                        if(cell.getStringCellValue()!=""){
                            orderPeople.setNationality(cell.getStringCellValue());
                        }

                    } else if (c == 12) {
                        //身份证号或护照号
                        if(cell.getStringCellValue()!=""){
                            orderPeople.setIdcard(cell.getStringCellValue());
                        }

                    } else if (c == 13) {
                        //意外伤害及身故（万元）
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "意外伤害及身故（万元）不能为空；";
                        }
                        orderPeople.setYiwaiBaoe(String.valueOf(Double.valueOf(cell.getStringCellValue())*10000));

                    } else if (c == 14) {
                        //险种
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "险种不能为空；";
                        }
                        orderPeople.setPlanName(cell.getStringCellValue());

                    } else if (c == 15) {
                        //保障代码
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "意外保险费不能为空；";
                        }
                        orderPeople.setCoverageCode(cell.getStringCellValue());

                    } else if (c == 16) {
                        //齿科
                        orderPeople.setDental(cell.getStringCellValue());

                    } else if (c == 17) {
                        //健康检查
                        orderPeople.setWellness(cell.getStringCellValue());

                    } else if (c == 18) {
                        //眼科福利
                        orderPeople.setVision(cell.getStringCellValue());

                    } else if (c == 19) {
                        //战争恐怖主义责任
                        orderPeople.setWar(cell.getStringCellValue());

                    } else if (c == 20) {
                        //生育福利
                        orderPeople.setMaternity(cell.getStringCellValue());

                    } else if (c == 21) {
                        //保险生效日
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "生效日期不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.SHENG_RI)) {
                            rowMessages += "生效日期格式错误；";
                        }
                        orderPeople.setStartTime(cell.getStringCellValue());

                    } else if (c == 22) {
                        //保险失效日
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "保险失效日不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.SHENG_RI)) {
                            rowMessages += "保险失效日格式错误；";
                        }
                        orderPeople.setEndTime(cell.getStringCellValue());
                    } else if (c == 23) {
                        //上一年保费
                        orderPeople.setBeforeBaofei(cell.getStringCellValue());

                    }else if (c == 24) {
                        //意外保费
                        orderPeople.setYiwaiBaofei(cell.getStringCellValue());

                    } else if (c == 25) {
                        //医疗保费
                        orderPeople.setYiliaoBaofei(cell.getStringCellValue());

                    } else if (c == 26) {
                        //保费合计
                        orderPeople.setBaofei(cell.getStringCellValue());

                    } else if (c == 27) {
                        //关系
                        orderPeople.setRelationship(cell.getStringCellValue());

                    } else if (c == 28) {
                        //家属姓
                        if(cell.getStringCellValue()!=""){
                            jiaShuXing = cell.getStringCellValue();
                        }

                    } else if (c == 29) {
                        //家属名
                        if(cell.getStringCellValue()!=""){
                            jiashuMing = cell.getStringCellValue();
                            orderPeople.setPeopleName(jiaShuXing+jiashuMing);
                        }

                    } else if (c == 30) {
                        //出生日期
                        if(cell.getStringCellValue()!=""){
                            orderPeople.setBirth(cell.getStringCellValue());
                        }

                    } else if (c == 31) {
                        //年龄
                        if(cell.getStringCellValue()!=""){
                            orderPeople.setAge(cell.getStringCellValue());
                        }

                    } else if (c == 32) {
                        //性别
                        if(cell.getStringCellValue()!=""){
                            if(cell.getStringCellValue().equals("F")){
                                orderPeople.setSex("女");
                            }else{
                                orderPeople.setSex("男");
                            }
                        }

                    } else if (c == 33) {
                        //国籍
                        if(cell.getStringCellValue()!=""){
                            orderPeople.setNationality(cell.getStringCellValue());
                        }

                    } else if (c == 34) {
                        //护照或身份证号码
                        if(cell.getStringCellValue()!=""){
                            orderPeople.setIdcard(cell.getStringCellValue());
                        }

                    } else if (c == 35) {
                        //福利是否拆分
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "编码不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "编码位数不能超过1000；";
                        }
                        orderPeople.setBenefits(cell.getStringCellValue());

                    } else if (c == 36) {
                        //付费方式
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "编码不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "编码位数不能超过1000；";
                        }
                        orderPeople.setPayWay(cell.getStringCellValue());

                    } else if (c == 37) {
                        //工作邮件地址
                        orderPeople.setWorkEmail(cell.getStringCellValue());

                    } else if (c == 38) {
                        //私人邮件地址
                        orderPeople.setPersonalEmail(cell.getStringCellValue());

                    } else if (c == 39) {
                        //联系邮件地址
                        orderPeople.setEmail(cell.getStringCellValue());

                    } else if (c == 40) {
                        //手机号码
                        orderPeople.setPhone(cell.getStringCellValue());

                    } else if (c == 41) {
                        //办公电话
                        orderPeople.setOfficePhone(cell.getStringCellValue());
                        orderPeopleList.add(orderPeople);
                    }
                } else {
                    rowMessages += "第" + (c + 1) + "列数据有问题，请仔细检查；";
                }
            }
            //拼接每行的错误提示
            if (!StringUtils.isEmpty(rowMessages)) {
                errorMsg +=  "第" + (r + 1) + "行，" + rowMessages + br;
            }
        }

        //全部验证通过才导入到数据库
        if (StringUtils.isEmpty(errorMsg)) {

            excelOrderAgainUtil.orderPeopleService.deleteOrderPeopleByOrderId(orderid);
            excelOrderAgainUtil.orderPeopleService.insertOrderPeopleList(orderPeopleList);

            errorMsg = "导入成功！";
            return errorMsg;
        }else{
            return errorMsg;
        }
    }
}

