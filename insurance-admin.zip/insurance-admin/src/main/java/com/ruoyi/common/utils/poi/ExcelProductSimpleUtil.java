package com.ruoyi.common.utils.poi;

import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.framework.web.controller.BaseController;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.project.system.product.domain.FeilvComplex;
import com.ruoyi.project.system.product.domain.ProductFeilvSimple;
import com.ruoyi.project.system.product.service.IProductFeilvComplexService;
import com.ruoyi.project.system.product.service.IProductFeilvSimpleService;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

/**
 * Excel相关处理高端复杂费率
 *
 * @author ruoyi
 */
@Component
public class ExcelProductSimpleUtil extends BaseController{

    private static final Logger log = LoggerFactory.getLogger(ExcelProductSimpleUtil.class);

    @Autowired
    private IProductFeilvSimpleService productFeilvSimpleService;

    private static ExcelProductSimpleUtil excelProductSimpleUtil;

    @PostConstruct     //关键二   通过@PostConstruct 和 @PreDestroy 方法 实现初始化和销毁bean之前进行的操作
    public void init() {
        excelProductSimpleUtil = this;
        excelProductSimpleUtil.productFeilvSimpleService = this.productFeilvSimpleService;   // 初使化时将已静态化的testService实例化
    }


    /**
     * 解析Excel里面的数据
     *
     * @param wb
     * @return
     */
    public String readExcel(Workbook wb, ProductFeilvSimple productFeilvSimples) throws CloneNotSupportedException {
        //错误信息接收器
        String errorMsg = "";
        //得到第一个shell
        Sheet sheet = wb.getSheetAt(0);
        //得到Excel的行数
        int totalRows = sheet.getPhysicalNumberOfRows();
        //总列数
        int totalCells = 0;
        //得到Excel的列数(前提是有行数)，从第3行算起
        if (totalRows >= 2 && sheet.getRow(1) != null) {
            totalCells = sheet.getRow(1).getLastCellNum();
        }
        List<ProductFeilvSimple> productFeilvSimpleList = new ArrayList<ProductFeilvSimple>();
        ProductFeilvSimple productFeilvSimple;
        String br = "<br/>";

        //循环Excel行数,从第3行开始。标题不入库
        for (int r = 1; r < totalRows; r++) {
            String rowMessage = "";
            Row row = sheet.getRow(r);
            if (row == null) {
                errorMsg +=  "第" + (r + 1) + "行数据有问题，请仔细检查！";
                continue;
            }
            productFeilvSimple = new ProductFeilvSimple();
            productFeilvSimple.setProductId(productFeilvSimples.getProductId());
            productFeilvSimple.setProductName(productFeilvSimples.getProductName());
            productFeilvSimple.setStartTime(productFeilvSimples.getStartTime());
            productFeilvSimple.setEndTime(productFeilvSimples.getEndTime());
            productFeilvSimple.setProName(productFeilvSimples.getProName());
            //循环Excel的列
            for (int c = 0; c < totalCells; c++) {
                Cell cell = row.getCell(c);
                if (null != cell) {
                    row.getCell(c).setCellType(Cell.CELL_TYPE_STRING);
                    if (c == 0) {
                        //年龄
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "年龄不能为空；";
                        } else if (cell.getStringCellValue().length() > 6) {
                            rowMessage += "年龄的字数不能超过6；";
                        }
                        productFeilvSimple.setAge(cell.getStringCellValue());
                    } else if (c == 1) {
                        //性别
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "性别不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "性别的字数不能超过1000；";
                        }
                        productFeilvSimple.setSex(cell.getStringCellValue());
                    }else if (c == 2) {
                        //计划名称
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "被保险人属性不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "被保险人属性的字数不能超过1000；";
                        }
                        productFeilvSimple.setPlan(cell.getStringCellValue());
                    }else if (c == 3) {
                        //保费
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "姓名不能为空；";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "姓名的字数不能超过1000；";
                        }
                        productFeilvSimple.setPlanValue(cell.getStringCellValue());
                    }
                } else {
                    rowMessage += "第" + (c + 1) + "列数据有问题，请仔细检查；";
                }
            }
            //拼接每行的错误提示
            if (!StringUtils.isEmpty(rowMessage)) {
                errorMsg +=  "第" + (r + 1) + "行，" + rowMessage + br;
            } else {
                productFeilvSimpleList.add(productFeilvSimple);
            }
        }
        //全部验证通过才导入到数据库
        if (StringUtils.isEmpty(errorMsg)) {
            excelProductSimpleUtil.productFeilvSimpleService.deleteProductFeilvSimpleByProductIdAndEndTime(productFeilvSimples.getProductId(),productFeilvSimples.getEndTime());
            excelProductSimpleUtil.productFeilvSimpleService.insertProductFeilvSimpleList(productFeilvSimpleList);
            errorMsg = "导入成功，共" + productFeilvSimpleList.size() + "条数据！";
            return errorMsg;
        }else{
            return errorMsg;
        }
    }
}

