package com.ruoyi.common.utils.poi;

import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.framework.aspectj.lang.annotation.Excel;
import com.ruoyi.framework.shiro.web.session.OnlineWebSessionManager;
import com.ruoyi.framework.web.domain.AjaxResult;
import com.ruoyi.project.system.customer.domain.Customer;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.ResourceUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Excel相关处理
 *
 * @author ruoyi
 */
public class ExcelUtil<T>
{

    private static final Logger log = LoggerFactory.getLogger(OnlineWebSessionManager.class);

    public Class<T> clazz;

    public ExcelUtil(Class<T> clazz)
    {
        this.clazz = clazz;
    }

    public List<T> importExcel(String sheetName, InputStream input) throws Exception
    {
        List<T> list = new ArrayList<T>();

        Workbook workbook = WorkbookFactory.create(input);
        Sheet sheet = workbook.getSheet(sheetName);
        if (!sheetName.trim().equals(""))
        {
            sheet = workbook.getSheet(sheetName); // 如果指定sheet名,则取指定sheet中的内容.
        }
        if (sheet == null)
        {
            sheet = workbook.getSheetAt(0); // 如果传入的sheet名不存在则默认指向第1个sheet.
        }
        int rows = sheet.getPhysicalNumberOfRows();

        if (rows > 0)
        {
            // 有数据时才处理
            Field[] allFields = clazz.getDeclaredFields(); // 得到类的所有field.
            Map<Integer, Field> fieldsMap = new HashMap<Integer, Field>(); // 定义一个map用于存放列的序号和field.
            for (int col = 0; col < allFields.length; col++)
            {
                Field field = allFields[col];
                // 将有注解的field存放到map中.
                if (field.isAnnotationPresent(Excel.class))
                {
                    field.setAccessible(true);// 设置类的私有字段属性可访问.
                    fieldsMap.put(col, field);
                }
            }
            for (int i = 1; i < rows; i++)
            {
                // 从第2行开始取数据,默认第一行是表头.
                Row row = sheet.getRow(i);
                int cellNum = sheet.getRow(0).getPhysicalNumberOfCells();
                T entity = null;
                for (int j = 0; j < cellNum; j++)
                {
                    Cell cell = row.getCell(j);
                    if (cell == null)
                    {
                        continue;
                    }
                    else
                    {
                        // 先设置Cell的类型，然后就可以把纯数字作为String类型读进来了 by zhuyangyong 20171228
                        row.getCell(j).setCellType(Cell.CELL_TYPE_STRING);
                        cell = row.getCell(j);
                    }

                    String c = cell.getStringCellValue();
                    if (c.equals(""))
                    {
                        continue;
                    }

                    entity = (entity == null ? clazz.newInstance() : entity);// 如果不存在实例则新建.
                    Field field = fieldsMap.get(j);// 从map中得到对应列的field.
                    // 取得类型,并根据对象类型设置值.
                    Class<?> fieldType = field.getType();
                    if (String.class == fieldType)
                    {
                        field.set(entity, String.valueOf(c));
                    }
                    else if ((Integer.TYPE == fieldType) || (Integer.class == fieldType))
                    {
                        field.set(entity, Integer.parseInt(c));
                    }
                    else if ((Long.TYPE == fieldType) || (Long.class == fieldType))
                    {
                        field.set(entity, Long.valueOf(c));
                    }
                    else if ((Float.TYPE == fieldType) || (Float.class == fieldType))
                    {
                        field.set(entity, Float.valueOf(c));
                    }
                    else if ((Short.TYPE == fieldType) || (Short.class == fieldType))
                    {
                        field.set(entity, Short.valueOf(c));
                    }
                    else if ((Double.TYPE == fieldType) || (Double.class == fieldType))
                    {
                        field.set(entity, Double.valueOf(c));
                    }
                    else if (Character.TYPE == fieldType)
                    {
                        if ((c != null) && (c.length() > 0))
                        {
                            field.set(entity, Character.valueOf(c.charAt(0)));
                        }
                    }
                    else if (java.util.Date.class == fieldType)
                    {
                        if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC)
                        {
                            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                            cell.setCellValue(sdf.format(cell.getNumericCellValue()));
                            c = sdf.format(cell.getNumericCellValue());
                        }
                        else
                        {
                            c = cell.getStringCellValue();
                        }
                    }
                    else if (java.math.BigDecimal.class == fieldType)
                    {
                        c = cell.getStringCellValue();
                    }
                }
                if (entity != null)
                {
                    list.add(entity);
                }
            }
        }

        return list;
    }

    /**
     * 对list数据源将其里面的数据导入到excel表单
     * 
     * @param sheetName 工作表的名称
     */
    public AjaxResult exportExcel(List<T> list, String sheetName)
    {
        Field[] allFields = clazz.getDeclaredFields();// 得到所有定义字段
        List<Field> fields = new ArrayList<Field>();
        // 得到所有field并存放到一个list中.
        for (Field field : allFields)
        {
            if (field.isAnnotationPresent(Excel.class))
            {
                fields.add(field);
            }
        }

        HSSFWorkbook workbook = new HSSFWorkbook();// 产生工作薄对象
        // excel2003中每个sheet中最多有65536行
        int sheetSize = 65536;
        double sheetNo = Math.ceil(list.size() / sheetSize);// 取出一共有多少个sheet.
        for (int index = 0; index <= sheetNo; index++)
        {
            HSSFSheet sheet = workbook.createSheet();// 产生工作表对象
            if (sheetNo == 0)
            {
                workbook.setSheetName(index, sheetName);
            }
            else
            {
                workbook.setSheetName(index, sheetName + index);// 设置工作表的名称.
            }
            HSSFRow row;
            HSSFCell cell; // 产生单元格

            row = sheet.createRow(0); // 产生一行
            // 写入各个字段的列头名称
            for (int i = 0; i < fields.size(); i++)
            {
                Field field = fields.get(i);
                Excel attr = field.getAnnotation(Excel.class);
                cell = row.createCell(i); // 创建列
                cell.setCellType(HSSFCell.CELL_TYPE_STRING); // 设置列中写入内容为String类型
                HSSFCellStyle cellStyle = workbook.createCellStyle();
                cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
                cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
                if (attr.name().indexOf("注：") >= 0)
                {
                    HSSFFont font = workbook.createFont();
                    font.setColor(HSSFFont.COLOR_RED);
                    cellStyle.setFont(font);
                    cellStyle.setFillForegroundColor(HSSFColor.LIGHT_YELLOW.index);
                    sheet.setColumnWidth(i, 6000);
                }
                else
                {
                    HSSFFont font = workbook.createFont();
                    font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD); // 粗体显示
                    cellStyle.setFont(font); // 选择需要用到的字体格式
                    cellStyle.setFillForegroundColor(HSSFColor.LIGHT_YELLOW.index);
                    // 设置列宽
                    sheet.setColumnWidth(i, 3766);
                }
                cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
                cellStyle.setWrapText(true);
                cell.setCellStyle(cellStyle);

                cell.setCellValue(attr.name());// 写入列名

                // 如果设置了提示信息则鼠标放上去提示.
                if (!attr.prompt().trim().equals(""))
                {
                    setHSSFPrompt(sheet, "", attr.prompt(), 1, 100, i, i); // 这里默认设了2-101列提示.
                }
                // 如果设置了combo属性则本列只能选择不能输入
                if (attr.combo().length > 0)
                {
                    setHSSFValidation(sheet, attr.combo(), 1, 100, i, i); // 这里默认设了2-101列只能选择不能输入.
                }
            }

            int startNo = index * sheetSize;
            int endNo = Math.min(startNo + sheetSize, list.size());
            // 写入各条记录,每条记录对应excel表中的一行
            HSSFCellStyle cs = workbook.createCellStyle();
            cs.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            cs.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
            for (int i = startNo; i < endNo; i++)
            {
                row = sheet.createRow(i + 1 - startNo);
                T vo = (T) list.get(i); // 得到导出对象.
                for (int j = 0; j < fields.size(); j++)
                {
                    Field field = fields.get(j); // 获得field.
                    field.setAccessible(true); // 设置实体类私有属性可访问
                    Excel attr = field.getAnnotation(Excel.class);
                    try
                    {
                        // 根据Excel中设置情况决定是否导出,有些情况需要保持为空,希望用户填写这一列.
                        if (attr.isExport())
                        {
                            cell = row.createCell(j);// 创建cell
                            cell.setCellStyle(cs);
                            try
                            {
                                if (String.valueOf(field.get(vo)).length() > 10)
                                {
                                    throw new Exception("长度超过10位就不用转数字了");
                                }
                                // 如果可以转成数字则导出为数字类型
                                BigDecimal bc = new BigDecimal(String.valueOf(field.get(vo)));
                                cell.setCellType(HSSFCell.CELL_TYPE_NUMERIC);
                                cell.setCellValue(bc.doubleValue());
                            }
                            catch (Exception e)
                            {
                                cell.setCellType(HSSFCell.CELL_TYPE_STRING);
                                if (vo == null)
                                {
                                    cell.setCellValue(""); // 如果数据存在就填入,不存在填入空格.
                                }
                                else
                                {
                                    cell.setCellValue(field.get(vo) == null ? "" : String.valueOf(field.get(vo)));// 如果数据存在就填入,不存在填入空格.
                                }

                            }
                        }
                    }
                    catch (Exception e)
                    {
                        log.error("导出Excel失败{}", e);
                    }
                }
            }
        }
        try
        {
            String filename = encodingFilename(sheetName);
            OutputStream out = new FileOutputStream(getfile() + filename);
            workbook.write(out);
            out.close();
            return AjaxResult.success(filename);
        }
        catch (Exception e)
        {
            log.error("关闭flush失败{}", e);
            return AjaxResult.error("导出Excel失败，请联系网站管理员！");
        }
    }

    /**
     * 拼装单个obj
     * @param obj
     * @param row
     * @return
     * @throws Exception
     */
    private  static  Map<String, Object>  dataObj(Object obj, HSSFRow row) throws Exception {
        Class<?> rowClazz= obj.getClass();
        Field[] fields = FieldUtils.getAllFields(rowClazz);
        if (fields == null || fields.length < 1) {
            return null;
        }

        //容器
        Map<String, Object> map = new HashMap<String, Object>();

        //注意excel表格字段顺序要和obj字段顺序对齐 （如果有多余字段请另作特殊下标对应处理）
        for (int j = 0; j < fields.length; j++) {
            map.put(fields[j].getName(), getVal(row.getCell(j)));
        }
        return map;
    }

    public  static   List<Map<String, Object>> importExcels(MultipartFile file, Object obj) throws Exception {

        //装载流
        POIFSFileSystem fs = new POIFSFileSystem(file.getInputStream());
        HSSFWorkbook hw= new HSSFWorkbook(fs);

        //获取第一个sheet页
        HSSFSheet sheet = hw.getSheetAt(1);

        //容器
        List<Map<String, Object>> ret = new ArrayList<Map<String, Object>>();

        log.error("sheet.getLastRowNum()==="+sheet.getLastRowNum());
        //遍历行 从下标第一行开始（去除标题）
        for (int i = 1; i < sheet.getLastRowNum()+1; i++) {
            HSSFRow row= sheet.getRow(i);
            if(row!=null){
                //装载obj
                ret.add(dataObj(obj,row));
            }
        }
        return ret;
    }

    /**
     * 处理val（暂时只处理string和number，可以自己添加自己需要的val类型）
     * @param hssfCell
     * @return
     */
    public static String getVal(HSSFCell hssfCell) {
        if(hssfCell!=null){
        if (hssfCell.getCellType() == HSSFCell.CELL_TYPE_STRING) {
            return hssfCell.getStringCellValue();
        } else {
            return String.valueOf(hssfCell.getNumericCellValue());
        }
        }else{
            return String.valueOf("");
        }
    }

    //(一：导入产品Product、Customer)
    public  static   List<Map<String, Object>> importExcelsPro(MultipartFile file, Object obj) throws Exception {

        //装载流
        POIFSFileSystem fs = new POIFSFileSystem(file.getInputStream());
        HSSFWorkbook hw = new HSSFWorkbook(fs);

        //获取第一个sheet页
        HSSFSheet sheet = hw.getSheetAt(0);

        //容器
        List<Map<String, Object>> ret = new ArrayList<Map<String, Object>>();

        log.error("sheet.getLastRowNum()===" + sheet.getLastRowNum());

//        if (totalRows >= 3 && sheet.getRow(1) != null) {
//            totalCells = sheet.getRow(1).getLastCellNum();
//        }
        //遍历行 从下标第一行开始（去除标题）
        for (int i = 1; i < sheet.getLastRowNum()+1; i++) {
//            String rowMessage = "";
            HSSFRow row= sheet.getRow(i);
            if(row!=null){
                System.out.println(row.toString());
                //装载obj
                ret.add(dataObjPro(obj,row));

            }
        }
        return ret;
    }
    /**
     * (二：导入产品Product,Customer)
     * 拼装单个obj
     * @param obj
     * @param row
     * @return
     * @throws Exception
     */
    private  static  Map<String, Object>  dataObjPro(Object obj, HSSFRow row) throws Exception {



        Class<?> rowClazz= obj.getClass();
        Field[] fields = FieldUtils.getAllFields(rowClazz);
        if (fields == null || fields.length-6 < 1) {
            return null;
        }
        log.info("--rowClazzrowClazz--"+obj.getClass().getName());
        String mes="成功";
        //容器
        Map<String, Object> map = new HashMap<String, Object>();
        //注意excel表格字段顺序要和obj字段顺序对齐 （如果有多余字段请另作特殊下标对应处理）
        int i=0;
        if(rowClazz.getName().contains("Pcustomer")){
                    //个人客户 or 企业客户
                    for (int j = 0; j < fields.length-3; j++) {
//
                        mes=getValCustomer(row.getCell(j),j,row.getRowNum());
                        if(mes.contains("格式错误")){
                            map.put("mes"+String.valueOf(i),mes);
        //                  map.put(fields[j].getName(), mes);
                            i++;
                        } else{
                            map.put(fields[j].getName(), mes);
                            i++;
                        }
            }
        }else{
            //产品
            for (int j = 0; j < fields.length-8; j++) {
                mes=getValPro(row.getCell(j),j,row.getRowNum());
                if(mes.contains("格式错误")){
                    map.put("mes"+String.valueOf(i),mes);
        //          map.put(fields[j].getName(), mes);
                    i++;
                } else{
                    map.put(fields[j].getName(), mes);
                    i++;
                }
            }
        }

        return map;
    }

    /**
     * (三：导入产品Product)
     * 处理val（暂时只处理string和number，可以自己添加自己需要的val类型）
     * @param cell
     * @return
     */
    public static String getValPro(HSSFCell cell,int c,int row) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //循环Excel的列
        String rowMessage="";
        if (null != cell) {
            cell.setCellType(Cell.CELL_TYPE_STRING);
//                    if (c == 0) {
//                        //费率id
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
////                    rowMessage += "格式错误：序号不能为空；";
//                        } else if (cell.getStringCellValue().length() > 6) {
//                            rowMessage += "序号的字数不能超过6；";
//                        } else {
////                    rowMessage= hssfCell.getStringCellValue();
//                        }
////						tempUserKB.setQuestion(question);
//                    } else
                    if (c == 0) {
                        //产品名称
                        if (cell.getStringCellValue()==null || cell.getStringCellValue().equals("")) {
                            rowMessage = "格式错误：第"+row+"行、第"+(c+1)+"列产品名称不能为空；</br>";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列产品名称字数不能超过1000；</br>";
                        }else {
                            rowMessage = cell.getStringCellValue();
                        }
                    } else if (c == 1) {
                        //产品id
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列产品id不能为空；</br>";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列产品id字数不能超过1000；</br>";
                        }else {
                            rowMessage = cell.getStringCellValue();
                        }
                    } else if (c == 2) {
                        //年龄
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列年龄不能为空；</br>";
                        } else if (Integer.parseInt(cell.getStringCellValue()) >= 150) {
                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列年龄不能超过150；</br>";
                        }else {
                            rowMessage = cell.getStringCellValue();
                        }
                    } else if (c == 3) {
                        //性别
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列性别不能为空；</br>";
                        }
                        else if (cell.getStringCellValue().length() > 4) {
                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列性别字数不能超过10；</br>";
                        }
                        else if (cell.getStringCellValue().equals("男") || cell.getStringCellValue().equals("女")) {
                            rowMessage = cell.getStringCellValue();
                        }else {
                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列性别只能输入男或女；</br>";
                        }
                    } else if (c == 4) {
                        //保费
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列保费不能为空；</br>";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列保费字数不能超过1000；</br>";
                        }else {
                            rowMessage = cell.getStringCellValue();
                        }
                    } else if (c == 5) {
                        //备注
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列备注不能为空；</br>";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列备注字数不能超过1000；</br>";
                        }else {
                            rowMessage = cell.getStringCellValue();
                        }
                    } else if (c == 6) {
                        //备注2
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列备注2不能为空；</br>";
                        } else if (cell.getStringCellValue().length() > 1000) {
                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列备注2字数不能超过1000；</br>";
                        }else {
                            rowMessage = cell.getStringCellValue();
                        }
                    }
//                    else if (c == 7) {
//                        //生效日期
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列备注2不能为空；</br>";
//                        } else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列备注2字数不能超过1000；</br>";
//                        }else {
//                            rowMessage = cell.getStringCellValue().replaceAll("/","-");
//                            Date date= null;
//                            try {
//                                date = sdf.parse(rowMessage);
//                                System.out.println(date);
//                            } catch (ParseException e) {
//                                e.printStackTrace();
//                            }
//                            rowMessage = sdf.format(date);
//                        }
//                    } else if (c == 8) {
//                        //关闭日期
//                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列备注2不能为空；</br>";
//                        } else if (cell.getStringCellValue().length() > 1000) {
//                            rowMessage += "格式错误：第"+row+"行、第"+(c+1)+"列备注2字数不能超过1000；</br>";
//                        }else {
//                            rowMessage = cell.getStringCellValue().replaceAll("/","-");
//                            Date date= null;
//                            try {
//                                date = sdf.parse(rowMessage);
//                                System.out.println(date);
//                            } catch (ParseException e) {
//                                e.printStackTrace();
//                            }
//                            rowMessage = sdf.format(date);
//                        }
//                    }
                } else {
                    rowMessage += "格式错误：超出列数是:第"+row+"行、第" + (c) + "列，请仔细检查；</br>";
                }
        return rowMessage;
    }


    /**
     * (四：导入Customer)
     * 处理val（暂时只处理string和number，可以自己添加自己需要的val类型）
     * @param cell
     * @return
     */

    public static String getValCustomer(HSSFCell cell,int c,int row) {

        //循环Excel的列
        String rowMessage="";
        if (null != cell) {
            cell.setCellType(Cell.CELL_TYPE_STRING);
            //1、判断是否是数值格式
//            if (cell.getCellType()==0){
//                if(HSSFDateUtil.isCellDateFormatted(cell)){
//                    String guarantee_date = null;
//                    //用于转化为日期格式
//                    Date d = cell.getDateCellValue();
//                    DateFormat formater = new SimpleDateFormat("yyyy-MM");
//                    guarantee_date=formater.format(d);
//                }
//            }

            if (c == 0) {
                //客户名称
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage = "格式错误：第"+row+"行的第"+(c+1)+"列客户名称不能为空；</br>";
                }
                else if (cell.getStringCellValue().length() > 1000) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列客户名称字数不能超过1000；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            } else if (c == 1) {
                //证件类型
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列证件类型不能为空；</br>";
                } else if (cell.getStringCellValue().length() >50) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列证件类型不能超过50；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            } else if (c == 2) {
                //证件号码

                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列证件号码不能为空；</br>";
                } else if (!cell.getStringCellValue().matches(UserConstants.SHENG_FEN_ZHENG)) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列证件号码格式错误；</br>";
                }
                else {
                    rowMessage = cell.getStringCellValue();
                }
            }  else if (c == 3) {
                //生日

                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage = "格式错误：第"+row+"行的第"+(c+1)+"列生日不能为空；</br>";

                } else if (!cell.getStringCellValue().matches(UserConstants.SHENG_RI)) {
                    rowMessage = "格式错误：第"+row+"行的第"+(c+1)+"列生日格式错误；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            } else if (c == 4) {
                //性别
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列性别不能为空；</br>";
                }
                else if (cell.getStringCellValue().length() > 4) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列性别字数不能超过10；</br>";
                }
                else if (cell.getStringCellValue().equals("男") || cell.getStringCellValue().equals("女")) {
                    rowMessage = cell.getStringCellValue();
                }else {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列性别只能输入男或者女；</br>";
                }
            } else if (c == 5) {
                //邮箱
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列邮箱不能为空；</br>";
                } else if (!cell.getStringCellValue().matches(UserConstants.EMAIL_PATTERN)) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列邮箱格式错误；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            } else if (c == 6) {
                //邮寄地址
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列邮寄地址不能为空；</br>";
                } else if (cell.getStringCellValue().length() > 1000) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列邮寄地址不能超过150；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            }  else if (c == 7) {
                //电话
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列电话不能为空；</br>";
                } else if (!cell.getStringCellValue().matches(UserConstants.MOBILE_PHONE_NUMBER_PATTERN)) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列电话格式错误；</br>";

                }else {
                    rowMessage = cell.getStringCellValue();
                }
            }else if (c == 8) {
                //微信号
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列微信号不能为空；</br>";
                } else if (cell.getStringCellValue().length() > 1000) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列微信号字数不能超过1000；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            } else if (c == 9) {
                //公司名称
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列公司名称不能为空；</br>";
                } else if (cell.getStringCellValue().length() > 1000) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列公司名称不能超过150；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            }  else if (c == 10) {
                //统一社会信用代码
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列统一社会信用代码不能为空；</br>";
                } else if (cell.getStringCellValue().length() > 1000) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列统一社会信用代码字数不能超过1000；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            }else if (c == 11) {
                //是否为增值税一般纳税人
                if (cell.getStringCellValue().equals("是") || cell.getStringCellValue().equals("否")) {
                    rowMessage = cell.getStringCellValue();
                } else if (cell.getStringCellValue().length() > 1000) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列是否为增值税一般纳税人字数不能超过1000；</br>";
                }else {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列是否为增值税一般纳税人只能输入是或者否；</br>";
                }
            } else if (c == 12) {
                //税务登记地址
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列税务登记地址不能为空；</br>";
                } else if (cell.getStringCellValue().length() > 1000) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列税务登记地址不能超过150；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            }  else if (c == 13) {
                //公司电话
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列公司电话不能为空；</br>";
                } else if (!cell.getStringCellValue().matches(UserConstants.ZUO_JI_HAO)) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列公司电话格式错误；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            }else if (c == 14) {
                //开户行
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列开户行不能为空；</br>";
                } else if (cell.getStringCellValue().length() > 1000) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列开户行字数不能超过1000；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            } else if (c == 15) {
                //开户支行
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列开户支行不能为空；</br>";
                } else if (cell.getStringCellValue().length() > 100) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列开户支行字数不能超过100；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            }
            else if (c == 16) {
                //开户账号
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列开户账号不能为空；</br>";
                } else if (!cell.getStringCellValue().matches(UserConstants.YIN_HANG_KA)) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列开户账号格式错误；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            } else if (c == 17) {
                //户名
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列户名不能为空；</br>";
                } else if (cell.getStringCellValue().length() > 1000) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列户名字数不能超过100；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            } else if (c == 18) {
                //开户行
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列开户行不能为空；</br>";
                } else if (cell.getStringCellValue().length() > 1000) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列开户行字数不能超过100；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            } else if (c == 19) {
                //开户支行
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列开户支行不能为空；</br>";
                } else if (cell.getStringCellValue().length() > 1000) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列开户支行字数不能超过100；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            }else if (c == 20) {
                //开户账号
                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列开户账号不能为空；</br>";
                } else if (!cell.getStringCellValue().matches(UserConstants.YIN_HANG_KA)) {
                    rowMessage += "格式错误：第"+row+"行的第"+(c+1)+"列开户账号格式错误；</br>";
                }else {
                    rowMessage = cell.getStringCellValue();
                }
            }
        } else {
            rowMessage += "格式错误：第"+row+"行的第" + (c+1) + "列客户名称不能为空；</br>";
        }
        return rowMessage;

    }
    /**
     * 将EXCEL中A,B,C,D,E列映射成0,1,2,3
     * 
     * @param col
     */
//    public static int getExcelCol(String col)
//    {
//        col = col.toUpperCase();
//        // 从-1开始计算,字母重1开始运算。这种总数下来算数正好相同。
//        int count = -1;
//        char[] cs = col.toCharArray();
//        for (int i = 0; i < cs.length; i++)
//        {
//            count += (cs[i] - 64) * Math.pow(26, cs.length - 1 - i);
//        }
//        return count;
//    }

    /**
     * 设置单元格上提示
     * 
     * @param sheet 要设置的sheet.
     * @param promptTitle 标题
     * @param promptContent 内容
     * @param firstRow 开始行
     * @param endRow 结束行
     * @param firstCol 开始列
     * @param endCol 结束列
     * @return 设置好的sheet.
     */
    public static HSSFSheet setHSSFPrompt(HSSFSheet sheet, String promptTitle, String promptContent, int firstRow,
            int endRow, int firstCol, int endCol)
    {
        // 构造constraint对象
        DVConstraint constraint = DVConstraint.createCustomFormulaConstraint("DD1");
        // 四个参数分别是：起始行、终止行、起始列、终止列
        CellRangeAddressList regions = new CellRangeAddressList(firstRow, endRow, firstCol, endCol);
        // 数据有效性对象
        HSSFDataValidation data_validation_view = new HSSFDataValidation(regions, constraint);
        data_validation_view.createPromptBox(promptTitle, promptContent);
        sheet.addValidationData(data_validation_view);
        return sheet;
    }

    /**
     * 设置某些列的值只能输入预制的数据,显示下拉框.
     * 
     * @param sheet 要设置的sheet.
     * @param textlist 下拉框显示的内容
     * @param firstRow 开始行
     * @param endRow 结束行
     * @param firstCol 开始列
     * @param endCol 结束列
     * @return 设置好的sheet.
     */
    public static HSSFSheet setHSSFValidation(HSSFSheet sheet, String[] textlist, int firstRow, int endRow,
            int firstCol, int endCol)
    {
        // 加载下拉列表内容
        DVConstraint constraint = DVConstraint.createExplicitListConstraint(textlist);
        // 设置数据有效性加载在哪个单元格上,四个参数分别是：起始行、终止行、起始列、终止列
        CellRangeAddressList regions = new CellRangeAddressList(firstRow, endRow, firstCol, endCol);
        // 数据有效性对象
        HSSFDataValidation data_validation_list = new HSSFDataValidation(regions, constraint);
        sheet.addValidationData(data_validation_list);
        return sheet;
    }

    /**
     * 编码文件名
     */
    public String encodingFilename(String filename)
    {
        filename = UUID.randomUUID().toString() + "_" + filename + ".xls";
        return filename;
    }

    public String getfile() throws FileNotFoundException
    {
        return ResourceUtils.getURL("classpath:").getPath() + "static/file/";
    }



}