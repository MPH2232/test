package com.ruoyi.common.utils;

import com.google.common.net.HttpHeaders;
import com.ruoyi.common.exception.file.FileNameLengthLimitExceededException;
import com.ruoyi.framework.config.RuoYiConfig;
import com.ruoyi.project.system.channel.domain.Channel;
import org.apache.commons.io.FileUtils;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.apache.tomcat.util.http.fileupload.FileUploadBase.FileSizeLimitExceededException;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.io.File.separator;

/**
 * 文件上传工具类
 *
 * @author ruoyi
 */
public class NewFileUploadUtils {

    // 默认大小 50M
    public static final long DEFAULT_MAX_SIZE = 52428800;

    // 默认上传的地址
    private static String defaultBaseDir = RuoYiConfig.getProfile();

    // 默认上传的地址
    private static String defaultBaseDirLinux = RuoYiConfig.getProfileLinux();

    // 默认的文件名最大长度
    public static final int DEFAULT_FILE_NAME_LENGTH = 200;

    // 默认文件类型jpg
    public static final String IMAGE_JPG_EXTENSION = ".jpg";

    private static int counter = 0;

    public static void setDefaultBaseDir(String defaultBaseDir) {
        NewFileUploadUtils.defaultBaseDir = defaultBaseDir;
    }

    public static String getDefaultBaseDir() {
        return defaultBaseDir;
    }

    public static String getDefaultBaseDirLinux() {
        return defaultBaseDirLinux;
    }

    public static void setDefaultBaseDirLinux(String defaultBaseDirLinux) {
        NewFileUploadUtils.defaultBaseDirLinux = defaultBaseDirLinux;
    }

    /**
     * 以默认配置进行文件上传
     *
     * @param file 上传的文件
     * @return 文件名称
     * @throws Exception
     */
    public static final String upload(MultipartFile file) throws IOException {
        try {
            return upload(getDefaultBaseDir(), file, NewFileUploadUtils.IMAGE_JPG_EXTENSION);
        } catch (Exception e) {
            throw new IOException(e);
        }
    }

    /**
     * 根据文件路径上传
     *
     * @param baseDir 相对应用的基目录
     * @param file    上传的文件
     * @return 文件名称
     * @throws IOException
     */
    public static final String upload(String baseDir, MultipartFile file) throws IOException {
        try {
            return upload(baseDir, file, NewFileUploadUtils.IMAGE_JPG_EXTENSION);
        } catch (Exception e) {
            throw new IOException(e);
        }
    }

    /**
     * 文件上传
     *
     * @param baseDir   相对应用的基目录
     * @param file      上传的文件
     * @param extension 上传文件类型
     * @return 返回上传成功的文件名
     * @throws FileSizeLimitExceededException       如果超出最大大小
     * @throws FileNameLengthLimitExceededException 文件名太长
     * @throws IOException                          比如读写文件出错时
     */
    public static final String upload(String baseDir, MultipartFile file, String extension)
            throws FileSizeLimitExceededException, IOException, FileNameLengthLimitExceededException {

        int fileNamelength = file.getOriginalFilename().length();
        if (fileNamelength > NewFileUploadUtils.DEFAULT_FILE_NAME_LENGTH) {
            throw new FileNameLengthLimitExceededException(file.getOriginalFilename(), fileNamelength,
                    NewFileUploadUtils.DEFAULT_FILE_NAME_LENGTH);
        }

        assertAllowed(file);

        String fileName = encodingFilename(file.getOriginalFilename(), extension);

        File desc = getAbsoluteFile(baseDir, baseDir + fileName);
        file.transferTo(desc);
        return fileName;
    }

    private static final File getAbsoluteFile(String uploadDir, String filename) throws IOException {
        File desc = new File(separator + filename);

        if (!desc.getParentFile().exists()) {
            desc.getParentFile().mkdirs();
        }
        if (!desc.exists()) {
            desc.createNewFile();
        }
        return desc;
    }

    /*
    * 单文件上传访问方法
    * */
    public static final Map uploadNew(MultipartFile file) throws IOException {
        Map mapStr = new HashMap();
        String mes = "";
        try {
            if (file.isEmpty()) {
                mes = "您没有选择文件!";
                mapStr.put("mes", mes);
                return mapStr;
            }
            long size = file.getSize();
            if (DEFAULT_MAX_SIZE != -1 && size > DEFAULT_MAX_SIZE) {
                mes = "上传失败:文件大小超出50M!";
                mapStr.put("mes", mes);
                return mapStr;
            }
            String fileName = file.getOriginalFilename();
//            logger.info("上传的文件名为：" + fileName);
            if (fileName.contains("\\")) {
                String temp[] = fileName.split("\\\\");
                if (temp.length > 1) {
                    fileName = temp[temp.length - 1];
                }
            }
            // 获取文件的后缀名
            String suffixName = fileName.substring(fileName.lastIndexOf("."));
//            logger.info("文件的后缀名为：" + suffixName);
            // 设置文件存储路径
            String osName = System.getProperties().getProperty("os.name");
            String filePath = "";
            if (osName.equals("Linux")) {
                filePath = defaultBaseDirLinux;
            } else {
                filePath = defaultBaseDir;
            }
            String path = filePath + fileName;

            File dest = new File(path);
            // 检测是否存在目录
            if (!dest.getParentFile().exists()) {
                dest.getParentFile().mkdirs();// 新建文件夹
            }
            file.transferTo(dest);// 文件写入
            mapStr.put("path", path);
            mes = "上传影像件成功";
        } catch (IllegalStateException e) {
            e.printStackTrace();
            mes = "上传失败:请检查文件!";
        } catch (IOException e) {
            e.printStackTrace();
            mes = "上传失败:请检查文件!";
        }

        mapStr.put("mes", mes);
        return mapStr;
    }

    /*
  * 多文件上传访问方法
  * */
    public static final Map uploadNewMany(MultipartFile[] files, String id) throws IOException {
        Map mapStr = new HashMap();
        String mes = "";
        String path = "";
        try {
            for (int i = 0; i < files.length; i++) {
                MultipartFile file = files[i];
                long size = file.getSize();
                if (DEFAULT_MAX_SIZE != -1 && size > DEFAULT_MAX_SIZE) {
                    mes = "上传失败:文件大小超出50M!";
                }
                String fileName = file.getOriginalFilename();
//            logger.info("上传的文件名为：" + fileName);
                if (fileName.contains("\\")) {
                    String temp[] = fileName.split("\\\\");
                    if (temp.length > 1) {
                        fileName = temp[temp.length - 1];
                    }
                }
                // 获取文件的后缀名
                String suffixName = fileName.substring(fileName.lastIndexOf("."));
//            logger.info("文件的后缀名为：" + suffixName);
                // 设置文件存储路径
                String osName = System.getProperties().getProperty("os.name");
                System.out.println("----系统是---"+osName);
                String filePath = "";
                if (osName.equals("Linux")) {
                    filePath = "/var/opt/profile/";
                    System.out.println("----LInux系统是---"+osName+"路径是---"+filePath);
                } else {
                    filePath = defaultBaseDir;
                    System.out.println("----windows系统是---"+osName+"路径是---"+filePath);
                }
                //订单号
                path = filePath + id + "/";
                File dest = new File(path + fileName);
                // 检测是否存在目录
                if (!dest.getParentFile().exists()) {
                    dest.getParentFile().mkdirs();// 新建文件夹
                    mapStr.put("separator", "1");//不存在
                } else {
                    //存在文件夹
                    mapStr.put("separator", "0");
                }
                file.transferTo(dest);// 文件写入
            }
            mapStr.put("path", path);
            mes = "上传影像件成功";
        } catch (IllegalStateException e) {
            e.printStackTrace();
            mes = "上传失败:请检查文件!";
        } catch (IOException e) {
            e.printStackTrace();
            mes = "上传失败:请检查文件!";
        }

        mapStr.put("mes", mes);
        return mapStr;
    }

    /*
 * 多文件上传访问方法
 * */
    public static final Map IndexUpload(MultipartFile[] files, String id) throws IOException {
        Map mapStr = new HashMap();
        String mes = "";
        String path = "";
        try {
            for (int i = 0; i < files.length; i++) {
                MultipartFile file = files[i];
                long size = file.getSize();
                if (DEFAULT_MAX_SIZE != -1 && size > DEFAULT_MAX_SIZE) {
                    mes = "上传失败:文件大小超出50M!";
                }
                String fileName = file.getOriginalFilename();
//            logger.info("上传的文件名为：" + fileName);
                if (fileName.contains("\\")) {
                    String temp[] = fileName.split("\\\\");
                    if (temp.length > 1) {
                        fileName = temp[temp.length - 1];
                    }
                }
                // 获取文件的后缀名
                String suffixName = fileName.substring(fileName.lastIndexOf("."));
//            logger.info("文件的后缀名为：" + suffixName);
                // 设置文件存储路径
                String osName = System.getProperties().getProperty("os.name");
                System.out.println("----系统是---"+osName);
                String filePath = "";
                if (osName.equals("Linux")) {
                    filePath = "/var/opt/profile/";
                    System.out.println("----LInux系统是---"+osName+"路径是---"+filePath);
                } else {
                    filePath = defaultBaseDir;
                    System.out.println("----windows系统是---"+osName+"路径是---"+filePath);
                }
                //订单号
                path = filePath + id + "shouye/";
                File dest = new File(path + fileName);
                // 检测是否存在目录
                if (!dest.getParentFile().exists()) {
                    dest.getParentFile().mkdirs();// 新建文件夹
                    mapStr.put("separator", "1");//不存在
                } else {
                    //存在文件夹
                    mapStr.put("separator", "0");
                }
                file.transferTo(dest);// 文件写入
            }
            mapStr.put("path", path);
            mes = "上传影像件成功";
        } catch (IllegalStateException e) {
            e.printStackTrace();
            mes = "上传失败:请检查文件!";
        } catch (IOException e) {
            e.printStackTrace();
            mes = "上传失败:请检查文件!";
        }

        mapStr.put("mes", mes);
        return mapStr;
    }

    /**
     * 编码文件名
     */
    private static final String encodingFilename(String filename, String extension) {
        filename = filename.replace("_", " ");
        filename = new Md5Hash(filename + System.nanoTime() + counter++).toHex().toString() + extension;
        return filename;
    }

    /**
     * 文件大小校验
     *
     * @param file 上传的文件
     * @return
     * @throws FileSizeLimitExceededException 如果超出最大大小
     */
    public static final void assertAllowed(MultipartFile file) throws FileSizeLimitExceededException {
        long size = file.getSize();
        if (DEFAULT_MAX_SIZE != -1 && size > DEFAULT_MAX_SIZE) {
            throw new FileSizeLimitExceededException("文件超出50M！", size, DEFAULT_MAX_SIZE);
        }
    }

    // @描述：是否是2003的excel，返回true是2003
    public static boolean isExcel2003(String filePath) {
        return filePath.matches("^.+\\.(?i)(xls)$");
    }

    //@描述：是否是2007的excel，返回true是2007
    public static boolean isExcel2007(String filePath) {
        return filePath.matches("^.+\\.(?i)(xlsx)$");
    }

    /**
     * 验证EXCEL文件
     *
     * @param filePath
     * @return
     */
    public static boolean validateExcel(String filePath) {
        if (filePath == null || !(isExcel2003(filePath) || isExcel2007(filePath))) {
            return false;
        }
        return true;
    }


//    public String handleFileUpload(HttpServletRequest request) {
//        List<MultipartFile> files = ((MultipartHttpServletRequest) request).getFiles("file");
//        MultipartFile file = null;
//        BufferedOutputStream stream = null;
//        for (int i = 0; i < files.size(); ++i) {
//            file = files.get(i);
//            String filePath = "D://aim//";
//            if (!file.isEmpty()) {
//                try {
//                    byte[] bytes = file.getBytes();
//                    stream = new BufferedOutputStream(new FileOutputStream(
//                            new File(filePath + file.getOriginalFilename())));//设置文件路径及名字
//                    stream.write(bytes);// 写入
//                    stream.close();
//                } catch (Exception e) {
//                    stream = null;
//                    return "第 " + i + " 个文件上传失败  ==> "
//                            + e.getMessage();
//                }
//            } else {
//                return "第 " + i
//                        + " 个文件上传失败因为文件为空";
//            }
//        }
//        return "上传成功";
//    }


    public static List<File> getFiles(String path){
        File root = new File(path);
        List<File> files = new ArrayList<File>();
        if(!root.isDirectory()){
            files.add(root);
        }else{
            File[] subFiles = root.listFiles();
            for(File f : subFiles){
                files.addAll(getFiles(f.getAbsolutePath()));
            }
        }
        return files;
    }




//
//        public ResponseEntity<byte[]> dowload () throws IOException {
//            String path = "D:/沈雪冰.png";
//            File file = new File(path);
//            String fileName = new String(file.getName().getBytes("utf-8"), "iso-8859-1"); //解决中文乱码问题
//            HttpHeaders headers;
//            headers = new HttpHeaders();
//            headers.setContentDispositionFormData("attachment", fileName);// aatachment  附件
//            headers.setContentType(MediaType.IMAGE_PNG);
//            ResponseEntity<byte[]> entity = new ResponseEntity<byte[]>(FileUtils.readFileToByteArray(file), headers, HttpStatus.CREATED);
//            return entity;
//        }

}
