package com.ruoyi.common.utils.poi;

import com.ruoyi.common.constant.UserConstants;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.PublicUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.project.order.order.domain.Order;
import com.ruoyi.project.order.order.service.IOrderService;
import com.ruoyi.project.order.orderPeople.domain.OrderPeople;
import com.ruoyi.project.order.orderPeople.service.IOrderPeopleService;
import com.ruoyi.project.order.orderproductPlan.domain.OrderProductPlan;
import com.ruoyi.project.system.channel.domain.Channel;
import com.ruoyi.project.system.channel.service.IChannelService;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.service.lCustomerService;
import com.ruoyi.project.system.product.domain.Product;
import com.ruoyi.project.system.product.service.IProductService;
import com.ruoyi.project.system.supplier1.domain.Supplier;
import com.ruoyi.project.system.supplier1.service.ISupplier1Service;
import com.ruoyi.project.system.user.domain.User;
import com.ruoyi.project.system.user.service.IUserService;
import org.apache.poi.ss.usermodel.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

/**
 * Excel相关处理订单批量导入
 *
 * @author ruoyi
 */
@Component
public class BatchDaDiOrderUtil {

    private static final Logger log = LoggerFactory.getLogger(BatchDaDiOrderUtil.class);

    @Autowired
    private ISupplier1Service supplier1Service;

    @Autowired
    private IUserService userService;

    @Autowired
    private lCustomerService customerService;

    @Autowired
    private IProductService productService;

    @Autowired
    private IChannelService channelService;

    @Autowired
    private IOrderService orderService;

//    @Autowired
//    private IOrderproductPlanService orderproductPlanService;

    @Autowired
    private IOrderPeopleService orderPeopleService;

    private static BatchDaDiOrderUtil excelOrderAgainUtil;

    @PostConstruct     //关键二   通过@PostConstruct 和 @PreDestroy 方法 实现初始化和销毁bean之前进行的操作
    public void init() {
        excelOrderAgainUtil = this;
        excelOrderAgainUtil.orderService = this.orderService;   // 初使化时将已静态化的testService实例化
//        excelOrderAgainUtil.orderproductPlanService = this.orderproductPlanService;
        excelOrderAgainUtil.orderPeopleService = this.orderPeopleService;

        excelOrderAgainUtil.supplier1Service = this.supplier1Service;
        excelOrderAgainUtil.userService = this.userService;
        excelOrderAgainUtil.customerService = this.customerService;
        excelOrderAgainUtil.productService = this.productService;
        excelOrderAgainUtil.channelService = this.channelService;
    }


    /**
     * 解析Excel里面的数据
     *
     * @param wb
     * @return
     */
    public String readExcel(Workbook wb, Order orders, OrderProductPlan orderProductPlans, OrderPeople orderPeoples) throws CloneNotSupportedException {
        //保险公司
        String strSupplier = "";
        List<Supplier> supplerList = excelOrderAgainUtil.supplier1Service.selectSupplierAll();
        for(Supplier suppliers : supplerList){
            strSupplier +=suppliers.getSupplierName()+',';
        }
        String arrSupplier [] = strSupplier.split(",");
        //业务员
        String strUser = "";
        List<User> userList = excelOrderAgainUtil.userService.selectUserAll();
        for(User users : userList){
            strUser +=users.getUserName()+',';
        }
        String arrUser [] = strUser.split(",");
        //客户名称
        String strCustomer = "";
        List<Customer> customerList = excelOrderAgainUtil.customerService.selectCustomersAll();
        for(Customer customers : customerList){
            strCustomer +=customers.getCustomerName()+',';
        }
        String arrCustomer [] = strCustomer.split(",");
        //计划名称
//        String strOrderProductPlan = "";
//        List<OrderProductPlan> orderProductPlansList = excelOrderAgainUtil.orderproductPlanService.selectOrderProductPlanAll();
//        for(OrderProductPlan orderProductPlanss : orderProductPlansList){
//            strOrderProductPlan +=orderProductPlanss.getPlanName()+',';
//        }
//        String arrOrderProductPlan [] = strOrderProductPlan.split(",");
        //产品名称
        String strProduct = "";
        List<Product> productList = excelOrderAgainUtil.productService.selectProductAll();
        for(Product products : productList){
            strProduct +=products.getProductName()+',';
        }
        String arrProduct [] = strProduct.split(",");
        //渠道名称
        String strChannel = "";
        List<Channel> channelList = excelOrderAgainUtil.channelService.selectChannelAll();
        for(Channel channels : channelList){
            strChannel +=channels.getChannelName()+',';
        }
        String arrChannel [] = strChannel.split(",");

//        Sheet sheet = null;
        //错误信息接收器
        String errorMsg = "";
        //sheet名字
        String sheetName = "";
        //最大的list
        List<Order> orderList = new ArrayList<Order>();
//        List<OrderProductPlan> orderProductPlanList = new ArrayList<OrderProductPlan>();
        List<OrderPeople> orderPeopleList = new ArrayList<OrderPeople>();
        //获取几个sheet;
//        wb.getNumberOfSheets();
//        for (int i = 0; i < wb.getNumberOfSheets(); i++) {
//            String code = DateUtils.dateTimeSSS();
//            sheet = wb.getSheetAt(i);
//            sheetName = sheet.getSheetName();
            //得到第一个shell
            Sheet sheet = wb.getSheetAt(0);
            //得到Excel的行数
            int totalRows = sheet.getPhysicalNumberOfRows();
//                    getLastRowNum();
//                    getPhysicalNumberOfRows();
            //总列数
            int totalCells = sheet.getRow(0).getLastCellNum();
//        //得到Excel的列数(前提是有行数)，从第2行算起
//        if (totalRows >= 2 && sheet.getRow(1) != null) {
//            totalCells = sheet.getRow(1).getLastCellNum();
//        }
            Order order;

            String piDanHao = DateUtils.dateTimeHh();

//            OrderProductPlan orderProductPlan;
            OrderPeople orderPeople;

            String br = "<br/>";
            String id = "";
//            Order orderHebing = new Order();

            //循环Excel行数,从第2行开始
            for (int r = 1; r < totalRows ; r++) {
                id = DateUtils.dateTimeSSS()+ PublicUtils.getRandom();
                //遍历行的同时看有多少列
//                if (totalRows >= 1 && sheet.getRow(r) != null) {
//                    totalCells = sheet.getRow(r).getLastCellNum();
//                }
                String rowMessage = "";
                Row row = sheet.getRow(r);
                if (row == null) {
                    errorMsg += "第" + (r + 1) + "行数据有问题，请仔细检查！";
                    continue;
                }

                //获取单元格
                Cell cella = row.getCell(0);
                //设置单元格类型
                cella.setCellType(CellType.STRING);
//                //获取单元格数据
//                String cellValue = cell.getStringCellValue();
//                if(!row.getCell(0).getStringCellValue().equals("")){
//                    id = DateUtils.dateTimeSSS()+ PublicUtils.getRandom();
//                    id = String.valueOf(System.currentTimeMillis());
//                }
//                String ia =DateUtils.dateTimeSSS()+System.currentTimeMillis();
//                order = new Order();
//                orderProductPlan = new OrderProductPlan();
//                feilvComplex.setRegionId(code);
//                feilvComplex.setRegionName(sheetName);
//                feilvComplex.setProductId(feilvComplexs.getProductId());
//                feilvComplex.setStatus(feilvComplexs.getStatus());
//                feilvComplex.setProductName(feilvComplexs.getProductName());
//                feilvComplex.setStartTime(feilvComplexs.getStartTime());
//                feilvComplex.setEndTime(feilvComplexs.getEndTime());
                order = new Order();
                order.setBatchNumber(piDanHao);
                order.setOrderId(id);
                order.setIsBatch("1");
                order.setStatus(0);
//                orderProductPlan.setOrderProductId(id);

                    //循环Excel的列
                    for (int c = 0; c < totalCells; c++) {
                        Cell cell = row.getCell(c);
                        if (null != cell) {
                        row.getCell(c).setCellType(Cell.CELL_TYPE_STRING);

                        //-开始-不等于空数据，不等于表头，
                        if (row.getCell(0) != null) {
                            if (!row.getCell(0).getStringCellValue().equals("")) {
//                                if (!row.getCell(0).getStringCellValue().contains("保单识别码")) {
//                                    orderHebing.setPolicyNum(row.getCell(0).getStringCellValue());
                                    if (c == 0) {
                                        //保单识别码
                                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                            rowMessage += "保单识别码不能为空；";
                                        } else if (cell.getStringCellValue().length() > 60) {
                                            rowMessage += "保单识别码的字数不能超过60；";
                                        }

//                                        orderHebing.setPolicyNum(cell.getStringCellValue());
                                        order.setPolicyNum(cell.getStringCellValue());
                                    } else if (c == 1) {
                                        //业务员
                                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                            rowMessage += "业务员不能为空；";
                                        } else if (cell.getStringCellValue().length() > 1000) {
                                            rowMessage += "业务员的字数不能超过1000；";
                                        } else if (!strUser.contains(cell.getStringCellValue())){
                                            rowMessage += "业务员还没有添加；";
                                        }
                                        //设置业务员id和团队名字和团队id
                                        if(strUser.contains(cell.getStringCellValue())) {
                                            for (int index = 0; index < arrUser.length; index++) {
                                                if (arrUser[index].equals(cell.getStringCellValue())) {
                                                    order.setUserId(Math.toIntExact(userList.get(index).getUserId()));
                                                    order.setTeamId(Math.toIntExact(userList.get(index).getDeptId()));
                                                    order.setTeamName(userList.get(index).getDept().getDeptName());
                                                }
                                            }
                                        }

                                        order.setUserName(cell.getStringCellValue());
//                                        orderHebing.setUserName(cell.getStringCellValue());
                                    } else if (c == 2) {
                                        //保险公司
                                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                            rowMessage += "保险公司不能为空；";
                                        } else if (cell.getStringCellValue().length() > 1000) {
                                            rowMessage += "保险公司的字数不能超过1000；";
                                        } else if (!strSupplier.contains(cell.getStringCellValue())){
                                            rowMessage += "保险公司还没有添加；";
                                        }
                                        //设置保险公司id
                                        if(strSupplier.contains(cell.getStringCellValue())) {
                                            for (int index = 0; index < arrSupplier.length; index++) {
                                                if (arrSupplier[index].equals(cell.getStringCellValue())) {
                                                    order.setInsureId(Math.toIntExact(supplerList.get(index).getSupplierId()));
                                                }
                                            }
                                        }
                                        order.setInsureCompany(cell.getStringCellValue());
//                                        orderHebing.setInsureCompany(cell.getStringCellValue());
                                    } else if (c == 3) {
                                        //客户名称
                                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                            rowMessage += "客户名称不能为空；";
                                        } else if (cell.getStringCellValue().length() > 1000) {
                                            rowMessage += "客户名称的字数不能超过1000；";
                                        }else if (!strCustomer.contains(cell.getStringCellValue())){
                                            rowMessage += "客户名称还没有添加；";
                                        }
                                        //设置客户名称id
                                        if(strCustomer.contains(cell.getStringCellValue())) {
                                            for (int index = 0; index < arrCustomer.length; index++) {
                                                if (arrCustomer[index].equals(cell.getStringCellValue())) {
                                                    order.setCustomerId(Math.toIntExact(customerList.get(index).getId()));
                                                }
                                            }
                                        }
                                        order.setCustomerName(cell.getStringCellValue());
//                                        orderHebing.setCustomerName(cell.getStringCellValue());
                                    } else if (c == 4) {
                                        //客户类型
                                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                            rowMessage += "客户类型不能为空；";
                                        } else if (cell.getStringCellValue().length() > 1000) {
                                            rowMessage += "客户类型的字数不能超过1000；";
                                        } else if (cell.getStringCellValue().equals("个人客户")) {
                                            order.setCustomerType(1);
//                                            orderHebing.setCustomerType(1);
                                        } else if (cell.getStringCellValue().equals("企业客户")) {
                                            order.setCustomerType(0);
//                                            orderHebing.setCustomerType(0);
                                        }

                                    } else if (c == 5) {
                                        //客户来源
                                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                            rowMessage += "客户来源不能为空；";
                                        } else if (cell.getStringCellValue().length() > 1000) {
                                            rowMessage += "客户来源的字数不能超过1000；";
                                        } else if (cell.getStringCellValue().equals("新保")) {
                                            order.setCustomerSo(0);
//                                            orderHebing.setCustomerSo(0);
                                        } else if (cell.getStringCellValue().equals("续保")) {
                                            order.setCustomerSo(1);
//                                            orderHebing.setCustomerSo(1);
                                        } else if (cell.getStringCellValue().equals("渠道")) {
                                            order.setCustomerSo(2);
//                                            orderHebing.setCustomerSo(2);
                                        } else if (cell.getStringCellValue().equals("自行拓展")) {
                                            order.setCustomerSo(3);
//                                            orderHebing.setCustomerSo(3);
                                        } else if (cell.getStringCellValue().equals("客户介绍")) {
                                            order.setCustomerSo(4);
//                                            orderHebing.setCustomerSo(4);
                                        } else if (cell.getStringCellValue().equals("现有客户再开发")) {
                                            order.setCustomerSo(5);
//                                            orderHebing.setCustomerSo(5);
                                        }

                                    } else if (c == 6) {
                                        //渠道名称
                                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                            rowMessage += "渠道名称不能为空；";
                                        } else if (cell.getStringCellValue().length() > 1000) {
                                            rowMessage += "渠道名称的字数不能超过1000；";
                                        } else if (!strChannel.contains(cell.getStringCellValue())){
                                            rowMessage += "渠道还没有添加；";
                                        }
                                        //设置渠道名称id
                                        if(strChannel.contains(cell.getStringCellValue())) {
                                            for (int index = 0; index < arrChannel.length; index++) {
                                                if (arrChannel[index].equals(cell.getStringCellValue())) {
                                                    order.setChannelId(Math.toIntExact(channelList.get(index).getChannelId()));
                                                }
                                            }
                                        }
                                        order.setChannelName(cell.getStringCellValue());
//                                        orderHebing.setChannelName(cell.getStringCellValue());
                                    } else if (c == 7) {
                                        //续保提醒日
                                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                            rowMessage += "续保提醒日不能为空；";
                                        } else if (cell.getStringCellValue().length() > 1000) {
                                            rowMessage += "续保提醒日的字数不能超过1000；";
                                        }
                                        order.setXubaoTime(cell.getStringCellValue());
//                                        orderHebing.setXubaoTime(cell.getStringCellValue());
                                    } else if (c == 8) {
                                        //生效日期
                                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                            rowMessage += "生效日期不能为空；";
                                        } else if (cell.getStringCellValue().length() > 1000) {
                                            rowMessage += "生效日期的字数不能超过1000；";
                                        }
                                        order.setStartTime(cell.getStringCellValue());
//                                        orderHebing.setStartTime(cell.getStringCellValue());
                                    } else if (c == 9) {
                                        //失效日期
                                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                            rowMessage += "失效日期不能为空；";
                                        } else if (cell.getStringCellValue().length() > 1000) {
                                            rowMessage += "失效日期的字数不能超过1000；";
                                        }
                                        order.setEndTime(cell.getStringCellValue());
//                                        orderHebing.setEndTime(cell.getStringCellValue());
                                    } else if (c == 10) {
                                        //缴费方式
                                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                            rowMessage += "缴费方式不能为空；";
                                        } else if (cell.getStringCellValue().length() > 1000) {
                                            rowMessage += "缴费方式的字数不能超过1000；";
                                        } else if (cell.getStringCellValue().equals("趸交")) {
                                            order.setPayMode("1");
//                                            orderHebing.setPayMode("1");
                                        } else if (cell.getStringCellValue().equals("月交")) {
                                            order.setPayMode("12");
//                                            orderHebing.setPayMode("12");
                                        } else if (cell.getStringCellValue().equals("季交")) {
                                            order.setPayMode("4");
//                                            orderHebing.setPayMode("4");
                                        } else if (cell.getStringCellValue().equals("四个月交")) {
                                            order.setPayMode("3");
//                                            orderHebing.setPayMode("3");
                                        } else if (cell.getStringCellValue().equals("半年交")) {
                                            order.setPayMode("2");
//                                            orderHebing.setPayMode("2");
                                        }
                                    } else if (c == 11) {
                                        //付费至
                                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                            rowMessage += "付费至不能为空；";
                                        } else if (cell.getStringCellValue().length() > 1000) {
                                            rowMessage += "付费至的字数不能超过1000；";
                                        } else if (cell.getStringCellValue().equals("保险公司")) {
                                            order.setPayTo("0");
//                                            orderHebing.setPayTo("0");
                                        } else if (cell.getStringCellValue().equals("FESCO")) {
                                            order.setPayTo("1");
//                                            orderHebing.setPayTo("1");
                                        } else if (cell.getStringCellValue().equals("方胜")) {
                                            order.setPayTo("2");
//                                            orderHebing.setPayTo("2");
                                        }

                                        orderList.add(order);
                                    }
//                                }
                            }  //--结束---不等于空数据，不等于表头--结束，

//                            else {
//                                order.setPolicyNum(orderHebing.getPolicyNum());
//                                order.setUserName(orderHebing.getUserName());
//                                order.setInsureCompany(orderHebing.getInsureCompany());
//                                order.setCustomerName(orderHebing.getCustomerName());
//                                order.setCustomerType(orderHebing.getCustomerType());
//                                order.setCustomerSo(orderHebing.getCustomerSo());
//                                order.setChannelName(orderHebing.getChannelName());
//                                order.setXubaoTime(orderHebing.getXubaoTime());
//                                order.setStartTime(orderHebing.getStartTime());
//                                order.setEndTime(orderHebing.getEndTime());
//                                order.setPayMode(orderHebing.getPayMode());
//                                order.setPayTo(orderHebing.getPayTo());
//                            }
                        }

//                        if (!row.getCell(12).getStringCellValue().contains("计划名称")) {
//                        if (c == 12) {
//                            //计划名称
//                            if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                                rowMessage += "计划名称不能为空；";
//                            } else if (cell.getStringCellValue().length() > 1000) {
//                                rowMessage += "计划名称的字数不能超过1000；";
//                            } else if (!strOrderProductPlan.contains(cell.getStringCellValue())){
//                                rowMessage += "计划名称还没有添加；";
//                            }
//                            orderProductPlan.setPlanName(cell.getStringCellValue());
//                        } else if (c == 13) {
//                            //产品名称
//                            if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                                rowMessage += "产品名称不能为空；";
//                            } else if (cell.getStringCellValue().length() > 1000) {
//                                rowMessage += "产品名称的字数不能超过1000；";
//                            } else if (!strProduct.contains(cell.getStringCellValue())){
//                                rowMessage += "产品名称还没有添加；";
//                            }
//                            //设置产品id
//                            if(strProduct.contains(cell.getStringCellValue())) {
//                                for (int index = 0; index < arrProduct.length; index++) {
//                                    if (arrProduct[index].equals(cell.getStringCellValue())) {
//                                        orderProductPlan.setProductId(Math.toIntExact(productList.get(index).getProductId()));
//                                    }
//                                }
//                            }
//                            orderProductPlan.setProductName(cell.getStringCellValue());
//                        } else if (c == 14) {
////                          产品备注
//                            if (StringUtils.isEmpty(cell.getStringCellValue())) {
//                                rowMessage += "产品备注不能为空；";
//                            } else if (cell.getStringCellValue().length() > 1000) {
//                                rowMessage += "产品备注的字数不能超过1000；";
//                            }
//                            orderProductPlan.setBeizhu(cell.getStringCellValue());
//                            orderProductPlanList.add(orderProductPlan);
//                        }
//                        }
                    }else {
                        rowMessage += "第" + (c + 1) + "列数据有问题，请仔细检查；";
                    }
                }

            //拼接每行的错误提示
            if (!StringUtils.isEmpty(rowMessage)) {
                errorMsg += "第1个表格中，" + "第" + (r + 1) + "行，" + rowMessage + br;
            }
        }
//        }

        //得到第二个shell
        Sheet sheets = wb.getSheetAt(1);
//		Sheet sheet = wb.getSheetAt(0);
        //得到Excel的行数
        int totalRowss = sheets.getPhysicalNumberOfRows();
        //总列数
        int totalCellss = sheets.getRow(0).getLastCellNum();

        //循环Excel行数,从第2行开始。标题不入库
        for (int r = 1; r < totalRowss; r++) {
            String rowMessages = "";
            Row row = sheets.getRow(r);
            if (row == null) {
                errorMsg += br+"第二个表格中，" + "第" + (r + 1) + "行数据有问题，请仔细检查！";
                continue;
            }
            orderPeople = new OrderPeople();
//            orderid=orderPeoples.getOrderId();
//            orderPeople.setOrderId(orderPeoples.getOrderId());
//            orderPeople.setOrderType(orderPeoples.getOrderType());
            String xing = "";
            String ming = "";
            String jiaShuXing = "";
            String jiashuMing = "";
            //循环Excel的列
            for (int c = 0; c < totalCellss; c++) {
                Cell cell = row.getCell(c);
                if (null != cell) {
                    row.getCell(c).setCellType(Cell.CELL_TYPE_STRING);

                    if (c == 0) {
                        //序号
                        orderPeople.setPeopleNo(cell.getStringCellValue());

                    } else if (c == 1) {
                        //雇主
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "雇主不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "雇主位数不能超过1000；";
                        }
                        else if (!strCustomer.contains(cell.getStringCellValue())){
                            rowMessages += "雇主还没有添加；";
                        }
                        orderPeople.setBranch(cell.getStringCellValue());

                    } else if (c == 2) {
                        //编码
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "编码不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "编码位数不能超过1000；";
                        }
                        orderPeople.setCode(cell.getStringCellValue());

                    } else if (c == 3) {
                        //员工编号
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "员工编号不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "员工编号位数不能超过1000；";
                        }
                        orderPeople.setEmpNo(cell.getStringCellValue());

                    } else if (c == 4) {
                        //英文姓
                        orderPeople.setPingXing(cell.getStringCellValue());

                    } else if (c == 5) {
                        //英文名
                        orderPeople.setPingMing(cell.getStringCellValue());

                    } else if (c == 6) {
                        //中文姓
                        if(cell.getStringCellValue()!=""){
                            xing = cell.getStringCellValue();
                        }

                    } else if (c == 7) {
                        //中文名
                        if(cell.getStringCellValue()!=""){
                            ming = cell.getStringCellValue();
                            orderPeople.setPeopleName(xing + ming);
                        }

                    } else if (c == 8) {
                        //出生年月
                        if(cell.getStringCellValue()!=""){
                            orderPeople.setBirth(cell.getStringCellValue());
                        }

                    } else if (c == 9) {
                        //年龄
                        if(cell.getStringCellValue()!=""){
                            orderPeople.setAge(cell.getStringCellValue());
                        }

                    } else if (c == 10) {
                        //性别
                        if(cell.getStringCellValue()!=""){
                            if(cell.getStringCellValue().equals("F")){
                                orderPeople.setSex("女");
                            }else{
                                orderPeople.setSex("男");
                            }
                        }

                    } else if (c == 11) {
                        //国籍
                        if(cell.getStringCellValue()!=""){
                            orderPeople.setNationality(cell.getStringCellValue());
                        }

                    } else if (c == 12) {
                        //身份证号或护照号
                        if(cell.getStringCellValue()!=""){
                            orderPeople.setIdcard(cell.getStringCellValue());
                        }

                    } else if (c == 13) {
                        //意外伤害及身故（万元）
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "意外伤害及身故（万元）不能为空；";
                        }
                        orderPeople.setYiwaiBaoe(String.valueOf(Double.valueOf(cell.getStringCellValue())*10000));

                    } else if (c == 14) {
                        //险种
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "险种不能为空；";
                        }
                        orderPeople.setPlanName(cell.getStringCellValue());

                    } else if (c == 15) {
                        //保障代码
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "意外保险费不能为空；";
                        }
                        orderPeople.setCoverageCode(cell.getStringCellValue());

                    } else if (c == 16) {
                        //齿科
                        orderPeople.setDental(cell.getStringCellValue());

                    } else if (c == 17) {
                        //健康检查
                        orderPeople.setWellness(cell.getStringCellValue());

                    } else if (c == 18) {
                        //眼科福利
                        orderPeople.setVision(cell.getStringCellValue());

                    } else if (c == 19) {
                        //战争恐怖主义责任
                        orderPeople.setWar(cell.getStringCellValue());

                    } else if (c == 20) {
                        //生育福利
                        orderPeople.setMaternity(cell.getStringCellValue());

                    } else if (c == 21) {
                        //保险生效日
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "生效日期不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.SHENG_RI)) {
                            rowMessages += "生效日期格式错误；";
                        }
                        orderPeople.setStartTime(cell.getStringCellValue());

                    } else if (c == 22) {
                        //保险失效日
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "保险失效日不能为空；";
                        }
                        else if (!cell.getStringCellValue().matches(UserConstants.SHENG_RI)) {
                            rowMessages += "保险失效日格式错误；";
                        }
                        orderPeople.setEndTime(cell.getStringCellValue());
                    } else if (c == 23) {
                        //上一年保费
                        orderPeople.setBeforeBaofei(cell.getStringCellValue());

                    }else if (c == 24) {
                        //意外保费
                        orderPeople.setYiwaiBaofei(cell.getStringCellValue());

                    } else if (c == 25) {
                        //医疗保费
                        orderPeople.setYiliaoBaofei(cell.getStringCellValue());

                    } else if (c == 26) {
                        //保费合计
                        orderPeople.setBaofei(cell.getStringCellValue());

                    } else if (c == 27) {
                        //关系
                        orderPeople.setRelationship(cell.getStringCellValue());

                    } else if (c == 28) {
                        //家属姓
                        if(cell.getStringCellValue()!=""){
                            jiaShuXing = cell.getStringCellValue();
                        }

                    } else if (c == 29) {
                        //家属名
                        if(cell.getStringCellValue()!=""){
                            jiashuMing = cell.getStringCellValue();
                            orderPeople.setPeopleName(jiaShuXing+jiashuMing);
                        }

                    } else if (c == 30) {
                        //出生日期
                        if(cell.getStringCellValue()!=""){
                            orderPeople.setBirth(cell.getStringCellValue());
                        }

                    } else if (c == 31) {
                        //年龄
                        if(cell.getStringCellValue()!=""){
                            orderPeople.setAge(cell.getStringCellValue());
                        }

                    } else if (c == 32) {
                        //性别
                        if(cell.getStringCellValue()!=""){
                            if(cell.getStringCellValue().equals("F")){
                                orderPeople.setSex("女");
                            }else{
                                orderPeople.setSex("男");
                            }
                        }

                    } else if (c == 33) {
                        //国籍
                        if(cell.getStringCellValue()!=""){
                            orderPeople.setNationality(cell.getStringCellValue());
                        }

                    } else if (c == 34) {
                        //护照或身份证号码
                        if(cell.getStringCellValue()!=""){
                            orderPeople.setIdcard(cell.getStringCellValue());
                        }

                    } else if (c == 35) {
                        //福利是否拆分
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "编码不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "编码位数不能超过1000；";
                        }
                        orderPeople.setBenefits(cell.getStringCellValue());

                    } else if (c == 36) {
                        //付费方式
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "编码不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "编码位数不能超过1000；";
                        }
                        orderPeople.setPayWay(cell.getStringCellValue());

                    } else if (c == 37) {
                        //工作邮件地址
                        orderPeople.setWorkEmail(cell.getStringCellValue());

                    } else if (c == 38) {
                        //私人邮件地址
                        orderPeople.setPersonalEmail(cell.getStringCellValue());

                    } else if (c == 39) {
                        //联系邮件地址
                        orderPeople.setEmail(cell.getStringCellValue());

                    } else if (c == 40) {
                        //手机号码
                        orderPeople.setPhone(cell.getStringCellValue());

                    } else if (c == 41) {
                        //办公电话
                        orderPeople.setOfficePhone(cell.getStringCellValue());

                    } else if (c == 42) {
                        //保单识别码
                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                            rowMessages = "编码不能为空；";
                        }
                        else if (cell.getStringCellValue().length() > 1000) {
                            rowMessages += "编码位数不能超过1000；";
                        }
                        orderPeople.setPolicyNum(cell.getStringCellValue());
                        orderPeopleList.add(orderPeople);

                    }
                } else {
                    rowMessages += "第" + (c + 1) + "列数据有问题，请仔细检查；";
                }
            }
            //拼接每行的错误提示
            if (!StringUtils.isEmpty(rowMessages)) {
                errorMsg += "第2个表格中，" + "第" + (r + 1) + "行，" + rowMessages + br;
            }
        }

        //全部验证通过才导入到数据库
        if (StringUtils.isEmpty(errorMsg)) {

            for(OrderPeople orderPeople1 : orderPeopleList){
                String policyNum = orderPeople1.getPolicyNum();
                if(policyNum!=null) {
                    excelOrderAgainUtil.orderPeopleService.deleteOrderPeopleByPolicyNum(policyNum);
                }
            }
            for(Order order1 : orderList){
                String policyNum = order1.getPolicyNum();
                if(policyNum!=null && excelOrderAgainUtil.orderService.selectOrderIdByPolicyNum(policyNum)!=null){
//                    excelOrderAgainUtil.orderproductPlanService.deleteOrderProductPlanByOrderProductId(excelOrderAgainUtil.orderService.selectOrderIdByPolicyNum(policyNum).getOrderId());
                    excelOrderAgainUtil.orderService.deleteOrderByPolicyNum(policyNum);
                }
            }
            excelOrderAgainUtil.orderService.insertOrderList(orderList);
//            excelOrderAgainUtil.orderproductPlanService.insertOrderProductPlanList(orderProductPlanList);
            excelOrderAgainUtil.orderPeopleService.insertOrderPeopleList(orderPeopleList);

            errorMsg = "导入成功！";
            return errorMsg;
        }else{
            return errorMsg;
        }
    }
}

