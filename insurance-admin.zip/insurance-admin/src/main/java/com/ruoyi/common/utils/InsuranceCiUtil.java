package com.ruoyi.common.utils;

/**
 * Created by x on 2018/9/11.
 */
/**
 * 通过险种名称 来获取 保险行次信息
 *
 */
public class InsuranceCiUtil {
//    public static void main(String[] args) {
//        String cardNumber = "普通定期寿险";
//        String name = getInsuranceCi(cardNumber);
//        System.out.println(name);
//    }

    //传入卡号 得到银行名称
    public static String getInsuranceCi(String productKind) {
        int index = -1;

        if(productKind==null){
            return "";
        }

        //6位Bin号
//        String cardbin_6 = idCard.substring(0, 6);
        for (int i = 0; i < bankBin.length; i++) {
            if (productKind.equals(bankBin[i])) {
                index = i;
            }
        }
        if (index != -1) {
            return bankName[index];
        }

        return "";
    }

    //险种名称
    private final static String[] bankBin = {
            "普通定期寿险", "普通两全寿险", "普通终身寿险", "普通年金保险", "分红定期寿险", "分红两全寿险", "分红终身寿险", "分红年金保险", "投资连结产品", "投资年金保险", "万能寿险",
            "万能年金保险", "一年以内意外险", "一年意外险", "一年以上意外险", "短期健康险", "长期健康险", "企业财产保险", "家庭财产保险", "投资型家财险", "机动车辆保险", "交强险",
            "工程保险", "责任保险", "信用保险", "保证保险", "保证机动车辆消费贷款保证保险", "保证个人贷款抵押房屋保证保险", "船舶保险", "货物运输保险", "特殊风险保险", "农业保险", "财险公司健康险",
            "投资型健康险", "财险公司意外伤害保险", "投资型意外险", "其他险"};


    //"保险行次"
    private static final String[] bankName = {
            "寿-3", "寿-4", "寿-5", "寿-6", "寿-8", "寿-9", "寿-10", "寿-11", "寿-12", "寿-13", "寿-14",
            "寿-15", "寿-17", "寿-18", "寿-19", "寿-21", "寿-22", "1", "2", "3", "4", "5",
            "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16",
            "17", "18", "19", "20"};

}
