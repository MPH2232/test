package com.ruoyi.common.utils;

/**
 * Created by x on 2018/10/31.
 */
//公共类
public class PublicUtils {

    //生成一个3位随机数并返回
    public static String getRandom() {
        String i= String.valueOf((Math.random()*900)+100);
//        System.out.print(i.substring(0,3));
        return i.substring(0,3);
    }
}
