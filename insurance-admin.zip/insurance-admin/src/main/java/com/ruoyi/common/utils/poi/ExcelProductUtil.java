package com.ruoyi.common.utils.poi;

import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.project.system.product.domain.FeilvComplex;
import com.ruoyi.project.system.product.service.IProductFeilvComplexService;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.List;

/**
 * Excel相关处理高端复杂费率
 *
 * @author ruoyi
 */
@Component
public class ExcelProductUtil {

    private static final Logger log = LoggerFactory.getLogger(ExcelProductUtil.class);

    @Autowired
    private IProductFeilvComplexService productFeilvComplexService;

    private static ExcelProductUtil excelProductUtil;

//    public void setProductFeilvComplexService(IProductFeilvComplexService  productFeilvComplexService) {
//        this.productFeilvComplexService = productFeilvComplexService;
//    }

    @PostConstruct     //关键二   通过@PostConstruct 和 @PreDestroy 方法 实现初始化和销毁bean之前进行的操作
    public void init() {
        excelProductUtil = this;
        excelProductUtil.productFeilvComplexService = this.productFeilvComplexService;   // 初使化时将已静态化的testService实例化
    }


    /**
     * 解析Excel里面的数据
     *
     * @param wb
     * @return
     */
    public String readExcel(Workbook wb, FeilvComplex feilvComplexs) throws CloneNotSupportedException {

        Sheet sheet = null;
        //错误信息接收器
        String errorMsg = "";
        //sheet名字
        String sheetName = "";
        //最大的list
        List<FeilvComplex> feilvComplexList = new ArrayList<FeilvComplex>();
        //获取几个sheet;
//        wb.getNumberOfSheets();
        for (int i = 0; i < wb.getNumberOfSheets(); i++) {
            String code = DateUtils.dateTimeSSS();
            sheet = wb.getSheetAt(i);
            sheetName = sheet.getSheetName();
            //得到第一个shell
//        Sheet sheet = wb.getSheetAt(0);
            //得到Excel的行数
            int totalRows = sheet.getPhysicalNumberOfRows();
            //总列数
            int totalCells = 0;
//        //得到Excel的列数(前提是有行数)，从第2行算起
//        if (totalRows >= 2 && sheet.getRow(1) != null) {
//            totalCells = sheet.getRow(1).getLastCellNum();
//        }
            FeilvComplex feilvComplex;
            String br = "<br/>";
            String name = "";
            FeilvComplex feilvComplexHebing = new FeilvComplex();

            List<String> list = new ArrayList<String>();
            int diYiHang = sheet.getRow(0).getLastCellNum();
            Row ro = sheet.getRow(0);
            for (int q=4; q<diYiHang; q++){
                if(ro.getCell(q).getStringCellValue()!=""){
                    list.add( ro.getCell(q).getStringCellValue());
                }
            }


            //循环Excel行数,从第1行开始
            for (int r = 0; r <= totalRows - 1 ; r++) {
                //遍历行的同时看有多少列
                if (totalRows >= 1 && sheet.getRow(r) != null) {
                    totalCells = sheet.getRow(r).getLastCellNum();
                }
                String rowMessage = "";
                Row row = sheet.getRow(r);
                if (row == null) {
                    errorMsg += "第" + (r + 1) + "行数据有问题，请仔细检查！";
                    continue;
                }
                feilvComplex = new FeilvComplex();
                feilvComplex.setRegionId(code);
                feilvComplex.setRegionName(sheetName);
                feilvComplex.setProductId(feilvComplexs.getProductId());
                feilvComplex.setStatus(feilvComplexs.getStatus());
                feilvComplex.setProductName(feilvComplexs.getProductName());
                feilvComplex.setStartTime(feilvComplexs.getStartTime());
                feilvComplex.setEndTime(feilvComplexs.getEndTime());
//            orderid=orderPeoples.getOrderId();
//            orderPeople.setOrderId(orderPeoples.getOrderId());
//            orderPeople.setOrderType(orderPeoples.getOrderType());
                if (row != null && row.getCell(0) != null) {
                    if (row.getCell(0).getStringCellValue().equals("责任名称")) {
                        name = row.getCell(0).getStringCellValue();
                        continue;
                    } else if (row.getCell(0).getStringCellValue().equals("可选责任名称")) {
                        name = row.getCell(0).getStringCellValue();
                        feilvComplexHebing = new FeilvComplex();
                        continue;
                    } else if (row.getCell(0).getStringCellValue().equals("折扣名称")) {
                        name = row.getCell(0).getStringCellValue();
                        feilvComplexHebing = new FeilvComplex();
                        continue;
                    } else if (row.getCell(0).getStringCellValue().equals("附加产品名称")) {
                        name = row.getCell(0).getStringCellValue();
                        feilvComplexHebing = new FeilvComplex();
                        continue;
                    }
                }


                if (name.equals("责任名称")) {
                    int jihua=0;
                    //循环Excel的列
                    for (int c = 0; c < totalCells; c++) {
                        Cell cell = row.getCell(c);
                        if (null != cell) {
                            row.getCell(c).setCellType(Cell.CELL_TYPE_STRING);

                            //-开始-不等于空数据，不等于表头，
                            if (row.getCell(0) != null) {
                                if (!row.getCell(0).getStringCellValue().equals("")) {
                                    if (!row.getCell(0).getStringCellValue().contains("责任名称")) {

                                        feilvComplexHebing.setDutyName(row.getCell(0).getStringCellValue());
                                        if (c == 0) {
                                            //责任名称
                                            if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                                rowMessage += "责任名称不能为空；";
                                            } else if (cell.getStringCellValue().length() > 60) {
                                                rowMessage += "责任名称的字数不能超过60；";
                                            }

                                            feilvComplexHebing.setDutyName(cell.getStringCellValue());
                                            feilvComplex.setDutyName(cell.getStringCellValue());
                                            continue;
                                        } else if (c == 1) {
                                            //责任详情
                                            if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                                rowMessage += "责任详情不能为空；";
                                            } else if (cell.getStringCellValue().length() > 1000) {
                                                rowMessage += "责任详情的字数不能超过1000；";
                                            }

                                            feilvComplex.setDutyDetail(cell.getStringCellValue());
                                            feilvComplexHebing.setDutyDetail(cell.getStringCellValue());
                                            continue;
                                        } else if (c == 2) {
                                            //特定医院赔付比例
                                            if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                                rowMessage += "特定医院赔付比例不能为空；";
                                            } else if (cell.getStringCellValue().length() > 1000) {
                                                rowMessage += "特定医院赔付比例的字数不能超过1000；";
                                            }
                                            feilvComplex.setDutyRatio(cell.getStringCellValue());
                                            feilvComplexHebing.setDutyRatio(cell.getStringCellValue());
                                            continue;
                                        }
                                    }
                                }  //--结束---不等于空数据，不等于表头--结束，

                                else {
                                    feilvComplex.setDutyName(feilvComplexHebing.getDutyName());
                                    feilvComplex.setDutyRatio(feilvComplexHebing.getDutyRatio());
                                    feilvComplex.setDutyDetail(feilvComplexHebing.getDutyDetail());
                                }
                            }

                            if (c == 3) {
                                //年龄
                                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                    rowMessage += "年龄不能为空；";
                                } else if (cell.getStringCellValue().length() > 1000) {
                                    rowMessage += "年龄的字数不能超过1000；";
                                }
                                feilvComplex.setAge(cell.getStringCellValue());
                                continue;
                            }
//c=4,j=4
                            for(int j=4+jihua;j==c;j++){
                                  if (c == j) {
                                      if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                          rowMessage += list.get(jihua) + "不能为空；";
                                      } else if (cell.getStringCellValue().length() > 1000) {
                                          rowMessage += list.get(jihua) + "的字数不能超过1000；";
                                      }
//list.size()
                                      for(int d=0;d<totalCells-4;d++){
                                            //第一个计划
                                            if(jihua==0){
                                                if(c == d+4){
                                                    //list.get(0)
                                                    feilvComplex.setPlan(list.get(jihua));
                                                    feilvComplex.setPlanValue(cell.getStringCellValue());
                                                    feilvComplexList.add(feilvComplex);
                                                    jihua++;
                                                    continue;
                                                }
                                            }else if(jihua==d){
                                                //计划n
                                                if(c == d+4){
                                                    FeilvComplex copy = (FeilvComplex) feilvComplex.clone();
                                                    //list.get(1)
                                                    copy.setPlan(list.get(jihua));
                                                    copy.setPlanValue(cell.getStringCellValue());
                                                    feilvComplexList.add(copy);
                                                    jihua++;
                                                    continue;
                                                }
                                            }
                                      }
                                  }
                            }


                        } else {
                            rowMessage += "第" + (c + 1) + "列数据有问题，请仔细检查；";
                        }
                    }
                }
//---------------------------------
                else if (name.equals("可选责任名称")) {
                    for (int c = 0; c < totalCells; c++) {
                        Cell cell = row.getCell(c);
                        if (null != cell) {
                            row.getCell(c).setCellType(Cell.CELL_TYPE_STRING);

                            //不等于空数据，不等于表头
                            if (row.getCell(0) != null) {
                                if (!row.getCell(0).getStringCellValue().equals("")) {

//                                feilvComplexHebing.setDutyName(row.getCell(0).getStringCellValue());
                                    if (c == 0) {
                                        //可选责任名称
                                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                            rowMessage += "可选责任名称不能为空；";
                                        } else if (cell.getStringCellValue().length() > 60) {
                                            rowMessage += "可选责任名称的字数不能超过60；";
                                        }

                                        feilvComplexHebing.setDutyName(cell.getStringCellValue());
                                        feilvComplex.setDutyName(cell.getStringCellValue());
                                        continue;

                                    } else if (c == 1) {
                                        //关联责任
                                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                            rowMessage += "关联责任不能为空；";
                                        } else if (cell.getStringCellValue().length() > 1000) {
                                            rowMessage += "关联责任的字数不能超过1000；";
                                        }

                                        feilvComplex.setDutyRelated(cell.getStringCellValue());
                                        feilvComplexHebing.setDutyRelated(cell.getStringCellValue());
                                        continue;

                                    } else if (c == 2) {
                                        //年龄
                                        if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                            rowMessage += "年龄不能为空；";
                                        } else if (cell.getStringCellValue().length() > 1000) {
                                            rowMessage += "年龄的字数不能超过1000；";
                                        }
                                        feilvComplex.setAge(cell.getStringCellValue());
                                        feilvComplexHebing.setAge(cell.getStringCellValue());
                                        continue;
                                    }
                                } else {
                                    feilvComplex.setDutyName(feilvComplexHebing.getDutyName());
                                    feilvComplex.setDutyRelated(feilvComplexHebing.getDutyRelated());
                                    feilvComplex.setAge(feilvComplexHebing.getAge());
                                }
                            }


                            if (c == 3) {
                                //保额
                                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                    rowMessage += "保额不能为空；";
                                } else if (cell.getStringCellValue().length() > 1000) {
                                    rowMessage += "保额的字数不能超过1000；";
                                }
                                feilvComplex.setPlan(cell.getStringCellValue());
                                continue;
                            } else if (c == 4) {
                                //适用计划
                                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                    rowMessage += "适用计划不能为空；";
                                } else if (cell.getStringCellValue().length() > 1000) {
                                    rowMessage += "适用计划的字数不能超过1000；";
                                }
                                feilvComplex.setDutyScope(cell.getStringCellValue());
                                continue;
                            } else if (c == 5) {
                                //保费值
                                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                    rowMessage += "保费值不能为空；";
                                } else if (cell.getStringCellValue().length() > 1000) {
                                    rowMessage += "保费值的字数不能超过1000；";
                                }
                                feilvComplex.setPlanValue(cell.getStringCellValue());
                                feilvComplexList.add(feilvComplex);
                                continue;
//                        orderPeople.setIdcard(cell.getStringCellValue());
                            }
                        } else {
                            rowMessage += "第" + (c + 1) + "列数据有问题，请仔细检查；";
                        }
                    }
                }

                //---------------------------------
                else if (name.equals("折扣名称")) {
                    for (int c = 0; c < totalCells; c++) {
                        Cell cell = row.getCell(c);
                        if (null != cell) {
                            row.getCell(c).setCellType(Cell.CELL_TYPE_STRING);

                            //不等于空数据，不等于表头，
                            if (!row.getCell(0).getStringCellValue().equals("")) {

//                                feilvComplexHebing.setDutyName(row.getCell(0).getStringCellValue());
                                if (c == 0) {
                                    //折扣名称
                                    if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                        rowMessage += "折扣名称不能为空；";
                                    } else if (cell.getStringCellValue().length() > 60) {
                                        rowMessage += "折扣名称的字数不能超过60；";
                                    }

                                    feilvComplexHebing.setDutyName(cell.getStringCellValue());
                                    feilvComplex.setDutyName(cell.getStringCellValue());
                                    continue;
                                }
                            } else {
                                feilvComplex.setDutyName(feilvComplexHebing.getDutyName());
                            }

                            if (c == 1) {
                                //折扣类型
                                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                    rowMessage += "折扣类型不能为空；";
                                } else if (cell.getStringCellValue().length() > 1000) {
                                    rowMessage += "折扣类型的字数不能超过1000；";
                                }
                                feilvComplex.setPlan(cell.getStringCellValue());
                                continue;
                            } else if (c == 2) {
                                //折扣系数
                                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                    rowMessage += "折扣系数不能为空；";
                                } else if (cell.getStringCellValue().length() > 1000) {
                                    rowMessage += "折扣系数的字数不能超过1000；";
                                }
                                feilvComplex.setDutyRatio(cell.getStringCellValue());
                                continue;
                            } else if (c == 3) {
                                //折扣计算基数
                                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                    rowMessage += "折扣计算基数不能为空；";
                                } else if (cell.getStringCellValue().length() > 1000) {
                                    rowMessage += "折扣计算基数的字数不能超过1000；";
                                }
                                feilvComplex.setDutyDetail(cell.getStringCellValue());
                                feilvComplexList.add(feilvComplex);
                                continue;
//                        orderPeople.setIdcard(cell.getStringCellValue());
                            }
                        } else {
                            rowMessage += "第" + (c + 1) + "列数据有问题，请仔细检查；";
                        }
                    }
                }

                //---------------------------------
                else if (name.equals("附加产品名称")) {
                    for (int c = 0; c < totalCells; c++) {
                        Cell cell = row.getCell(c);
                        if (null != cell) {
                            row.getCell(c).setCellType(Cell.CELL_TYPE_STRING);
                            //不等于空数据，不等于表头，
                            if (!row.getCell(0).getStringCellValue().equals("")) {
                                if (c == 0) {
                                    //附加产品名称
                                    if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                        rowMessage += "附加产品名称不能为空；";
                                    } else if (cell.getStringCellValue().length() > 60) {
                                        rowMessage += "附加产品名称的字数不能超过60；";
                                    }

                                    feilvComplexHebing.setFujiaProtocolName(cell.getStringCellValue());
                                    feilvComplex.setFujiaProtocolName(cell.getStringCellValue());
                                    continue;
                                }
                            } else {
                                feilvComplex.setFujiaProtocolName(feilvComplexHebing.getFujiaProtocolName());
                            }
                            if (c == 1) {
                                //年龄
                                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                    rowMessage += "年龄不能为空；";
                                } else if (cell.getStringCellValue().length() > 1000) {
                                    rowMessage += "年龄的字数不能超过1000；";
                                }
                                feilvComplex.setAge(cell.getStringCellValue());
                                continue;
                            } else if (c == 2) {
                                //详细
                                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                    rowMessage += "详细不能为空；";
                                } else if (cell.getStringCellValue().length() > 1000) {
                                    rowMessage += "详细的字数不能超过1000；";
                                }
                                feilvComplex.setDutyScope(cell.getStringCellValue());
                                continue;
                            } else if (c == 3) {
                                //保额
                                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                    rowMessage += "保额不能为空；";
                                } else if (cell.getStringCellValue().length() > 1000) {
                                    rowMessage += "保额的字数不能超过1000；";
                                }
                                feilvComplex.setPlan(cell.getStringCellValue());
                                continue;
                            } else if (c == 4) {
                                //保费
                                if (StringUtils.isEmpty(cell.getStringCellValue())) {
                                    rowMessage += "保费不能为空；";
                                } else if (cell.getStringCellValue().length() > 1000) {
                                    rowMessage += "保费的字数不能超过1000；";
                                }
                                feilvComplex.setPlanValue(cell.getStringCellValue());
                                feilvComplexList.add(feilvComplex);
                                continue;
//                        orderPeople.setIdcard(cell.getStringCellValue());
                            }
                        } else {
                            rowMessage += "第" + (c + 1) + "列数据有问题，请仔细检查；";
                        }
                    }
                }


                //拼接每行的错误提示
                if (!StringUtils.isEmpty(rowMessage)) {
                    errorMsg += "第"+(i+1)+"个表格中" + "第" + (r + 1) + "行，" + rowMessage + br;
                }
//            else {
//                feilvComplexList.add(feilvComplex);
//            }
            }

        }
        //全部验证通过才导入到数据库
        if (StringUtils.isEmpty(errorMsg)) {
//            excelProductUtil.productFeilvComplexService.deleteFeilvComplexByProductId(feilvComplexs.getProductId());
            excelProductUtil.productFeilvComplexService.deleteFeilvComplexByProductIdAndEndTime(feilvComplexs.getProductId(),feilvComplexs.getEndTime());
            excelProductUtil.productFeilvComplexService.insertFeilvComplexList(feilvComplexList);
//            for (FeilvComplex userKnowledgeBase : feilvComplexList) {
//                excelProductUtil.productFeilvComplexService.insertFeilvComplex(userKnowledgeBase);
//            }
            errorMsg = "导入成功，共" + feilvComplexList.size() + "条数据！";
            return errorMsg;
        }else{
            return errorMsg;
        }
    }
}

