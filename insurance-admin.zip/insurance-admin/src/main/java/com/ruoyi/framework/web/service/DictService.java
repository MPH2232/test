package com.ruoyi.framework.web.service;

import java.util.List;

import com.ruoyi.project.system.channel.domain.Channel;
import com.ruoyi.project.system.channel.service.IChannelService;
import com.ruoyi.project.system.customer.domain.Customer;
import com.ruoyi.project.system.customer.service.lCustomerService;
import com.ruoyi.project.system.supplier.service.ISupplierService;
import com.ruoyi.project.system.supplier1.domain.Supplier;
import com.ruoyi.project.system.user.domain.User;
import com.ruoyi.project.system.user.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ruoyi.project.system.dict.domain.DictData;
import com.ruoyi.project.system.dict.service.IDictDataService;

/**
 * RuoYi首创 html调用 thymeleaf 实现字典读取
 * 
 * @author ruoyi
 */
@Service("dict")
public class DictService
{
    @Autowired
    private IDictDataService dictDataService;

    //供应商列表
    @Autowired
    private ISupplierService supplierService;

    //客户列表
    @Autowired
    private lCustomerService lCustomerService;

    //渠道列表
    @Autowired
    private IChannelService iChannelService;

    //业务员列表
    @Autowired
    private IUserService iUserService;

    /**
     * 根据字典类型查询字典数据信息
     * 
     * @param dictType 字典类型
     * @return 参数键值
     */
    public List<DictData> getType(String dictType)
    {
        return dictDataService.selectDictDataByType(dictType);
    }

    /**
     * 根据字典类型和字典键值查询字典数据信息
     * 
     * @param dictType 字典类型
     * @param dictValue 字典键值
     * @return 字典标签
     */
    public String getLabel(String dictType, String dictValue)
    {
        return dictDataService.selectDictLabel(dictType, dictValue);
    }
    /**
     * 查询保险公司供应商     *
     * @return 供应商列表
     */
    public List<Supplier> getSupplier()
    {
//        dictDataService.selectDictLabel(dictType, dictValue);
        return supplierService.selectSupplierAllOption();
    }

    /**
     * 查询客户列表，企业和个人客户     *
     * @return 客户列表
     */
    public List<Customer> getCustomer(String type)
    {
        return lCustomerService.selectCustomerAllOption(type);
    }

    /**
     * 查询渠道列表  *
     * @return 渠道列表
     */
    public List<Channel> getChannel()
    {
        return iChannelService.selectChannelAll();
    }

    /**
     * 查询业务员     *
     * @return 业务员列表
     */
    public List<User> getUser()
    {
        User user=new User();
        return iUserService.selectUserListPublic(user);
    }


}
