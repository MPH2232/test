function getSteps(list, code) {
    headerList_1 = list.slice(1);
    var crimsonList = "";
    if(code == 0){
        crimsonList += "<li id=\"step1Li\" class=\"gray\">";
    }else{
        crimsonList += "<li id=\"step1Li\" class=\"blue\">";
    }
    crimsonList += "<span>" + list[0] + "</span>";
    crimsonList += "</li>";
    $.each(headerList_1, function(index, item) {
        if(code < (index+1)){
            crimsonList += "<li id=\"step" + (index + 2) + "Li\"  class=\"gray\">"
            crimsonList += "<img id=\"step" + (index + 2) + "Img\" src=\"/tuanxian/img/stepsimg3.png\"/>"
        }else if(code == (index+1)){
            crimsonList += "<li id=\"step" + (index + 2) + "Li\"  class=\"gray\">"
            crimsonList += "<img id=\"step" + (index + 2) + "Img\" src=\"/tuanxian/img/stepsimg2.png\"/>"
        }else if(code > (index+1)){
            crimsonList += "<li id=\"step" + (index + 2) + "Li\"  class=\"blue\">"
            crimsonList += "<img id=\"step" + (index + 2) + "Img\" src=\"/tuanxian/img/stepsimg1.png\"/>"
        }
        crimsonList += "<span>" + item + "</span>";
        crimsonList += "</li>";
    })
    $('#myTab').html(crimsonList);
    $('#myTab li').css('width', ($('.row').width() / list.length) + 'px');
};

window.onresize = function(){
    $('#myTab li').css('width', ($('.row').width() / ($('#myTab img').length + 1)) + 'px');
}