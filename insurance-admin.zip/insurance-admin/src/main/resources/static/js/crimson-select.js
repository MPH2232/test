$(function() {
    // $('.fuckDiv').css('margin-right', ($('.fuckDiv').parent().width() - $('.fuckDiv').find("select").width() - $('.fuckDiv').parent().find('span').width() - 4) + 'px');
    $('.fuckInput').css('margin-left', '-' + ($('.fuckInput').parent().find(".select2-container").width() - 9) + 'px');
    $('.fuckInput').css('width', ($('.fuckInput').parent().find(".select2-container").width() - 29) + 'px');
});
//
window.onresize = function(){
    // $('.fuckDiv').css('margin-right', ($('.fuckDiv').parent().width() - $('.fuckDiv').find("select").width() - $('.fuckDiv').parent().find('span').width() - 4) + 'px');
    $('.fuckInput').css('margin-left', '-' + ($('.fuckInput').parent().find(".select2-container").width() - 9) + 'px');
    $('.fuckInput').css('width', ($('.fuckInput').parent().find(".select2-container").width() - 29) + 'px');
}

function getCrimsonSelectVal(selectId, inputId) {
    $("#" + selectId +" option").each(function(i){
        if(this.innerHTML == $("#" + inputId).val()){
            $("#" + inputId + "Display").val(this.value);
            return false;
        }else{
            $("#" + inputId + "Display").val($("#" + inputId).val());
        }
    });
}